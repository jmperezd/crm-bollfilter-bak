﻿using System;
using Xamarin.Forms;
using AppCRM.Views;
using Xamarin.Forms.Xaml;
using AppCRM_Shared;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace AppCRM
{
    public partial class App : Application
    {

        public static string ServerUrl
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SERVER_ServerUrl"))
                {
                    return Application.Current.Properties["SERVER_ServerUrl"] as string;
                }
                else
                {
                    return Constants.DEV_SERVER_URL;
                }
            }
            set
            {
                Application.Current.Properties["SERVER_ServerUrl"] = value;
            }
        }
        public static string InstancePath
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SERVER_InstancePath"))
                {
                    return Application.Current.Properties["SERVER_InstancePath"] as string;
                }
                else
                {
                    return Constants.DEV_INSTANCE_PATH;
                }
            }
            set
            {
                Application.Current.Properties["SERVER_InstancePath"] = value;
            }
        }
        public static string ServerUserName
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SERVER_UserName"))
                {
                    return Application.Current.Properties["SERVER_UserName"] as string;
                }
                else
                {
                    return Constants.DEV_USERNAME;
                }
            }
            set
            {
                Application.Current.Properties["SERVER_UserName"] = value;
            }
        }
        public static string ServerPassword 
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SERVER_Password"))
                {
                    return Application.Current.Properties["SERVER_Password"] as string;
                }
                else
                {
                    return Constants.DEV_PASSWORD;
                }
            }
            set
            {
                Application.Current.Properties["SERVER_Password"] = value;
            }
        }
        public static string ServerWebUser
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SERVER_WebUser"))
                {
                    return Application.Current.Properties["SERVER_WebUser"] as string;
                }
                else
                {
                    return Constants.DEV_WEBUSER;
                }
            }
            set
            {
                Application.Current.Properties["SERVER_WebUser"] = value;
            }
        }

        public static string LastVisitedPage
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("APP_LastVisitedPage"))
                {
                    return Application.Current.Properties["APP_LastVisitedPage"] as string;
                }
                else
                {
                    return "TASKS";
                }
            }
            set
            {
                Application.Current.Properties["APP_LastVisitedPage"] = value;
            }
        }

        public static string QuotationLayout
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("PRINT_QuotationLayout"))
                {
                    return Application.Current.Properties["PRINT_QuotationLayout"] as string;
                }
                else
                {
                    return "XMASTER";
                }
            }
            set
            {
                Application.Current.Properties["PRINT_QuotationLayout"] = value;
            }
        }


        public static string SaleOrderLayout
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("PRINT_SaleOrderLayout"))
                {
                    return Application.Current.Properties["PRINT_SaleOrderLayout"] as string;
                }
                else
                {
                    return "XMASTER";
                }
            }
            set
            {
                Application.Current.Properties["PRINT_SaleOrderLayout"] = value;
            }
        }

        public static string ItemSearch
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SEARCH_ItemSearch"))
                {
                    return Application.Current.Properties["SEARCH_ItemSearch"] as string;
                }
                else
                {
                    return "all";
                }
            }
            set
            {
                Application.Current.Properties["SEARCH_ItemSearch"] = value;
            }
        }






        public App()
        {
            InitializeComponent();

            // This lookup NOT required for Windows platforms - the Culture will be automatically set
            if (Device.RuntimePlatform == Device.iOS || Device.RuntimePlatform == Device.Android)
            {
                // determine the correct, supported .NET culture
                var ci = DependencyService.Get<ILocalize>().GetCurrentCultureInfo();
				AppCRM.Resx.AppResources.Culture = ci; // set the RESX for resource localization
                WFramework_Xamarin.Base.Init(ci);
                DependencyService.Get<ILocalize>().SetLocale(ci); // set the Thread for locale-aware methods
            }

            MainPage = new NavigationPage();
            ((NavigationPage)this.MainPage).BarTextColor = Color.White;
            ((NavigationPage)this.MainPage).PushAsync(new Login(((NavigationPage)this.MainPage).Navigation));
            /*
            foreach (string sName in UIFont.FamilyNames)
            {
                foreach (string sFontName in UIFont.FontNamesForFamilyName(sName))
                {
                    Debug.WriteLine(string.Format("FamilyName:{0} FontName:{1}", sName, sFontName));
                }
            }
            */
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
