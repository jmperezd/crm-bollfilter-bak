﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using Xamarin.Forms;

using AppCRM.Models;
using AppCRM.Services;
using AppCRM.Views;

namespace AppCRM.ViewModels
{
    public class ConfigurationViewModel : BaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }

        public INavigation _navigation;

        private string serverUrl = App.ServerUrl;
        public string ServerUrl
        {
            get { return this.serverUrl; }
            set
            {
                this.serverUrl = value;
            }
        }

        private string instancePath = App.InstancePath;
        public string InstancePath
        {
            get { return this.instancePath; }
            set
            {
                this.instancePath = value;
            }
        }

        private string serverUserName = App.ServerUserName;
        public string ServerUserName
        {
            get { return this.serverUserName; }
            set
            {
                this.serverUserName = value;
            }
        }

        private string serverPassword = App.ServerPassword;
        public string ServerPassword
        {
            get { return this.serverPassword; }
            set
            {
                this.serverPassword = value;
            }
        }

        private string serverWebUser = App.ServerWebUser;
        public string ServerWebUser
        {
            get { return this.serverWebUser; }
            set
            {
                this.serverWebUser = value;
            }
        }

        public ConfigurationViewModel(INavigation iNavigation)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this._navigation = iNavigation;
        }


        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                if (!string.IsNullOrWhiteSpace(this.serverUrl)
                    && !string.IsNullOrWhiteSpace(this.InstancePath))
                {
                    App.ServerUrl = this.ServerUrl;
                    App.InstancePath = this.InstancePath;
                    this._navigation.PushAsync(new Login(this._navigation), true);
                }
            });
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this._navigation.PushAsync(new Login(this._navigation), true);
            });
        }

    }
}

