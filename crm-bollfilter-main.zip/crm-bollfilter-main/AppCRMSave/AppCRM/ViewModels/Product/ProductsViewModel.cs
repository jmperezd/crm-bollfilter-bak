﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;

namespace AppCRM.ViewModels
{

    public class ProductsViewModel : BaseViewModel, ITableViewModel
    {
        //id,idno,descrOperLang,salesTradeUnit,purchTradeUnit,SU,purchPrice,searchExt
        private List<string> ListGridFields = new List<string> { "id", "descrOperLang", "purchPrice", "salesTradeUnit" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "descrOperLang", "purchPrice", "salesTradeUnit" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;
        public bool LazyLoading { get; set; } = true;

        public string IdClient { get; private set; } = null;

        public int NbElementsPerPage { get; set; }

        public ProductsViewModel(string idClient)
        {
            this.InitGridFields();
            this.IdClient = idClient;
            this.Page = "Articles";
            this.Prefix = string.Empty;
        }



        private void InitGridFields()
        {
            foreach (string stringGridField in this.ListGridFieldsComplete)
            {
                GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                this.GridFields.Add(gridField);
            }


            /*foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "descrOperLang")
                {
                    gridField.Order = GridField.SortOrder.Asc;
                }
            }*/

        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            if (!Context.Instance.IsConnected)
            {
                foreach (GridField gridField in this.GridFields)
                {
                    gridField.FieldName = gridField.FieldName.Replace("^", "_");
                }
            }

            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = "all", Operator = "~/", Value = globalSearchedString.ToLower() });
            }

            EntityTable entityTable = this.Service.ReadTableOffline<Models.Product>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;

            return entityTable;
        }
    }
}
