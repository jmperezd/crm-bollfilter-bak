﻿using System;
using Xamarin.Forms;
using AppCRM.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using System.Linq;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{
    public class AddUpdateSaleProductViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command DeleteCommand { get; set; }
        public Command CancelCommand { get; set; }
        public Command LoadTradeUnitObjectsCommand { get; set; }

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;

        public delegate void OnListObjectsLoadedDelegate();
        public event OnListObjectsLoadedDelegate OnProductObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnTradeUnitObjectsLoaded;

        public delegate void OnLoadCustomerDelegate(SaleProduct saleProduct);
        public event OnLoadCustomerDelegate OnLoadSaleProduct;

        public event EventHandler OnValidate;
        public event EventHandler OnDelete;
        public event EventHandler OnCancel;

        public string OriginQuantity { get; set; }
        public string OriginUnit { get; set; }

        private string titlePrefix;
        public string TitlePrefix
        {
            get { return this.titlePrefix; }
            set
            {
                SetProperty(ref titlePrefix, value);
            }
        }

        private string title;
        public string Title
        {
            get { return this.title; }
            set
            {
                SetProperty(ref title, value);
            }
        }

        private SaleProduct saleProduct;
        public SaleProduct SaleProduct
        {
            get
            {
                return saleProduct;
            }
            set
            {
                SetProperty(ref saleProduct, value);
            }
        }

        private Product Product { get; set; }

        private ObservableCollection<IItemList> tradeUnits;
        public ObservableCollection<IItemList> TradeUnits
        {
            get { return this.tradeUnits; }
            set { SetProperty(ref tradeUnits, value); }
        }

        private SimpleObject selectedTradeUnitObject = null;
        public SimpleObject SelectedTradeUnitObject
        {
            get
            {
                return this.selectedTradeUnitObject;
            }
            set
            {
                if (this.SaleProduct != null)
                {
                    this.SaleProduct.tradeUnit = value.Id;
                }
                SetProperty(ref selectedTradeUnitObject, value);
            }
        }

        public AddUpdateSaleProductViewModel(string idProduct = null, SaleProduct saleProduct = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.DeleteCommand = new Command(async () => await ExecuteDeleteCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.LoadTradeUnitObjectsCommand = new Command(async () => await ExecuteLoadTradeUnitObjects());


            if (saleProduct == null)
            {
                var task = System.Threading.Tasks.Task.Run(async () => { this.Product = await this.Service.ReadOffline<Product>(idProduct); });
                task.Wait();
                this.SaleProduct = new SaleProduct() { product = idProduct, product_descrOperLang = this.Product.descrOperLang, productDescr = this.Product.descrOperLang, unitQty = "1" };
                this.TitlePrefix = AppResources.Ajouter_l_article;
            }
            else
            {
                try
                {
                    this.OriginUnit = saleProduct.tradeUnit;
                    this.OriginQuantity = saleProduct.unitQty;

                    this.saleProduct = saleProduct;
                    //var task1 = System.Threading.Tasks.Task.Run(async () => { this.SaleProduct = await this.Service.Read<SaleProduct>(saleProduct.id); });
                    //task1.Wait();
                    //this.SaleProduct = saleProduct;
                    var task2 = System.Threading.Tasks.Task.Run(async () => { this.Product = await this.Service.ReadOffline<Product>(SaleProduct.product); });
                    task2.Wait();

                    this.TitlePrefix = AppResources.Modifier_l_article;
                }
                catch(Exception e)
                {

                }
            }

            //this.SaleProduct.rowNo = rowNo;

            this.Title = this.SaleProduct.product_descrOperLang;
             

            //this.Init();
        }


        public void Init()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                this.LoadTradeUnitObjectsCommand.Execute(null);
            });
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            int i;
            if (int.TryParse(this.SaleProduct.unitQty, out i) && i > 0)
            {
                if (this.OnBusy != null)
                {
                    this.OnBusy(true);
                }
                await System.Threading.Tasks.Task.Run(() =>
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this.SaleProduct, null);
                        }
                    });
                });
            }
        }

        async System.Threading.Tasks.Task ExecuteDeleteCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            await System.Threading.Tasks.Task.Run(() =>
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (this.OnDelete != null)
                    {
                        this.OnDelete(this.SaleProduct, null);
                    }
                });
            });
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            saleProduct.tradeUnit = this.OriginUnit;
            saleProduct.unitQty = this.OriginQuantity;

            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadTradeUnitObjects()
        {
            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            List<FilterField> filterFields = new List<FilterField>();
            FilterField filterField = new FilterField() { FieldName = "unitIdentifier", Operator = "==", Value = this.Product.salesTradeUnit.Replace("(", "").Replace(")", "") };
            filterFields.Add(filterField);

            var unit1 = Service.ReadList<Unit>(null, filterFields).Result;
            if (unit1.FirstOrDefault() != null)
            {
                obsList.Add(new SimpleObject(unit1.FirstOrDefault().descrOperLang, this.Product.salesTradeUnit));
            }

            if(obsList.Count(x => x.Id == this.Product.purchPriceUnit) == 0 && !string.IsNullOrWhiteSpace(this.Product.purchPriceUnit))
            {
                filterField.Value = this.Product.purchPriceUnit.Replace("(", "").Replace(")", "");
                var unit2 = Service.ReadList<Unit>(null, filterFields).Result;
                if (unit2.FirstOrDefault() != null)
                {
                    obsList.Add(new SimpleObject(unit2.FirstOrDefault().descrOperLang, this.Product.purchPriceUnit));
                }
            }
            if (obsList.Count(x => x.Id == this.Product.SU) == 0 && !string.IsNullOrWhiteSpace(this.Product.SU))
            {
                filterField.Value = this.Product.SU.Replace("(", "").Replace(")", "");
                var unit3 = Service.ReadList<Unit>(null, filterFields).Result;
                if (unit3.FirstOrDefault() != null)
                {
                    obsList.Add(new SimpleObject(unit3.FirstOrDefault().descrOperLang, this.Product.SU));
                }
            }

            this.TradeUnits = obsList;

            if (this.OnTradeUnitObjectsLoaded != null)
            {
                this.OnTradeUnitObjectsLoaded();
            }

            foreach (SimpleObject obj in this.TradeUnits)
            {
                if (obj.Id == this.SaleProduct.tradeUnit)
                {
                    this.SelectedTradeUnitObject = obj;
                    break;
                }
            }
            if(this.SelectedTradeUnitObject == null && this.TradeUnits != null && this.TradeUnits.Count > 0)
            {
                this.SelectedTradeUnitObject = this.TradeUnits.First() as SimpleObject;
            }




        }


    }
}