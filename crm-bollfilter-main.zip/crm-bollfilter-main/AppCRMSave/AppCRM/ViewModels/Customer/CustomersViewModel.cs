﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;
using WFramework_Xamarin;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class CustomersViewModel : BaseViewModel, ITableViewModel
    {
        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public string IdClient { get; private set; }
        public CustomersPageDisplayTypes CustomersPageDisplayTypes { get; private set; } = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;
        public Command DisplayMap { get; set; }
        public event EventHandler OnDisplayMap;

        public bool ShowNewObjectButton 
        {
            get{
                switch(LastShowedCustomerTab)
                {
                    case CustomerTypes.PROSPECT:
                    case CustomerTypes.CONTACT_PROSPECT:
                    case CustomerTypes.CONTACT_CUSTOMER:
                        return true;
                        break;
                    case CustomerTypes.ALL:
                    case CustomerTypes.CUSTOMER:
                    default:
                        return false;
                        break;
                }
            }
        }

        private CustomerTypes lastShowedCustomerTab = CustomerTypes.ALL;
        public CustomerTypes LastShowedCustomerTab
        {
            get
            {
                return this.lastShowedCustomerTab;
            }
            set
            {
                SetProperty(ref lastShowedCustomerTab, value);

            }
        }
        /*
        public CustomerTypes LastShowedCustomerTab
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("APP_LastShowedCustomerTab"))
                {
                    return (CustomerTypes)Enum.Parse(typeof(CustomerTypes), Application.Current.Properties["APP_LastShowedCustomerTab"] as string);
                }
                else
                {
                    return CustomerTypes.ALL;
                }
            }
            set
            {
                Application.Current.Properties["APP_LastShowedCustomerTab"] = value.ToString();

            }
        }
        */

        public CustomersViewModel(string idClient = null, CustomersPageDisplayTypes customersPageDisplayTypes = CustomersPageDisplayTypes.CUSTOMER_PROSPECT)
        {
            //this.Service.PrintImpression<Quotation>("(2574,3,0)");

            this.IdClient = idClient;
            this.CustomersPageDisplayTypes = customersPageDisplayTypes;

            switch (this.CustomersPageDisplayTypes)
            {
                case CustomersPageDisplayTypes.ALL:
                    this.Page = AppResources.Clients_prospects_et_contacts;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT:
                    this.Page = AppResources.Clients_et_contacts;
                    break;
                case CustomersPageDisplayTypes.PROSPECT_AND_CONTACT:
                    this.Page = AppResources.Prospects_et_contacts;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER:
                    this.Page = AppResources.Clients;
                    break;
                case CustomersPageDisplayTypes.PROSPECT:
                    this.Page = AppResources.Prospects;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    this.Page = AppResources.Clients_et_prospects;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                    this.Page = AppResources.Contacts;
                    break;
            }
            this.Prefix = string.Empty;

            this.DisplayMap = new Command(ExecuteDisplayMapCommand);
            this.NewObject = new Command(ExecuteNewObjectCommand);

            this.InitGridFields();
        }

        public void Init()
        {
            this.OnPropertyChanged("ShowNewObjectButton");
        }

        private void ExecuteDisplayMapCommand()
        {
            if (this.OnDisplayMap != null)
            {
                this.OnDisplayMap(this, null);
            }
        }

        private List<string> ListGridFields = new List<string> { "id", "idno", "swd", "grpNo", "descrOperLang" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "idno", "swd", "grpNo", "descrOperLang" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;

        public bool LazyLoading { get; set; } = true;

        public int NbElementsPerPage { get; set; }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }


            foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "idno")
                {
                    gridField.Order = GridField.SortOrder.Asc;
                }
                if (gridField.FieldName == "descrOperLang")
                {
                    gridField.DisplayedName = AppResources.Designation;
                }
            }
        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = App.ItemSearch, Operator = "~/", Value = globalSearchedString.ToLower() });
            }

            if (string.IsNullOrWhiteSpace(this.IdClient))
            {
                filterFields.Add(new FilterField() { FieldName = "rep", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleSalesRep });
            }
            else
            {
                filterFields.Add(new FilterField() { FieldName = "companyARAP", Operator = "==", Value = this.IdClient });
            }
            /*
            if (this.CustomersPageDisplayTypes == CustomersPageDisplayTypes.CUSTOMER)
            {
                filterFields.Add(new FilterField() { FieldName = "grpNo", Operator = "==", Value = "1" });
            }
            else if (this.CustomersPageDisplayTypes == CustomersPageDisplayTypes.PROSPECT)
            {
                filterFields.Add(new FilterField() { FieldName = "grpNo", Operator = "==", Value = "6" });
            }
            */

            EntityTable entityTable = null;
            try
            {
                switch (this.LastShowedCustomerTab)
                {
                    case CustomerTypes.ALL:
                        switch (this.CustomersPageDisplayTypes)
                        {
                            case CustomersPageDisplayTypes.ALL:
                                entityTable = this.Service.ReadTableOffline<Tiers>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                                entityTable = this.Service.ReadTableOffline<CustomerProspect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.CUSTOMER:
                                entityTable = this.Service.ReadTableOffline<Customer>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.PROSPECT:
                                entityTable = this.Service.ReadTableOffline<Prospect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT:
                                entityTable = this.Service.ReadTableOffline<CustomerAndContact>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.PROSPECT_AND_CONTACT:
                                entityTable = this.Service.ReadTableOffline<ProspectAndContact>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                                entityTable = this.Service.ReadTableOffline<ContactCustomer>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                            case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                                entityTable = this.Service.ReadTableOffline<ContactProspect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                                break;
                        }
                        break;
                    case CustomerTypes.CUSTOMER:
                        entityTable = this.Service.ReadTableOffline<Customer>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                        break;
                    case CustomerTypes.PROSPECT:
                        entityTable = this.Service.ReadTableOffline<Prospect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                        break;
                    case CustomerTypes.CONTACT_CUSTOMER:
                        entityTable = this.Service.ReadTableOffline<ContactCustomer>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        entityTable = this.Service.ReadTableOffline<ContactProspect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
                        break;
                }
                //entityTable = this.Service.ReadTableOffline<CustomerProspect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return entityTable;
        }

        public String GetTiersType(TableTools tools, String id)
        {
            for (int i = 0; i <= tools.CurrentPage; i++)
            {
                var res = tools.DicoTables[i].Rows.Find(r => r.Cells["id"].Value == id);
                if (res != null)
                {
                    return res.Cells["grpNo"].Value;
                }
            }
            return null;
        }

        private void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }
    }
}
