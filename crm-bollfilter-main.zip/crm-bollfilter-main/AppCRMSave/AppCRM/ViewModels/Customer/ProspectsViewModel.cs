﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;

namespace AppCRM.ViewModels
{
    
    public class ProspectsViewModel : BaseViewModel, ITableViewModel
    {
        public string IdClient { get; private set; }

        private List<string> ListGridFields = new List<string> { "id", "idno", "swd", "descrOperLang" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "idno", "swd", "descrOperLang" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;
        public bool LazyLoading { get; set; } = false;

        public int NbElementsPerPage { get; set; }

        public ProspectsViewModel(string idClient = null)
        {
            this.IdClient = idClient;
            this.InitGridFields();
        }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = "swd", Operator = "~/", Value = globalSearchedString });
            }

            if (string.IsNullOrWhiteSpace(this.IdClient))
            {
                filterFields.Add(new FilterField() { FieldName = "rep", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleSalesRep });
            }
            else
            {

            }

            EntityTable entityTable = null;
            try
            {
                entityTable = this.Service.ReadTable<Prospect>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;

            }catch(Exception e)
            {
                
            }
            return entityTable;
        }
    }
}
