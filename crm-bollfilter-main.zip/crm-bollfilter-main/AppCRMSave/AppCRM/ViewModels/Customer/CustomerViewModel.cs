﻿using System.Threading.Tasks;
using AppCRM.Models;
using Xamarin.Forms;
using System;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class CustomerViewModel : BaseViewModel, IRefreshable
    {
        public string CustomerId { get; private set; }

        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command NewObjectCommand { get; set; }
        public event EventHandler OnNewObject;

        public Command ShowTurnoverCommand { get; set; }
        public event EventHandler OnShowTurnover;

        public Command ShowContactsCommand { get; set; }
        public event EventHandler OnShowContacts;

        private AppCRM.Models.Customer customer;
        public AppCRM.Models.Customer Customer
        {
            get { return customer; }
            set
            {
                SetProperty(ref customer, value);
                this.OnPropertyChanged("DisplayAddress");
                this.OnPropertyChanged("DisplayAddress2");
            }
        }

        private ActivityObject activity;
        public ActivityObject Activity
        {
            get { return activity; }
            set
            {
                SetProperty(ref activity, value);
            }
        }

        string repName = String.Empty;
        public string RepName
        {
            get { return repName; }
            private set { SetProperty(ref repName, value); }
        }

        string inhouseContactName = String.Empty;
        public string InhouseContactName
        {
            get { return inhouseContactName; }
            private set { SetProperty(ref inhouseContactName, value); }
        }

        public bool DisplayAddress
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Customer.addr);
            }
        }

        public bool DisplayAddress2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Customer.addr2);
            }
        }

        public bool DisplayCharacteristic2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic2);
            }
        }
        public bool DisplayCharacteristic3
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic3);
            }
        }
        public bool DisplayCharacteristic4
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic4);
            }
        }
        public bool DisplayCharacteristic5
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic5);
            }
        }
        public bool DisplayCharacteristic6
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic6);
            }
        }

        public CustomerViewModel(string id)
        {
            this.CustomerId = id;

            this.Refresh();
        }

        public void Refresh()
        {
            this.Customer = this.Service.ReadOffline<Models.Customer>(this.CustomerId).Result;
            this.Prefix = AppResources.Client;
            this.Page = this.Customer.descrOperLang;
            this.ShowTurnoverCommand = new Command(async () => await ExecuteShowTurnoverCommand());
            this.ShowContactsCommand = new Command(async () => await ExecuteShowContactsCommand());
            this.NewObjectCommand = new Command(async () => await ExecuteNewObjectCommand());
            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.Activity = await this.Service.GetActivity(this.CustomerId);
            });

            System.Threading.Tasks.Task.Run(async () =>
            {
                Employee employee = await this.Service.Read<Employee>(this.Customer.inhouseContact);
                this.InhouseContactName = employee.Descr;
            });

            System.Threading.Tasks.Task.Run(async () =>
            {
                Tiers tiers = await this.Service.ReadOffline<Tiers>(this.Customer.rep);
                this.RepName = tiers.descrOperLang;
            });
        }

        async System.Threading.Tasks.Task ExecuteShowTurnoverCommand()
        {
            if (IsBusy)
                return;
            if (this.OnShowTurnover != null)
            {
                this.OnShowTurnover(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteShowContactsCommand()
        {
            if (IsBusy)
                return;
            if (this.OnShowContacts != null)
            {
                this.OnShowContacts(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }
    }
}
