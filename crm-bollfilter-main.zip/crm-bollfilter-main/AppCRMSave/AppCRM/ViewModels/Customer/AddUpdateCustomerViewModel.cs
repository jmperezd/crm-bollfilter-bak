﻿using System;
using Xamarin.Forms;
using AppCRM.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using AppCRM.Resx;
using System.Linq;


namespace AppCRM.ViewModels
{
    public class AddUpdateCustomerViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }
        //public Command LoadContactObjectsCommand { get; set; }

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;


        public delegate void OnListObjectsLoadedDelegate();
        //public event OnListObjectsLoadedDelegate OnProductObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnContactObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnEmployeeObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnCharacteristicObjectsLoaded;


        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCompany;

        /*
        public delegate void OnLoadEmployeeDelegate(Employee tiers);
        public event OnLoadEmployeeDelegate OnLoadInhouseContact;
        */

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        public CustomerTypes CustomersType { get; private set; }

        private Tiers tiers;
        public Tiers Tiers
        {
            get
            {
                return tiers;
            }
            set
            {
                SetProperty(ref tiers, value);
            }
        }

        private ObservableCollection<IItemList> employeeObjects;
        public ObservableCollection<IItemList> EmployeeObjects
        {
            get { return this.employeeObjects; }
            set { SetProperty(ref employeeObjects, value); }
        }

        private EmployeeObject selectedEmployeeObject;
        public EmployeeObject SelectedEmployeeObject
        {
            get
            {
                return this.selectedEmployeeObject;
            }
            set
            {
                this.Tiers.rep = value.Id;
                SetProperty(ref selectedEmployeeObject, value);
            }
        }

        private EmployeeObject selectedInhouseContactObject;
        public EmployeeObject SelectedInhouseContactObject
        {
            get
            {
                return this.selectedInhouseContactObject;
            }
            set
            {
                this.Tiers.inhouseContact = value.Id;
                SetProperty(ref selectedInhouseContactObject, value);
            }
        }

        private ObservableCollection<IItemList> characteristic1Objects;
        public ObservableCollection<IItemList> Characteristic1Objects
        {
            get { return this.characteristic1Objects; }
            set { SetProperty(ref characteristic1Objects, value); }
        }
        private SimpleObject selectedCharacteristic1Object;
        public SimpleObject SelectedCharacteristic1Object
        {
            get
            {
                return this.selectedCharacteristic1Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic1Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic2Objects;
        public ObservableCollection<IItemList> Characteristic2Objects
        {
            get { return this.characteristic2Objects; }
            set { SetProperty(ref characteristic2Objects, value); }
        }
        private SimpleObject selectedCharacteristic2Object;
        public SimpleObject SelectedCharacteristic2Object
        {
            get
            {
                return this.selectedCharacteristic2Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic2Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic3Objects;
        public ObservableCollection<IItemList> Characteristic3Objects
        {
            get { return this.characteristic3Objects; }
            set { SetProperty(ref characteristic3Objects, value); }
        }
        private SimpleObject selectedCharacteristic3Object;
        public SimpleObject SelectedCharacteristic3Object
        {
            get
            {
                return this.selectedCharacteristic3Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic3Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic4Objects;
        public ObservableCollection<IItemList> Characteristic4Objects
        {
            get { return this.characteristic4Objects; }
            set { SetProperty(ref characteristic4Objects, value); }
        }
        private SimpleObject selectedCharacteristic4Object;
        public SimpleObject SelectedCharacteristic4Object
        {
            get
            {
                return this.selectedCharacteristic4Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic4Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic5Objects;
        public ObservableCollection<IItemList> Characteristic5Objects
        {
            get { return this.characteristic5Objects; }
            set { SetProperty(ref characteristic5Objects, value); }
        }
        private SimpleObject selectedCharacteristic5Object;
        public SimpleObject SelectedCharacteristic5Object
        {
            get
            {
                return this.selectedCharacteristic5Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic5Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic6Objects;
        public ObservableCollection<IItemList> Characteristic6Objects
        {
            get { return this.characteristic6Objects; }
            set { SetProperty(ref characteristic6Objects, value); }
        }
        private SimpleObject selectedCharacteristic6Object;
        public SimpleObject SelectedCharacteristic6Object
        {
            get
            {
                return this.selectedCharacteristic6Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic6Object, value);
            }
        }


        public bool DisplayCharacteristic2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Tiers.characteristic2);
            }
        }
        public bool DisplayCharacteristic3
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Tiers.characteristic3);
            }
        }
        public bool DisplayCharacteristic4
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Tiers.characteristic4);
            }
        }
        public bool DisplayCharacteristic5
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Tiers.characteristic5);
            }
        }
        public bool DisplayCharacteristic6
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Tiers.characteristic6);
            }
        }

        public string ClientOrProspect
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        return AppResources.Client;
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        return AppResources.Prospect;
                        break;
                    default:
                        return string.Empty;
                        break;
                }
            }
        }

        public bool ShowContactSelection
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                    case CustomerTypes.PROSPECT:
                        return true;
                        break;
                    default:
                        return false;

                }
            }
        }
        public bool ShowCompanySelection
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                    case CustomerTypes.CONTACT_PROSPECT:
                        return true;
                        break;
                    default:
                        return false;

                }
            }
        }

        public bool DisplayAddress
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                    case CustomerTypes.CONTACT_PROSPECT:
                        return true;
                        break;
                    default:
                        return false;

                }
            }
        }
        public bool ShowAddress
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.PROSPECT:
                        return false;
                        break;
                    default:
                        return true;

                }
            }
        }
        /*
        private ObservableCollection<IItemList> typeObjects;
        public ObservableCollection<IItemList> TypeObjects
        {
            get { return this.typeObjects; }
            set { SetProperty(ref typeObjects, value); }
        }

        private ObservableCollection<IItemList> productObjects = new ObservableCollection<IItemList>();
        public ObservableCollection<IItemList> ProductObjects
        {
            get { return this.productObjects; }
            set { SetProperty(ref productObjects, value); }
        }

        private TypeObject selectedTypeObject;
        public TypeObject SelectedTypeObject
        {
            get
            {
                return this.selectedTypeObject;
            }
            set
            {
                this.Tiers.type = value.Id;
                SetProperty(ref selectedTypeObject, value);
            }
        }

        private ProductObject selectedProductObject;
        public ProductObject SelectedProductObject
        {
            get
            {
                return this.selectedProductObject;
            }
            set
            {
                this.Tiers.productListElem = value.Id;
                SetProperty(ref selectedProductObject, value);
            }
        }


        private string editorName = String.Empty;
        public string EditorName
        {
            get { return editorName; }
            private set { SetProperty(ref editorName, value); }
        }
        */


        public AddUpdateCustomerViewModel(CustomerTypes customerType, string idObj, Tiers obj = null, string idTiers = null)
        {
            this.CustomersType = customerType;
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());

            //this.LoadContactObjectsCommand = new Command(async () => await ExecuteLoadContactObjects());

            if (obj == null)
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                        this.Page = AppResources.Client.ToLower();
                        this.Tiers = new Customer() { rep = Context.Instance.CurrentWebUser.RoleSalesRep };
                        break;
                    case CustomerTypes.PROSPECT:
                        this.Page = AppResources.Prospect.ToLower();
                        this.Tiers = new Prospect() { rep = Context.Instance.CurrentWebUser.RoleSalesRep };
                        break;
                    case CustomerTypes.CONTACT_CUSTOMER:
                        this.Page = AppResources.Contact.ToLower();
                        this.Tiers = new ContactCustomer() { companyARAP = idTiers };
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        this.Page = AppResources.Contact.ToLower();
                        this.Tiers = new ContactProspect() { companyARAP = idTiers };
                        break;
                }

                this.Prefix = AppResources.Creer_un;
            }
            else
            {
                //this.tiers = this.Service.ReadOffline<Tiers>(obj.id).Result;
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                        this.tiers = this.Service.ReadOffline<Customer>(obj.id).Result;
                        this.Page = AppResources.Client.ToLower();
                        break;
                    case CustomerTypes.PROSPECT:
                        this.tiers = this.Service.ReadOffline<Prospect>(obj.id).Result;
                        this.Page = AppResources.Prospect.ToLower();
                        break;
                    case CustomerTypes.CONTACT_CUSTOMER:
                        this.tiers = this.Service.ReadOffline<ContactCustomer>(obj.id).Result;
                        this.Page = AppResources.Contact.ToLower();
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        this.tiers = this.Service.ReadOffline<ContactProspect>(obj.id).Result;
                        this.Page = AppResources.Contact.ToLower();
                        break;
                }

                this.Prefix = AppResources.Modifier_un;
            }

            /*
            System.Threading.Tasks.Task.Run(async () =>
            {
                this.EditorName = (await this.Service.Read<Models.Employee>(this.Tiers.editor)).Descr;
            });
            */


        }

        public void Init()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                //this.ExecuteLoadProductsObjects(string.Empty);
                //this.LoadTypeObjectsCommand.Execute(null);
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        this.ExecuteLoadCompany((this.Tiers as ContactCustomer).companyARAP);
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        this.ExecuteLoadCompany((this.Tiers as ContactProspect).companyARAP);
                        break;
                    case CustomerTypes.CUSTOMER:
                        this.ExecuteLoadEmployeesObjects();
                        break;
                    case CustomerTypes.PROSPECT:
                        this.ExecuteLoadEmployeesObjects();
                        break;
                }
                this.ExecuteLoadCharacteristicObjects();
                //this.ExecuteLoadInhouseContact(this.Tiers.inhouseContact);
            });
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        this.Tiers.swd = this.Tiers.descrOperLang.Replace(" ", "_").Replace(".", "_").Replace(",", "_").Replace("-", "_");
                        if (!string.IsNullOrWhiteSpace(this.Tiers.id))
                        {
                            System.Threading.Tasks.Task task = null;
                            switch (this.CustomersType)
                            {
                                case CustomerTypes.CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Customer>(this.Tiers as Customer); });
                                    break;
                                case CustomerTypes.PROSPECT:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Prospect>(this.Tiers as Prospect); });
                                    break;
                                case CustomerTypes.CONTACT_CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<ContactCustomer>(this.Tiers as ContactCustomer); });
                                    break;
                                case CustomerTypes.CONTACT_PROSPECT:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<ContactProspect>(this.Tiers as ContactProspect); });
                                    break;
                            }
                            task.Wait();
                        }
                        else
                        {
                            /*
                            if (string.IsNullOrWhiteSpace(this.Tiers.swd))
                            {
                                this.Tiers.swd = this.Tiers.descrOperLang.Replace(" ", "_").Replace(".", "_").Replace(",", "_").Replace("-", "_");
                            }
                            */
                            System.Threading.Tasks.Task task = null;
                            switch (this.CustomersType)
                            {
                                case CustomerTypes.CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<Customer>(this.Tiers as Customer, true); });
                                    break;
                                case CustomerTypes.PROSPECT:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<Prospect>(this.Tiers as Prospect, true); });
                                    break;
                                case CustomerTypes.CONTACT_CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<ContactCustomer>(this.Tiers as ContactCustomer, true); });
                                    break;
                                case CustomerTypes.CONTACT_PROSPECT:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<ContactProspect>(this.Tiers as ContactProspect, true); });
                                    break;
                            }
                            task.Wait();
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }


        bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Tiers.descrOperLang);
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadEmployeesObjects()
        {
            List<Employee> employees = this.Service.ReadList<Employee>().Result;

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (Employee employee in employees)
            {
                obsList.Add(new EmployeeObject(employee.Descr, employee.id));
            }
            this.EmployeeObjects = obsList;

            foreach (EmployeeObject obj in this.EmployeeObjects)
            {
                /*string repId = string.Empty;
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                        repId = (this.Tiers as Customer).rep;
                        break;
                    case CustomerTypes.PROSPECT:
                        repId = (this.Tiers as Prospect).rep;
                        break;
                }*/
                if (obj.Id == this.Tiers.rep)
                {
                    this.SelectedEmployeeObject = obj;
                }
                if (obj.Id == this.Tiers.inhouseContact)
                {
                    this.SelectedInhouseContactObject = obj;
                }
            }

            if (this.OnEmployeeObjectsLoaded != null)
            {
                this.OnEmployeeObjectsLoaded();
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadCompany(string id)
        {
            Tiers tiers = await this.Service.ReadOffline<Tiers>(id);
            if (this.OnLoadCompany != null)
            {
                this.OnLoadCompany(tiers);
            }
        }

        /*
        async System.Threading.Tasks.Task ExecuteLoadInhouseContact(string id)
        {
            Employee employee = await this.Service.Read<Employee>(id);
            if (this.OnLoadInhouseContact != null)
            {
                this.OnLoadInhouseContact(employee);
            }
        }
        */

        /*
        async System.Threading.Tasks.Task ExecuteLoadContactObjects()
        {
            List<Tiers> tiers;

            switch(this.CustomersType)
            {
                case CustomerTypes.CUSTOMER:
                    tiers = await this.Service.ReadList<ContactCustomer>());
                    break;
                case CustomerTypes.PROSPECT:
                    break;
            }

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (AppCRM.Models.Type type in types)
            {
                obsList.Add(new TypeObject(type.enumDescr, type.enumIdentifierComplete));
            }
            this.TypeObjects = obsList;
            
            if (this.OnTypeObjectsLoaded != null)
            {
                this.OnTypeObjectsLoaded();
            }

            foreach (TypeObject obj in this.TypeObjects)
            {
                if (obj.Id == this.Tiers.type)
                {
                    this.SelectedTypeObject = obj;
                    break;
                }
            }

        }
        */
        /*
        public void LoadProductsObjects(string search)
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                this.ExecuteLoadProductsObjects(search);
            });
        }

        async System.Threading.Tasks.Task ExecuteLoadProductsObjects(string search, int page = 0)
        {
            try
            {
                int limit = 100;

                List<FilterField> filterFields = new List<FilterField>();
                if (!string.IsNullOrWhiteSpace(search))
                {
                    filterFields.Add(new FilterField() { FieldName = "descrOperLang", Operator = "~/", Value = search });
                }
                List<Product> products = await this.Service.ReadList<Product>(null, filterFields, page, limit);

                //ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();
                this.ProductObjects.Clear();

                foreach (Product product in products)
                {
                    //obsList.Add(new ProductObject(product.descrOperLang, product.id));
                    ProductObject productObject = new ProductObject(product.descrOperLang, product.id);
                    this.ProductObjects.Add(productObject);
                    if (productObject.Id == this.Tiers.productListElem)
                    {
                        this.SelectedProductObject = productObject;
                    }
                }
                //this.ProductObjects = obsList;
                //this.ProductObjects.Add()

                if (this.OnProductObjectsLoaded != null)
                {
                    this.OnProductObjectsLoaded();
                }

                if (products.Count == limit)
                {
                    //this.ExecuteLoadProductsObjects(search, page + 1);
                }
            }
            catch(Exception e)
            {
                
            }
        }
        */

        async System.Threading.Tasks.Task ExecuteLoadCharacteristicObjects()
        {
            //Dictionary<string, string> priorities = this.Service.GetPriosAsync().Result;

            List<Characteristic1> characteristics = await this.Service.GetEnumAsync<Characteristic1>();
            this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics), ref this.characteristic1Objects, ref this.selectedCharacteristic1Object, this.Tiers.characteristic1);
            if (!string.IsNullOrWhiteSpace(this.Tiers.characteristic2))
            {
                List<Characteristic2> characteristics2 = await this.Service.GetEnumAsync<Characteristic2>();
                this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics2), ref this.characteristic2Objects, ref this.selectedCharacteristic2Object, this.Tiers.characteristic2);
            }
            if (!string.IsNullOrWhiteSpace(this.Tiers.characteristic3))
            {
                List<Characteristic3> characteristics3 = await this.Service.GetEnumAsync<Characteristic3>();
                this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics3), ref this.characteristic3Objects, ref this.selectedCharacteristic3Object, this.Tiers.characteristic3);
            }
            if (!string.IsNullOrWhiteSpace(this.Tiers.characteristic4))
            {
                List<Characteristic4> characteristics4 = await this.Service.GetEnumAsync<Characteristic4>();
                this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics4), ref this.characteristic4Objects, ref this.selectedCharacteristic4Object, this.Tiers.characteristic4);
            }
            if (!string.IsNullOrWhiteSpace(this.Tiers.characteristic5))
            {
                List<Characteristic5> characteristics5 = await this.Service.GetEnumAsync<Characteristic5>();
                this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics5), ref this.characteristic5Objects, ref this.selectedCharacteristic5Object, this.Tiers.characteristic5);
            }
            if (!string.IsNullOrWhiteSpace(this.Tiers.characteristic6))
            {
                List<Characteristic6> characteristics6 = await this.Service.GetEnumAsync<Characteristic6>();
                this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics6), ref this.characteristic6Objects, ref this.selectedCharacteristic6Object, this.Tiers.characteristic6);
            }





            if (this.OnCharacteristicObjectsLoaded != null)
            {
                this.OnCharacteristicObjectsLoaded();
            }
        }

        private void FillCaracteristic(ObservableCollection<EnumReference> characteristics, ref ObservableCollection<IItemList> localList, ref SimpleObject selectedObject, string value )
        {
            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();
            foreach (EnumReference enumeReference in characteristics)
            {
                obsList.Add(new SimpleObject(enumeReference.enumDescr, enumeReference.enumIdentifierComplete));
            }
            localList = obsList;

            foreach (SimpleObject obj in localList)
            {
                if (obj.Id == value)
                {
                    selectedObject = obj;
                    break;
                }
            }
        }
    }
}