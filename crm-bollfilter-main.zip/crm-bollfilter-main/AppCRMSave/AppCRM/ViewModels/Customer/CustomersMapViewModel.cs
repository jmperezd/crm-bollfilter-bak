﻿using System.Threading.Tasks;
using AppCRM.Models;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using System.Linq;
using Xamarin.Forms;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class CustomersMapViewModel : BaseViewModel
    {
        private CustomersPageDisplayTypes CustomersPageDisplayTypes { get; set; } = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;
        public string IdClient { get; private set; }

        private string globalSearchedString;
        public string GlobalSearchedString
        {
            get
            {
                return this.globalSearchedString;
            }
            set
            {
                this.globalSearchedString = value;
                this.OnPropertyChanged("GlobalSearchedString");
            }
        }

        public Command ReinitGlobalSearchCommand { get; set; }

        private List<Customer> customers;
        public List<Customer> Customers
        {
            get { return customers; }
            set
            {
                SetProperty(ref customers, value);
            }
        }

        private const int RANGE = 50;

        public event OnCustomersLoadedDelegate OnCustomersLoaded;
        public delegate void OnCustomersLoadedDelegate(List<Tiers> customers);


        public CustomersMapViewModel(string idClient = null, CustomersPageDisplayTypes customersPageDisplayTypes = CustomersPageDisplayTypes.CUSTOMER_PROSPECT, string defaultGlobalSearch = "")
        {
            this.CustomersPageDisplayTypes = customersPageDisplayTypes;
            this.IdClient = idClient;
            this.GlobalSearchedString = defaultGlobalSearch;

            this.ReinitGlobalSearchCommand = new Command(async () => await ReinitGlobalSearchCommandExecute());

            //this.Customer = this.Service.GetCustomerAsync(id).Result; 
            this.Prefix = "";
            this.Page = AppResources.Carte;

            //this.Customers = new List<Customer>(this.Service.ReadList<Customer>().Result);

        }

        public void Init()
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                this.GetCustomers(0);
            });
        }

        private void GetCustomers(int requestedPage)
        {
            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(this.GlobalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = App.ItemSearch, Operator = "~/", Value = this.GlobalSearchedString });
            }

            if (string.IsNullOrWhiteSpace(this.IdClient))
            {
                //filterFields.Add(new FilterField() { FieldName = "rep", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleEmployee });
            }

            List<Tiers> tiers = null;
            //switch (CustomersViewModel.LastShowedCustomerTab)
            //{
            //case CustomerTypes.ALL:
            switch (this.CustomersPageDisplayTypes)
            {
                case CustomersPageDisplayTypes.ALL:
                    tiers = this.Service.ReadListOffline<Tiers>(null, filterFields, requestedPage, RANGE).Result;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    tiers = this.Service.ReadListOffline<CustomerProspect>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomersPageDisplayTypes.CUSTOMER:
                    tiers = this.Service.ReadListOffline<Customer>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomersPageDisplayTypes.PROSPECT:
                    tiers = this.Service.ReadListOffline<Prospect>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                    tiers = this.Service.ReadListOffline<ContactCustomer>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                    tiers = this.Service.ReadListOffline<ContactProspect>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT:
                    tiers = this.Service.ReadListOffline<CustomerAndContact>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomersPageDisplayTypes.PROSPECT_AND_CONTACT:
                    tiers = this.Service.ReadListOffline<ProspectAndContact>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
            }
                  /*  break;
                case CustomerTypes.CUSTOMER:
                    tiers = this.Service.ReadListOffline<Customer>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomerTypes.PROSPECT:
                    tiers = this.Service.ReadListOffline<Prospect>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomerTypes.CONTACT_CUSTOMER:
                    tiers = this.Service.ReadListOffline<ContactCustomer>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
                case CustomerTypes.CONTACT_PROSPECT:
                    tiers = this.Service.ReadListOffline<ContactProspect>(null, filterFields, requestedPage, RANGE).Result.Cast<Tiers>().ToList();
                    break;
            }*/
            /*
            if (customerType == CustomerTypes.CUSTOMER)
            {
                tiers = new List<Tiers>(this.Service.ReadList<Customer>(null, null, currentPage, RANGE).Result);
            }
            else
            {
                tiers = new List<Tiers>(this.Service.ReadList<Prospect>(null, null, currentPage, RANGE).Result);
                //List<Customer> customers = new List<Customer>(this.Service.GetProspectsAsync(null, currentPage, RANGE).Result); 
            }
            */

            if (tiers != null && tiers.Count > 0)
            {
                if (this.OnCustomersLoaded != null)
                {
                    this.OnCustomersLoaded(tiers);
                    this.GetCustomers(requestedPage + 1);
                }
            }
        }
        async System.Threading.Tasks.Task ReinitGlobalSearchCommandExecute()
        {
            this.GlobalSearchedString = string.Empty;
        }
    }
}

