﻿using System;
using Xamarin.Forms;
using AppCRM.Views;
using AppCRM.Models;
using System.Threading.Tasks;

namespace AppCRM.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        private INavigation _navigation;

        public Command Connect { get; set; }
        public Command ShowConfigurationCommand { get; set; }

        public delegate void ErrorEventHandler();
        public event ErrorEventHandler OnError;

        public delegate void BusyEventHandler(bool busy);
        public event BusyEventHandler OnBusy;

        public LoginViewModel(INavigation navigation)
        {
            this._navigation = navigation;
            Context.Navigation = navigation;

            Connect = new Command(async () => await ExecuteConnectCommand());
            ShowConfigurationCommand = new Command(async () => await ExecuteShowConfigurationCommand());

            this.Service.InitOfflineDB();
        }

        public String ServerUrl { get; set; }
        public String InstancePath { get; set; }
        public String ServerUsername { get; set; }
        public String ServerPassword { get; set; }

#if DEBUG
        public String Username { get; set; } = "bmarzloff";
        public String Password { get; set; } = "motDEpasse123";
#else
        public String Username { get; set; }
        public String Password { get; set; }
#endif


        async System.Threading.Tasks.Task ExecuteConnectCommand()
        {
            if(this.OnBusy != null)
            {
                this.OnBusy(true);
            }
           
            System.Threading.Tasks.Task.Run(async () =>
            {
                bool connectionSuccess = false;
                try
                {
                    bool success = await this.Service.LoginAsync(this.ServerUrl, this.InstancePath, this.ServerUsername, this.ServerPassword);

                    if (success)
                    {
                        if(Context.Instance.IsConnected)
                        {
                            this.Service.PopulateDB();
                            Context.SwitchToOnline();
                        }

                        var result = await this.Service.UserLoginAsync(this.Username, this.Password);
                        if (result)
                        {
                            MainMenuPage page = new MainMenuPage(this._navigation);
                            //TransactionView page = new TransactionView();
                            //Application.Current.Properties["CONNECTION_LastUser"] = Login;

                            Device.BeginInvokeOnMainThread(async () =>
                            {
                                await this._navigation.PushAsync(page, true);

                                if (this.OnBusy != null)
                                {
                                    this.OnBusy(false);
                                }
                            });
                            connectionSuccess = true;
                        }
                    }
                }
                catch (Exception e)
                {
                }
                if(!connectionSuccess)
                {
                    if (this.OnBusy != null)
                    {
                        this.OnBusy(false);
                    }
                    this.IsBusy = false;
                    if (this.OnError != null)
                    {
                        this.OnError();
                    }
                }

            });
        }

        public async void Login()
        {
            await this.Service.LoginAsync(this.ServerUrl, this.InstancePath, this.ServerUsername, this.ServerPassword);

            //if (success)
            //{
                //Context.ResetCurrentClientContextCommand.Execute(null);
            await this._navigation.PushAsync(new MainMenuPage(this._navigation), true);
            //}
        }

        private DateTime LastShowConfigurationRequest = DateTime.Now;
        async System.Threading.Tasks.Task ExecuteShowConfigurationCommand()
        {
            if (DateTime.Now - LastShowConfigurationRequest <= new TimeSpan(0, 0, 0, 0, 300))
            {
                await this._navigation.PushAsync(new Configuration(this._navigation), true);
            }
            else
            {
                this.LastShowConfigurationRequest = DateTime.Now;
            }
        }
    }
}
