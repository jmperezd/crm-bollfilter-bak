﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AppCRM.Services;

using Xamarin.Forms;

namespace AppCRM.ViewModels
{
    public class StackedBaseViewModel : BaseViewModel
    {
        public Command ShowPreviousCommand { get; set; }

        public IAbasService Service => DependencyService.Get<IAbasService>() ?? new AbasService();

        public event EventHandler OnShowPrevious;

        public StackedBaseViewModel()
        {
            this.ShowPreviousCommand = new Command(async () => await ExecuteShowPreviousCommand());
        }

        async Task ExecuteShowPreviousCommand()
        {
            this.OnShowPrevious(this, new EventArgs());
        }
    }
}
