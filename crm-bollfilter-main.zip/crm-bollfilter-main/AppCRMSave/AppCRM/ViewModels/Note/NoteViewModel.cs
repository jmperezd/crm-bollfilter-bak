﻿using System.Threading.Tasks;
using AppCRM.Models;
using Xamarin.Forms;
using System;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class NoteViewModel : BaseViewModel
    {
        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        private Note note;
        public Note Note
        {
            get { return note; }
            set { SetProperty(ref note, value); }
        }

        private string businessPartnerName = String.Empty;
        public string BusinessPartnerName
        {
            get { return businessPartnerName; }
            private set { SetProperty(ref businessPartnerName, value); }
        }

        private string editorName = String.Empty;
        public string EditorName
        {
            get { return editorName; }
            private set { SetProperty(ref editorName, value); }
        }

        private string NoteId { get; set; }

        public NoteViewModel(string id)
        {
            this.NoteId = id;
            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
        }

        public async System.Threading.Tasks.Task Refresh()
        {
            this.Note = await this.Service.Read<Note>(this.NoteId);
            this.Prefix = AppResources.Note;
            this.Page = this.Note.descrOperLang;

            System.Threading.Tasks.Task.Run(async () =>
            {
                Tiers tiers = (Tiers)await this.Service.ReadOffline<Tiers>(this.Note.businessPartner);
                this.BusinessPartnerName = tiers.descrOperLang;
            });

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.EditorName = ((Employee)await this.Service.Read<Employee>(this.Note.editor)).Descr;
            });
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (IsBusy)
                return;
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }
    }
}
