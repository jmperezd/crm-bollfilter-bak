﻿using System;
using Xamarin.Forms;
using AppCRM.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using AppCRM.Resx;


namespace AppCRM.ViewModels
{
    public class AddUpdateNoteViewModel: StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }
        public Command LoadTypeObjectsCommand { get; set; }

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;

        public delegate void OnListObjectsLoadedDelegate();
        public event OnListObjectsLoadedDelegate OnProductObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnTypeObjectsLoaded;

        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCustomer;

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        private Note note;
        public Note Note
        {
            get
            {
                return note;
            }
            set
            {
                SetProperty(ref note, value);
            }
        }

        private bool showTiersSelection = true;
        public bool ShowTiersSelection
        {
            get { return this.showTiersSelection; }
            set { SetProperty(ref showTiersSelection, value); }
        }

        private ObservableCollection<IItemList> typeObjects;
        public ObservableCollection<IItemList> TypeObjects
        {
            get { return this.typeObjects; }
            set { SetProperty(ref typeObjects, value); }
        }

        private ObservableCollection<IItemList> productObjects = new ObservableCollection<IItemList>();
        public ObservableCollection<IItemList> ProductObjects
        {
            get { return this.productObjects; }
            set { SetProperty(ref productObjects, value); }
        }

        private TypeObject selectedTypeObject;
        public TypeObject SelectedTypeObject
        {
            get
            {
                return this.selectedTypeObject;
            }
            set
            {
                this.Note.type = value.Id;
                SetProperty(ref selectedTypeObject, value);
            }
        }

        private ProductObject selectedProductObject;
        public ProductObject SelectedProductObject
        {
            get
            {
                return this.selectedProductObject;
            }
            set
            {
                this.Note.productListElem = value.Id;
                SetProperty(ref selectedProductObject, value);
            }
        }


        private string editorName = String.Empty;
        public string EditorName
        {
            get { return editorName; }
            private set { SetProperty(ref editorName, value); }
        }


        public AddUpdateNoteViewModel(string idObj, Note obj = null, string idTiers = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.LoadTypeObjectsCommand = new Command(async () => await ExecuteLoadTypesObjects());

            if (obj == null)
            {
                
                this.Page = AppResources.Note.ToLower();
                this.Prefix = AppResources.Creer_une;
                this.Note = new Note() { date = DateTime.Now, currTime = DateTime.Now, editor = Context.Instance.CurrentWebUser.RoleEmployee };
            }
            else
            {

                this.Page = AppResources.Note.ToLower();
                this.Prefix = AppResources.Modifier_une;
                this.Note = obj;
            }
            if (!string.IsNullOrWhiteSpace(idTiers))
            {
                this.Note.businessPartner = idTiers;
                this.ShowTiersSelection = false;
            }

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.EditorName = (await this.Service.Read<Models.Employee>(this.Note.editor)).Descr;
            });


        }

        public void Init()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                //this.ExecuteLoadProductsObjects(string.Empty);
                this.LoadTypeObjectsCommand.Execute(null);
            });
            this.ExecuteLoadCustomer(this.Note.businessPartner);
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        //TODO: A la saisie du partenaire commercial ou de l'article, le systèmé 
                        //initialise la clé de recherche de la note avec celle du partenaire / article. 
                        //Voir comment reproduire ce comportement en création depuis l'app. 
                        //En théorie, l'API se comporte de la même manière. 
                        //this.Note.swd = this.Note.descrOperLang.Replace(" ", "");
                        this.Note.swd = this.Service.ReadOffline<Tiers>(this.note.businessPartner).Result.swd;
                        if (!string.IsNullOrWhiteSpace(this.Note.id))
                        {
                            //Mise à jour
                            var taskMaj = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Note>(this.Note); });
                            taskMaj.Wait();
                        }
                        else
                        {
                            //Ajout
                            var taskAdd = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<Note>(this.Note); });
                            taskAdd.Wait();
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }


        bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Note.businessPartner);
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadCustomer(string id)
        {
            Tiers tiers = await this.Service.ReadOffline<Tiers>(id);
            if (this.OnLoadCustomer != null)
            {
                this.OnLoadCustomer(tiers);
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadTypesObjects()
        {
            List<AppCRM.Models.Type> types = await this.Service.GetEnumAsync<AppCRM.Models.Type>();

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (AppCRM.Models.Type type in types)
            {
                obsList.Add(new TypeObject(type.enumDescr, type.enumIdentifierComplete));
            }
            this.TypeObjects = obsList;
            
            if (this.OnTypeObjectsLoaded != null)
            {
                this.OnTypeObjectsLoaded();
            }

            foreach (TypeObject obj in this.TypeObjects)
            {
                if (obj.Id == this.Note.type)
                {
                    this.SelectedTypeObject = obj;
                    break;
                }
            }

        }

        public void LoadProductsObjects(string search)
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                this.ExecuteLoadProductsObjects(search);
            });
        }

        async System.Threading.Tasks.Task ExecuteLoadProductsObjects(string search, int page = 0)
        {
            try
            {
                int limit = 100;

                List<FilterField> filterFields = new List<FilterField>();
                if (!string.IsNullOrWhiteSpace(search))
                {
                    filterFields.Add(new FilterField() { FieldName = "descrOperLang", Operator = "~/", Value = search });
                }
                List<Product> products = await this.Service.ReadList<Product>(null, filterFields, page, limit);

                //ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();
                this.ProductObjects.Clear();

                foreach (Product product in products)
                {
                    //obsList.Add(new ProductObject(product.descrOperLang, product.id));
                    ProductObject productObject = new ProductObject(product.descrOperLang, product.id);
                    this.ProductObjects.Add(productObject);
                    if (productObject.Id == this.Note.productListElem)
                    {
                        this.SelectedProductObject = productObject;
                    }
                }
                //this.ProductObjects = obsList;
                //this.ProductObjects.Add()

                if (this.OnProductObjectsLoaded != null)
                {
                    this.OnProductObjectsLoaded();
                }

                if (products.Count == limit)
                {
                    //this.ExecuteLoadProductsObjects(search, page + 1);
                }
            }
            catch(Exception e)
            {
                
            }
        }

    }
}