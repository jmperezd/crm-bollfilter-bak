﻿using System.Threading.Tasks;
using AppCRM.Models;
using Xamarin.Forms;
using System;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using System.Net;
using System.IO;
using System.Text;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class TransactionViewModel : BaseViewModel
    {

        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command EditPDFCommand { get; set; }
        public event EventHandler OnEditPDF;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;

        private string TransactionId { get; set; }
        public TransactionTypes TransactionType { get; private set; }

        private PopupBusy PopupBusy { get; set; }

        public bool ShowAnalysis
        {
            get
            {
                if (this.TransactionType != TransactionTypes.ORDER)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool ShowContact
        {
            get
            {
                if (this.TransactionType == TransactionTypes.ORDER)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool ShowEditPDF
        {
            get
            {
                if (this.TransactionType != TransactionTypes.OPPORTUNITY)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public string DisplayProbability
        {
            get
            {
                return this.Transaction != null ? (!string.IsNullOrWhiteSpace(this.Transaction.probability) ? this.Transaction.probability + "%" : string.Empty): string.Empty;
            }
        }

        public string DisplayTotalHT
        {
            get
            {
                double res;

                if (this.Transaction != null && double.TryParse(this.Transaction.totalNetAmt, out res))
                {
                    return DisplayTools.FormatAmount(res);
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public string DisplayTransLock
        {
            get
            {
                if (this.Transaction != null)
                {
                    return this.Transaction.transLock ? "oui" : "non";
                }
                else
                {
                    return string.Empty;
                }

            }
        }

        string repName = String.Empty;
        public string RepName
        {
            get { return repName; }
            private set { SetProperty(ref repName, value); }
        }

        string inhouseContactName = String.Empty;
        public string InhouseContactName
        {
            get { return inhouseContactName; }
            private set { SetProperty(ref inhouseContactName, value); }
        }

        string customerName = String.Empty;
        public string CustomerName
        {
            get { return customerName; }
            private set { SetProperty(ref customerName, value); }
        }

        string goodsRecipentName = String.Empty;
        public string GoodsRecipentName
        {
            get { return goodsRecipentName; }
            private set { SetProperty(ref goodsRecipentName, value); }
        }




        private AppCRM.Models.Transaction transaction;
        public AppCRM.Models.Transaction Transaction
        {
            get { return transaction; }
            set
            {
                SetProperty(ref transaction, value);
                this.OnPropertyChanged("ShowAnalysis");
                this.OnPropertyChanged("DisplayProbability");
                this.OnPropertyChanged("DisplayTotalHT");
                this.OnPropertyChanged("DisplayTransLock");
            }
        }

        public TransactionViewModel(string id, TransactionTypes transactionType)
        {
            this.EditPDFCommand = new Command(async () => await ExecuteEditPDFCommand());
            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            this.TransactionId = id;
            this.TransactionType = transactionType;


            var taskResfresh = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
            taskResfresh.Wait();

        }


        public async System.Threading.Tasks.Task Refresh()
        {

            switch(this.TransactionType)
            {
                case TransactionTypes.OPPORTUNITY:
                    this.Prefix = AppResources.Opportunite.ToLower();
                    this.Transaction = await this.Service.Read<Models.Opportunity, Models.SaleProduct>(this.TransactionId);
                    break;
                case TransactionTypes.QUOTATION:
                    this.Prefix = AppResources.Offre.ToLower();
                    this.Transaction = await this.Service.Read<Models.Quotation, Models.SaleProduct>(this.TransactionId);
                    break;
                case TransactionTypes.ORDER:
                    this.Prefix = AppResources.Commande.ToLower();
                    this.Transaction = await this.Service.Read<Models.Order, Models.SaleProduct>(this.TransactionId);

                    System.Threading.Tasks.Task.Run(async () =>
                    {
                        Employee employee = await this.Service.Read<Employee>((this.Transaction as Order).inhouseContact);
                        this.InhouseContactName = employee.Descr;
                    });

                    System.Threading.Tasks.Task.Run(async () =>
                    {
                        Tiers tiers = await this.Service.ReadOffline<Tiers>(this.Transaction.rep);
                        this.RepName = tiers.descrOperLang;
                    });

                    break;
            }
            this.Page = this.Transaction.idno.ToString();


            System.Threading.Tasks.Task.Run(async () =>
            {
                Tiers tiers = await this.Service.ReadOffline<Tiers>(this.Transaction.customer);
                this.CustomerName = tiers.descrOperLang;
            });

            System.Threading.Tasks.Task.Run(async () =>
            {
                Tiers tiers = await this.Service.ReadOffline<Tiers>(this.Transaction.goodsRecipient);
                this.GoodsRecipentName = tiers.descrOperLang;
            });

        }

        async System.Threading.Tasks.Task ExecuteEditPDFCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }

            try
            {
                Uri uriPdf = new Uri("http://vide.com");
                switch (this.TransactionType)
                {
                    case TransactionTypes.OPPORTUNITY:
                        uriPdf = await Service.PrintImpression<Opportunity>(this.TransactionId);
                        break;
                    case TransactionTypes.QUOTATION:
                        uriPdf = await Service.PrintImpression<Quotation>(this.TransactionId);
                        break;
                    case TransactionTypes.ORDER:
                        uriPdf = await Service.PrintImpression<Order>(this.TransactionId);
                        break;
                }
                if(uriPdf.AbsoluteUri != "http://vide.com")
                {
                    var webClient = new WebClient();

                    webClient.Proxy = WebRequest.DefaultWebProxy;
                    webClient.Credentials = new NetworkCredential("_abas_", "adm");
                    webClient.Encoding = Encoding.UTF8;

                    var bytes = webClient.DownloadData(uriPdf);

                    var text = bytes; // get the downloaded text
                    string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                    string localFilename = "abas.pdf";
                    string localPath = Path.Combine(documentsPath, localFilename);
                    File.WriteAllBytes(localPath, text); // writes to local storage
                    bool exists = File.Exists(localPath);


                    if (exists)
                    {

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            var intentHelper = DependencyService.Get<IIntentHelper>();
                            intentHelper.File(localPath);
                        });

                    }
                }

                if (this.OnEditPDF != null)
                {
                    this.OnEditPDF(this, null);
                }
                if (this.OnBusy != null)
                {
                    this.OnBusy(false);
                }
            }
            catch (Exception e)
            {
                if (this.OnBusy != null)
                {
                    this.OnBusy(false);
                }
            }
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (IsBusy)
                return;
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }

    }
}
