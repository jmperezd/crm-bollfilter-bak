﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;
using WFramework_Xamarin.Components;

namespace AppCRM.ViewModels
{

    public class OpportunitiesViewModel : BaseViewModel, ITableViewModel
    {
        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public string IdClient { get; private set; }

        private List<string> ListGridFields = new List<string> { "id", "customerDescr^descrOperLang", "idno", "dateFrom", "totalNetAmt", "probability" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "customerDescr^descrOperLang", "idno", "dateFrom", "totalNetAmt", "probability" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;
        public bool LazyLoading { get; set; } = true;

        public int NbElementsPerPage { get; set; }

        private Color tabBackgroundColor = Color.FromHex("1BB8A3");
        public Color TabBackgroundColor
        {
            get { return tabBackgroundColor; }
            set { SetProperty(ref tabBackgroundColor, value); }
        }

        private Color tabTextColor = Color.White;
        public Color TabTextColor
        {
            get { return tabTextColor; }
            set { SetProperty(ref tabTextColor, value); }
        }

        private string tabLabel = "OPPORTUNITÉS";
        public string TabLabel
        {
            get { return tabLabel; }
            set { SetProperty(ref tabLabel, value); }
        }



        public OpportunitiesViewModel(string idClient = null)
        {
            this.IdClient = idClient;
            this.InitGridFields();

            this.NewObject = new Command(ExecuteNewObjectCommand);

        }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }

            foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "dateFrom")
                {
                    gridField.Order = GridField.SortOrder.Asc;
                }
            }
        }

        private Dictionary<string, string> DicoNames = new Dictionary<string, string>();
        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {

            if (!Context.Instance.IsConnected)
            {
                foreach (GridField gridField in this.GridFields)
                {
                    gridField.FieldName = gridField.FieldName.Replace("^", "_");
                }
            }

            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = "all", Operator = "~/", Value = globalSearchedString.ToLower() });
            }

            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                filterFields.Add(new FilterField() { FieldName = "customer", Operator = "==", Value = this.IdClient });
            }
            else
            {
                filterFields.Add(new FilterField() { FieldName = "rep", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleSalesRep });
            }

            EntityTable entityTable = this.Service.ReadTable<Opportunity>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
           
            return entityTable;
        }

        private void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }
    }
}
