﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;
using System.Linq;

namespace AppCRM.ViewModels
{

    public class TransactionProductsViewModel : BaseViewModel, ITableViewModel
    {      
        public string IdTransaction { get; private set; }
        public Transaction Transaction { get; private set; }

        private List<string> ListGridFields = new List<string> { "id", "productDescr", "unitQty", "tradeUnit", "price", "percent", "itemValEntCurr", "rowNo", "startDateTime", "product" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "productDescr", "unitQty", "tradeUnit", "price", "percent", "itemValEntCurr", "rowNo", "startDateTime", "product" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();
           
        public bool MultiPage { get; set; } = false;
        public bool LazyLoading { get; set; } = false;

        public int NbElementsPerPage { get; set; }

        public TransactionProductsViewModel(string idTransaction = null, Transaction transaction = null)
        {
            if (idTransaction != null)
            {
                this.IdTransaction = idTransaction;
            }
            if(transaction != null)
            {
                this.IdTransaction = transaction.id;
                this.Transaction = transaction;
            }


            this.InitGridFields();

            //this.Page = "Products";
            //this.Prefix = string.Empty;         
        }

        public void ReInit()
        {
            this.Transaction = null;
        }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdTransaction))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }


            foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "recordNo")
                {
                    gridField.Order = GridField.SortOrder.Desc;
                }
            }
        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(this.IdTransaction))
            {
                filterFields.Add(new FilterField() { FieldName = "head", Operator = "==", Value = this.IdTransaction });
                filterFields.Add(new FilterField() { FieldName = "status", Operator = "<>", Value = "A" });
            }

            EntityTable entityTable = null;
            if (this.Transaction == null)
            {
                entityTable = this.Service.ReadTable<SaleProduct>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
            }
            else
            {
                if (this.Transaction.SubItems == null)
                {
                    this.Transaction.SubItems = new List<object>();
                }

                List<SaleProduct> subItemsToDisplay = new List<SaleProduct>();
                foreach (SaleProduct saleProduct in this.Transaction.SubItems)
                {
                    if(saleProduct.status != "A")
                    {
                        subItemsToDisplay.Add(saleProduct);
                    }
                }
                entityTable = new EntityTable(subItemsToDisplay, this.GridFields);
                
            }

            List<FilterField> filterFields2 = new List<FilterField>();
            FilterField filterField = new FilterField() { FieldName = "unitIdentifier", Operator = "==", Value = "" };
            filterFields2.Add(filterField);
            foreach (EntityRow row in entityTable.Rows)
            {
                foreach(KeyValuePair<string, EntityCell> kvp in row.Cells)
                {
                    if(kvp.Key == "tradeUnit")
                    {
                        filterField.Value = kvp.Value.Value.Replace("(", "").Replace(")", "");
                        var unit = Service.ReadList<Unit>(null, filterFields2).Result;
                        if (unit.FirstOrDefault() != null)
                        {
                            kvp.Value.Value = unit.FirstOrDefault().descrOperLang;
                        }
                            break;
                    }
                }
            }
            return entityTable;
        }

    }
}
