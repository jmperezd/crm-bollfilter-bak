﻿using System;
using Xamarin.Forms;
using AppCRM.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using System.Net;
using System.IO;
using AppCRM.Resx;
using System.Linq;

namespace AppCRM.ViewModels
{
    public class AddUpdateTransactionViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }
        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public Command LoadPayTermObjectsCommand { get; set; }
        public Command LoadRefusalReasonObjectsCommand { get; set; }

        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCustomer;
        public event OnLoadCustomerDelegate OnLoadGoodsRecipient;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;


        public delegate void OnListObjectsLoadedDelegate();
        /*
        public event OnListObjectsLoadedDelegate OnContactObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnProductObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnTypeObjectsLoaded;
        */

        public event OnListObjectsLoadedDelegate OnPayTermObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnRefusalReasonObjectsLoaded;

        private Transaction transaction;
        public Transaction Transaction
        {
            get
            {
                return transaction;
            }
            set
            {
                SetProperty(ref transaction, value);
            }
        }

        private DateTime? dataValidFrom = null;
        public DateTime? DataValidFrom
        {
            get
            {
                if (this.Transaction != null)
                {
                    switch (this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            return (this.Transaction as Opportunity).dataValidFrom;
                        case TransactionTypes.QUOTATION:
                            return (this.Transaction as Quotation).dataValidFrom;
                        default:
                            return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (this.Transaction != null)
                {
                    switch (this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            (this.Transaction as Opportunity).dataValidFrom = value;
                            break;
                        case TransactionTypes.QUOTATION:
                            (this.Transaction as Quotation).dataValidFrom = value;
                            break;
                    }
                }
                SetProperty(ref dataValidFrom, value);
            }
        }

        private DateTime? dataValidUntil = null;
        public DateTime? DataValidUntil
        {
            get
            {
                if (this.Transaction != null)
                {
                    switch (this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            return (this.Transaction as Opportunity).dataValidUntil;
                        case TransactionTypes.QUOTATION:
                            return (this.Transaction as Quotation).dataValidUntil;
                        default:
                            return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (this.Transaction != null)
                {
                    switch (this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            (this.Transaction as Opportunity).dataValidUntil = value;
                            break;
                        case TransactionTypes.QUOTATION:
                            (this.Transaction as Quotation).dataValidUntil = value;
                            break;
                    }
                }
                SetProperty(ref dataValidUntil, value);
            }
        }

        private DateTime? salesOrderDate = null;
        public DateTime? SalesOrderDate
        {
            get
            {
                if (this.Transaction != null)
                {
                    switch (this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            return (this.Transaction as Opportunity).salesOrderDate;
                        case TransactionTypes.QUOTATION:
                            return (this.Transaction as Quotation).salesOrderDate;
                        default:
                            return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (this.Transaction != null)
                {
                    switch (this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            (this.Transaction as Opportunity).salesOrderDate = value;
                            break;
                        case TransactionTypes.QUOTATION:
                            (this.Transaction as Quotation).salesOrderDate = value;
                            break;
                    }
                }
                SetProperty(ref salesOrderDate, value);
            }
        }


        public TransactionTypes TransactionType { get; private set; }

        public bool ShowAnalysis
        {
            get
            {
                if (this.TransactionType != TransactionTypes.ORDER)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool ShowContact
        {
            get
            {
                if (this.TransactionType == TransactionTypes.ORDER)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool ShowRefusalReasons
        {
            get
            {
                if (this.Transaction != null && this.Transaction.id != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool showAddProduct = false;
        public bool ShowAddProduct
        {
            get
            {
                return this.showAddProduct;
            }
            set
            {
                SetProperty(ref showAddProduct, value);
            }
        }

        private ObservableCollection<IItemList> payTermObjects = new ObservableCollection<IItemList>();
        public ObservableCollection<IItemList> PayTermObjects
        {
            get { return this.payTermObjects; }
            set { SetProperty(ref payTermObjects, value); }
        }

        private SimpleObject selectedPayTermObject;
        public SimpleObject SelectedPayTermObject
        {
            get
            {
                return this.selectedPayTermObject;
            }
            set
            {
                this.Transaction.payTerm = value.Id;
                SetProperty(ref selectedPayTermObject, value);
            }
        }

        private ObservableCollection<IItemList> refusalReasonObjects = new ObservableCollection<IItemList>();
        public ObservableCollection<IItemList> RefusalReasonObjects
        {
            get { return this.refusalReasonObjects; }
            set { SetProperty(ref refusalReasonObjects, value); }
        }

        private SimpleObject selectedRefusalReasonObject;
        public SimpleObject SelectedRefusalReasonObject
        {
            get
            {
                return this.selectedRefusalReasonObject;
            }
            set
            {
                if(this.TransactionType != TransactionTypes.ORDER)
                {
                    switch(this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            (this.Transaction as Opportunity).refusalReason  = value.Id;
                            break;
                        case TransactionTypes.QUOTATION:
                            (this.Transaction as Quotation).refusalReason = value.Id;
                            break;
                    }
                    SetProperty(ref selectedRefusalReasonObject, value);
                }
            }
        }

        public AddUpdateTransactionViewModel(TransactionTypes transactionType, string idObj, Transaction obj = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.NewObject = new Command(ExecuteNewObjectCommand);

            this.LoadPayTermObjectsCommand = new Command(async () => await ExecuteLoadPayTermObjects());
            this.LoadRefusalReasonObjectsCommand = new Command(async () => await ExecuteLoadRefusalReasonObjects());

            this.TransactionType = transactionType;

            if (obj == null)
            {
                this.Prefix = AppResources.Creer_une;
                switch (this.TransactionType)
                {
                    case TransactionTypes.OPPORTUNITY:
                        this.Page = AppResources.Opportunite.ToLower();
                        this.Transaction = new Opportunity();
                        break;
                    case TransactionTypes.QUOTATION:
                        this.Page = AppResources.Offre.ToLower();
                        this.Transaction = new Quotation();
                        break;
                    case TransactionTypes.ORDER:
                        this.Page = AppResources.Commande.ToLower();
                        this.Transaction = new Order();
                        break;
                }
                this.Transaction.dateFromDate = DateTime.Now;
                this.Transaction.transLock = false;
                this.transaction.rep = Context.Instance.CurrentWebUser.RoleSalesRep;
            }
            else
            {
                this.Transaction = obj;
                this.ShowAddProduct = true;
                switch (this.TransactionType)
                {
                    case TransactionTypes.OPPORTUNITY:
                        this.Prefix = AppResources.Modifier_une;
                        this.Page = AppResources.Opportunites.ToLower();
                        break;
                    case TransactionTypes.QUOTATION:
                        this.Prefix = AppResources.Modifier_une;
                        this.Page = AppResources.Offre.ToLower();
                        break;
                    case TransactionTypes.ORDER:
                        this.Prefix = AppResources.Modifier_une;
                        this.Page = AppResources.Commande.ToLower();
                        break;
                }
            }
            /*
            System.Threading.Tasks.Task.Run(async () =>
            {
                this.RepName = (await this.Service.Read<Models.Employee>(this.Transaction.rep)).Descr;
            });
            */


        }


        public void Init()
        {

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.LoadPayTermObjectsCommand.Execute(null);
                if (this.TransactionType != TransactionTypes.ORDER)
                {
                    this.LoadRefusalReasonObjectsCommand.Execute(null);
                }
            });

            this.ExecuteLoadCustomer(this.OnLoadCustomer, this.Transaction.customer);
            this.ExecuteLoadCustomer(this.OnLoadGoodsRecipient, this.Transaction.goodsRecipient);

        }


        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }

            System.Threading.Tasks.Task.Run(async () => 
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        this.Transaction.customerDescr_descrOperLang = this.Service.ReadOffline<Tiers>(this.Transaction.customer).Result.descrOperLang;
                        if (!string.IsNullOrWhiteSpace(this.Transaction.id))
                        {
                            switch (this.TransactionType)
                            {
                                case TransactionTypes.OPPORTUNITY:
                                    await this.UpdateTransaction<Opportunity, SaleProduct>((Opportunity)this.Transaction);
                                    break;
                                case TransactionTypes.QUOTATION:
                                    await this.UpdateTransaction<Quotation, SaleProduct>((Quotation)this.Transaction);
                                    break;
                                case TransactionTypes.ORDER:
                                    await this.UpdateTransaction<Order, SaleProduct>((Order)this.Transaction);
                                    break;
                            }
                        }
                        else
                        {
                            switch (this.TransactionType)
                            {
                                case TransactionTypes.OPPORTUNITY:
                                    await this.Service.Create<Opportunity, SaleProduct>((Opportunity)this.Transaction);
                                    break;
                                case TransactionTypes.QUOTATION:
                                    await this.Service.Create<Quotation, SaleProduct>((Quotation)this.Transaction);
                                    break;
                                case TransactionTypes.ORDER:
                                    await this.Service.Create<Order, SaleProduct>((Order)this.Transaction);
                                    break;
                            }
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }


        bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Transaction.customer);
        }

        private async System.Threading.Tasks.Task UpdateTransaction<T, U>(T o)
                                where T : IModel, new()
                                where U : IModel, new()
        {
            try
            {
                await this.Service.Update<T, U>(o);
                /*await this.Service.InitTransactionWorkspace<T>(o.id);
                await this.SaveRows<T>(o);
                await this.Service.CommitAndCloseTransactionWorkspace();*/
            }
            catch (WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    string result = streamReader.ReadToEnd();
                }
            }
            catch(Exception e)
            {

            }
        }

        private async System.Threading.Tasks.Task SaveRows<T>(T o)
            where T : IModel, new()
        {
            try
            {
               /*foreach (string saleProductIdToDeleteOrCancel in this.SaleProductIdsToDeleteOrCancel)
                {
                    switch(this.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            //await Service.CancelRowInObject<T>(this.Transaction.id, saleProductIdToDeleteOrCancel);
                            //await Service.DeleteRowFromObject<T>(this.Transaction.id, saleProductIdToDeleteOrCancel);
                            //break;
                        case TransactionTypes.ORDER:
                        case TransactionTypes.QUOTATION:
                            await Service.CancelRowInObject<T>(this.Transaction.id, saleProductIdToDeleteOrCancel);
                            break;
                    }
                }
                this.SaleProductIdsToDeleteOrCancel.Clear();
                */

                foreach (SaleProduct saleProduct in o.SubItems)
                {
                    if (saleProduct.id == null)
                    {
                        await Service.AddRowToObject<T>(this.Transaction.id, saleProduct.product, saleProduct.unitQty);
                    }
                }
            }
            catch(WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    string result = streamReader.ReadToEnd();
                }
            }
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadCustomer(OnLoadCustomerDelegate delegateToCall, string id)
        {
            Tiers tiers = await this.Service.ReadOffline<Tiers>(id);
            if(delegateToCall != null)
            {
                delegateToCall(tiers);
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadPayTermObjects()
        {
            List<TermsOfPayment> payTerms = await this.Service.ReadList<TermsOfPayment>();

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (TermsOfPayment payTerm in payTerms)
            {
                obsList.Add(new SimpleObject(payTerm.descrOperLang, payTerm.id));
            }
            this.PayTermObjects = obsList;
            
            if (this.OnPayTermObjectsLoaded != null)
            {
                this.OnPayTermObjectsLoaded();
            }

            foreach (SimpleObject obj in this.PayTermObjects)
            {
                if (obj.Id == this.Transaction.payTerm)
                {
                    this.SelectedPayTermObject = obj;
                    break;
                }
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadRefusalReasonObjects()
        {
            List<RefusalReason> refusalReasons = await this.Service.GetEnumAsync<RefusalReason>();

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach(RefusalReason refusalReason in refusalReasons)
            {
                obsList.Add(new SimpleObject(refusalReason.enumDescr, refusalReason.enumIdentifierComplete));
            }
            this.RefusalReasonObjects = obsList;

            if (this.OnRefusalReasonObjectsLoaded != null)
            {
                this.OnRefusalReasonObjectsLoaded();
            }

            foreach (SimpleObject obj in this.RefusalReasonObjects)
            {
                switch(this.TransactionType)
                {
                    case TransactionTypes.OPPORTUNITY:
                        if (obj.Id == (this.Transaction as Opportunity).refusalReason)
                        {
                            this.SelectedRefusalReasonObject = obj;
                            break;
                        }
                        break;
                    case TransactionTypes.QUOTATION:
                        if (obj.Id == (this.Transaction as Quotation).refusalReason)
                        {
                            this.SelectedPayTermObject = obj;
                            break;
                        }
                        break;
                }
            }
        }


        private  void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }


    }
}