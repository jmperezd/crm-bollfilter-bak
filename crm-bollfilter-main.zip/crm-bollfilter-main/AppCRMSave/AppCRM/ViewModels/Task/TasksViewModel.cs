﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class TasksViewModel : BaseViewModel, ITableViewModel
    {
        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public string IdClient { get; private set; }

        private List<string> ListGridFields = new List<string> { "id", "descrOperLang", "prio^descrOperLang", "endDate", "confirm^descrOperLang", "status" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "descrOperLang", "prio^descrOperLang", "endDate", "confirm^descrOperLang", "status" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;
        public bool LazyLoading { get; set; } = true;

        public int NbElementsPerPage { get; set; }

        public static TaskTypes LastShowedTaskTab
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("APP_LastShowedTaskTab"))
                {
                    return (TaskTypes)Enum.Parse(typeof(TaskTypes), Application.Current.Properties["APP_LastShowedTaskTab"] as string);
                }
                else
                {
                    return TaskTypes.MINE;
                }
            }
            set
            {
                Application.Current.Properties["APP_LastShowedTaskTab"] = value.ToString();
            }
        }

        public TasksViewModel(string idClient = null)
        {
            this.IdClient = idClient;
            this.InitGridFields();

            this.Page = AppResources.Taches;
            this.Prefix = string.Empty;

            this.NewObject = new Command(ExecuteNewObjectCommand);

        }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }

            foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "endDate")
                {
                    gridField.Order = GridField.SortOrder.Asc;
                }
            }

        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            if (!Context.Instance.IsConnected)
            {
                foreach (GridField gridField in this.GridFields)
                {
                    gridField.FieldName = gridField.FieldName.Replace("^", "_");
                }
            }

            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = "swdLower", Operator = "~/", Value = globalSearchedString });
            }
            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                filterFields.Add(new FilterField() { FieldName = "businessPartner", Operator = "==", Value = this.IdClient });
            }
            else
            {
                if (LastShowedTaskTab == TaskTypes.MINE)
                {
                    filterFields.Add(new FilterField() { FieldName = "editor", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleEmployee });
                }
                else if (LastShowedTaskTab == TaskTypes.ASSIGNED)
                {
                    filterFields.Add(new FilterField() { FieldName = "confirm", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleEmployee });
                }
            }

            EntityTable entityTable = this.Service.ReadTable<Models.Task>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;


            return entityTable;
        }

        private void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }
    }

    public enum TaskTypes
    {
        MINE,
        ASSIGNED
    }
}
