﻿using System;
using Xamarin.Forms;
using AppCRM.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{
    public class AddUpdateTaskViewModel: StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }
        public Command LoadEmployeeObjectsCommand { get; set; }
        public Command LoadPriorityObjectsCommand { get; set; }
        public Command LoadStatusObjectsCommand { get; set; }

        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCustomer;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;

        public delegate void OnListObjectsLoadedDelegate();
        public event OnListObjectsLoadedDelegate OnEmployeeObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnPriorityObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnStatusObjectsLoaded;

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        private Task task;
        public Task Task
        {
            get
            {
                return task;
            }
            set
            {
                SetProperty(ref task, value);
            }
        }

        private bool showTiersSelection = true;
        public bool ShowTiersSelection
        {
            get { return this.showTiersSelection; }
            set { SetProperty(ref showTiersSelection, value); }
        }

        private ObservableCollection<IItemList> employeeObjects;
        public ObservableCollection<IItemList> EmployeeObjects
        {
            get { return this.employeeObjects; }
            set { SetProperty(ref employeeObjects, value); }
        }

        private ObservableCollection<IItemList> priorityObjects;
        public ObservableCollection<IItemList> PriorityObjects
        {
            get { return this.priorityObjects; }
            set { SetProperty(ref priorityObjects, value); }
        }

        private ObservableCollection<IItemList> statusObjects;
        public ObservableCollection<IItemList> StatusObjects
        {
            get { return this.statusObjects; }
            set { SetProperty(ref statusObjects, value); }
        }

        private EmployeeObject selectedEmployeeObject;
        public EmployeeObject SelectedEmployeeObject 
        {
            get
            {
                return this.selectedEmployeeObject;
            }
            set
            {
                this.Task.editor = value.Id;
                SetProperty(ref selectedEmployeeObject, value);
            }
        }

        private EmployeeObject selectedEmployeeConfirmObject;
        public EmployeeObject SelectedEmployeeConfirmObject
        {
            get
            {
                return this.selectedEmployeeConfirmObject;
            }
            set
            {
                this.Task.confirm = value.Id;
                SetProperty(ref selectedEmployeeConfirmObject, value);
            }
        }

        private PriorityObject selectedPriorityObject;
        public PriorityObject SelectedPriorityObject
        {
            get
            {
                return this.selectedPriorityObject;
            }
            set
            {
                this.Task.prio = value.Id;
                SetProperty(ref selectedPriorityObject, value);
            }
        }

        SimpleObject selectedStatusObject;
        public SimpleObject SelectedStatusObject
        {
            get
            {
                return this.selectedStatusObject;
            }
            set
            {
                this.Task.prio = value.Id;
                SetProperty(ref selectedStatusObject, value);
            }
        }

        private string confirmName = String.Empty;
        public string ConfirmName
        {
            get { return confirmName; }
            private set { SetProperty(ref confirmName, value); }
        }


        public AddUpdateTaskViewModel(string idObj, Task obj = null, string idTiers = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.LoadEmployeeObjectsCommand = new Command(async () => await ExecuteLoadEmployeesObjects());
            this.LoadPriorityObjectsCommand = new Command(async () => await ExecuteLoadPrioritiesObjects());
            //this.LoadStatusObjectsCommand = new Command(async () => await ExecuteLoadStatusesObjects());

            if (obj == null)
            {
                
                this.Page = AppResources.Tache.ToLower();
                this.Prefix = AppResources.Creer_une;
                this.Task = new Task(){endDate = DateTime.Now, confirm = Context.Instance.CurrentWebUser.RoleEmployee, editor = Context.Instance.CurrentWebUser.RoleEmployee };
            }
            else
            {
                
                this.Page = AppResources.Tache.ToLower();
                this.Prefix = AppResources.Modifier_une;
                this.Task = obj;
            }
            if (!string.IsNullOrWhiteSpace(idTiers))
            {
                this.Task.businessPartner = idTiers;
                this.ShowTiersSelection = false;
            }

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.ConfirmName = (await this.Service.Read<Models.Employee>(this.Task.confirm)).Descr;
            });

            //Title = "Tâches";
        }

        public void Init()
        {

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.ExecuteLoadCustomer(this.Task.businessPartner);
                
                this.LoadEmployeeObjectsCommand.Execute(null);
                this.LoadPriorityObjectsCommand.Execute(null);
                this.LoadStatusObjectsCommand.Execute(null);

                /*
                this.CustomerObjects = new ObservableCollection<IItemList>();
                this.LoadCustomerObjectsCommand = new Command(async () => await ExecuteLoadCustomersObjects(string search));
                this.LoadCustomerObjectsCommand.Execute(null);
                */
            });
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        this.Task.swd = this.Service.ReadOffline<Tiers>(this.Task.businessPartner).Result.swd;
                        if (!string.IsNullOrWhiteSpace(this.Task.id))
                        {
                            //Mise à jour
                            var taskMaj = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Task>(this.Task); });
                            taskMaj.Wait();
                        }
                        else
                        {
                            //Ajout
                            var taskAdd = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<Task>(this.Task); });
                            taskAdd.Wait();
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }

        private bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Task.businessPartner);
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadEmployeesObjects()
        {
            List<Employee> employees = this.Service.ReadList<Employee>().Result;

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (Employee employee in employees)
            {
                obsList.Add(new EmployeeObject(employee.Descr, employee.id));
            }
            this.EmployeeObjects = obsList;

            foreach (EmployeeObject obj in this.EmployeeObjects)
            {
                if (obj.Id == this.Task.editor)
                {
                    this.SelectedEmployeeObject = obj;
                }

                if (obj.Id == this.Task.confirm)
                {
                    this.SelectedEmployeeConfirmObject = obj;
                }
            }

            if (this.OnEmployeeObjectsLoaded != null)
            {
                this.OnEmployeeObjectsLoaded();
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadPrioritiesObjects()
        {
            //Dictionary<string, string> priorities = this.Service.GetPriosAsync().Result;

            List<Priority> priorities = await this.Service.GetEnumAsync<Priority>();

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (Priority priority in priorities)
            {
                obsList.Add(new PriorityObject(priority.enumDescr, priority.enumIdentifierComplete));
            }
            this.PriorityObjects = obsList;

            foreach (PriorityObject obj in this.PriorityObjects)
            {
                if (obj.Id == this.Task.prio)
                {
                    this.SelectedPriorityObject = obj;
                    break;
                }
            }

            if(this.OnPriorityObjectsLoaded != null)
            {
                this.OnPriorityObjectsLoaded();
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadStatusesObjects()
        {
            //Dictionary<string, string> priorities = this.Service.GetPriosAsync().Result;
            /*
            Dictionary<string, string> statuses = await this.Service.GetEnumAsync<Status>();

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (KeyValuePair<string, string> status in statuses)
            {
                obsList.Add(new SimpleObject(status.Value, status.Key));
            }
            this.StatusObjects = obsList;

            foreach (SimpleObject obj in this.StatusObjects)
            {
                if (obj.Id == this.Task.status)
                {
                    this.SelectedStatusObject = obj;
                    break;
                }
            }

            if (this.OnStatusObjectsLoaded != null)
            {
                this.OnStatusObjectsLoaded();
            }
            */
        }

        async System.Threading.Tasks.Task ExecuteLoadCustomer(string id)
        {
            Tiers tiers = await this.Service.ReadOffline<Tiers>(id);
            if (this.OnLoadCustomer != null)
            {
                this.OnLoadCustomer(tiers);
            }
        }


    }
}