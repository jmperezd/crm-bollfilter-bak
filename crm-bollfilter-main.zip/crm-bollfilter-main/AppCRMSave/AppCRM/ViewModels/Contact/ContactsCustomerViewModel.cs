﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using AppCRM.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;

namespace AppCRM.ViewModels
{
    
    public class ContactsCustomerViewModel : BaseViewModel, ITableViewModel
    {
        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public Command DisplayMap { get; set; }
        public event EventHandler OnDisplayMap;

        public string IdCustomer { get; private set; }

        private List<string> ListGridFields = new List<string> { "id", "idno", "swd", "descrOperLang" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "idno", "swd", "descrOperLang" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;
        public bool LazyLoading { get; set; } = false;

        public int NbElementsPerPage { get; set; }

        public ContactsCustomerViewModel(string idCustomer = null)
        {
            this.IdCustomer = idCustomer;
            this.InitGridFields();
            this.Page = "Contacts";
            this.Prefix = string.Empty;

            this.NewObject = new Command(ExecuteNewObjectCommand);

            this.DisplayMap = new Command(ExecuteDisplayMapCommand);
        }

        private void ExecuteDisplayMapCommand()
        {
            if (this.OnDisplayMap != null)
            {
                this.OnDisplayMap(this, null);
            }
        }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdCustomer))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = "swd", Operator = "~/", Value = globalSearchedString });
            }

            if (!string.IsNullOrWhiteSpace(this.IdCustomer))
            {
                filterFields.Add(new FilterField() { FieldName = "companyARAP", Operator = "==", Value = this.IdCustomer });
            }


            EntityTable entityTable = null;
            try
            {
                entityTable = this.Service.ReadTable<ContactCustomer>(this.GridFields, filterFields, requestedPage, NbElementsPerPage).Result;
            }
            catch(Exception e)
            {
                
            }
            return entityTable;
        }

        private void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }
    }
}
