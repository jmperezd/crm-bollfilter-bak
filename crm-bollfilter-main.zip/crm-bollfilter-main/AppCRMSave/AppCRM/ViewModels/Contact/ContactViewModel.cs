﻿using System.Threading.Tasks;
using AppCRM.Models;
using Xamarin.Forms;
using System;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class ContactViewModel : BaseViewModel
    {
        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command NewObjectCommand { get; set; }
        public event EventHandler OnNewObject;

        public CustomerTypes CustomerType { get; private set; }
        public string IdCustomer { get; private set; }

        private AppCRM.Models.Tiers tiers;
        public AppCRM.Models.Tiers Tiers
        {
            get { return tiers; }
            set
            {
                SetProperty(ref tiers, value);
                this.OnPropertyChanged("DisplayAddress");
                this.OnPropertyChanged("DisplayAddress2");
            }
        }

        private ActivityObject activity;
        public ActivityObject Activity
        {
            get { return activity; }
            set
            {
                SetProperty(ref activity, value);
            }
        }

        public bool DisplayAddress
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Tiers.addr);
            }
        }

        public bool DisplayAddress2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Tiers.addr2);
            }
        }

        public ContactViewModel(string id, CustomerTypes customerType)
        {
            this.CustomerType = customerType;
            this.IdCustomer = id;

            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            this.Refresh();
        }

        public void Refresh()
        {
            if (this.CustomerType == CustomerTypes.CONTACT_CUSTOMER)
            {
                this.Tiers = this.Service.ReadOffline<Models.ContactCustomer>(this.IdCustomer).Result;
            }
            else
            {
                this.Tiers = this.Service.ReadOffline<Models.ContactProspect>(this.IdCustomer).Result;
            }
            this.Prefix = AppResources.Contact;
            this.Page = this.Tiers.descrOperLang;
            this.NewObjectCommand = new Command(async () => await ExecuteNewObjectCommand());

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.Activity = await this.Service.GetActivity(this.IdCustomer);
            });
        }

        async System.Threading.Tasks.Task ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }
    }
}
