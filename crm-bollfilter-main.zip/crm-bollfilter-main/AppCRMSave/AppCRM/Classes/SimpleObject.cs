﻿using System;
using WFramework_Xamarin.Components;

namespace AppCRM
{
    public class SimpleObject : IItemList
    {

        public string Text { get; set; }
        public string Id { get; set; }
        public string DescroperLang { get; set; }



        public SimpleObject(string text, string id, string descroperLang = null)
        {
            this.Text = text;
            this.Id = id;
            this.DescroperLang = descroperLang;

        }
    }
}
