﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xamarin.Forms;
using System.Collections.Generic;
using WFramework_Xamarin.Components;
using Plugin.Connectivity;
using Plugin.Connectivity.Abstractions;
using AppCRM.Views;
using AppCRM.Models;
using System.Linq;
using AppCRM.Services;
using AppCRM.ViewModels;
using WFramework_Xamarin.Table;

namespace AppCRM
{
    public class Context : INotifyPropertyChanged
    {
        public IAbasService Service => DependencyService.Get<IAbasService>() ?? new AbasService();

        public INavigation Navigation { get; set; }

        private static Context instance = null;
        public static Context Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Context();
                }
                return instance;
            }
        }


        private ContentView mainPageContainer;
        public ContentView MainPageContainer
        {
            get { return this.mainPageContainer; }
            set
            {
                this.mainPageContainer = value;
            }
        }

        private string previousPage;
        public string PreviousPage
        {
            get
            {
                return previousPage;
            }
            private set
            {
                previousPage = value;
                OnPropertyChanged("PreviousPage");
            }
        }

        public Command ShowPreviousPage { get; set; }
        public Command DeconnexionCommand { get; set; }

        private string currentPage;
        public string CurrentPage
        {
            get
            {
                return currentPage;
            }
            set
            {
                currentPage = value;
                OnPropertyChanged("CurrentPage");
            }
        }

        private string currentPagePrefix;
        public string CurrentPagePrefix
        {
            get
            {
                return currentPagePrefix;
            }
            set
            {
                currentPagePrefix = value;
                OnPropertyChanged("CurrentPagePrefix");
            }
        }

        private WebUser currentWebUser;
        public WebUser CurrentWebUser
        {
            get
            {
                return currentWebUser;
            }
            set
            {
                currentWebUser = value;
                //currentWebUser.id = "(182,11,0)";
                OnPropertyChanged("CurrentWebUser");
            }
        }

        //spublic string CurrentUser { get; set; } = "(182,11,0)";

        public Command ResetCurrentClientContextCommand { get; set; }
        public Context()
        {
            ShowPreviousPage = new Command(ExecuteShowPreviousPageCommand);
            DeconnexionCommand = new Command(ExecuteDeconnexionCommand);

            this.ResetCurrentClientContextCommand = new Command(async () => await ExecuteResetCurrentClientContextCommand());

            this.InitConnectivity();
        }

        private void ExecuteShowPreviousPageCommand()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                this.ShowPreviousView(this.MainPageContainer);
            });
        }

        private void ExecuteDeconnexionCommand()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                this.Navigation.PushAsync(new Login(this.Navigation), true);
            });
        }

        public static async System.Threading.Tasks.Task ExecuteResetCurrentClientContextCommand()
        {
            /* 
             this.CurrentClientId = null;
             this.CurrentClientName = null;
             this.CurrentCart = null;
             this.CurrentOfflineCart = null;
             */
        }

        public Popup PopupError;


        #region Navigation

        private List<StackedView> stackedViews = new List<StackedView>();

        public bool ExistsStackedViews
        {
            get
            {
                if (this.stackedViews.Count == 1 && this.stackedViews[0] != null || this.stackedViews.Count > 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public void StackView(StackedView stackedView, int level)
        {
            for (int i = this.stackedViews.Count - 1; i >= level; i--)
            {
                this.stackedViews.RemoveAt(i);
            }
            StackView(stackedView);
        }

        public void StackView(StackedView stackedView)
        {
            this.stackedViews.Add(stackedView);
            this.DisplayPreviousPageLabel(stackedView);
            this.OnPropertyChanged("ExistsStackedViews");
        }

        public void ShowPreviousView(ContentView contentView)
        {
            int level = this.stackedViews.Count - 1;
            this.ShowPreviousView(level, contentView);
        }

        public void ShowPreviousView(int level, ContentView contentView)
        {
            if (this.stackedViews.Count > level)
            {
                try
                {
                    contentView.Content = this.stackedViews[level].View;
                    this.CurrentPage = this.stackedViews[level].Page;
                    this.CurrentPagePrefix = this.stackedViews[level].Prefix;
                    this.DisplayChange(this.stackedViews[level]);
                    if (level - 1 >= 0)
                    {
                        this.DisplayPreviousPageLabel(this.stackedViews[level - 1]);
                    }
                    else
                    {
                        this.PreviousPage = string.Empty;
                    }
                    this.stackedViews.RemoveRange(level, this.stackedViews.Count - level);
                }
                catch (Exception e)
                {

                }
            }
            this.OnPropertyChanged("ExistsStackedViews");
        }

        private void DisplayPreviousPageLabel(StackedView stackedView)
        {
            this.PreviousPage = !string.IsNullOrWhiteSpace(stackedView.Prefix) ? stackedView.Prefix + " " + stackedView.Page : stackedView.Page;
        }


        private void DisplayChange(StackedView stackedView)
        {
            if (this.ChangeToDisplay)
            {
                if (stackedView.View is ITablePage)
                {
                    this.ChangeToDisplay = false;
                    (stackedView.View as ITablePage).Refresh();
                }
                else if (stackedView.View is IRefreshable)
                {
                    (stackedView.View as IRefreshable).Refresh();
                }
            }
        }

        public void ClearStackedView()
        {
            this.ChangeToDisplay = false;
            this.stackedViews.Clear();
            this.OnPropertyChanged("ExistsStackedViews");
        }

        public bool ChangeToDisplay { get; set; } = false;

        #endregion

        #region Connection

        bool forceDisconnected = false;
        public bool ForceDisconnected
        {
            get
            {
                return forceDisconnected;
            }
            set
            {
                forceDisconnected = value;

                OnPropertyChanged("ForceDisconnected");
                OnPropertyChanged("IsConnected");
                OnPropertyChanged("ConnectionIcon");
                OnPropertyChanged("ConnectionStatus");
            }
        }

    private bool isConnected;
        public bool IsConnected
        {
            get
            {
                if(this.ForceDisconnected)
                {
                    return false;
                }
                else
                {
                    return isConnected;
                }
            }
            set
            {
                isConnected = value;
                if(this.isConnected)
                {
                    this.SwitchToOnline();
                }

                OnPropertyChanged("IsConnected");
                OnPropertyChanged("ConnectionIcon");
                OnPropertyChanged("ConnectionStatus");
            }
        }

        public string ConnectionIcon
        {
            get
            {
                if (this.IsConnected)
                {
                    if (this.SynchronisationUpRunning)
                    {
                        return Icon.FACloudUpload;
                    }
                    else if (this.SynchronisationRunning)
                    {
                        return Icon.FACloudDownload;
                    }
                    else
                    {
                        return Icon.FACloud;
                    }

                }
                else
                {
                    return Icon.FABan;
                }
            }
        }

        public string ConnectionStatus
        {
            get
            {
                if (this.IsConnected)
                {
                    if (!this.SynchronisationRunning)
                    {
                        return "CONNECTÉ";
                    }
                    else
                    {
                        return "SYNCHRONISATION EN COURS";
                    }
                }
                else
                {
                    return "DÉCONNECTÉ";
                }
            }
        }

        private bool synchronisationRunning = false;
        public bool SynchronisationRunning
        {
            get
            {
                return synchronisationRunning;
            }
            set
            {
                synchronisationRunning = value;
                OnPropertyChanged("SynchronisationRunning");
                OnPropertyChanged("ConnectionIcon");
                OnPropertyChanged("ConnectionStatus");
            }
        }

        private bool synchronisationUpRunning = false;
        public bool SynchronisationUpRunning
        {
            get
            {
                return synchronisationUpRunning;
            }
            set
            {
                synchronisationUpRunning = value;
                OnPropertyChanged("SynchronisationUpRunning");
                OnPropertyChanged("ConnectionIcon");
                OnPropertyChanged("ConnectionStatus");
            }
        }


        public void SwitchToOnline()
        {
            this.Service.SwitchToOnline();
        }

        bool _ConnectivitySubscribed = false;
        private Object thisLock = new Object();

        private void InitConnectivity()
        {
            lock (thisLock)
            {

                this.CheckConnectivity();

                if (!_ConnectivitySubscribed)
                {
                    _ConnectivitySubscribed = true;

                    CrossConnectivity.Current.ConnectivityChanged += async (sender, args) =>
                    {
                        this.CheckConnectivity();
                    };

                    CrossConnectivity.Current.ConnectivityTypeChanged += async (sender, args) =>
                    {
                        this.CheckConnectivity();
                    };


                }
            }
        }

        private void CheckConnectivity()
        {
            if (CrossConnectivity.Current.IsConnected)
            {
                var wifi = Plugin.Connectivity.Abstractions.ConnectionType.WiFi;
                var cellular = Plugin.Connectivity.Abstractions.ConnectionType.Cellular;
                var connectionTypes = CrossConnectivity.Current.ConnectionTypes;

                var reqWifi = connectionTypes.Any(c => c == wifi);
                var reqCellular = connectionTypes.Count(c => c == cellular);
                if (reqWifi || reqCellular == 2)
                {
                    this.IsConnected = true;
                }
                else
                {
                    this.IsConnected = false;
                }
            }
            else
            {
                this.IsConnected = false;
            }
        }

        #endregion

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion



    }

    public class StackedView
    {
        public string Page { get; set; }

        public string Prefix { get; set; }

        public View View { get; set; }

    }
}
