﻿using System;
using WFramework_Xamarin.Components;

namespace AppCRM
{
    public class ProductObject : IItemList
    {

        public string Text { get; set;}
        public string Id { get; set; }
        public string Swd { get; set; }
        public string DescroperLang { get; set; }


        public ProductObject(string text, string id)
        {
            this.Text = text;
            this.Id = id;
        }
    }
}
