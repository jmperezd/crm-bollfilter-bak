﻿using System;
using System.Collections.Generic;
using System.Linq;
using WFramework_Xamarin.Table;
using AppCRM.Services;

namespace AppCRM
{
    public class BetterUri : UriBuilder
    {
        private HashSet<String> m_queryParams;
        public BetterUri(String val):base(val){
            m_queryParams = new HashSet<string>();
        }

        private String GetQueryFromParams()
        {
            string acc = m_queryParams.Aggregate("", (acc_string, x) => acc_string + x + "&");
            return acc.Substring(0, acc.Length - 1);
        }

        public void AddParam(String param)
        {
            if(!String.IsNullOrWhiteSpace(param))
            {
                m_queryParams.Add(param);
            }
        }

        public override string ToString()
        {
            Query = GetQueryFromParams();
            return base.ToString();
        }

        public static BetterUri GetUri<T>(string id = null)
            where T : IModel, new()
        {
            T foo = new T();
            BetterUri uri = new BetterUri(AbasService.BaseUriString);
            uri.Path += foo.BasePath;
            if (!String.IsNullOrWhiteSpace(id))
            {
                uri.Path += "/" + id;
            }
            else
            {
                uri.AddParam(AbasRequests.GetCriteriaParam(foo.DefaultFilters));
            }
            uri.AddParam(Constants.URI_PARAM_LANGUAGE);
            return uri;
        }

        public static BetterUri GetRichUri<T>(List<GridField> gridFields = null, string search = null, int requestedPage = 0, int count = 0)
           where T : IModel, new()
        {
            BetterUri uri = GetUri<T>();
            uri.AddParam(AbasRequests.GetFieldsStringFromList(gridFields));
            uri.AddParam(AbasRequests.GetLimitAndOffsetString(requestedPage, count));
            uri.AddParam(AbasRequests.GetCriteriaParam(GetFilterFieldsFromSearch(search), gridFields));
            return uri;
        }

        public static BetterUri GetRichUri<T>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {
            BetterUri uri = GetUri<T>();
            uri.AddParam(AbasRequests.GetFieldsStringFromList(gridFields));
            uri.AddParam(AbasRequests.GetLimitAndOffsetString(requestedPage, count));
            uri.AddParam(AbasRequests.GetCriteriaParam(filterFields, gridFields));
            return uri;
        }

        public static BetterUri GetRichUri<T>(List<FilterField> filterFields = null)
            where T : IModel, new()
        {
            BetterUri uri = GetUri<T>();
            uri.AddParam(AbasRequests.GetCriteriaParam(filterFields));
            return uri;
        }

        private static List<FilterField> GetFilterFieldsFromSearch(string search)
        {
            List<FilterField> l = new List<FilterField>
            {
                new FilterField(){ FieldName = "swd", Operator = "~/", Value = search }
            };
            return l;
        }
    }
}
