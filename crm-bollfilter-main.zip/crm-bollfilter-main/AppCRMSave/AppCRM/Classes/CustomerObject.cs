﻿using System;
using WFramework_Xamarin.Components;
using static AppCRM.Services.Utils;

namespace AppCRM
{
    public class CustomerObject : IItemList
    {

        public string Text { get; set;}
        [ForeignKeyID]
        public string Id { get; set; }
        public string Swd { get; set; }
        public string DescroperLang { get; set; }

        public CustomerObject(string text, string id, string descroperLang = null)
        {
            this.Text = text;
            this.Id = id;
            this.DescroperLang = descroperLang;
        }
    }
}
