﻿using System;
using WFramework_Xamarin.Components;
using static AppCRM.Services.Utils;

namespace AppCRM
{
    public class PriorityObject : IItemList
    {
        
        public string Text { get; set;}
        [ForeignKeyID]
        public string Id { get; set; }
        public string DescroperLang { get; set; }


        public PriorityObject(string text, string id)
        {
            this.Text = text;
            this.Id = id;
        }
    }
}
