﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class DisplayPDF : ContentPage
    {
        public DisplayPDF()
        {
            InitializeComponent();

        }
    }
}
