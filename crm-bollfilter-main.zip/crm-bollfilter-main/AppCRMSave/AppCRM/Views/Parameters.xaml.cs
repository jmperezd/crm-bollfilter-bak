﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using AppCRM.ViewModels;
using WFramework_Xamarin.Components;

namespace AppCRM.Views
{
    public partial class Parameters : ContentView
    {
        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Context Context
        {
            get { return Context.Instance; }
        }

        private ParametersViewModel viewModel { get; set; }

        public Parameters()
        {
            InitializeComponent();

            this.BindingContext = this.viewModel = new ParametersViewModel();
            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;


            this.viewModel.ExecuteLoadQuotationPrintLayout().ContinueWith((arg) => this.SearchableListQuotationDisplay.ItemsSource = this.viewModel.LayoutSource).ContinueWith(HandleActionQuotation);
            this.SearchableListQuotationDisplay.OnSelection += SearchableListQuotationDisplay_OnSelection;

            this.viewModel.ExecuteLoadSalesPrintLayout().ContinueWith((arg) => this.SearchableListSalesDisplay.ItemsSource = this.viewModel.LayoutSource).ContinueWith(HandleActionSales);
            this.SearchableListSalesDisplay.OnSelection += SearchableListSalesDisplay_OnSelection;

            this.viewModel.ExecuteLoadItemSearch().ContinueWith((arg) => this.SearchableListItemSearchDisplay.ItemsSource = this.viewModel.LayoutSource).ContinueWith(HandleActionItemSearch);
            this.SearchableListItemSearchDisplay.OnSelection += SearchableListItemSearch_OnSelection;


            //this.ComboBoxOffre.ItemsSource
        }


        void HandleActionQuotation(System.Threading.Tasks.Task<System.Collections.ObjectModel.ObservableCollection<IItemList>> arg)
        {
            this.SearchableListQuotationDisplay.SelectedItem = this.viewModel.SelectedQuotationPrintLayoutObject;
        }

        void HandleActionSales(System.Threading.Tasks.Task<System.Collections.ObjectModel.ObservableCollection<IItemList>> arg)
        {
            this.SearchableListSalesDisplay.SelectedItem = this.viewModel.SelectedSalesPrintLayoutObject;
        }

        void HandleActionItemSearch(System.Threading.Tasks.Task<System.Collections.ObjectModel.ObservableCollection<IItemList>> arg)
        {
            this.SearchableListItemSearchDisplay.SelectedItem = this.viewModel.SelectedItemSearchObject;
        }

        async void SearchableListQuotationDisplay_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedQuotationPrintLayoutObject = this.SearchableListQuotationDisplay.SelectedItem as SimpleObject;
        }

        async void SearchableListSalesDisplay_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedSalesPrintLayoutObject = this.SearchableListSalesDisplay.SelectedItem as SimpleObject;
        }

        async void SearchableListItemSearch_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedItemSearchObject = this.SearchableListItemSearchDisplay.SelectedItem as SimpleObject;
        }


        //IItemList item = new IItemList();

    }
}
