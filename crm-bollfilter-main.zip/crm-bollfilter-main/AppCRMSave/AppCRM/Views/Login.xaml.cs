﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Components;

using AppCRM.ViewModels;
using System.Threading.Tasks;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Login : ContentPage
    {
        private LoginViewModel viewModel { get; set; }
        private PopupBusy PopupBusy;

        public Login(INavigation navigation)
        {
            try
            {
                InitializeComponent();

                NavigationPage.SetHasNavigationBar(this, false);

                Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);
                this.Entry1.Keyboard = keyboard;
                this.Entry2.Keyboard = keyboard;

                this.viewModel = new LoginViewModel(navigation)
                {
                    ServerUrl = App.ServerUrl,
                    InstancePath = App.InstancePath,
                    ServerUsername = App.ServerUserName,
                    ServerPassword = App.ServerPassword
                };

                BindingContext = this.viewModel;
                this.viewModel.OnError += this.OnError;
                this.viewModel.OnBusy += this.OnBusy;
                this.PopupBusy = new PopupBusy(MainFrame);

                this.Entry1.Completed += (s, e) => this.Entry2.Focus();
                this.Entry2.Completed += (s, e) => this.viewModel.Connect.Execute(null);

            }
            catch(Exception e)
            {

            }
           /*CustomWebView cwv = new CustomWebView
            {
                Uri = "/Users/pierrebrisset/Library/Developer/CoreSimulator/Devices/B6904301-A616-4B1E-B194-639307049626/data/Containers/Data/Application/C8908C47-2A4E-4DE8-B6F0-AEFFD62F4AFF/Documents/test.pdf",
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand
            };

            this.test.Children.Add(cwv);
            */
                           // < ws:CustomWebView Uri = "/Users/pierrebrisset/Library/Developer/CoreSimulator/Devices/B6904301-A616-4B1E-B194-639307049626/data/Containers/Data/Application/C8908C47-2A4E-4DE8-B6F0-AEFFD62F4AFF/Documents/test.pdf" HorizontalOptions = "FillAndExpand" VerticalOptions = "FillAndExpand" />
        }

        void OnAppearing()
        {
            base.OnAppearing();
            this.Entry1.Focus();
        }


        private void OnBusy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        private void OnError()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                this.PopupBusy.Hide();
                this.FeedBack.Text = "Une erreur est survenue";

                Task.Run(async () =>
                {
                    await Task.Delay(3000);
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.FeedBack.Text = string.Empty;
                    });
                });
            });
        }
    }
}
