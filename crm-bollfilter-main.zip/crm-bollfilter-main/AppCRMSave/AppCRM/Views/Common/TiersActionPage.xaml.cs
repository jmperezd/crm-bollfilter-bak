﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using AppCRM.Models;

namespace AppCRM.Views
{
    public partial class TiersActionPage : ContentView, IHideable
    {
        private string TiersId { get; set; }
        public AppCRM.ViewModels.BaseViewModel ParentModel { get; set; }

        public PopupBusy PopupBusy;

        public Command ShowAddTaskCommand { get; set; }
        public Command ShowAddNoteCommand { get; set; }

        public event EventHandler OnAction;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public TiersActionPage(string tiersId)
        {
            this.ShowAddTaskCommand = new Command(ExecuteShowAddTaskCommand);
            this.ShowAddNoteCommand = new Command(ExecuteShowAddNoteCommand);
            InitializeComponent();
            this.BindingContext = this;
            this.TiersId = tiersId;
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(-20) };
        }

        void ExecuteShowAddTaskCommand()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    AddUpdateTask page = new AddUpdateTask(null, null, this.TiersId);
                    page.OnValidate += Page_OnValidate;
                    this.ShowView(page);

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                    this.Hiding(null, null);
                }
            });
        }

        void ExecuteShowAddNoteCommand()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    AddUpdateNote page = new AddUpdateNote(null, null, this.TiersId);
                    page.OnValidate += Page_OnValidate;
                    this.ShowView(page);

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                    this.Hiding(null, null);
                }
            });
        }

        private void ShowView(ContentView page)
        {
            Context.Instance.StackView(new StackedView() { View = this.parentPageContainer.Content, Page = this.ParentModel.Page, Prefix = this.ParentModel.Prefix });
           

            Device.BeginInvokeOnMainThread(() =>
            {
                this.ParentPageContainer.Content = page;
                if(page is AddUpdateTask)
                {
                    (page as AddUpdateTask).ParentPageContainer = this.ParentPageContainer;
                }
                if(page is AddUpdateNote)
                {
                    (page as AddUpdateNote).ParentPageContainer = this.ParentPageContainer;
                }
                this.PopupBusy.Hide();
                this.Hiding(null, null);
            });
        } 


        void Page_OnValidate(object sender, EventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }
    }
}
