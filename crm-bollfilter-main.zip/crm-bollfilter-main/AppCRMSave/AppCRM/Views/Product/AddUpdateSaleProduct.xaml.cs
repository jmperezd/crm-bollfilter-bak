﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using AppCRM.Models;
using WFramework_Xamarin.Components;
using Xamarin.Forms;

using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class AddUpdateSaleProduct : ContentView
    {
        AddUpdateSaleProductViewModel viewModel;
        private PopupBusy PopupBusy;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public AddUpdateSaleProduct(string idProduct = null,  SaleProduct saleProduct = null)
        {
            InitializeComponent();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateSaleProductViewModel(idProduct, saleProduct);

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnDelete += this.Delete;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;
            viewModel.OnTradeUnitObjectsLoaded += ViewModel_OnTradeUnitObjectsLoaded;

            /*
            this.Entry1.Completed += (sender, e) => {
                this.viewModel.ValidateCommand.Execute(null);
            };
            */
        }

        void ViewModel_OnTradeUnitObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListTradeUnitObjects.ItemsSource = this.viewModel.TradeUnits;
                this.SearchableListTradeUnitObjects.SelectedItem = this.viewModel.SelectedTradeUnitObject;
                this.SearchableListTradeUnitObjects.OnSelection += SearchableListTradeUnitObjects_OnSelection;

                this.Entry1.Focus();
            });

        }

        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(sender, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        public event EventHandler OnDelete;
        void Delete(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnDelete != null)
            {
                this.OnDelete(sender, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
        }

        async void SearchableListTradeUnitObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedTradeUnitObject = this.SearchableListTradeUnitObjects.SelectedItem as SimpleObject;
        }

        void ViewModel_OnLoadSaleProduct(SaleProduct saleProduct)
        {

        }

    }
}
