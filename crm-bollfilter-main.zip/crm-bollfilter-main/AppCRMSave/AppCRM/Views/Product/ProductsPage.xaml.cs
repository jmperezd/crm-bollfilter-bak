﻿using System;
using AppCRM.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProductsPage : ContentView, ITablePage
    {
        ProductsViewModel viewModel;

        public delegate void OnSelectionDelegate(string id, string label);
        public event OnSelectionDelegate OnSelection;
        private bool SelectionMode { get; set; } = false;

        private TableTools TableTools;
        private PopupBusy PopupBusy;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableTools.Init();
            }
        }

        public ProductsPage(string idClient, bool selectionMode = false)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);

            this.SelectionMode = selectionMode;
            BindingContext = viewModel = new ProductsViewModel(idClient);

            this.InitTableTools();
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayout1, viewModel);
            this.TableTools.EnableGlobalSearch = true;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.ArgAttributes = new List<string>() { "descrOperLang" };
            this.TableTools.ListFieldsAmount = new List<string>() { "purchPrice" };
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.OnViewClicked += object_clicked;
        }

        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    if (!this.SelectionMode)
                    {
                        //Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                        /*
                        ProductPage page = new ProductPage(id);
                        page.ParentPageContainer = this.ParentPageContainer;

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            this.ParentPageContainer.Content = page;
                            this.PopupBusy.Hide();
                        });
                        */
                    }
                    else
                    {
                        if (this.OnSelection != null)
                        {
                            this.OnSelection(id, dicoArgs["descrOperLang"] as string);
                        }
                    }

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateNote page = new AddUpdateNote();
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.TableTools.Init();
        }
    }
}
