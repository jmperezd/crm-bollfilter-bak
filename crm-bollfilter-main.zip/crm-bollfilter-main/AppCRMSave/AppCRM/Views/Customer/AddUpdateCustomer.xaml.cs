﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using AppCRM.Models;
using WFramework_Xamarin.Components;

using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class AddUpdateCustomer : ContentView
    {
        AddUpdateCustomerViewModel viewModel;
        private PopupBusy PopupBusy;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }
        /*
        public string BusinessPartner
        {
            set
            {
                this.viewModel.Tiers.businessPartner = value;
                this.viewModel.Tiers.triggerOfEnt = value;
            }
        }
*/

        public AddUpdateCustomer(CustomerTypes customerType, string idObj = null, Tiers obj = null, string idTiers = null)
        {
            InitializeComponent();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateCustomerViewModel(customerType, idObj, obj, idTiers);
            viewModel.OnEmployeeObjectsLoaded += ViewModel_OnEmployeeObjectsLoaded;
            viewModel.OnCharacteristicObjectsLoaded += ViewModel_OnCharacteristicObjectsLoaded;


            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;
            this.ContentFrame3.ContentView.BindingContext = this.viewModel;
            this.ContentFrame4.ContentView.BindingContext = this.viewModel;

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;

            /*viewModel.OnProductObjectsLoaded += ViewModel_OnProductObjectsLoaded;
            viewModel.OnTypeObjectsLoaded += ViewModel_OnTypeObjectsLoaded;
            */

            //this.viewModel.OnLoadInhouseContact += ViewModel_OnLoadInhouseContact;
            this.viewModel.OnLoadCompany += ViewModel_OnLoadCompany;

            this.LinkedListSelectionContact.ContentText = this.viewModel.Tiers.contactPerson;
            //this.LinkedListSelectionInhouseContact.OnClick += LinkedListSelectionInhouseContact_OnClick;
            this.LinkedListSelectionContact.OnClick += LinkedListSelectionContact_OnClick;
            this.LinkedListSelectionCompany.OnClick += LinkedListSelectionCompany_OnClick;


            this.viewModel.Init();

        }

        void ViewModel_OnLoadCompany(Tiers tiers)
        {
            LinkedListSelectionCompany.ContentText = tiers.descrOperLang;
        }

        /*
        void ViewModel_OnLoadInhouseContact(Employee employee)
        {
            LinkedListSelectionInhouseContact.ContentText = employee.Descr;
        }
        */


        /*
        void ViewModel_OnTypeObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListTypeObjects.ItemsSource = this.viewModel.TypeObjects;
                this.SearchableListTypeObjects.SelectedItem = this.viewModel.SelectedTypeObject;
                this.SearchableListTypeObjects.OnSelection += SearchableListTypeObjects_OnSelection;
            });

        }
        */
        /*
        void ViewModel_OnProductObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {

                //this.SearchableListProductObjects.ItemsSource = this.viewModel.ProductObjects;
            });
        }
        */


        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
        }


        void LinkedListSelectionContact_OnClick()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage contactsPageSelection = null;
                    switch(this.viewModel.CustomersType)
                    {
                        case CustomerTypes.CUSTOMER:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER_CONTACT, true, this.viewModel.Tiers.id);
                            break;
                        case CustomerTypes.PROSPECT:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.PROSPECT_CONTACT, true, this.viewModel.Tiers.id);
                            break;
                    }
                    contactsPageSelection.OnSelection += this.Page_LinkedListSelectionContacts_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = contactsPageSelection;
                        contactsPageSelection.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_LinkedListSelectionContacts_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Tiers.contactPerson = id;
                this.LinkedListSelectionContact.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        void LinkedListSelectionCompany_OnClick()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage contactsPageSelection = null;
                    switch (this.viewModel.CustomersType)
                    {
                        case CustomerTypes.CONTACT_CUSTOMER:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER, true, this.viewModel.Tiers.id);
                            break;
                        case CustomerTypes.CONTACT_PROSPECT:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.PROSPECT, true, this.viewModel.Tiers.id);
                            break;
                    }
                    contactsPageSelection.OnSelection += Page_LinkedListSelectionCompany_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = contactsPageSelection;
                        contactsPageSelection.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }


        void Page_LinkedListSelectionCompany_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                switch(this.viewModel.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        (this.viewModel.Tiers as ContactCustomer).companyARAP = id;
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        (this.viewModel.Tiers as ContactProspect).companyARAP = id;
                        break;

                }
                this.LinkedListSelectionCompany.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        /*
        void LinkedListSelectionInhouseContact_OnClick()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage contactsPageSelection = null;
                    switch (this.viewModel.CustomersType)
                    {
                        case CustomerTypes.CUSTOMER:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER_CONTACT, true, this.viewModel.Tiers.id);
                            break;
                        case CustomerTypes.PROSPECT:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.PROSPECT_CONTACT, true, this.viewModel.Tiers.id);
                            break;
                    }
                    contactsPageSelection.OnSelection += this.Page_LinkedListSelectionInhouseContacts_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = contactsPageSelection;
                        contactsPageSelection.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }


        void Page_LinkedListSelectionInhouseContacts_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Tiers.inhouseContact = id;
                this.LinkedListSelectionInhouseContact.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }
        */

        /*
        async void SearchableListTypeObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedTypeObject = this.SearchableListTypeObjects.SelectedItem as TypeObject;
        }

        async void SearchableListProductObjects_OnSelection(object sender, EventArgs e)
        {
           //this.viewModel.SelectedProductObject = this.SearchableListProductObjects.SelectedItem as ProductObject;
        }
        */

        void ViewModel_OnLoadContact(Tiers tiers)
        {
            this.LinkedListSelectionContact.ContentText = tiers.descrOperLang;
        }

        void ViewModel_OnEmployeeObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListEmployeeObjects.ItemsSource = this.viewModel.EmployeeObjects;
                this.SearchableListEmployeeObjects.SelectedItem = this.viewModel.SelectedEmployeeObject;
                this.SearchableListEmployeeObjects.OnSelection += SearchableListEmployeeObjects_OnSelection;

                this.SearchableListInhouseContactObjects.ItemsSource = this.viewModel.EmployeeObjects;
                this.SearchableListInhouseContactObjects.SelectedItem = this.viewModel.SelectedInhouseContactObject;
                this.SearchableListInhouseContactObjects.OnSelection += SearchableListInhouseContactObjects_OnSelection;
            });
        }

        void ViewModel_OnCharacteristicObjectsLoaded()
        {
            this.SearchableListCharacteristic1Objects.ItemsSource = this.viewModel.Characteristic1Objects;
            this.SearchableListCharacteristic1Objects.SelectedItem = this.viewModel.SelectedCharacteristic1Object;
            this.SearchableListCharacteristic1Objects.OnSelection += SearchableListCharacteristic1Objects_OnSelection;

            this.SearchableListCharacteristic2Objects.ItemsSource = this.viewModel.Characteristic2Objects;
            this.SearchableListCharacteristic2Objects.SelectedItem = this.viewModel.SelectedCharacteristic2Object;
            this.SearchableListCharacteristic2Objects.OnSelection += SearchableListCharacteristic2Objects_OnSelection;

            this.SearchableListCharacteristic3Objects.ItemsSource = this.viewModel.Characteristic3Objects;
            this.SearchableListCharacteristic3Objects.SelectedItem = this.viewModel.SelectedCharacteristic3Object;
            this.SearchableListCharacteristic3Objects.OnSelection += SearchableListCharacteristic3Objects_OnSelection;

            this.SearchableListCharacteristic4Objects.ItemsSource = this.viewModel.Characteristic4Objects;
            this.SearchableListCharacteristic4Objects.SelectedItem = this.viewModel.SelectedCharacteristic4Object;
            this.SearchableListCharacteristic4Objects.OnSelection += SearchableListCharacteristic4Objects_OnSelection;

            this.SearchableListCharacteristic5Objects.ItemsSource = this.viewModel.Characteristic5Objects;
            this.SearchableListCharacteristic5Objects.SelectedItem = this.viewModel.SelectedCharacteristic5Object;
            this.SearchableListCharacteristic5Objects.OnSelection += SearchableListCharacteristic5Objects_OnSelection;

            this.SearchableListCharacteristic6Objects.ItemsSource = this.viewModel.Characteristic6Objects;
            this.SearchableListCharacteristic6Objects.SelectedItem = this.viewModel.SelectedCharacteristic6Object;
            this.SearchableListCharacteristic6Objects.OnSelection += SearchableListCharacteristic6Objects_OnSelection;
        }

        void SearchableListCharacteristic1Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic1Object = this.SearchableListCharacteristic1Objects.SelectedItem as SimpleObject;
        }
        void SearchableListCharacteristic2Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic2Object = this.SearchableListCharacteristic2Objects.SelectedItem as SimpleObject;
        }
        void SearchableListCharacteristic3Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic3Object = this.SearchableListCharacteristic3Objects.SelectedItem as SimpleObject;
        }
        void SearchableListCharacteristic4Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic4Object = this.SearchableListCharacteristic4Objects.SelectedItem as SimpleObject;
        }
        void SearchableListCharacteristic5Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic5Object = this.SearchableListCharacteristic5Objects.SelectedItem as SimpleObject;
        }
        void SearchableListCharacteristic6Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic6Object = this.SearchableListCharacteristic6Objects.SelectedItem as SimpleObject;
        }


        async void SearchableListEmployeeObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedEmployeeObject = this.SearchableListEmployeeObjects.SelectedItem as EmployeeObject;
        }

        void SearchableListInhouseContactObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedInhouseContactObject = this.SearchableListInhouseContactObjects.SelectedItem as EmployeeObject;
        }

        /*
        void ViewModel_OnLoadCustomerInhouseContact(Tiers tiers)
        {
            this.LinkedListSelectionInhouseContact.ContentText = tiers.Descr;
        }
        */



    }
}
