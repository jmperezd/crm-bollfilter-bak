﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using AppCRM.Models;
using Xamarin.Forms;
using WFramework_Xamarin;
using System.Threading.Tasks;
using TK.CustomMap;
using System.Collections.ObjectModel;
using System.Net;
using WFramework_Xamarin.Components;
using System.Diagnostics.Contracts;
using System.Globalization;

namespace AppCRM.Views
{
    public partial class CustomersMap : ContentView
    {
        private CustomersPageDisplayTypes CustomersPageDisplayTypes { get; set; } = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;
        public string IdClient { get; private set; }
        private string DefaultGlobalSearch { get; set; }

        private CustomersMapViewModel viewModel { get; set; }

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Dictionary<string, string> PinnedCustomers { get; set; } = new Dictionary<string, string>();

        private PopupBusy PopupBusy;

        private int CurrentMAJId = 0;


        public CustomersMap(string idClient = null, CustomersPageDisplayTypes customersPageDisplayTypes = CustomersPageDisplayTypes.CUSTOMER_PROSPECT, string defaultGlobalSearch = "")
        {
            InitializeComponent();

            this.CustomersPageDisplayTypes = CustomersPageDisplayTypes;
            this.IdClient = idClient;
            this.DefaultGlobalSearch = defaultGlobalSearch;

            //this.Map.PropertyChanged += this.MapPropertyChanged;
            this.PopupBusy = new PopupBusy(this.ContentFrame1);

            this.Map.Pins = this.Pins;
            this.Map.CalloutClicked += this.CalloutClicked;
            this.Map.PinSelected += this.PinSelected;
            this.Map.MapClicked += this.MapClicked;

            this.SearchEntry.Completed += (sender, e) => { this.Pins.Clear(); this.PinnedCustomers.Clear(); this.viewModel.Init(); };
            Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);
            this.SearchEntry.Keyboard = keyboard;

            System.Threading.Tasks.Task.Run(() =>
            {
                Plugin.Geolocator.Abstractions.Position position = MapTools.GetCurrentPosition().Result;

                if (position != null)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        this.Map.MapRegion = MapSpan.FromCenterAndRadius(new Position(position.Latitude, position.Longitude), Distance.FromKilometers(1200));
                    });
                }
            });


            BindingContext = viewModel = new CustomersMapViewModel(this.IdClient, this.CustomersPageDisplayTypes, this.DefaultGlobalSearch);//coordonnees);
            this.ContentFrameSearchBar.ContentView.BindingContext = viewModel;
            viewModel.OnCustomersLoaded += ViewModel_OnCustomersLoaded;
            this.viewModel.Init();
        }
        /*
        private void ButtonShowDirection_clicked(object sender, EventArgs e)
        {
            switch (Device.RuntimePlatform)
            {
                case Device.iOS:
                    Device.OpenUri(
                        new Uri(string.Format("http://maps.apple.com/?mode=d&q={0}", WebUtility.UrlEncode(this.Map.SelectedPin.Position.Latitude.ToString().Replace(',', '.') + "," + this.Map.SelectedPin.Position.Longitude.ToString().Replace(',', '.')))));
                    break;
                case Device.Android:
                    Device.OpenUri(
                        new Uri(string.Format("google.navigation:?mode=d&q={0}", WebUtility.UrlEncode(this.Map.SelectedPin.Position.Latitude.ToString().Replace(',', '.') + "," + this.Map.SelectedPin.Position.Longitude.ToString().Replace(',', '.')))));
                    break;
            }
        }
        */

        private void CalloutClicked(object sender, TKGenericEventArgs<TKCustomMapPin> e)
        {
            Tuple<string, PlaceTypes> bindingContext = e.Value.BindingContext as Tuple<string, PlaceTypes>;
            //PlaceTypes? placeType = e.Value.BindingContext as PlaceTypes?;
            if (bindingContext != null)
            {
                this.ShowTiers(bindingContext.Item1, bindingContext.Item2);
                //this.ButtonShowDirection.IsVisible = false;
                this.Map.SelectedPin = null;
            }
        }

        private void PinSelected(object sender, TKGenericEventArgs<TKCustomMapPin> e)
        {
            //this.ButtonShowDirection.IsVisible = true;
        }

        private void MapClicked(object sender, TKGenericEventArgs<Position> e)
        {
            //this.ButtonShowDirection.IsVisible = false;
            this.Map.SelectedPin = null;
        }
        /*
        private void MapPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "MapRegion")
            {
                this.CurrentMAJId++;
                if(this.viewModel != null)
                {
                    this.DefaultGlobalSearch = this.viewModel.GlobalSearchedString;
                }
                System.Threading.Tasks.Task.Run(() => PlacePins(CurrentMAJId));
            }
        }
        */
        /*
        private void PlacePins(int id)
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                await System.Threading.Tasks.Task.Delay(100);

                if (id == this.CurrentMAJId)
                {
           //        this.InitMap();
                    this.DefaultGlobalSearch = string.Empty;
                }
            });
        }
        */

        public async System.Threading.Tasks.Task InitMap()
        {
            //Task.Run(() =>
            //{
            //Plugin.Geolocator.Abstractions.Position position = MapTools.GetCurrentPosition().Result;

            var latitudeSud = this.Map.MapCenter.Latitude - this.Map.MapRegion.LatitudeDegrees / 2;
            var latitudeNord = this.Map.MapCenter.Latitude + this.Map.MapRegion.LatitudeDegrees / 2;

            var longitudeOuest = this.Map.MapCenter.Longitude - this.Map.MapRegion.LongitudeDegrees / 2;
            var longitudeEst = this.Map.MapCenter.Longitude + this.Map.MapRegion.LongitudeDegrees / 2;

            Coordonnee coordonnees = new Coordonnee(longitudeEst, longitudeOuest, latitudeNord, latitudeSud);



           // this.ContentFrame1.ContentView.BindingContext = viewModel;

            //Device.BeginInvokeOnMainThread(async () =>
            //{
            try
            {
                /*
                if (this.viewModel.Sites.Count > 499)
                {
                    this.LabelTooManySites.IsVisible = true;
                }
                else
                {
                    this.LabelTooManySites.IsVisible = false;
                }
                */

                /*
                List<List<Customer>> customerLists = new List<List<Customer>>();
                customerLists.Add(this.viewModel.Clients);
                customerLists.Add(this.viewModel.Prospects);

                bool isCustomer = true;
                foreach (List<Customer> customers in customerLists)
                {
                    foreach (Customer customer in customers)
                    {
                        if (!this.PinnedCustomers.ContainsKey(customer.id))
                        {

                            double lat = 0;
                            double lon = 0;
                            if (!double.TryParse(customer.latitude, System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lat)
                               || !double.TryParse(customer.longitude, System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lon))
                            {
                                double.TryParse(customer.latitude.Replace(".", ","), System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lat);
                                double.TryParse(customer.longitude.Replace(".", ","), System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lon);
                            }
                            Device.BeginInvokeOnMainThread(async () =>
                            {
                                try
                                {
                                    if (lat == -1 && lon == 0 || lat == 0 && lon == 0)
                                    {
                                    }
                                    else
                                    {
                                        this.PlacePinOnMap(lat, lon, customer.descr, string.Format("{0} {1} {2}", customer.addr, customer.street, customer.town), customer.id.ToString(), isCustomer ? PlaceTypes.CUSTOMER : PlaceTypes.PROSPECT);
                                    }
                                    this.PinnedCustomers.Add(customer.id, string.Empty);
                                }
                                catch (Exception e)
                                {

                                }
                            });
                        }
                    }
                    isCustomer = !isCustomer;
                }

                */
               
            }
            catch (Exception e)
            {

            }
            // });
            // });

        }

        private ObservableCollection<TKCustomMapPin> Pins = new ObservableCollection<TKCustomMapPin>();

        private void PlacePinOnMap(double lat, double lon, string label, string address, string id, PlaceTypes type)
        {
            var position = new Position(lat, lon); // Latitude, Longitude
            var pin = new TKCustomMapPin()
            {
                Position = position,
                Title = label,
                Subtitle = address,
                //BindingContext = new Tuple<string, string, PlaceTypes>(id, label, type),
                BindingContext = new Tuple<string, PlaceTypes>(id, type),
                ShowCallout = true,
                IsCalloutClickable = true

            };
            if (type == PlaceTypes.CUSTOMER)
            {
                pin.DefaultPinColor = Color.Maroon;
                pin.Image = new Image() { Source = "pinGreen.png" }.Source;
                pin.Group = "Clients";
            }
            else if (type == PlaceTypes.PROSPECT)
            {
                pin.DefaultPinColor = Color.LightSteelBlue;
                pin.Image = new Image() { Source = "pinDark.png" }.Source;
                pin.Group = "Chantiers";
            }
            this.Pins.Add(pin);
            //this.Map.Pins = Pins;
        }

        private void ShowTiers(string id, PlaceTypes placeType)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ContentView page;
                    if (placeType == PlaceTypes.CUSTOMER)
                    {
                        page = new CustomerPage(id);
                        (page as CustomerPage).ParentPageContainer = this.ParentPageContainer;
                    }
                    else
                    {
                        page = new ProspectPage(id);
                        (page as ProspectPage).ParentPageContainer = this.ParentPageContainer;
                    }

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        /*
        private void ResetInitialPosition()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                this.Map.MoveToMapRegion(
                    MapSpan.FromCenterAndRadius(new Position(this.Map.MapCenter.Latitude, this.Map.MapCenter.Longitude), this.Map.MapRegion.Radius), true
                );
            });
        }
        */



        void ViewModel_OnCustomersLoaded(List<Tiers> customers)
        {
            foreach (Tiers tiers in customers)
            {
                if (!this.PinnedCustomers.ContainsKey(tiers.id))
                {

                    double lat = 0;
                    double lon = 0;
                    if (!double.TryParse(tiers.latitude, System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lat)
                       || !double.TryParse(tiers.longitude, System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lon))
                    {
                        double.TryParse(tiers.latitude.Replace(".", ","), System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lat);
                        double.TryParse(tiers.longitude.Replace(".", ","), System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out lon);
                    }
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        try
                        {
                            if (lat == -1 && lon == 0 || lat == 0 && lon == 0)
                            {
                            }
                            else
                            {
                                CustomerTypes customerType = (tiers.grpNo == "1" || tiers.grpNo == "2") ? CustomerTypes.CUSTOMER : CustomerTypes.PROSPECT;
                                this.PlacePinOnMap(lat, lon, tiers.descrOperLang, string.Format("{0} {1} {2}", tiers.addr, tiers.street, tiers.town), tiers.id.ToString(), customerType == CustomerTypes.CUSTOMER ? PlaceTypes.CUSTOMER : PlaceTypes.PROSPECT);
                            }
                            this.PinnedCustomers.Add(tiers.id, string.Empty);
                        }
                        catch (Exception e)
                        {

                        }
                    });
                }
            }
        }

    }
}
