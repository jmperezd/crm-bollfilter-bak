﻿using System;
using AppCRM.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomersPage : ContentView, ITablePage
    {
        CustomersViewModel viewModel;

        public delegate void OnSelectionDelegate(string id, string label);
        public event OnSelectionDelegate OnSelection;
        private bool SelectionMode { get; set; } = false;

        private TableTools TableToolsClients;

        private PopupBusy PopupBusy;

        private CustomersPageDisplayTypes CustomersPageDisplayType { get; set; } = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;


        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableToolsClients.Init();
                this.Init();
            }
        }

        public CustomersPage(CustomersPageDisplayTypes customersPageDisplayType = CustomersPageDisplayTypes.CUSTOMER_PROSPECT, bool selectionMode = false, string idClient = null)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);

            this.CustomersPageDisplayType = customersPageDisplayType;
            this.SelectionMode = selectionMode;

            BindingContext = viewModel = new CustomersViewModel(idClient, this.CustomersPageDisplayType);
            this.viewModel.OnDisplayMap += ViewModel_OnDisplayMap;
            this.viewModel.OnNewObject += ViewModel_OnNewObject;

            this.StackLayoutClients.BindingContext = viewModel;

            this.AllCustomTab.OnAction += CustomTab_OnAction;
            this.AllCustomTab.Target = CustomerTypes.ALL.ToString();

            this.ClientsCustomTab.OnAction += CustomTab_OnAction;
            this.ClientsCustomTab.Target = CustomerTypes.CUSTOMER.ToString();

            this.ProspectsCustomTab.OnAction += CustomTab_OnAction;
            this.ProspectsCustomTab.Target = CustomerTypes.PROSPECT.ToString();

            this.ProspectContactsCustomTab.OnAction += CustomTab_OnAction;
            this.ProspectContactsCustomTab.Target = CustomerTypes.CONTACT_PROSPECT.ToString();

            this.ClientContactsCustomTab.OnAction += CustomTab_OnAction;
            this.ClientContactsCustomTab.Target = CustomerTypes.CONTACT_CUSTOMER.ToString();


            this.AllCustomTab.Label = this.AllCustomTab.Label.ToUpper();
            this.ClientsCustomTab.Label = this.ClientsCustomTab.Label.ToUpper();
            this.ClientContactsCustomTab.Label = this.ClientContactsCustomTab.Label.ToUpper();
            this.ProspectsCustomTab.Label = this.ProspectsCustomTab.Label.ToUpper();
            this.ProspectContactsCustomTab.Label = this.ProspectContactsCustomTab.Label.ToUpper();


            switch (this.CustomersPageDisplayType)
            {
                case CustomersPageDisplayTypes.PROSPECT:
                case CustomersPageDisplayTypes.CUSTOMER:
                    this.AllCustomTab.IsVisible = false;
                    this.ProspectsCustomTab.IsVisible = false;
                    this.ProspectContactsCustomTab.IsVisible = false;
                    this.ClientsCustomTab.IsVisible = false;
                    this.ClientContactsCustomTab.IsVisible = false;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT:
                    this.ProspectsCustomTab.IsVisible = false;
                    this.ProspectContactsCustomTab.IsVisible = false;
                    break;
                case CustomersPageDisplayTypes.PROSPECT_AND_CONTACT:
                    this.ClientsCustomTab.IsVisible = false;
                    this.ClientContactsCustomTab.IsVisible = false;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    this.ProspectContactsCustomTab.IsVisible = false;
                    this.ClientContactsCustomTab.IsVisible = false;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                    this.AllCustomTab.IsVisible = false;
                    this.ProspectsCustomTab.IsVisible = false;
                    this.ProspectContactsCustomTab.IsVisible = false;
                    this.ClientsCustomTab.IsVisible = false;
                    this.ClientContactsCustomTab.IsVisible = false;
                    break;
            }
            this.InitTableTools();
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsClients = new TableTools(this.StackLayoutClients, this.viewModel);
            this.TableToolsClients.EnableGlobalSearch = true;
            this.TableToolsClients.LinkAttribute = "id";
            this.TableToolsClients.HiddenAttributes.Add("grpNo");
            this.TableToolsClients.ArgAttributes = new List<string>() { "descrOperLang" };
            this.TableToolsClients.PopupBusy = this.PopupBusy;
            this.TableToolsClients.OnViewClicked += object_clicked;
            this.TableToolsClients.PaddingSearchBar = 270;
            this.TableToolsClients.OnRowCellCreated += TableToolsClients_OnRowCellCreated;

            switch(this.CustomersPageDisplayType)
            {
                case CustomersPageDisplayTypes.ALL:
                    this.TableToolsClients.PaddingSearchBar = 600;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    this.TableToolsClients.PaddingSearchBar = 270;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT:
                case CustomersPageDisplayTypes.PROSPECT_AND_CONTACT:
                    this.TableToolsClients.PaddingSearchBar = 320;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER:
                case CustomersPageDisplayTypes.PROSPECT:
                case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                    this.TableToolsClients.PaddingSearchBar = 10;
                    break;

            }

        }


        private void Init()
        {
            switch (this.viewModel.LastShowedCustomerTab)
            {
                case CustomerTypes.ALL:
                    this.AllCustomTab.Selected = true;
                    break;
                case CustomerTypes.CUSTOMER:
                    this.ClientsCustomTab.Selected = true;
                    break;
                case CustomerTypes.PROSPECT:
                    this.ProspectsCustomTab.Selected = true;
                    break;
                case CustomerTypes.CONTACT_CUSTOMER:
                    this.ClientContactsCustomTab.Selected = true;
                    break;
                case CustomerTypes.CONTACT_PROSPECT:
                    this.ProspectContactsCustomTab.Selected = true;
                    break;
            }

            switch (this.CustomersPageDisplayType)
            {
                case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.CONTACT_CUSTOMER;
                    break;
                case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.CONTACT_PROSPECT;
                    break;
            }
            this.viewModel.Init();
        }

        void TableToolsClients_OnRowCellCreated(StackLayout e, EntityRow row)
        {
            if (row.Cells["grpNo"].Value == "6")
            {
                e.BackgroundColor = Color.FromRgba(0, 0, 0, 15);
            }
        }

        void ViewModel_OnDisplayMap(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersMap page = new CustomersMap(null, this.CustomersPageDisplayType, this.TableToolsClients.TextGlobalSearch);
                    page.ParentPageContainer = this.ParentPageContainer;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateCustomer page = new AddUpdateCustomer(this.viewModel.LastShowedCustomerTab, null, null, this.viewModel.IdClient);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.TableToolsClients.Init();
        }


        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    if (!this.SelectionMode)
                    {
                        Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                        ContentView page = null;
                        var tiersType = this.viewModel.GetTiersType(TableToolsClients, id);
                        if (tiersType == "1")
                        {
                            page = new CustomerPage(id);
                            (page as CustomerPage).ParentPageContainer = this.ParentPageContainer;
                        }
                        else if (tiersType == "6")
                        {
                            page = new ProspectPage(id);
                            (page as ProspectPage).ParentPageContainer = this.ParentPageContainer;
                        }
                        else if (tiersType == "2")
                        {
                            page = new ContactPage(id, CustomerTypes.CONTACT_CUSTOMER);
                            (page as ContactPage).ParentPageContainer = this.ParentPageContainer;
                        }
                        else if (tiersType == "7")
                        {
                            page = new ContactPage(id, CustomerTypes.CONTACT_PROSPECT);
                            (page as ContactPage).ParentPageContainer = this.ParentPageContainer;
                        }

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            this.ParentPageContainer.Content = page;
                            this.PopupBusy.Hide();
                        });
                    }
                    else
                    {
                        if(this.OnSelection != null)
                        {
                            this.OnSelection(id, dicoArgs["descrOperLang"] as string);
                        }
                    }

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }

            });
        }

        private void CustomTab_OnAction(string target)
        {
            switch (Enum.Parse(typeof(CustomerTypes), target))
            {
                case CustomerTypes.ALL:
                    this.AllCustomTab.Selected = true;
                    this.ClientsCustomTab.Selected = false;
                    this.ProspectsCustomTab.Selected = false;
                    this.ClientContactsCustomTab.Selected = false;
                    this.ProspectContactsCustomTab.Selected = false;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.ALL;
                    TableToolsClients.Init();
                    break;
                case CustomerTypes.CUSTOMER:
                    this.AllCustomTab.Selected = false;
                    this.ClientsCustomTab.Selected = true;
                    this.ProspectsCustomTab.Selected = false;
                    this.ClientContactsCustomTab.Selected = false;
                    this.ProspectContactsCustomTab.Selected = false;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.CUSTOMER;
                    TableToolsClients.Init();
                    break;
                case CustomerTypes.PROSPECT:
                    this.AllCustomTab.Selected = false;
                    this.ProspectsCustomTab.Selected = true;
                    this.ClientsCustomTab.Selected = false;
                    this.ClientContactsCustomTab.Selected = false;
                    this.ProspectContactsCustomTab.Selected = false;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.PROSPECT;
                    TableToolsClients.Init();
                    break;
                case CustomerTypes.CONTACT_CUSTOMER:
                    this.AllCustomTab.Selected = false;
                    this.ProspectsCustomTab.Selected = false;
                    this.ClientsCustomTab.Selected = false;
                    this.ClientContactsCustomTab.Selected = true;
                    this.ProspectContactsCustomTab.Selected = false;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.CONTACT_CUSTOMER;
                    TableToolsClients.Init();
                    break;
                case CustomerTypes.CONTACT_PROSPECT:
                    this.AllCustomTab.Selected = false;
                    this.ProspectsCustomTab.Selected = false;
                    this.ClientsCustomTab.Selected = false;
                    this.ClientContactsCustomTab.Selected = false;
                    this.ProspectContactsCustomTab.Selected = true;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.CONTACT_PROSPECT;
                    TableToolsClients.Init();
                    break;
            }
            this.Init();
        }





    }



}