﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using Microcharts;
using SkiaSharp;
using AppCRM.Models;

namespace AppCRM.Views
{
    public partial class CustomerTurnover : ContentView
    {
        private CustomerTurnoverViewModel viewModel { get; set; }

        private PopupBusy popupBusyCA;
        private PopupBusy popupBusyOpenItems;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }


        public CustomerTurnover(string id)
        {
            InitializeComponent();
            BindingContext = viewModel = new CustomerTurnoverViewModel(id);
            this.viewModel.OnLoadDatas += ViewModel_OnLoadDatas;
            this.viewModel.OnLoadOpenItemsDatas += ViewModel_OnLoadOpenItemsDatas;
            this.viewModel.OnBusy += ViewModel_OnBusy;
            this.viewModel.OnBusyOpenItems += ViewModel_OnBusyOpenItems;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
            this.popupBusyCA = new PopupBusy(this.ContentFrame1);
            this.popupBusyOpenItems = new PopupBusy(this.ContentFrame2);

            this.viewModel.Init();

            //this.LoadBarChart();
        }

        void ViewModel_OnLoadDatas()
        {
            this.LoadCAChart();
        }

        void ViewModel_OnLoadOpenItemsDatas()
        {
            this.LoadBarChart();
        }


        void ViewModel_OnBusy(bool busy)
        {
            if (busy)
            {
                this.popupBusyCA.Show();
            }
            else
            {
                this.popupBusyCA.Hide();
            }
        }
        void ViewModel_OnBusyOpenItems(bool busy)
        {
            if (busy)
            {
                this.popupBusyOpenItems.Show();
            }
            else
            {
                this.popupBusyOpenItems.Hide();
            }
        }


        public void LoadCAChart()
        {
            float maxValue = 0;

            if (this.viewModel.IsTurnoversVisible)
            {
                List<Microcharts.Entry> entriesCA = new List<Microcharts.Entry>();
                foreach (CAChartItem turnover in this.viewModel.Turnovers)
                {
                    if (maxValue < turnover.Value)
                    {
                        maxValue = (float)turnover.Value;
                    }

                    Microcharts.Entry entry = new Microcharts.Entry((float)turnover.Value)
                    {
                        Label = turnover.Label.Substring(0, 3).ToUpper(),
                        ValueLabel = DisplayTools.FormatAmount(turnover.Value, string.Empty),
                        Color = SKColor.Parse("#1BB8A3"),
                        TextColor = SKColor.Parse("#2A3539")
                    };
                    entriesCA.Add(entry);
                }
                this.chartCA.IsVisible = true;
                this.chartCA.Chart = new LineChart()
                {
                    Entries = entriesCA.ToArray(),
                    LabelTextSize = 22,
                    LabelFooterTextSize = 20,
                    LineMode = LineMode.Straight,
                    BackgroundColor = SKColors.Transparent,
                    HeaderHeight = 130,
                    MaxValue = maxValue,
                    Offset = -15,
                    Margin = 15
                };
            }
            else
            {
                this.chartCA.IsVisible = false;
            }

            if (this.viewModel.IsTurnoversMinusVisible)
            {
                List<Microcharts.Entry> entriesCAMinus = new List<Microcharts.Entry>();
                foreach (CAChartItem turnover in this.viewModel.TurnoversMinus)
                {
                    if (maxValue < turnover.Value)
                    {
                        maxValue = (float)turnover.Value;
                    }

                    Microcharts.Entry entry = new Microcharts.Entry((float)turnover.Value)
                    {
                        Label = turnover.Label.Substring(0, 3).ToUpper(),
                        ValueLabel = DisplayTools.FormatAmount(turnover.Value, string.Empty),
                        Color = SKColor.Parse("#2A3539"),
                        TextColor = SKColor.Parse("#2A3539")
                    };
                    entriesCAMinus.Add(entry);
                }
                this.chartCAPrevious.IsVisible = true;
                this.chartCAPrevious.Chart = new LineChart()
                {
                    Entries = entriesCAMinus.ToArray(),
                    LabelTextSize = 22,
                    LabelFooterTextSize = 20,
                    LineMode = LineMode.Straight,
                    BackgroundColor = SKColors.Transparent,
                    HeaderHeight = 130,
                    MaxValue = maxValue,
                    Offset = 15,
                    Margin = 15
                };
            }
            else
            {
                this.chartCAPrevious.IsVisible = false;
            }

            if(!this.viewModel.IsTurnoversVisible && !this.viewModel.IsTurnoversMinusVisible)
            {
                this.NoTurnoverData.IsVisible = true;
            }
            else
            {
                this.NoTurnoverData.IsVisible = false;
            }
        }

        public void LoadBarChart()
        {
            float maxValue = 0;

            List<Microcharts.Entry> entriesBar = new List<Microcharts.Entry>();
            bool even = true;
            foreach (OpenItemChartItem openItem in this.viewModel.EntriesBar)
            {
                if (maxValue < openItem.Value)
                {
                    maxValue = (float)openItem.Value;
                }
                Microcharts.Entry entry = new Microcharts.Entry((float)openItem.Value)
                {
                    Label = openItem.Label,
                    ValueLabel = openItem.ValueLabel,
                    TextColor = SKColor.Parse("#2A3539"),
                };
                if(even)
                {
                    entry.Color = SKColor.Parse("#1BB8A3");
                }
                else
                {
                    entry.Color = SKColor.Parse("#2A3539");
                }
                entriesBar.Add(entry);
                even = !even;
            }


            this.chartOpenItems.Chart = new BarChart()
            {
                Entries = entriesBar.ToArray(),
                LabelTextSize = 22,
                LabelFooterTextSize = 20,
                //LineMode = LineMode.Straight,
                BackgroundColor = SKColors.Transparent,
                //HeaderHeight = 130,
                MaxValue = maxValue,
                Offset = 20,
                Margin = 15
            };
        }

    }
}
