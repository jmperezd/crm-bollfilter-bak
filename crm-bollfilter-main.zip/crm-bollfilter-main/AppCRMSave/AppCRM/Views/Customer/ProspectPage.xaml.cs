﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using AppCRM.Models;

namespace AppCRM.Views
{
    public partial class ProspectPage : ContentView, IRefreshable
    {
        private ProspectViewModel viewModel { get; set; }

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Popup PopupNewObject;


        public ProspectPage(string id)
        {
            InitializeComponent();
            BindingContext = viewModel = new ProspectViewModel(id);
            //this.viewModel.OnShowTurnover += ViewModel_OnShowTurnover;
            this.viewModel.OnShowContacts += ViewModel_OnShowContacts;
            this.viewModel.OnNewObject += this.ViewModel_OnNewObject;
            this.viewModel.OnEdit += this.ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            //this.ContentFrame2.ContentView.BindingContext = viewModel;
            //this.ContentFrame3.ContentView.BindingContext = viewModel;
            this.ContentFrame4.ContentView.BindingContext = viewModel;
            this.ContentFrame5.ContentView.BindingContext = viewModel;
            this.ContentFrame6.ContentView.BindingContext = viewModel;

            this.PopupNewObject = new Popup(this);


            this.LabelNotes.Text = this.LabelNotes.Text.ToUpper();
            this.LabelTasks.Text = this.LabelTasks.Text.ToUpper();
            //this.LabelOrders.Text = this.LabelOrders.Text.ToUpper();
            this.LabelQuotations.Text = this.LabelQuotations.Text.ToUpper();
            this.LabelOpportunities.Text = this.LabelOpportunities.Text.ToUpper();


            NotesStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new NotesPage(id)))
            });
            TasksStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TasksPage(id)))
            });
            OpportunitiesStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.OPPORTUNITY)))
            });
            QuotationsStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.QUOTATION)))
            });
            /*OrdersStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.ORDER)))
            });*/

            LinkMail.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.Mail(this.viewModel.Prospect.emailAddr))
            });
            LinkWebSite.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.WebSite(this.viewModel.Prospect.webSiteURL))
            });
            LinkAddress.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Prospect.zipCode + "," + this.viewModel.Prospect.town + "," + this.viewModel.Prospect.addr + "," + this.viewModel.Prospect.street))
            });
            LinkAddress2.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Prospect.zipCode2 + "," + this.viewModel.Prospect.town2 + "," + this.viewModel.Prospect.addr2 + "," + this.viewModel.Prospect.street2))
            });
        }

        private void ShowPage(ITablePage page)
        {
            //this.PopupBusy.Show();
            try
            {
                Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ParentPageContainer.Content = page as ContentView;
                    page.ParentPageContainer = this.parentPageContainer;
                    //this.PopupBusy.Hide();
                });

            }
            catch (Exception ex)
            {
                //this.PopupBusy.Hide();
            }
        }


        void ViewModel_OnShowContacts(object sender, EventArgs e)
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage page = new CustomersPage(CustomersPageDisplayTypes.PROSPECT_CONTACT, false, this.viewModel.Prospect.id);
                    page.ParentPageContainer = this.parentPageContainer;
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            TiersActionPage page = new TiersActionPage(this.viewModel.Prospect.id);
            page.ParentModel = this.viewModel;
            page.ParentPageContainer = this.ParentPageContainer;

            this.PopupNewObject.ContentView = page;
            this.PopupNewObject.Show();
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateCustomer page = new AddUpdateCustomer(CustomerTypes.PROSPECT, null, this.viewModel.Prospect);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }


        public void Refresh()
        {
            this.viewModel.Refresh();
        }
    }
}
