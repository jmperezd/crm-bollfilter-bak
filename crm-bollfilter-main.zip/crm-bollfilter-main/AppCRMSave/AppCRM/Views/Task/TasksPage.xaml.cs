﻿using System;
using AppCRM.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;
using AppCRM.Resx;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TasksPage : ContentView, ITablePage
    {
        TasksViewModel viewModel;
        private TableTools TableTools;
        private PopupBusy PopupBusy;

        TaskTypes? TaskTypeShowed { get; set; } = null;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableTools.Init();
                this.Init(this.TaskTypeShowed);
            }
        }

        public TasksPage(string customerId = null, TaskTypes? taskTypeShowed = null)
        {
            InitializeComponent();
            this.TaskTypeShowed = taskTypeShowed;
            NavigationPage.SetHasNavigationBar(this, false);

            BindingContext = viewModel = new TasksViewModel(customerId);


            this.viewModel.OnNewObject += ViewModel_OnNewObject;


            this.MyTasksCustomTab.OnAction += CustomTab_OnAction;
            this.MyTasksCustomTab.Target = TaskTypes.MINE.ToString();

            this.AssignedTasksCustomTab.OnAction += CustomTab_OnAction;
            this.AssignedTasksCustomTab.Target = TaskTypes.ASSIGNED.ToString();
            this.MyTasksCustomTab.Label = this.MyTasksCustomTab.Label.ToUpper();
            this.AssignedTasksCustomTab.Label = this.AssignedTasksCustomTab.Label.ToUpper();

            this.InitTableTools();

        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayout1, viewModel);
            //this.TableTools.EnableGlobalSearch = true;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.OnViewClicked += object_clicked;
            this.TableTools.EnableGlobalSearch = true;
            this.TableTools.HiddenAttributes.Add("status");
            this.TableTools.OnLoadSpecialIndicator += TableTools_OnLoadSpecialIndicator;
            this.TableTools.ArgAttributes = new List<string>() { "endDate", "status" };
            if(string.IsNullOrWhiteSpace(this.viewModel.IdClient))
            {
                this.TableTools.PaddingSearchBar = 265;
            }
            else
            {
                this.GridTabs.IsVisible = false;
            }
        }

        private void Init(TaskTypes? taskTypeShowed = null)
        {
            switch (taskTypeShowed != null ? taskTypeShowed : TasksViewModel.LastShowedTaskTab)
            {
                case TaskTypes.MINE:
                    this.MyTasksCustomTab.Selected = true;
                    //filtrer ici
                    break;
                case TaskTypes.ASSIGNED:
                    this.AssignedTasksCustomTab.Selected = true;
                    //filtrer ici
                    break;
            }
        }

        private void CustomTab_OnAction(string target)
        {
            switch (Enum.Parse(typeof(TaskTypes), target))
            {
                case TaskTypes.MINE:
                    this.AssignedTasksCustomTab.Selected = false;
                    TasksViewModel.LastShowedTaskTab = TaskTypes.MINE;
                    break;
                case TaskTypes.ASSIGNED:
                    this.MyTasksCustomTab.Selected = false;
                    TasksViewModel.LastShowedTaskTab = TaskTypes.ASSIGNED;
                    break;
            }
            this.TableTools.Init();
            this.Init();
        }

        bool TableTools_OnLoadSpecialIndicator(Dictionary<string, object> dicoArgs)
        {
            if(dicoArgs.ContainsKey("endDate") && dicoArgs.ContainsKey("status"))
            {
                DateTime dt;
                DateTime.TryParse(dicoArgs["endDate"] as string, out dt);
                if(dicoArgs["status"] as string != "(Done)" && dicoArgs["status"] as string != "(Confirmed)" && dt != null && dt < DateTime.Now)
                {
                    return true;
                }
            }
            return false;
        }


        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    TaskPage page = new TaskPage(id);
                    page.ParentPageContainer = this.ParentPageContainer;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTask page = new AddUpdateTask(null, null, this.viewModel.IdClient);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.TableTools.Init();
        }

    }
}