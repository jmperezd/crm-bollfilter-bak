﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using AppCRM.Models;
using WFramework_Xamarin.Components;

using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class AddUpdateTask : ContentView
    {
        AddUpdateTaskViewModel viewModel;
        private PopupBusy PopupBusy;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public AddUpdateTask(string idObj = null, Task obj = null, string idTiers = null)
        {
            InitializeComponent();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateTaskViewModel(idObj, obj, idTiers);
            //viewModel.OnCustomerObjectsLoaded += ViewModel_OnCustomerObjectsLoaded;
            viewModel.OnEmployeeObjectsLoaded += ViewModel_OnEmployeeObjectsLoaded;
            viewModel.OnPriorityObjectsLoaded += ViewModel_OnPriorityObjectsLoaded;
            //viewModel.OnStatusObjectsLoaded += ViewModel_OnStatusObjectsLoaded;
            this.LinkedListSelectionCustomer.OnClick += LinkedListSelectionCustomer_OnClick;

            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;
            viewModel.OnLoadCustomer += ViewModel_OnLoadCustomer;

            this.viewModel.Init();
            /*
            this.Entry1.Completed += (s, e) => this.Entry2.Focus();
            this.Entry2.Completed += (s, e) => this.Entry3.Focus();
            this.Entry3.Completed += (s, e) => this.Entry4.Focus();
            this.Entry4.Completed += (s, e) => this.Entry5.Focus();
            this.Entry5.Completed += (s, e) => this.Entry6.Focus();
            */

        }

        /*
        void ViewModel_OnCustomerObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCustomerObjects.ItemsSource = this.viewModel.CustomerObjects;
                this.SearchableListCustomerObjects.SelectedItem = this.viewModel.SelectedCustomerObject;
                this.SearchableListCustomerObjects.OnSelection += SearchableListCustomerObjects_OnSelection;
            });
        }
        */
        void ViewModel_OnEmployeeObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListEmployeeObjects.ItemsSource = this.viewModel.EmployeeObjects;
                this.SearchableListEmployeeObjects.SelectedItem = this.viewModel.SelectedEmployeeObject;
                this.SearchableListEmployeeObjects.OnSelection += SearchableListEmployeeObjects_OnSelection;

                this.SearchableListEmployeeConfirmObjects.ItemsSource = this.viewModel.EmployeeObjects;
                this.SearchableListEmployeeConfirmObjects.SelectedItem = this.viewModel.SelectedEmployeeConfirmObject;
                this.SearchableListEmployeeConfirmObjects.OnSelection += SearchableListEmployeeConfirmObjects_OnSelection;
            });
        }
        void ViewModel_OnPriorityObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListPriorityObjects.ItemsSource = this.viewModel.PriorityObjects;
                this.SearchableListPriorityObjects.SelectedItem = this.viewModel.SelectedPriorityObject;
                this.SearchableListPriorityObjects.OnSelection += SearchableListPriorityObjects_OnSelection;
            });
        }
        /*
        void ViewModel_OnStatusObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListStatusObjects.ItemsSource = this.viewModel.StatusObjects;
                this.SearchableListStatusObjects.SelectedItem = this.viewModel.SelectedStatusObject;
                this.SearchableListStatusObjects.OnSelection += SearchableListStatusObjects_OnSelection;
            });
        }
        */

        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
        }

        async void SearchableListEmployeeObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedEmployeeObject =  this.SearchableListEmployeeObjects.SelectedItem as EmployeeObject;
        }

        async void SearchableListEmployeeConfirmObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedEmployeeConfirmObject = this.SearchableListEmployeeConfirmObjects.SelectedItem as EmployeeObject;
        }

        async void SearchableListPriorityObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedPriorityObject = this.SearchableListPriorityObjects.SelectedItem as PriorityObject;
        }

        async void SearchableListStatusObjects_OnSelection(object sender, EventArgs e)
        {
            //this.viewModel.SelectedStatusObject = this.SearchableListStatusObjects.SelectedItem as SimpleObject;
        }
        /*
        async void SearchableListCustomerObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCustomerObject = this.SearchableListCustomerObjects.SelectedItem as CustomerObject;
        }
        */

        void LinkedListSelectionCustomer_OnClick()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.ALL, true);
                    customersPageSelection.OnSelection += Page_LinkedListSelectionCustomers_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = customersPageSelection;
                        customersPageSelection.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }


        void Page_LinkedListSelectionCustomers_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Task.businessPartner = id;
                this.LinkedListSelectionCustomer.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        void ViewModel_OnLoadCustomer(Tiers tiers)
        {
            this.LinkedListSelectionCustomer.ContentText = tiers.descrOperLang;
        }
    }
}
