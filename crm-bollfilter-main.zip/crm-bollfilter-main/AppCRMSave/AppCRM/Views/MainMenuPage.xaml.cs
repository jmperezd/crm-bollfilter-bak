﻿using System;
using System.Collections.Generic;
using AppCRM.Views;
using WFramework_Xamarin.Components;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using AppCRM.Services;

using Xamarin.Forms;

namespace AppCRM
{
    public partial class MainMenuPage : ContentPage, INotifyPropertyChanged
    {

        public Command DisplayPage { get; set; }
        public Command DisplayOptions { get; set; }
        private INavigation _navigation;
        private Popup PopupOptions;

        public Context Context
        {
            get { return Context.Instance; }
        }

        public MainMenuPage(INavigation navigation)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            this.DisplayOptions = new Command(ExecuteDisplayOptionsCommand);
            this.PopupOptions = new Popup(this.MainFrame) { AllowUserClose = true };


            this._navigation = navigation;
            DisplayPage = new Command<string>(ExecuteDisplayPageCommand);
            this.BindingContext = this;

            Context.MainPageContainer = this.PageContainer;
            this.ExecuteDisplayPageCommand(App.LastVisitedPage);

            //Pour forcer le disconnected mode
            this.labelStatus.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ForceDisconnected()),
            });


        }

        private void NotifyMenuColor()
        {
            OnPropertyChanged("TaskColor");
            OnPropertyChanged("TiersColor");
            OnPropertyChanged("NotesColor");
            OnPropertyChanged("TransactionsColor");
            OnPropertyChanged("ActivityColor");
        }


        private void ShowElement(Grid box, bool show)
        {
            this.HideAllElements();
            if (show)
            {
                box.FadeTo(1, 500, Easing.SpringOut);
            }
            else
            {
                box.FadeTo(0, 500, Easing.SpringOut);
            }
        }

        private void HideAllElements()
        {
            this.TaskElement.FadeTo(0, 500, Easing.SpringOut);
            this.TiersElement.FadeTo(0, 500, Easing.SpringOut);
            this.NotesElement.FadeTo(0, 500, Easing.SpringOut);
            this.TransactionsElement.FadeTo(0, 500, Easing.SpringOut);
            //this.ActivityElement.FadeTo(0, 500, Easing.SpringOut);
        }

        private void ExecuteDisplayPageCommand(string origin)
        {
            this.IsBusy = true;

            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    ITablePage view = null;
                    switch (origin.ToUpper())
                    {
                        case "TASKS":
                            this.ShowElement(this.TaskElement, true);
                            view = new TasksPage();
                            break;
                        case "TIERS":
                            this.ShowElement(this.TiersElement, true);
                            view = new CustomersPage();
                            break;
                        case "NOTES":
                            this.ShowElement(this.NotesElement, true);
                            view = new NotesPage();
                            break;
                        case "TRANSACTIONS":
                            this.ShowElement(this.TransactionsElement, true);
                            view = new TransactionsPage();
                            break;
                        //case "ACTIVITE":
                            //this.ShowElement(this.ActivityElement, true);
                            //view = new ActivityPage();
                            //break;
                    }
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        if (view != null)
                        {
                            App.LastVisitedPage = origin;
                            Context.Instance.ClearStackedView();
                            this.PageContainer.Content = view as ContentView;
                            view.ParentPageContainer = this.PageContainer;
                            //await this._navigation.PushAsync(page, true);
                        }
                        this.IsBusy = false;
                    });
                }

                catch (Exception e)
                {
                    this.IsBusy = false;
                }

            });
        }

        private void ExecuteDisplayOptionsCommand()
        {
            OptionsPopup options = new OptionsPopup();
            options.OnHide += Options_OnHide;
            options.OnOpenParameters += Options_OnOpenParameters;
            options.ParentPageContainer = this.PageContainer;
            this.PopupOptions.ContentView = options;
            this.PopupOptions.Show();
        }

        void Options_OnHide()
        {
            this.PopupOptions.Hide();
        }

        void Options_OnOpenParameters()
        {
            this.HideAllElements();
        }


        int TotalForceDisconnectedHit = 0;
        DateTime LastForceDisconnectedHit = DateTime.Now;
        private void ForceDisconnected()
        {
            if (DateTime.Now - LastForceDisconnectedHit <= new TimeSpan(0, 0, 0, 0, 300) && this.TotalForceDisconnectedHit == 4)
            {
                Context.ForceDisconnected = !Context.ForceDisconnected;
                this.TotalForceDisconnectedHit = 0;
            }
            else if(DateTime.Now - LastForceDisconnectedHit <= new TimeSpan(0, 0, 0, 0, 300))
            {
                this.TotalForceDisconnectedHit++;
                this.LastForceDisconnectedHit = DateTime.Now;
            }
            else
            {
                this.LastForceDisconnectedHit = DateTime.Now;
            }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}

