﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using AppCRM.Models;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using System.Linq;

using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class AddUpdateTransaction : ContentView
    {

        AddUpdateTransactionViewModel viewModel;
        TransactionProductsViewModel transactionProductsViewModel;

        private TableTools TableTools;

        private PopupBusy PopupBusy;
        private Popup PopupAddUpdateSaleProduct;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableTools.Init();
            }
        }

        public AddUpdateTransaction(TransactionTypes transactionType, string idObj = null, Transaction obj = null)
        {
            InitializeComponent();

            this.PopupBusy = new PopupBusy(this);
            this.PopupAddUpdateSaleProduct = new Popup(this) { AllowUserClose = false };

            BindingContext = viewModel = new AddUpdateTransactionViewModel(transactionType, idObj, obj);

            this.StackLayoutProducts.BindingContext = transactionProductsViewModel = new TransactionProductsViewModel(idObj, this.viewModel.Transaction);

            this.LinkedListSelectionClient.OnClick += LinkedListSelectionClient_OnClick;
            this.LinkedListSelectionGoodsRecipient.OnClick+= LinkedListSelectionGoodsRecipient_OnClick;


            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;

            this.viewModel.OnValidate += this.Validate;
            this.viewModel.OnBusy += this.Busy;
            this.viewModel.OnError += ViewModel_OnError;

            this.viewModel.OnPayTermObjectsLoaded += ViewModel_OnPayTermObjectsLoaded;
            this.viewModel.OnRefusalReasonObjectsLoaded += ViewModel_OnRefusalReasonObjectsLoaded;
            this.viewModel.OnLoadCustomer += ViewModel_OnLoadCustomer;
            this.viewModel.OnLoadGoodsRecipient += ViewModel_OnLoadGoodsRecipient;
            this.viewModel.OnNewObject += ViewModel_OnNewObject;
            /*
            viewModel.OnContactObjectsLoaded += ViewModel_OnContactObjectsLoaded;
            viewModel.OnProductObjectsLoaded += ViewModel_OnProductObjectsLoaded;
            */


            this.viewModel.Init();
            this.InitTableTools();
        }


        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayoutProducts, this.transactionProductsViewModel);
            this.TableTools.EnableGlobalSearch = false;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.HiddenAttributes = new List<string>() { "rowNo", "product" };
            this.TableTools.ArgAttributes = new List<string>() { "rowNo", "id", "product", "unitQty"};
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.ListFieldsAmount = new List<string>() { "itemValEntCurr", "price" };
            this.TableTools.OnViewClicked += TableTools_OnViewClicked;
            //this.TableTools.OnViewClicked += object_clicked;
            //this.TableTools.PaddingSearchBar = 200;
        }

        void ViewModel_OnPayTermObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListPayTerms.ItemsSource = this.viewModel.PayTermObjects;
                this.SearchableListPayTerms.SelectedItem = this.viewModel.SelectedPayTermObject;
                this.SearchableListPayTerms.OnSelection += SearchableListPayTermObjects_OnSelection;
            });
        }
        void ViewModel_OnRefusalReasonObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListRefusalReasons.ItemsSource = this.viewModel.RefusalReasonObjects;
                this.SearchableListRefusalReasons.SelectedItem = this.viewModel.SelectedRefusalReasonObject;
                this.SearchableListRefusalReasons.OnSelection += SearchableListRefusalReasonObjects_OnSelection;
            });
        }




        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
        }

        void LinkedListSelectionClient_OnClick()
        {
            this.DisplaySelectContactPage(this.CustomersPageSelection_LinkedListSelectionCustomers_OnSelection);
        }

        void LinkedListSelectionGoodsRecipient_OnClick()
        {
            this.DisplaySelectContactPage(this.CustomersPageSelection_LinkedListSelectionGoodsRecipient_OnSelection);
        }

        private void DisplaySelectContactPage(CustomersPage.OnSelectionDelegate delegateToCall)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage customersPageSelection = null;
                    switch (this.viewModel.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.ALL, true);
                            break;
                        case TransactionTypes.QUOTATION:
                            customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.ALL, true);
                            break;
                        case TransactionTypes.ORDER:
                            customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT, true);
                            break;

                    }
                    customersPageSelection.OnSelection += delegateToCall;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = customersPageSelection;
                        customersPageSelection.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void CustomersPageSelection_LinkedListSelectionCustomers_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Transaction.customer = id;
                this.viewModel.ShowAddProduct = true;
                this.LinkedListSelectionClient.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        void CustomersPageSelection_LinkedListSelectionGoodsRecipient_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Transaction.goodsRecipient = id;
                this.LinkedListSelectionGoodsRecipient.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }


        async void SearchableListPayTermObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedPayTermObject = this.SearchableListPayTerms.SelectedItem as SimpleObject;
        }

        async void SearchableListRefusalReasonObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedRefusalReasonObject = this.SearchableListRefusalReasons.SelectedItem as SimpleObject;
        }

        void ViewModel_OnLoadCustomer(Tiers tiers)
        {
            this.LinkedListSelectionClient.ContentText = tiers.descrOperLang;
        }

        void ViewModel_OnLoadGoodsRecipient(Tiers tiers)
        {
            this.LinkedListSelectionGoodsRecipient.ContentText = tiers.descrOperLang;
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ProductsPage productsPage = new ProductsPage(this.viewModel.Transaction.customer, true);
                    productsPage.OnSelection += ProductsPage_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = productsPage;
                        productsPage.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ProductsPage_OnSelection(string id, string label)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.DisplayAddUpdateSaleProductPopup(id, null);
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        private void DisplayAddUpdateSaleProductPopup(string idProduct = null, SaleProduct saleProduct = null)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                AddUpdateSaleProduct addUpdateSaleProduct = new AddUpdateSaleProduct(idProduct, saleProduct);
                this.PopupAddUpdateSaleProduct.ContentView = addUpdateSaleProduct;
                addUpdateSaleProduct.OnHide += this.PopupAddUpdateSaleProduct.OnHide;
                addUpdateSaleProduct.OnValidate += AddUpdateSaleProduct_OnValidate;
                addUpdateSaleProduct.OnDelete += AddUpdateSaleProduct_OnDelete;
                this.PopupAddUpdateSaleProduct.Show();
            });
        }

        void AddUpdateSaleProduct_OnValidate(object sender, EventArgs e)
        {
            bool found = false;
            for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
            {
                SaleProduct saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                if (saleProduct.id != null && saleProduct.id == (sender as SaleProduct).id)
                {
                    found = true;
                   /*if (saleProduct.unitQty != (sender as SaleProduct).unitQty
                       || saleProduct.tradeUnit != (sender as SaleProduct).tradeUnit)
                    {
                        //this.viewModel.SaleProductIdsToDeleteOrCancel.Add((sender as SaleProduct).rowNo);
                        (sender as SaleProduct).id = null;
                        (this.viewModel.Transaction.SubItems[i] as SaleProduct).status = "A";

                        this.Busy(true);
                        var task1 = System.Threading.Tasks.Task.Run(async () => { await this.viewModel.Save(); });
                        task1.Wait();
                        this.viewModel.Transaction.SubItems.Insert(i + 1, (sender as SaleProduct));
                        var task2 = System.Threading.Tasks.Task.Run(async () => { await this.viewModel.Save(); });
                        task2.Wait();
                        this.Busy(false);
                    }*/
                }
            }
            if(!found)
            {
                found = false;
                for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
                {
                    SaleProduct saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                    if(saleProduct.product == (sender as SaleProduct).product)
                    {
                        this.viewModel.Transaction.SubItems.RemoveAt(i);
                        this.viewModel.Transaction.SubItems.Insert(i, sender);
                        found = true;
                        break;
                    }
                }
                if(!found)
                {
                    this.viewModel.Transaction.SubItems.Add(sender);
                }
            }
            this.TableTools.Init();
        }

        void AddUpdateSaleProduct_OnDelete(object sender, EventArgs e)
        {
            bool found = false;
            for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
            {
                SaleProduct saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                if (saleProduct.id != null && saleProduct.id == (sender as SaleProduct).id)
                {
                    found = true;
                    (this.viewModel.Transaction.SubItems[i] as SaleProduct).status = "A";
                }
            }
            if(!found)
            {
                for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
                {
                    SaleProduct saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                    if (saleProduct.product == (sender as SaleProduct).product)
                    {
                        this.viewModel.Transaction.SubItems.RemoveAt(i);
                    }
                }
            }

            this.TableTools.Init();
        }


        void TableTools_OnViewClicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            switch (this.viewModel.TransactionType)
            {
                case TransactionTypes.OPPORTUNITY:
                //this.DisplayAddUpdateSaleProductPopup(null, id, dicoArgs["rowNo"]);
                //break;
                case TransactionTypes.ORDER:
                case TransactionTypes.QUOTATION:
                    //this.DisplayAddUpdateSaleProductPopup(null, id, dicoArgs["id"]);
                    //"unitQty", "tradeUnit"
                    //this.DisplayAddUpdateSaleProductPopup(dicoArgs["product"], id, dicoArgs["rowNo"], dicoArgs["unitQty"]);
                    this.DisplayAddUpdateSaleProductPopup(null, dicoArgs["_object"] as SaleProduct);
                    break;
            }
        }

    }
}
