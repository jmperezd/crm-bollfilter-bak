﻿using System;
using AppCRM.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TransactionPage : ContentView, IRefreshable
    {
        TransactionViewModel viewModel;
        TransactionProductsViewModel transactionProductsViewModel;

        private TableTools TableTools;

        private PopupBusy PopupBusy;

        private TransactionPageTypes SelectedTransactionPageType { get; set; } = TransactionPageTypes.TRANSACTION;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableTools.Init();
            }
        }

        public TransactionPage(string idTransaction, TransactionTypes transactionType)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);

            BindingContext = viewModel = new TransactionViewModel(idTransaction, transactionType);
            this.viewModel.OnBusy += ViewModel_OnBusy;
            this.viewModel.OnEdit += ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
            this.ContentFrame3.ContentView.BindingContext = viewModel;


            this.StackLayoutProducts.BindingContext = transactionProductsViewModel = new TransactionProductsViewModel(idTransaction, this.viewModel.Transaction);
           
            /*
            this.TransactionCustomTab.OnAction += CustomTab_OnAction;
            this.TransactionCustomTab.Target = TransactionPageTypes.TRANSACTION.ToString();

            this.ProductsCustomTab.OnAction += CustomTab_OnAction;
            this.ProductsCustomTab.Target = TransactionPageTypes.PRODUCTS.ToString();
            */

            this.InitTableTools();
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayoutProducts, this.transactionProductsViewModel);
            this.TableTools.EnableGlobalSearch = false;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.HiddenAttributes = new List<string>() { "rowNo", "product", "tradeUnitOrigin" };
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.ArgAttributes = new List<string>() { "rowNo" };
            this.TableTools.ListFieldsAmount = new List<string>() { "itemValEntCurr", "price" };
            //this.TableTools.OnViewClicked += object_clicked;
            //this.TableTools.PaddingSearchBar = 200;
            this.Init();
        }

        private void Init()
        {
            /*
            switch (this.SelectedTransactionPageType)
            {
                case TransactionPageTypes.TRANSACTION:
                    this.TransactionCustomTab.Selected = true;
                    this.productView.IsVisible = false;
                    this.transactionView.IsVisible = true;
                    break;
                case TransactionPageTypes.PRODUCTS:
                    this.ProductsCustomTab.Selected = true;
                    this.productView.IsVisible = true;
                    this.transactionView.IsVisible = false;
                    break;
            }
            */
        }

        private void CustomTab_OnAction(string target)
        {
            /*
            this.SelectedTransactionPageType = (TransactionPageTypes)Enum.Parse(typeof(TransactionPageTypes), target);
            switch (Enum.Parse(typeof(TransactionPageTypes), target))
            {
                case TransactionPageTypes.TRANSACTION:
                    this.TransactionCustomTab.Selected = true;
                    this.ProductsCustomTab.Selected = false;
                    break;
                case TransactionPageTypes.PRODUCTS:
                    this.ProductsCustomTab.Selected = true;
                    this.TransactionCustomTab.Selected = false;
                    break;
            }
            this.Init();
            */
        }

        public void Refresh()
        {

            var taskResfresh = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.viewModel.Refresh(); ;
            });
            taskResfresh.Wait();

            this.transactionProductsViewModel.ReInit();
            this.TableTools.Init();
        }

        void ViewModel_OnBusy(bool busy)
        {
            if(busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTransaction page = new AddUpdateTransaction(this.viewModel.TransactionType, null, this.viewModel.Transaction);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

    }

    public enum TransactionPageTypes
	{
        TRANSACTION,
        PRODUCTS
	}
}