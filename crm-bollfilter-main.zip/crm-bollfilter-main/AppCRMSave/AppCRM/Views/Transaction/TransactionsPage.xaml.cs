﻿using System;
using AppCRM.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TransactionsPage : ContentView, ITablePage
    {
        OpportunitiesViewModel opportunitiesViewModel;
        QuotationsViewModel quotationsViewModel;
        SalesViewModel salesViewModel;
        TransactionsViewModel viewModel;

        private TableTools TableToolsOpportunities;
        private TableTools TableToolsQuotations;
        private TableTools TableToolsSales;

        private PopupBusy PopupBusy;


        TransactionTypes? TransactionTypeShowed { get; set; } = null;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableToolsOpportunities.Init();
                this.TableToolsSales.Init();
                this.TableToolsQuotations.Init();
                this.Init(this.TransactionTypeShowed);
            }
        }

        public TransactionsPage(string customerId = null, TransactionTypes? transactionTypeShowed = null)
        {
            InitializeComponent();
            this.TransactionTypeShowed = transactionTypeShowed;
            NavigationPage.SetHasNavigationBar(this, false);
            
            this.BindingContext = this.viewModel = new TransactionsViewModel();
            this.viewModel.OnNewObject += ViewModel_OnNewObject;

            this.StackLayoutOpportunities.BindingContext = opportunitiesViewModel = new OpportunitiesViewModel(customerId);
            this.StackLayoutQuotations.BindingContext = quotationsViewModel = new QuotationsViewModel(customerId);
            this.StackLayoutSales.BindingContext = salesViewModel = new SalesViewModel(customerId);

            this.OpportunitiesCustomTab.OnAction += CustomTab_OnAction;
            this.OpportunitiesCustomTab.Target = TransactionTypes.OPPORTUNITY.ToString();

            this.QuotationsCustomTab.OnAction += CustomTab_OnAction;
            this.QuotationsCustomTab.Target = TransactionTypes.QUOTATION.ToString();

            this.SalesCustomTab.OnAction += CustomTab_OnAction;
            this.SalesCustomTab.Target = TransactionTypes.ORDER.ToString();

            this.OpportunitiesCustomTab.Label = this.OpportunitiesCustomTab.Label.ToUpper();
            this.QuotationsCustomTab.Label = this.QuotationsCustomTab.Label.ToUpper();
            this.SalesCustomTab.Label = this.SalesCustomTab.Label.ToUpper();

            this.InitTableTools();

        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsOpportunities = new TableTools(this.StackLayoutOpportunities, opportunitiesViewModel);
            //this.TableToolsOpportunities.EnableGlobalSearch = true;
            this.TableToolsOpportunities.LinkAttribute = "id";
            this.TableToolsOpportunities.PopupBusy = this.PopupBusy;
            this.TableToolsOpportunities.OnViewClicked += object_clicked;
            this.TableToolsOpportunities.ListFieldsAmount = new List<string>() { "totalNetAmt" };

            this.TableToolsQuotations = new TableTools(this.StackLayoutQuotations, quotationsViewModel);
            //this.TableToolsQuotations.EnableGlobalSearch = true;
            this.TableToolsQuotations.LinkAttribute = "id";
            this.TableToolsQuotations.PopupBusy = this.PopupBusy;
            this.TableToolsQuotations.OnViewClicked += object_clicked;
            this.TableToolsQuotations.ListFieldsAmount = new List<string>() { "totalNetAmt" };

            this.TableToolsSales = new TableTools(this.StackLayoutSales, salesViewModel);
            //this.TableToolsSales.EnableGlobalSearch = true;
            this.TableToolsSales.LinkAttribute = "id";
            this.TableToolsSales.PopupBusy = this.PopupBusy;
            this.TableToolsSales.OnViewClicked += object_clicked;
            this.TableToolsSales.ListFieldsAmount = new List<string>() { "totalNetAmt" };
        }

        private void Init(TransactionTypes? transactionTypeShowed = null)
        {
            switch(transactionTypeShowed != null ? transactionTypeShowed : TransactionsViewModel.LastShowedTransactionTab)
            {
                case TransactionTypes.OPPORTUNITY:
                    this.OpportunitiesCustomTab.Selected = true;
                    this.StackLayoutQuotations.IsVisible = false;
                    this.StackLayoutSales.IsVisible = false;
                    this.StackLayoutOpportunities.IsVisible = true;
                    break;
                case TransactionTypes.QUOTATION:
                    this.QuotationsCustomTab.Selected = true;
                    this.StackLayoutQuotations.IsVisible = true;
                    this.StackLayoutSales.IsVisible = false;
                    this.StackLayoutOpportunities.IsVisible = false;
                    break;
                case TransactionTypes.ORDER:
                    this.SalesCustomTab.Selected = true;
                    this.StackLayoutQuotations.IsVisible = false;
                    this.StackLayoutSales.IsVisible = true;
                    this.StackLayoutOpportunities.IsVisible = false;
                    break;
            }
        }

        private void CustomTab_OnAction(string target)
        {
            switch(Enum.Parse(typeof(TransactionTypes), target))
            {
                case TransactionTypes.OPPORTUNITY:
                    this.QuotationsCustomTab.Selected = false;
                    this.SalesCustomTab.Selected = false;
                    TransactionsViewModel.LastShowedTransactionTab = TransactionTypes.OPPORTUNITY;
                    break;
                case TransactionTypes.QUOTATION:
                    this.OpportunitiesCustomTab.Selected = false;
                    this.SalesCustomTab.Selected = false;
                    TransactionsViewModel.LastShowedTransactionTab = TransactionTypes.QUOTATION;
                    break;
                case TransactionTypes.ORDER:
                    this.OpportunitiesCustomTab.Selected = false;
                    this.QuotationsCustomTab.Selected = false;
                    TransactionsViewModel.LastShowedTransactionTab = TransactionTypes.ORDER;
                    break;
            }
            this.Init();
        }

        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    TransactionPage page;
                    if (this.OpportunitiesCustomTab.Selected == true)
                    {
                        page = new TransactionPage(id, TransactionTypes.OPPORTUNITY);
                    }
                    else if(this.QuotationsCustomTab.Selected == true)
                    {
                        page = new TransactionPage(id, TransactionTypes.QUOTATION);
                    }
                    else
                    {
                        page = new TransactionPage(id, TransactionTypes.ORDER);
                    }


                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTransaction page = new AddUpdateTransaction(TransactionsViewModel.LastShowedTransactionTab, null, null);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.TableToolsOpportunities.Init();
            this.TableToolsQuotations.Init();
            this.TableToolsSales.Init();
        }

    }
}