﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;

namespace AppCRM.Views
{
    public partial class NotePage : ContentView, IRefreshable
    {
        private NoteViewModel viewModel { get; set; }

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public NotePage(string id)
        {
            InitializeComponent();
            BindingContext = viewModel = new NoteViewModel(id);
            this.viewModel.OnEdit += ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateNote page = new AddUpdateNote(null, this.viewModel.Note);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.viewModel.Refresh();
        }

    }
}
