﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class Configuration : ContentPage
    {

        ConfigurationViewModel viewModel;

        public Configuration(INavigation iNavigation)
        {
            InitializeComponent();
            BindingContext = viewModel = new ConfigurationViewModel(iNavigation);

            Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);
            this.Entry1.Keyboard = keyboard;
            this.Entry2.Keyboard = keyboard;
            this.Entry3.Keyboard = keyboard;
            this.Entry4.Keyboard = keyboard;
            this.Entry5.Keyboard = keyboard;

            this.Entry1.Completed += (s, e) => this.Entry2.Focus();
            this.Entry2.Completed += (s, e) => this.Entry3.Focus();
            this.Entry3.Completed += (s, e) => this.Entry4.Focus();
            this.Entry4.Completed += (s, e) => this.Entry5.Focus();

        }
    }
}
