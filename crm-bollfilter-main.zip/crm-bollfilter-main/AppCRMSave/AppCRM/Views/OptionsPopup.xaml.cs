﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using AppCRM_Shared.Classes;
using AppCRM_Shared;

namespace AppCRM.Views
{
    public partial class OptionsPopup : ContentView
    {
        public Command DisplayParameterCommand { get; set; }
        public delegate void OnHideDelegate();
        public event OnHideDelegate OnHide;
        public delegate void OnOpenParametersDelegate();
        public event OnOpenParametersDelegate OnOpenParameters;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Context Context
        {
            get { return Context.Instance; }
        }


        public OptionsPopup()
        {
            InitializeComponent();

            this.DisplayParameterCommand = new Command(async () => await ExecuteGoToParameterCommand());

            this.DeconnexionButton.BindingContext = Context.Instance;
            this.ParametersButton.Text = this.ParametersButton.Text.ToUpper();
            this.DeconnexionButton.Text = this.DeconnexionButton.Text.ToUpper();

            this.ContentFrame1.ContentView.BindingContext = this;

        }

        private void Hide()
        {
            if (this.OnHide != null)
            {
                this.OnHide();
            }
        }

        #region NavigationParameter

        async System.Threading.Tasks.Task ExecuteGoToParameterCommand()
        {
            try
            {
                Parameters page = new Parameters();
                page.ParentPageContainer = this.ParentPageContainer;
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ParentPageContainer.Content = page as ContentView;
                    page.ParentPageContainer = this.parentPageContainer;
                });
                this.Hide();
                if(this.OnOpenParameters != null)
                {
                    this.OnOpenParameters();
                }

            }
            catch (Exception ex)
            {

            }


        }
        #endregion



        #region Parameters
        //Parameter page = new Parameter();
        //page.ParentPageContainer = this.ParentPageContainer;

        //Device.BeginInvokeOnMainThread(() =>
        //{

        //    //this.ParentPageContainer.Content = page;

        //});

        #endregion

    }
}
