﻿using System;
using AppCRM.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ContactsPage : ContentView, ITablePage
    {
        ContactsViewModel viewModel;
        private TableTools TableTools;
        private PopupBusy PopupBusy;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.TableTools.Init();
            }
        }

        public ContactsPage(CustomerTypes customerType, string contactId = null)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = viewModel = new ContactsViewModel(customerType, contactId);
            this.viewModel.OnDisplayMap += ViewModel_OnDisplayMap;
            this.viewModel.OnNewObject += ViewModel_OnNewObject;

            this.InitTableTools();
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayout1, viewModel);
            this.TableTools.EnableGlobalSearch = true;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.OnViewClicked += object_clicked;
        }

        void ViewModel_OnDisplayMap(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ContactsMap page = new ContactsMap(this.viewModel.IdContact, this.viewModel.CustomerType);
                    page.ParentPageContainer = this.ParentPageContainer;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ContactPage page = new ContactPage(id, this.viewModel.CustomerType);
                    page.ParentPageContainer = this.ParentPageContainer;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            /*
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateContact page = new AddUpdateContact();
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
            */
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.TableTools.Init();
        }
    }
}
