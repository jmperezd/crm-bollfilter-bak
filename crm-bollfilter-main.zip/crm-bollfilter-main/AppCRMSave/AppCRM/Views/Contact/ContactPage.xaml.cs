﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using AppCRM_Shared.Models;
using WFramework_Xamarin.Table;

namespace AppCRM.Views
{
    public partial class ContactPage : ContentView, IRefreshable
    {
        private ContactViewModel viewModel { get; set; }

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Popup PopupNewObject;


        public ContactPage(string id, CustomerTypes customerType)
        {
            InitializeComponent();
            BindingContext = viewModel = new ContactViewModel(id, customerType);
            this.viewModel.OnNewObject += this.ViewModel_OnNewObject;
            this.viewModel.OnEdit += this.ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
            this.ContentFrame3.ContentView.BindingContext = viewModel;
            this.ContentFrame4.ContentView.BindingContext = viewModel;

            this.PopupNewObject = new Popup(this);


            this.LabelNotes.Text = this.LabelNotes.Text.ToUpper();
            this.LabelTasks.Text = this.LabelTasks.Text.ToUpper();
            this.LabelOrders.Text = this.LabelOrders.Text.ToUpper();
            this.LabelQuotations.Text = this.LabelQuotations.Text.ToUpper();
            this.LabelOpportunities.Text = this.LabelOpportunities.Text.ToUpper();

            NotesStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new NotesPage(id)))
            });
            TasksStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TasksPage(id)))
            });
            OpportunitiesStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.OPPORTUNITY)))
            });
            QuotationsStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.QUOTATION)))
            });
            OrdersStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.ORDER)))
            });

            LinkMail.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.Mail(this.viewModel.Tiers.emailAddr))
            });
            LinkWebSite.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.WebSite(this.viewModel.Tiers.webSiteURL))
            });
            LinkAddress.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Tiers.zipCode + "," + this.viewModel.Tiers.town + "," + this.viewModel.Tiers.addr + "," + this.viewModel.Tiers.street))
            });
            LinkAddress2.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Tiers.zipCode2 + "," + this.viewModel.Tiers.town2 + "," + this.viewModel.Tiers.addr2 + "," + this.viewModel.Tiers.street2))
            });
        }

        private void ShowPage(ITablePage page)
        {
            //this.PopupBusy.Show();
            try
            {
                Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ParentPageContainer.Content = page as ContentView;
                    page.ParentPageContainer = this.parentPageContainer;
                    //this.PopupBusy.Hide();
                });

            }
            catch (Exception ex)
            {
                //this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });

                    AddUpdateCustomer page = new AddUpdateCustomer(this.viewModel.CustomerType, null, this.viewModel.Tiers);

                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            TiersActionPage page = new TiersActionPage(this.viewModel.Tiers.id);
            page.ParentModel = this.viewModel;
            page.ParentPageContainer = this.ParentPageContainer;

            this.PopupNewObject.ContentView = page;
            this.PopupNewObject.Show();
        }

        public void Refresh()
        {
            this.viewModel.Refresh();
        }


    }
}
