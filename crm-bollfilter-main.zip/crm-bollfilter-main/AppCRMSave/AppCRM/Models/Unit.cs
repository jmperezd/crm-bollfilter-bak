﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class Unit : Model, IModel
    {
        public Unit()
        {
            base.DefaultHeadFieldsString = Constants.URI_UNIT_HEADFIELDS;
        }

        public Unit(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_UNIT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string unitIdentifier { get; set; } 
        public string descrOperLang { get; set; } //Titre

    }
}
