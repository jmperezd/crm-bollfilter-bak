﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;

namespace AppCRM.Models
{
    public class Product : Model, IModel
    {
        public Product()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRODUCT_HEADFIELDS;
        }
        public Product(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_PRODUCT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [JsonIgnore]
        public string all {
            get { return this.idno + " " + this.searchExtLower + " " + this.descrOperLangLower; }
        }

        public string idno { get; set; }
        public string descrOperLang { get; set; }
        [JsonIgnore]
        public string descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.descrOperLang) ? this.descrOperLang.ToLower() : string.Empty; } }
        public string salesTradeUnit { get; set; } //Unité à proposer par défaut
        public string purchPriceUnit { get; set; } //
        public string SU { get; set; } // 
        public double purchPrice { get; set; }
        public bool ysynccrm { get; set; }
        public string searchExt { get; set; }
        [JsonIgnore]
        public string searchExtLower { get { return !string.IsNullOrWhiteSpace(this.searchExt) ? this.searchExt.ToLower() : string.Empty; } }


        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("descrOperLang");
                defaultIndexes.Add("searchExtLower");
                defaultIndexes.Add("all");
                return defaultIndexes;
            }
        }

        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;//new List<FilterField>() { new FilterField() { FieldName = "ysynccrm", Operator = "==", Value = "True" } };

            }
        }

        //Calcul du prix
        //http://rdp.abas-france.fr:10080/mw/r/demo/workspace/ws-151/wip/ep-4d9cb71c-dcd0-436d-bf73-697a8436ebda?variableLanguage=EN
        //http://rdp.abas-france.fr:10080/mw/r/demo/sys/typeCmd/(PriceInformation)
        //Id du client dans custVendor
        //Id product dans product
        //quantité dans unitQty
        //unité de vente dans tradeUnit

        //Date de conditionnement condDate
    }
}
