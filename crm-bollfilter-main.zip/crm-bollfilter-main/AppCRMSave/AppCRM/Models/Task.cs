﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class Task : Model, IModel
    {
        public Task()
        {
            base.DefaultHeadFieldsString = Constants.URI_TASK_HEADFIELDS;
        }

        public Task(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_TASK;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string status { get; set; }
        public string swd { get; set; } //clé de recherche
        [JsonIgnore]
        public string swdLower { get { return !string.IsNullOrWhiteSpace(this.swd) ? this.swd.ToLower() : string.Empty; } } //Clé de recherche
        public string keyWord { get; set; } //Mot-clé
        public string descrOperLang { get; set; } //Titre
        public string prio { get; set; } //Priorité

        [JsonProperty(PropertyName = "prio^descrOperLang")]
        public string prio_descrOperLang {get; set;}
        public bool ShouldSerializeprio_descrOperLang()
        {
            return false;
        }

        [ForeignKeyID]
        public string purchSalesTrans { get; set; }
        [JsonProperty(PropertyName = "purchSalesTrans^purchSalesTrans")]
        public string purchSalesTrans_purchSalesTrans { get; set; }
        public bool ShouldSerializepurchSalesTrans_purchSalesTrans()
        {
            return false;
        }

        public DateTime endDate { get; set; } //Date
        [ForeignKeyID]
        public string confirm { get; set; } //Responsable (planifié par?)
        [JsonProperty(PropertyName = "confirm^descrOperLang")]
        public string confirm_descrOperLang { get; set; }
        public bool ShouldSerializeconfirm_descrOperLang()
        {
            return false;
        }

        //Utiles dans l'écran d'édition :
        public string descrTextModuleOperLang { get; set; } //Description

        public string editor { get; set; }//Opérateur (planifié pour?)
        [JsonProperty(PropertyName = "editor^descrOperLang")]
        public string editor_descrOperLang { get; set; }
        public bool ShouldSerializeeditor_descrOperLang()
        {
            return false;
        }

        public string businessPartner { get; set; } //Partenaire commercial (contact ?)

        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("swdLower");
                return l;
            }
        }


    }
}
