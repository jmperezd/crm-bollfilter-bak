﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class WebRole : Model, IModel
    {
        public WebRole()
        {
            base.DefaultHeadFieldsString = "id,roleRef,roleRef^swdn,userTab";
        }

        public WebRole(string _id) : this()
        {
            id = _id;
        }

        public string BasePath
        {
            get
            {
                return "/obj/data/93:2";
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string roleRef { get; set; }
        [JsonProperty(PropertyName = "roleRef^swd")]
        public string roleRef_swd { get; set; }
        public string userTab { get; set; }
    }
}
