﻿using System;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using System.Collections.Generic;

namespace AppCRM.Models
{
    public class ActivityObject: Model, IModel
    {
        public int Notes { get; set; } = 0;
        public int Taches { get; set; } = 0;
        public int Opportunites { get; set; } = 0;
        public int Offres { get; set; } = 0;
        public int Commandes { get; set; } = 0;

        public String BasePath
        {
            get
            {
                return Constants.URI_INFOSYS + Constants.URI_INFOSYS_ACTIVITY;
            }
        }

        public double OpportunitesValeur { get; set; } = 0;
        public string OpportunitesValeurDisplay
        {
            get
            {
                return DisplayTools.FormatAmount(this.OpportunitesValeur, "");
            }
        }

        public double OffresValeur { get; set; } = 0;
        public string OffresValeurDisplay
        {
            get
            {
                return DisplayTools.FormatAmount(this.OffresValeur, "");
            }
        }

        public double CommandesValeur { get; set; } = 0;
        public string CommandesValeurDisplay
        {
            get
            {
                return DisplayTools.FormatAmount(this.CommandesValeur, "");
            }
        }

        public ActivityObject()
        {
            base.DefaultHeadFieldsString = Constants.URI_INFOSYS_ACTIVITY_HEADFIELDS;
            base.DefaultTableFieldsString = Constants.URI_INFOSYS_ACTIVITY_TABLEFIELDS;
        }

        public ActivityObject(dynamic d) : this()
        {
            List<Table> tab = new List<Table>();
            foreach (dynamic item in d)
            {

                tab.Add(item.ToObject<Table>());
            }

            foreach (dynamic item in tab)
            {
                if (item.tvktypa == "(Opportunity)")
                {
                    this.Opportunites = item.tabsvorkommen;
                    this.OpportunitesValeur = item.tnettowert;
                }
                else if (item.tvktypa == "(Quotation)")
                {
                    this.Offres = item.tabsvorkommen;
                    this.OffresValeur = item.tnettowert;
                }
                else if (item.tvktypa == "(SalesOrder)")
                {
                    this.Commandes = item.tabsvorkommen;
                    this.CommandesValeur = item.tnettowert;
                }
            }
        }
    }
}