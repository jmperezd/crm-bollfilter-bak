﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace AppCRM.Models
{

    public class RootObject
    {
        //[JsonProperty] 
        public List<ActionActivity> actions { get; set; }

        public List<Table> table { get; set; }
        //[JsonProperty] 
        public string headFields { get; set; }
        //[JsonProperty] 
        public string tableFields { get; set; }

        public RootObject()
        {
            this.actions = new List<ActionActivity>();
        }

    }

}