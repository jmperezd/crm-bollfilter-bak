﻿using System; 
namespace AppCRM.Models 
{ 
    public class Table 
    { 
        public int tabsvorkommen { get; set; } 
        public double tnettowert { get; set; } 
        public string tvktypa { get; set; } 
    } 
} 