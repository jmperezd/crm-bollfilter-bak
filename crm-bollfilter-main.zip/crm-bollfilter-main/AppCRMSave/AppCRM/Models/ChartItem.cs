﻿using System;
namespace AppCRM.Models
{
    public class ChartItem
    {
        public string Label { get; set; }
        public double Value { get; set; }
    }
}
