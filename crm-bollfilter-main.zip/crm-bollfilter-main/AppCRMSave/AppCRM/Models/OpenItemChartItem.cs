﻿using System;
namespace AppCRM.Models
{
    public class OpenItemChartItem : ChartItem
    {
        public string ValueLabel { get; set; }
    }
}
