﻿using System;
namespace AppCRM.Models.Print
{
    public class PrintParameterLayout : Model, IModel
    {
        public PrintParameterLayout()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRINTLAYOUT_HEADFIELS;
        }
        public PrintParameterLayout(string _id) : this()
        {
            id = _id;
        }

        public string BasePath
        {
            get
            {
                return Constants.URI_PRINTPARAMETERLAYOUT;
            }
        }

        public string id { get; set; }
        public int idno { get; set; }
        public string swd { get; set; }
        public string descroperLang { get; set; }

    }
}