﻿using System;
namespace AppCRM.Models
{
    public enum CustomerTypes
    {
        CUSTOMER,
        PROSPECT,
        CONTACT_CUSTOMER,
        CONTACT_PROSPECT,
        ALL
    }
}
