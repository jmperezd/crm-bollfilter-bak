﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class CustomerAndContact : Tiers, IModel
    {
        public CustomerAndContact()
            : base(new List<String> { "1", "2" })
        {
            base.DefaultHeadFieldsString = Constants.URI_CUSTOMER_HEADFIELDS;
        }

        public CustomerAndContact(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_CUSTOMER;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }


        public string rep { get; set; }//Representant
        /*
        [JsonIgnore]
        public string InfoSysPath
        {
            get
            {
                return "/st/LKU";
            }
        }

        [JsonIgnore]
        public string InfoSysMember
        {
            get
            {
                return "tnum";
            }
        }
*/
    }
}
