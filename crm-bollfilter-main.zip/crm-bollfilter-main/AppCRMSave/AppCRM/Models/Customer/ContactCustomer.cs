﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class ContactCustomer : Tiers, IModel
    {
        public ContactCustomer()
            : base("2")
        {
            base.DefaultHeadFieldsString = Constants.URI_CONTACT_CUSTOMER_HEADFIELDS;
        }

        public ContactCustomer(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_CONTACT_CUSTOMER;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }

        public string companyARAP { get; set; }
        [JsonProperty(PropertyName = "companyARAP^rep")]
        public string companyARAP_rep { get; set; }
        public bool ShouldSerializecompanyARAP_rep()
        {
            return false;
        }
        [JsonIgnore]
        public string rep { get { return this.companyARAP_rep; } }

        [JsonIgnore]
        public string InfoSysPath
        {
            get
            {
                return "/st/KONTAKT";
            }
        }

        [JsonIgnore]
        public string InfoSysMember
        {
            get
            {
                return "idno";
            }
        }

    }
}
