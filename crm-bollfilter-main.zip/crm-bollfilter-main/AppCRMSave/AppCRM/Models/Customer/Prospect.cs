﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class Prospect : Tiers, IModel
    {
        public Prospect()
            : base("6")
        {
			base.DefaultHeadFieldsString = Constants.URI_PROSPECT_HEADFIELDS;
        }

		public Prospect(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_PROSPECT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }

        public string repDescr { get; set; }
        public bool ShouldSerializerepDescr()
        {
            return false;
        }

    }
}
