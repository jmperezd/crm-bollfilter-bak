﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class SaleProduct : Model, IModel
    {
        public SaleProduct()
        {
            base.DefaultHeadFieldsString = Constants.URI_SALE_PRODUCT_HEADFIELDS;
        }

        public SaleProduct(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_SALE_PRODUCT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [ForeignKeyID]
        public string head { get; set; }

        public bool ShouldSerializeid()
        {
            return false;
        }
        public string product { get; set; }
        public string status { get; set; }
        [JsonProperty(PropertyName = "product^descrOperLang")]
        public string product_descrOperLang { get; set; }
        public bool ShouldSerializeproduct_descrOperLang()
        {
            return false;
        }

        public string rowNo { get; set; }
        public bool ShouldSerializerowNo()
        {
            return false;
        }

        public string unitQty { get; set; }
        public string tradeUnit { get; set; }
        /*[JsonProperty(PropertyName = "tradeUnit^descrOperLang")]
        public string tradeUnit_descrOperLang { get; set; }
        public bool ShouldSerializetradeUnit_descrOperLang()
        {
            return false;
        }*/
        public string price { get; set; }
        public bool ShouldSerializeprice()
        {
            return false;
        }
        public string percent { get; set; }
        public bool ShouldSerializepercent()
        {
            return false;
        }
        public string itemValEntCurr { get; set; }
        public bool ShouldSerializeitemValEntCurr()
        {
            return false;
        }
        public string productDescr { get; set; }
        public bool ShouldSerializeproductDescr()
        {
            return false;
        }
        public string recordNo { get; set; }
        public bool ShouldSerializerecordNo()
        {
            return false;
        }
        public DateTime startDateTime { get; set; }
        public bool ShouldSerializestartDateTime()
        {
            return false;
        }



        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("head");
                defaultIndexes.Add("product_descrOperLang");
                return defaultIndexes;
            }
        }
    }
}
