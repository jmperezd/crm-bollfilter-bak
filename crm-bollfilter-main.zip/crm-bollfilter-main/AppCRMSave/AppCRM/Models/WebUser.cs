﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class WebUser : Model, IModel
    {
        public WebUser()
        {
            base.DefaultHeadFieldsString = "login,pwd,id,webRoleList";
        }

        public WebUser(string _id) : this()
        {
            id = _id;
        }

        public override string BasePath
        {
            get
            {
                return Constants.URI_WEBUSERS;
            }
        }

        public string login { get; set; }
        public string pwd { get; set; }
        public string webRoleList { get; set; }

        [JsonIgnore]
        public string RoleEmployee { get; set; } // Employé associé au rôle pointe vers la table employee
        [JsonIgnore]
        public string RoleSalesRep { get; set; } // Commercial associé au rôle /!\ pointe vers la table des clients

    }
}
