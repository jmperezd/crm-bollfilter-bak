﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class WebRoleList : Model, IModel
    {
        public WebRoleList()
        {
            base.DefaultHeadFieldsString = "id";
        }

        public WebRoleList(string _id) : this()
        {
            id = _id;
        }

        public string BasePath
        {
            get
            {
                return "/obj/data/93:4";
            }
        }
    }
}
