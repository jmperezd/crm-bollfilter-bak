﻿using System;
namespace AppCRM.Models
{
    public class User
    {
        public string code { get; set; }
        public string email { get; set; }
        public string name { get; set; }
        public string loginName { get; set; }
        public string account { get; set; }
        public string employee { get; set; }
    }
}
