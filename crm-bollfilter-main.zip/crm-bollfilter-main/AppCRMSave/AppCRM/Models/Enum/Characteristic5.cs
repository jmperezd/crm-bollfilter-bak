﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace AppCRM.Models
{
    public class Characteristic5 : EnumReference, IModel
    {
        public Characteristic5()
        {
            base.DefaultTableFieldsString = "enumIdentifier,enumDescr";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(173,107,0)";
            }
        }


    }
}
