﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace AppCRM.Models
{
    public class Characteristic4 : EnumReference, IModel
    {
        public Characteristic4()
        {
            base.DefaultTableFieldsString = "enumIdentifier,enumDescr";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(172,107,0)";
            }
        }


    }
}
