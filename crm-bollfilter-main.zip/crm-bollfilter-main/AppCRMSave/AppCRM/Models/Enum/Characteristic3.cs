﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace AppCRM.Models
{
    public class Characteristic3 : EnumReference, IModel
    {
        public Characteristic3()
        {
            base.DefaultTableFieldsString = "enumIdentifier,enumDescr";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(171,107,0)";
            }
        }


    }
}
