﻿using System;
using LiteDB;
using Newtonsoft.Json;

namespace AppCRM.Models
{
    public class EnumReference : Model
    {
        public string enumIdentifier { get; set; }
        public string enumDescr { get; set; }
        [JsonIgnore]
        public string id
        {
            get { return this.enumIdentifier; }
            set { }
        }

        [JsonIgnore]
        [BsonIgnore]
        public string enumIdentifierComplete
        {
            get
            {
                return "(" + this.enumIdentifier + ")";
            }
        }

    }
}

