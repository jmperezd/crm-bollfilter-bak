﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace AppCRM.Models
{
    public class Characteristic6 : EnumReference, IModel
    {
        public Characteristic6()
        {
            base.DefaultTableFieldsString = "enumIdentifier,enumDescr";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(174,107,0)";
            }
        }


    }
}
