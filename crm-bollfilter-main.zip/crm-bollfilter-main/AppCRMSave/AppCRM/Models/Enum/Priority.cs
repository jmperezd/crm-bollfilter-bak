﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace AppCRM.Models
{
    public class Priority : EnumReference, IModel
    {
        public Priority()
        {
            base.DefaultTableFieldsString = "enumIdentifier,enumDescr";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(167,107,0)";
            }
        }


    }
}
