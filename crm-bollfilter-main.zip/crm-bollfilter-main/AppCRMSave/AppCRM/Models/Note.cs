﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static AppCRM.Services.Utils;

namespace AppCRM.Models
{
    public class Note : Model, IModel
    {
        public Note()
        {
            base.DefaultHeadFieldsString = Constants.URI_NOTE_HEADFIELDS;
        }
        
        public Note(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_NOTE;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public int idno { get; set; }
        public bool ShouldSerializeidno()
        {
            return false;
        }
        public string swd { get; set; }
        [JsonIgnore]
        public string swdLower { get { return !string.IsNullOrWhiteSpace(this.swd) ? this.swd.ToLower() : string.Empty; } } //Clé de recherche

        public string type { get; set; }
        public bool ShouldSerializetype()
        {
            if (string.IsNullOrWhiteSpace(type))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        [JsonProperty(PropertyName = "type^descrOperLang")]
        public string type_descrOperLang { get; set; }
        public bool ShouldSerializetype_descrOperLang()
        {
            return false;
        }

        public string descrOperLang { get; set; }
        public string descrTextModuleOperLang { get; set; }
        [ForeignKeyID]
        public string triggerOfEnt { get; set; }
        [ForeignKeyID]
        public string businessPartner { get; set; }
        public bool ShouldSerializebusinessPartner()
        {
            if (string.IsNullOrWhiteSpace(businessPartner))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        [ForeignKeyID]
        public string productListElem { get; set; }
        [ForeignKeyID]
        public string purchSalesTrans { get; set; }
        public string purchSalesTransExt { get; set; }

        public string intProcess { get; set; }
        [ForeignKeyID]
        public string editor { get; set; }
        [JsonProperty(PropertyName = "editor^descrOperLang")]
        public string editor_descrOperLang { get; set; }
        public bool ShouldSerializeeditor_descrOperLang()
        {
            return false;
        }

        public string prio { get; set; }
        public DateTime date { get; set; }
        public bool ShouldSerializedate()
        {
            return false;
        }
        public DateTime currTime { get; set; }
        public bool ShouldSerializecurrTime()
        {
            return false;
        }


        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("swdLower");
                return l;
            }
        }

    }
}
