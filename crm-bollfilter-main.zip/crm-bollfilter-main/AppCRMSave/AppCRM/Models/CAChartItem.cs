﻿using System;
namespace AppCRM.Models
{
    public class CAChartItem : ChartItem
    {
        public string Month { get; set; }
    }
}
