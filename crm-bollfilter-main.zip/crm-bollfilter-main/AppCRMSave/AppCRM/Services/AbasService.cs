﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using AppCRM.Models;
using Newtonsoft.Json;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using Xamarin.Forms;
using System.Net.Http;
using QuickLook;
using UIKit;
using Foundation;
using System.Text.RegularExpressions;

[assembly: Xamarin.Forms.Dependency(typeof(AppCRM.Services.AbasService))]
namespace AppCRM.Services
{
    public partial class AbasService : IAbasService
    {
        private static string _serverUrl = null;
        private static string _instancePath = null;
        public string _username = null;
        private string _password = null;
        public static string BaseUriString { get { return _serverUrl + _instancePath; } }

        public string Username
        {
            get { return this._username; }
        }

        #region Common

        public bool IsAuthenticated()
        {
            return !String.IsNullOrWhiteSpace(_serverUrl)
                   && !String.IsNullOrWhiteSpace(_instancePath)
                   && !String.IsNullOrWhiteSpace(_username)
                   && !String.IsNullOrWhiteSpace(_password);
        }

        #endregion

        #region Authentication
        private Uri GetLoginUri() { return new Uri(BaseUriString); }
        public async System.Threading.Tasks.Task<bool> LoginAsync(string serverUrl, string instancePath, string username, string password)
        {
#if DEBUG
            // En mode debug si on ne passe pas un des 3 arguments on le prérempli
            if (String.IsNullOrWhiteSpace(serverUrl))
            {
                serverUrl = Constants.DEV_SERVER_URL;
            }
            if (String.IsNullOrWhiteSpace(instancePath))
            {
                instancePath = Constants.DEV_INSTANCE_PATH;
            }
            if (String.IsNullOrWhiteSpace(username))
            {
                username = Constants.DEV_USERNAME;
            }
            if (String.IsNullOrWhiteSpace(password))
            {
                password = Constants.DEV_PASSWORD;
            }
#endif

            if (String.IsNullOrWhiteSpace(serverUrl))
            {
                throw new ArgumentNullException(nameof(serverUrl));
            }
            else if (String.IsNullOrWhiteSpace(instancePath))
            {
                throw new ArgumentNullException(nameof(instancePath));
            }
            else if (String.IsNullOrWhiteSpace(username))
            {
                throw new ArgumentNullException(nameof(username));
            }
            else if (String.IsNullOrWhiteSpace(password))
            {
                throw new ArgumentNullException(nameof(password));
            }

            _serverUrl = serverUrl;
            _instancePath = instancePath;
            this._username = username;
            this._password = password;

            if (Context.Instance.IsConnected)
            {
                Uri myUri = new Uri(serverUrl + instancePath);

                //Création de la requète à l'aide du webRequest avec différentes propriétés
                var request = WebRequest.Create(myUri);
                request.ContentType = Constants.WEBREQUEST_CONTENT_TYPE;

                ((HttpWebRequest)request).Accept = Constants.WEBREQUEST_ACCEPT;
                request.Headers.Set(HttpRequestHeader.AcceptLanguage, Constants.WEBREQUEST_ACCEPT_LANGUAGE);
                request.Method = Constants.WEBREQUEST_GET;


                //Ajout d'identifiants de connexion à l'API
                NetworkCredential myNetworkCredentials = new NetworkCredential(username, password);
                CredentialCache myCredentialCache = new CredentialCache
                {
                    { myUri, Constants.WEBREQUEST_AUTH_BASIC, myNetworkCredentials }
                };
                request.Credentials = myCredentialCache;
                request.PreAuthenticate = true;

                try
                {
                    //Récupération de la réponse depuis l'API.            
                    WebResponse myResponse = await request.GetResponseAsync();
                    Stream responseStream = myResponse.GetResponseStream();
                    StreamReader myStreamReader = new StreamReader(responseStream, Encoding.Default);


                    //Stockage de la réponse dans une variable string et fermeture des flux
                    string pageContent = myStreamReader.ReadToEnd();
                    responseStream.Close();
                    myResponse.Close();
                }
                catch (Exception e)
                {
                    return false;
                }


            }
            else
            {
                return true;
            }

            return true;
        }

        /*
        private Uri GetCA(string id, int annee)
        {
            return new Uri(GetBaseUriString() + Constants.URI_CA + Constants.URI_CA_PARAMS + Constants.URI_CA_CRITERIA + "mainObj==" + id + ";" + "FY=" + annee);
        }

        public async System.Threading.Tasks.Task<Models.turnover> GetTurnoverAsync(string id, int annee)
        {
            string pageContent = await ExecuteGetRequestAsync(this.GetCA(id, annee));
            dynamic j = JsonConvert.DeserializeObject(pageContent);
            dynamic a = j.erpDataObjects[0];
            turnover test = a.head.ToObject<Models.turnover>();
            return test;
        }
        */

        #endregion Authentication API

        private Uri GetUserUri() { return new Uri(BaseUriString + "/userInfo"); }

        public async System.Threading.Tasks.Task<Models.User> GetCurrentUserAsync()
        {
            WebRequest request = AbasRequests.PrepareAbasRequest(GetUserUri(), _username, _password);
            WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
            string pageContent = AbasRequests.ReadWebResponse(response);  // ExecuteGetRequestAsync(this.GetUserUri());
            dynamic j = JsonConvert.DeserializeObject(pageContent);
            User test = j.ToObject<Models.User>();
            return test;
        }


        


        #region Activity

        public async System.Threading.Tasks.Task<ActivityObject> GetActivity(string ID = null)
        {
            ActivityObject activityObject;
            if (Context.Instance.IsConnected)
            {
                AbasInfoSystem abasInfoSystem = new AbasInfoSystem(_username, _password);
                abasInfoSystem.ActionSetFieldValueAsync("vkanko", "true");
                abasInfoSystem.ActionSetFieldValueAsync("vkabko", "true");
                abasInfoSystem.ActionSetFieldValueAsync("vomvom", "");
                abasInfoSystem.ActionSetFieldValueAsync("vombis", "");
                if (ID != null)
                {
                    abasInfoSystem.ActionSetFieldValueAsync("vkpartner", ID);
                }
                abasInfoSystem.ActionSetFieldValueAsync("betreuer", "");
                dynamic j = await abasInfoSystem.Execute<ActivityObject>();

                dynamic table = j.table;
                activityObject = new ActivityObject(table);
            }
            else
            {
                activityObject = new ActivityObject();

                var opportunities = await this.ReadList<Opportunity>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "customer", Operator = "==", Value = ID } });
                activityObject.Opportunites = opportunities.Count;
                try
                {
                    activityObject.OpportunitesValeur = opportunities.Sum(o => int.Parse(o.totalGrossAmtDom));
                }
                catch(Exception e)
                {

                }


                var quotations = await this.ReadList<Quotation>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "customer", Operator = "==", Value = ID } });
                activityObject.Offres = quotations.Count;
                try
                {
                    activityObject.OffresValeur = quotations.Sum(o => int.Parse(o.totalGrossAmtDom));
                }
                catch (Exception e)
                {

                }


                var orders = await this.ReadList<Order>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "customer", Operator = "==", Value = ID } });
                activityObject.Commandes = orders.Count;
                try
                {
                    activityObject.CommandesValeur = orders.Sum(o => int.Parse(o.totalGrossAmtDom));
                }
                catch (Exception e)
                {

                }

                //TODO: remplir les valeurs avec les données hors ligne
            }

            var notes = await this.ReadList<Note>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "businessPartner", Operator = "==", Value = ID } });
            activityObject.Notes = notes.Count;

            var taches = await this.ReadList<AppCRM.Models.Task>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "businessPartner", Operator = "==", Value = ID } });
            activityObject.Taches = taches.Count;

            return activityObject;
        }

        #endregion

        #region Impression

        //Déclaration des Uri à utiliser

        private Uri GetOpenCustomerViewUri(string UriEcran, string id) { return new Uri(BaseUriString + UriEcran + "/" + id + "/commands/VIEW?filterHeadFields=budruck"); }
        private Uri GetOpenPrintViewUri(string UriEcranPrint) { return new Uri(_serverUrl + UriEcranPrint + "/fields/head/budruck/commands/SUBEDIT?filterHeadFields=layout,datname,drucker"); }
        private Uri GetOpenLinkFilesUri(string UriEcranPrintLink) { return new Uri(_serverUrl + UriEcranPrintLink); }

        // Récupération du lien de la fenêtre d'impression de l'écran souhaité
        /// <summary>
        /// Prints the impression.
        /// </summary>
        /// <returns>The impression.</returns>
        /// <param name="id">Correspond à l'id de l'objet demandé</param>
        /// <typeparam name="T">The 1st type parameter.</typeparam>
        public async Task<Uri> PrintImpression<T>(string id)
        where T : IModel, new()
        {
            T foo = new T();
            // Récupération du lien de la fenêtre d'impression de l'écran souhaité
            //---------------------------------------------------------------------------------------------------
            WebRequest request = AbasRequests.PrepareAbasRequest(GetOpenCustomerViewUri(foo.BasePath, id), this._username, this._password);
            request.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request).Accept = Constants.ABAS_SIMPLE_JSON;
            request.Method = "POST";
            WebResponse Webresponse = await AbasRequests.ExecuteRequestAsync(request);
            string response = AbasRequests.ReadWebResponse(Webresponse);
            dynamic reponse1deserialise = JsonConvert.DeserializeObject(response);
            string link1 = reponse1deserialise.meta.link.href;
            //---------------------------------------------------------------------------------------------------


            // Ouverture de la fenêtre de selection de la mise en page et des paramètres voulus
            //---------------------------------------------------------------------------------------------------
            WebRequest request2 = AbasRequests.PrepareAbasRequest(GetOpenPrintViewUri(link1), this._username, this._password);
            request2.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request2).Accept = Constants.ABAS_SIMPLE_JSON;
            request2.Method = "POST";
            WebResponse Webresponse2 = await AbasRequests.ExecuteRequestAsync(request2);
            string response2 = AbasRequests.ReadWebResponse(Webresponse2);
            dynamic reponse2deserialise = JsonConvert.DeserializeObject(response2);
            string link2 = reponse2deserialise.meta.link.href;
            //---------------------------------------------------------------------------------------------------


            // Récupération du lien menant à la fenetre contenant le lien du dl
            //---------------------------------------------------------------------------------------------------
            Uri linkDl = GetOpenLinkFilesUri(link2);
            RootObject
            ro = new RootObject();

            string LayoutValue()
            {
                if (foo.BasePath == "/obj/data/3:21")
                {
                    //ParametersViewModel parameters = new ParametersViewModel();
                    return App.QuotationLayout != null ? App.QuotationLayout : "XMASTER";
                }
                else if (foo.BasePath == "/obj/data/3:22")
                {
                    //ParametersViewModel parameters = new ParametersViewModel();
                    return App.SaleOrderLayout != null ? App.SaleOrderLayout : "XMASTER";
                }
                else
                {
                    return "XMASTER";
                }
            }

            ro.actions.Add(ActionActivity.New(LayoutValue(), "layout", "SetFieldValue"));
            //ro.actions.Add(ActionActivity.New("(166,88,0)", "kanal", "SetFieldValue"));
            //ro.actions.Add(ActionActivity.New("1", "aktiv", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New("DATEI", "drucker", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New("test", "datname", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(null, null, "Commit"));

            WebRequest request3 = AbasRequests.PrepareAbasRequest(GetOpenLinkFilesUri(link2), this._username, this._password);
            request3.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            ((HttpWebRequest)request3).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            request3.Method = "POST";
            string body = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref request3, body);
            WebResponse Webresponse3 = await AbasRequests.ExecuteRequestAsync(request3);
            string response3 = AbasRequests.ReadWebResponse(Webresponse3);
            dynamic reponse3deserialise = JsonConvert.DeserializeObject(response3);
            string link3 = reponse3deserialise.content.document.link.href;
            //---------------------------------------------------------------------------------------------------


            //Exécution de la requête GET afin de télecharger le PDF
            //---------------------------------------------------------------------------------------------------
            WebRequest request4 = AbasRequests.PrepareAbasRequest(GetOpenLinkFilesUri(link3), this._username, this._password);
            request4.ContentType = null;
            ((HttpWebRequest)request4).Accept = Constants.ABAS_SIMPLE_PDF;
            WebResponse Webresponse4 = await AbasRequests.ExecuteRequestAsync(request4);
            //---------------------------------------------------------------------------------------------------


            //Fermeture du WorkSpace généré
            //---------------------------------------------------------------------------------------------------
            string CurrentWorkspace = reponse1deserialise.meta.workingSetId;
            WebRequest request5 = AbasRequests.PrepareAbasRequest(new Uri(BaseUriString + "/workspace/" + CurrentWorkspace + "/commands/CANCEL"), "_abas_", "adm");
            request5.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            ((HttpWebRequest)request5).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            request5.Method = "POST";
            WebResponse Webresponse5 = await AbasRequests.ExecuteRequestAsync(request5);
            //---------------------------------------------------------------------------------------------------


            //Valeur de retour : Url du pdf
            //---------------------------------------------------------------------------------------------------
            return Webresponse4.ResponseUri;


        }
        #endregion
    }

}