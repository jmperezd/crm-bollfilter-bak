﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using System.Net;
using System.IO;

namespace AppCRM.Services
{
    public partial class AbasService
    {
        /*
   private string DBPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Evolubat.db");

        private LiteDatabase _dbInstance { get; set; }
        private LiteRepository _liteRepository { get; set; }

        public OfflineDB()
        {
            _dbInstance = new LiteDatabase(DBPath);
            _liteRepository = new LiteRepository(DBPath);
        }

        public void RemoveDB()
        {
            if (File.Exists(DBPath))
            {
                File.Delete(DBPath);
                _dbInstance = new LiteDatabase(DBPath);
                _liteRepository = new LiteRepository(DBPath);
            }
        }

*/

        private string DBPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "abas.db");
        LiteDatabase db;

        Type[] tablesTypes =  {
                typeof(Models.Note)
            };

        public void InitOfflineDB()
        {
            db = new LiteDatabase(DBPath);
            //db = new LiteDatabase($"{dbName}.db");
        }

        class PreferenceEntry
        {
            [BsonId]
            public string id { get; set; }
            public string value { get; set; }
        }

        private void SetPersistantPreference(string _id, string _value)
        {
            LiteCollection<PreferenceEntry> preferences = db.GetCollection<PreferenceEntry>("Preferences");
            PreferenceEntry pref = new PreferenceEntry { id = _id, value = _value };
            preferences.Upsert(pref);
        }

        private string GetPersistantPreference(string _id, string defaultValue = "")
        {
            LiteCollection<PreferenceEntry> preferences = db.GetCollection<PreferenceEntry>("Preferences");
            PreferenceEntry entry = preferences.FindOne( x => x.id.Equals(_id));
            if(null == entry)
            {
                return defaultValue;
            }
            return entry.value;
        }

        public Object SingleObjectRequest<T>(string id, string headFields = null, string tableFields = null)
            where T : IModel, new()
        {
            var tableName = getTableName<T>();
            var collection = db.GetCollection<T>(tableName);

            return collection.FindOne(x=>x.id.Equals(id));
        }

        public bool UpdateObjectRequest<T>(string id, T o)
                where T : IModel, new()
        {
            var tableName = getTableName<T>();
            var collection = db.GetCollection<T>(tableName);

            T dbObject = collection.FindOne(x => x.id.Equals(id));
            if (dbObject != null)
            {
                Utils.MergeObjects(dbObject, o);
                collection.Update(dbObject);
                return true;
            }
            else
            {
                return false;
            }
        }

        private Query FilterFieldListToQuery(List<GridField> gridFields = null, List<FilterField> filterFields = null)
        {
            if(AbasRequests.IsNullOrEmpty(filterFields))
            {
                return Query.All();
            }
            //Convertit la liste de filterFields en liste de Query simples (des filtres pour LiteDB) (la lambda est la fonction de conversion)
            //Ensuite, on les met ensemble avec la Query.And (conjonction de tous les filtres)
            var queryList = filterFields.ConvertAll<Query>(x => x.ToLiteDBQuery());
            queryList.Add(GridFieldListToQuery(gridFields));
            return Query.And(queryList.ToArray());
        }

        private Query GridFieldListToQuery(List<GridField> gridFields)
        {
            if (!AbasRequests.IsNullOrEmpty(gridFields))
            {
                GridField sortField = gridFields.Find(x => x.Order != GridField.SortOrder.None);
                if (sortField != null)
                {
                    return Query.All(sortField.FieldName, sortField.GetQueryValue());
                }
            }
            return Query.All();
        }

        public List<Object> TableRequest<T>(List<GridField> gridFields = null, List<FilterField> filterFields = null)
            where T : IModel, new()
        {
            var tableName = getTableName<T>();
            var collection = db.GetCollection<T>(tableName);

            Query query = Query.All();
            if (filterFields != null)
            {
                query = FilterFieldListToQuery(gridFields, filterFields);
            }

            return (List<Object>) collection.Find(query);
        }

        private string DateTimeToVersionn(DateTime dateTime)
        {
            //renvoie une date sous la forme du champ "version", exemple : 2018062715032100000000
            return dateTime.ToString("yyyyMMddHHMMss") + "00000000"; //Je ne sais pas à quoi servent les 0s à la fin pour l'instant, parfois ils ne sont pas à 0
        }

        public async Task<bool> PingApi()
        {
            try
            {
                Uri uri = new Uri(BaseUriString);
                WebRequest request = AbasRequests.PrepareAbasRequest(uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                await AbasRequests.ExecuteRequestAsync(request);
                return true;
            }
            catch (WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                }
                return false;
            }
        }
    }
}
