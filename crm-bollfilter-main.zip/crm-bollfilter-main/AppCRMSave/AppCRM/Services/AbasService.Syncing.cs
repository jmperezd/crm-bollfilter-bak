﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using System.Net;
using LiteQueue;
using System.Linq;
using Xamarin.Forms;
using System.Runtime;

namespace AppCRM.Services
{
    //On ne peut pas empiler des requêtes HTTP brutes, car dans certains cas les actions hors-ligne sont plus complexes (insertion de ligne dans la table)
    //Voici donc une abstraction d'une action, qui pourra s'adapter aux différents cas (à transformer en interface/faire hériter plus tard ?)
    class AbstractRequest
    {
        public object requestObject { get; set; }
        public ActionType Action { get; set; }
        public enum ActionType
        {
            Create,
            Update,
            Delete
        }
    }

    public partial class AbasService
    {
        private void QueueRequest(AbstractRequest item)
        {
            var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
            offlineRequests.Enqueue(item);
        }

        private AbstractRequest DequeueRequest()
        {
            var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
            var req = offlineRequests.Dequeue();
            offlineRequests.Commit(req);
            return req.Payload;
        }

        private AbstractRequest PeekRequest()
        {
            var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
            var req = offlineRequests.Dequeue();
            offlineRequests.Abort(req);
            return req.Payload;
        }

        async Task ExecRequest(AbstractRequest r)
        {
            ReplaceForeignKeyPersistance(r.requestObject);
            switch (r.Action)
            {   
                case (AbstractRequest.ActionType.Create):
                    {
                        dynamic o = (dynamic)r.requestObject;
                        string oldId = o.id;
                        o.id = null;
                        // On utilise la réflection pour appeller les méthodes génériques de CRUD
                        string id = string.Empty;
                        if (o is Models.Transaction)
                        {
                            var tableNameSubItems = getTableName<Models.SaleProduct>();
                            var collSubItems = db.GetCollection<Models.SaleProduct>(tableNameSubItems);
                            var res = collSubItems.Find(LiteDB.Query.EQ("head", oldId));
                            (o as IModel).SubItems = res.ToList<object>();
                            (o as IModel).SubItems.ForEach(x => (x as IModel).id = null);
                            (o as IModel).SubItems.ForEach(x => (x as Models.SaleProduct).head = null);

                            if (o is Models.Opportunity)
                            {
                                id = await Create<Models.Opportunity, Models.SaleProduct>(o, true);
                            }
                            else if (o is Models.Quotation)
                            {
                                id = await Create<Models.Quotation, Models.SaleProduct>(o, true);
                            }
                            if (o is Models.Order)
                            {
                                id = await Create<Models.Order, Models.SaleProduct>(o, true);
                            }

                            if (res != null)
                            {
                                //Supprime tous les subItems (puiqu'ils n'ont pas le bon id et ne servaient qu'à l'affichage horsligne)
                                foreach (Models.SaleProduct currentSubItem in res)
                                {
                                    collSubItems.Delete(currentSubItem.id);
                                }
                            }
                        }
                        else
                        {
                            id = await Create(o, true);
                        }
                        AddSubstitutionPersistant(oldId, id);
                    }
                    break;
                case (AbstractRequest.ActionType.Update):
                    {
                        dynamic o = (dynamic)r.requestObject;
                        // On utilise la réflection pour appeller les méthodes génériques de CRUD
                        if (o is Models.Transaction)
                        {
                            var tableNameSubItems = getTableName<Models.SaleProduct>();
                            var collSubItems = db.GetCollection<Models.SaleProduct>(tableNameSubItems);
                            var res = collSubItems.Find(LiteDB.Query.EQ("head", (o as IModel).id));
                            (o as IModel).SubItems = res.ToList<object>();

                            var newItems = (o as IModel).SubItems.Where(x => (x as Models.SaleProduct).id.Length > 15);
                            newItems.ToList().ForEach(x => (x as Models.SaleProduct).head = null);
                            newItems.ToList().ForEach(x => (x as IModel).id = null);

                            if (o is Models.Opportunity)
                            {
                                await Update<Models.Opportunity, Models.SaleProduct>(o);
                            }
                            else if (o is Models.Quotation)
                            {
                                await Update<Models.Quotation, Models.SaleProduct>(o);
                            }
                            if (o is Models.Order)
                            {
                                await Update<Models.Order, Models.SaleProduct>(o);
                            }
                        }
                        else
                        {
                            await Update(o);
                        }
                    }
                    break;
                case (AbstractRequest.ActionType.Delete):
                    {
                        dynamic o = (dynamic)r.requestObject;
                        //o.id = null;
                        // On utilise la réflection pour appeller les méthodes génériques de CRUD
                        //string id = 
                        await Delete(o);
                    }
                    break;
            }
        }

        public async Task SwitchToOnline()
        {
            //TODO : dépiler les requêtes *en s'assurant qu'elles se passent bien*
            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    Context.Instance.SynchronisationUpRunning = true;
                });

                var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
                while (offlineRequests.Count() > 0)
                {
                    AbstractRequest r = PeekRequest(); // Au lieu d'utiliser PeekRequest, on peut utiliser directement la fonctionnalité de
                    // LiteQueue qui permet d'annuler le dequeue après coup (abort)
                   
                    await ExecRequest(r);
                    DequeueRequest();
                }

                Device.BeginInvokeOnMainThread(async () =>
                {
                    Context.Instance.SynchronisationUpRunning = false;
                });

            }
            catch(InvalidOperationException)
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    Context.Instance.SynchronisationUpRunning = false;
                });
                return;
            }
            catch (Exception e)
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    Context.Instance.SynchronisationUpRunning = false;
                });
                //?? Reessayer ? 
            }
        }

        public void SwitchToOffline()
        {
            
        }

        public async Task PopulateDB()
        {
            try
            {
                Context.Instance.SynchronisationRunning = true;

                DateTime beginSyncDate = await GetERPDateAsync();

                //Contacts
                await SyncTable<Models.Customer>();
                await SyncTable<Models.Prospect>();
                await SyncTable<Models.ContactCustomer>();
                await SyncTable<Models.ContactProspect>();

                await SyncTable<Models.Turnover>();

                await SyncTable<Models.Employee>();
                await SyncTable<Models.Note>();
                await SyncTable<Models.Task>();

                //Transactions
                await SyncTable<Models.Order>();
                await SyncTable<Models.Opportunity>();
                await SyncTable<Models.Quotation>();
                await SyncTable<Models.Unit>();
                await SyncTable<Models.Product>();
                await SyncTable<Models.SaleProduct>();
                await SyncTable<Models.TermsOfPayment>();


                //Enum refs
                await SyncTable<Models.Priority>();
                await SyncTable<Models.RefusalReason>();
                //await SyncTable<Models.Status>(); //TODO: vraie enum à récupérer
                await SyncTable<Models.Type>();
                await SyncTable<Models.Characteristic1>();
                await SyncTable<Models.Characteristic2>();
                await SyncTable<Models.Characteristic3>();
                await SyncTable<Models.Characteristic4>();
                await SyncTable<Models.Characteristic5>();
                await SyncTable<Models.Characteristic6>();

                //Très long
                await SyncTableOpenItems();

                Context.Instance.SynchronisationRunning = false;

                SetPersistantPreference("_lastSyncDate", beginSyncDate.ToString()); //On met en mémoire la date de dernière synchronisation (à faire par table ?)
            }catch(Exception e)
            {
                Context.Instance.SynchronisationRunning = false;
            }
        }

        //Retourne un nom de table propre à un modèle, du type (30-1)
        private string getTableName<T>() where T : IModel, new()
        {
            try
            {
                var t = new T();
                if (String.IsNullOrEmpty(t.CustomTableName))
                {
                    if (t is Models.EnumReference)
                    {
                        var lel = t.BasePath.Split(new string[] { "/" }, StringSplitOptions.None);
                        return lel[lel.Length - 1].Replace(',', '-').Replace("(", "").Replace(")", "");
                    }
                    else
                    {
                        var lel = t.BasePath.Split(new string[] { "/" }, StringSplitOptions.None);
                        return lel[lel.Length - 1].Replace(':', '-');
                    }
                }
                else
                {
                    return t.CustomTableName;
                }
            }
            catch(Exception e)
            {
                return null;
            }
        }

        public async Task SyncTable<T>( int pageSize = 200)
            where T : IModel, new()
        {
            if(!Context.Instance.IsConnected)
            {
                throw new Exception("La synchronisation ne peut pas avoir lieu hors-ligne !");
            }
            var tableName = getTableName<T>();
            LiteDB.LiteCollection<T> collection = db.GetCollection<T>(tableName);

            //TODO: remettre limitation mise à jour
            //String lastSyncString = null;
            String lastSyncString = GetPersistantPreference("_lastSyncDate", null);

            T foo = new T();

            List<FilterField> filterFields = new List<FilterField>();
            if (!String.IsNullOrEmpty(lastSyncString))
            {
                filterFields.Add(new FilterField { FieldName = "version", Operator = ">", Value = DateTimeToVersionn(DateTime.Parse(lastSyncString)) });

                if (foo is Models.Turnover)
                {
                    filterFields.Add(new FilterField() { FieldName = "FY", Operator = ">=", Value = DateTime.Now.AddYears(-1).ToString("yy") });
                }
            }


            int page = 0;
            while(true)
            {
                List<T> objects = null;
                if (foo is Models.EnumReference)
                {
                    try
                    {
                        objects = await GetEnumAsync<T>();
                    }
                    catch(Exception e)
                    {

                    }
                }
                else
                {
                    //TODO filters for sync
                    objects = await ReadList<T>(null, filterFields, page, pageSize);
                }
                if(objects == null)
                {
                    return;
                };

                if (foo is Models.Turnover)
                {
                    objects.ForEach(o => o.id = (o as Models.Turnover).mainObj + "_" + (o as Models.Turnover).FY);
                }

                objects.ForEach(o => collection.Upsert(o));
                //TODO: Enlever la limitation à 5
                if (objects.Count != pageSize || page == 5)
                {
                    break;
                }
                page++;
            }

            foreach (string defaultIndex in new T().DefaultIndexes)
            {
                collection.EnsureIndex(defaultIndex);
            }
        }

        public async Task SyncTableOpenItems()
        {
            if (!Context.Instance.IsConnected)
            {
                throw new Exception("La synchronisation ne peut pas avoir lieu hors-ligne !");
            }
            var tableName = getTableName<Models.OpenItemsObject>();
            LiteDB.LiteCollection<Models.OpenItemsObject> collection = db.GetCollection<Models.OpenItemsObject>(tableName);

            foreach (Models.Tiers tiers in ReadListOffline<Models.Customer>(null, null).Result)
            {
                try
                {
                    var openItemObject = await GetOpenItems(tiers.id);

                    if (openItemObject != null)
                    {
                        collection.Upsert(openItemObject);
                    };
                }
                catch(Exception e)
                {

                }
            }

            foreach (string defaultIndex in (new Models.OpenItemsObject()).DefaultIndexes)
            {
                collection.EnsureIndex(defaultIndex);
            }
        }

        public async Task SyncTable<T, U>(int pageSize = 200)
            where T : IModel, new()
            where U : IModel, new()
        {
            if (!Context.Instance.IsConnected)
            {
                throw new Exception("La synchronisation ne peut pas avoir lieu hors-ligne !");
            }
            var tableName = getTableName<T>();
            var coll = db.GetCollection<T>();
            LiteDB.LiteCollection<T> collection = db.GetCollection<T>(tableName);

            T foo = new T();
            var tableNameSubItems = getTableName<U>();
            LiteDB.LiteCollection<U> collectionSubItems = null;
            if (foo.HasSubItems)
            {
                collectionSubItems = db.GetCollection<U>(tableNameSubItems);
            }

            FilterField filterByDate = null;

            //TODO: remettre limitation mise à jour
            //String lastSyncString = null;//GetPersistantPreference("_lastSyncDate", null);
            String lastSyncString = GetPersistantPreference("_lastSyncDate", null);

            if (!String.IsNullOrEmpty(lastSyncString))
            {
                filterByDate = new FilterField { FieldName = "version", Operator = ">", Value = DateTimeToVersionn(DateTime.Parse(lastSyncString)) };
            }

            int page = 0;
            while (true)
            {
                //TODO filters for sync
                List<T> objects = await ReadList<T,U>(null, (filterByDate != null ? new List<FilterField> { filterByDate } : null), page, pageSize);
                if (objects == null)
                {
                    return;
                }
                foreach (T o in objects)
                {
                    collection.Upsert(o);
                    if (o.HasSubItems && o.SubItems != null)
                    {
                        o.SubItems.Cast<U>().ToList().ForEach(sub => collectionSubItems.Upsert(sub));
                    }
                    //TODO: Enlever la limitation à 5
                    if (objects.Count != pageSize || page == 5)
                    {
                        break;
                    }
                }
                page++;
            }

            foreach (string defaultIndex in new T().DefaultIndexes)
            {
                collection.EnsureIndex(defaultIndex);
            }
        }
    }
}
