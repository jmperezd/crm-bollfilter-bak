﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using Newtonsoft.Json;
using AppCRM.Classes.Requests;
using System.Dynamic;
using System.Web;

namespace AppCRM.Services
{
    public class AbasRequests
    {
        public static bool IsNullOrEmpty<T>(List<T> s)
        {
            return s == null || s.Count() == 0;
        }

        public static WebRequest PrepareAbasRequest(Uri link, string user, string password)
        {
            var request = WebRequest.Create(link);
            request.ContentType = Constants.WEBREQUEST_CONTENT_TYPE;
            ((HttpWebRequest)request).Accept = Constants.WEBREQUEST_ACCEPT;
            request.Headers.Add(HttpRequestHeader.AcceptLanguage, Constants.WEBREQUEST_ACCEPT_LANGUAGE);

            //Ajout d'identifiants de connexion à l'API
            NetworkCredential myNetworkCredentials = new NetworkCredential(user, password);
            CredentialCache myCredentialCache = new CredentialCache
            {
                { link, "Basic", myNetworkCredentials }
            };
            request.Credentials = myCredentialCache;
            request.PreAuthenticate = true;
            return request;
        }

        public static void WriteRequestBodyFromHeadObject(ref WebRequest request, object o)
        {
            string body = JsonConvert.SerializeObject(new { head = o }, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            WriteRequestBody(ref request, body);
        }

        public static void WriteRequestBodyFromHeadAndTableObject(ref WebRequest request, object oHead, object oTable)
        {
            string body = JsonConvert.SerializeObject(new { head = oHead, table = oTable }, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            WriteRequestBody(ref request, body);
        }

        public static void WriteRequestBody(ref WebRequest request, string body)
        {
            using (var sw = new StreamWriter(request.GetRequestStream()))
            {
                sw.Write(body);
            }
        }

        public static void DownloadFilesFromUri(Uri link)
        {
            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadFile(link, "test.exe");
            }
        }




        //public static void WriteRequestBodyTest(ref WebRequest request, object o)
        //{
        //    Stream stream = request.GetRequestStream();
        //    var sw = new StreamWriter(stream);
        //    string body = JsonConvert.SerializeObject(o, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
        //    sw.Write(body);
        //    sw.Close();
        //    stream.Close();
        //}


        public static async Task<WebResponse> ExecuteRequestAsync(WebRequest request)
        {
            try
            {
                return await request.GetResponseAsync();
            }
            catch(WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    string result = streamReader.ReadToEnd();
                    throw e;
                }
            }
        }

        public static String ReadWebResponse(WebResponse response)
        {
            using (var streamReader = new StreamReader(response.GetResponseStream()))
            {
                string result = streamReader.ReadToEnd();
                return result;
            }
        }

        public static String GetFieldsStringFromList(List<GridField> gridFields)
        {
            string ret = string.Empty;
            if (gridFields != null && gridFields.Count > 0)
            {
                ret = gridFields.Aggregate("", (acc_string, x) => acc_string + x.FieldName + ",");
                ret = "headFields=" + ret.Substring(0, ret.Length - 1);
            }
            return ret;
        }

        public static String GetHeadFieldsParam(List<string> headFields)
        {
            if (IsNullOrEmpty(headFields))
            {
                return string.Empty;
            }
            string ret = headFields.Aggregate("", (acc_string, x) => acc_string + x + ",");
            return "headFields=" + ret.Substring(0, ret.Length - 1);
        }

        public static String GetTableFieldsParam(List<string> tableFields)
        {
            if (IsNullOrEmpty(tableFields))
            {
                return string.Empty;
            }
            string ret = tableFields.Aggregate("", (acc_string, x) => acc_string + x + ",");
            return "tableFields=" + ret.Substring(0, ret.Length - 1);
        }

        private static String GetFilterStringFromFields(List<FilterField> filterFields)
        {
            string ret = filterFields.Aggregate("", (acc_string, x) => acc_string + x.FieldName + x.Operator + x.Value + ";");
            return ret.Substring(0, ret.Length - 1);
        }


        public static List<Models.ActionActivity> GetInfosysAction(List<GridField> gridFields = null, int requestedPage = 0, int count = 0)
        {
            List<Models.ActionActivity> actions = new List<Models.ActionActivity>();

            actions.Add(Models.ActionActivity.New("", "start", "SetFieldValue"));

            if (!IsNullOrEmpty(gridFields))
            {
                foreach (GridField gridField in gridFields)
                {
                    if(!string.IsNullOrEmpty(gridField.Value))
                    {
                        actions.Add(Models.ActionActivity.New(gridField.Value, gridField.FieldName, "SetFieldValue"));
                    }
                }
            }
            else if (IsNullOrEmpty(gridFields))
            {
                return null;
            }
            if (!IsNullOrEmpty(gridFields))
            {
                GridField sortField = gridFields.Find(x => x.Order != GridField.SortOrder.None);
                if (sortField != null)
                {
                    try
                    {
                        List<Object> order = new List<Object>();
                        order.Add(
                            new
                            {
                                fieldName = sortField.FieldName,
                                direction = sortField.GetOrderTypeString()
                            });

                        dynamic ordering = new
                        {
                            _type = "OrderTableBy",
                            order = order
                        };
                    /*
                        ordering._type = "OrderTableBy";
                        ordering.order = new List<Object>();
                        ordering.order.Add(
                            new
                            {
                                fieldName = sortField.FieldName,
                                direction = sortField.GetOrderTypeString()
                            });
                            */
                        actions.Add(ordering);
                    }
                    catch(Exception e)
                    {
                        
                    }
                }
            }
            return actions;
        }

        public static String GetLimitAndOffsetString(int requestedPage, int count)
        {
            return $"limit={count}&offset={requestedPage * count}";
        }

        public static String GetSearchFilterString(string search = null)
        {
            return (String.IsNullOrWhiteSpace(search) ? string.Empty : $"criteria=searchExt~/{search}");
        }

        public static String GetCriteriaParam(List<FilterField> filterFields, List<GridField> gridFields = null)
        {
            string str = "criteria=";

            if (!IsNullOrEmpty(filterFields))
            {
                str += GetFilterStringFromFields(filterFields);
            }
            else if (IsNullOrEmpty(gridFields))
            {
                return string.Empty;
            }
            if (!IsNullOrEmpty(gridFields))
            {
                GridField sortField = gridFields.Find(x => x.Order != GridField.SortOrder.None);
                if(sortField != null)
                {
                    str += sortField.GetOrderString();
                }
            }
            return str;
        }
    }
}
