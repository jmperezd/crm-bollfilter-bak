﻿using AppCRM.Classes.Requests;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using AppCRM.Models;

namespace AppCRM.Services
{
    public partial class AbasInfoSystem
    {
        string _login;
        string _pass;
        Models.RootObject RootObject { get; set; } = new Models.RootObject(); 

        public AbasInfoSystem(string login, string pass)
        {
            _login = login;
            _pass = pass;
        }


        public void ActionSetFieldValueAsync(string field, string value)
        {
            this.RootObject.actions.Add(Models.ActionActivity.New(value, field, "SetFieldValue")); 
        }

        public async Task<Object> Execute<T>() where T : IModel, new()
        {
            T foo = new T();
            this.RootObject.actions.Add(ActionActivity.New("", "bstart", "SetFieldValue")); 
            this.RootObject.headFields = foo.DefaultHeadFieldsString;
            //uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
            this.RootObject.tableFields = foo.DefaultTableFieldsString;

            Uri uri = new Uri(AbasService.BaseUriString + foo.BasePath);
            WebRequest request = AbasRequests.PrepareAbasRequest(uri, _login, _pass);
            request.Method = Constants.WEBREQUEST_POST;
            string body = JsonConvert.SerializeObject(this.RootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }); 
            AbasRequests.WriteRequestBody(ref request, body);

            WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
            string responseString = AbasRequests.ReadWebResponse(response);
            dynamic j = JsonConvert.DeserializeObject(responseString);

            return j;
        }
    }
}
