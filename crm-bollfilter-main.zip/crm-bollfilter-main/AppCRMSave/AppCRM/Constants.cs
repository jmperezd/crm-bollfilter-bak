﻿using System;
using System.Globalization;

namespace AppCRM
{
    public class Constants
    {
        
        public const string DEV_SERVER_URL = "http://109.190.129.211:10080";
        //public const string DEV_SERVER_URL = "http://rdp.abas-france.fr:10080";
        //public const string DEV_SERVER_URL = "http://wessix:10080";
        public const string DEV_INSTANCE_PATH = "/mw/r/demo";
        public const string DEV_USERNAME = "_abas_";
        public const string DEV_PASSWORD = "adm";
        public const string DEV_WEBUSER = "(183,11,0)";

        public const string ABAS_SIMPLE_JSON = "application/abas.objects.simple+json";
        public const string ABAS_SIMPLE_PDF = "application/pdf";
        public const string ABAS_SIMPLE_JSON_APPLICATION = "application/abas.objects.simple+json";
        public const string ABAS_SIMPLE_JSON_OBJECTS = "application/abas.objects+json";

        public const string URI_INFOSYS = "/infosys/data";
        public const string URI_INFOSYS_ACTIVITY = "/ev/BELEGVORKOMMEN";
        public const string URI_INFOSYS_OPEN_ITEMS = "/op/LOP";

        public const string URI_INFOSYS_ACTIVITY_HEADFIELDS = "";
        public const string URI_INFOSYS_ACTIVITY_TABLEFIELDS = "tabsvorkommen,tnettowert,tvktypa";

        public const string URI_PRINTLAYOUT_HEADFIELS = "id,idno,descrOperLang,swd,layoutContext";
        public const string URI_PRINTCOLLECTIVELAYOUT = "/obj/data/88:2";
        public const string URI_PRINTLAYOUT = "/obj/data/88:3";
        public const string URI_PRINTPARAMETERLAYOUT = "/obj/data/88:8";


        public const string URI_OPEN_ITEMS_HEADFIELDS = "fgesamt,fbetr1,fbetr2,fbetr3,fbetr4,f2betr1,f2betr2,f2betr3,f2betr4";


        public const string WEBREQUEST_GET = "GET";
        public const string WEBREQUEST_POST = "POST";
        public const string WEBREQUEST_PUT = "PUT";
        public const string WEBREQUEST_DELETE = "DELETE";
        public const string WEBREQUEST_CONTENT_TYPE = ABAS_SIMPLE_JSON;
        public const string WEBREQUEST_ACCEPT = ABAS_SIMPLE_JSON;
        public static string WEBREQUEST_ACCEPT_LANGUAGE { get
            {
                if(AppCRM.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToLower() == "fr"
                   || AppCRM.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToLower() == "en")
                {
                    return AppCRM.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToUpper();
                }
                else
                {
                    return "EN";
                }
            }
        }
        public const string WEBREQUEST_AUTH_BASIC = "Basic";

        public const string URI_PARAM_LANGUAGE = "variableLanguage=EN";

        public const string URI_WEBUSERS = "/obj/data/93:1";

        public const string URI_EMPLOYEE = "/obj/data/11:1";
        public const string URI_EMPLOYEE_HEADFIELDS = "id,descr,descr1,descr2,descr3";

        public const string URI_NOTE = "/obj/data/134:1";
        public const string URI_NOTE_HEADFIELDS = "id,idno,swd,type,type^descrOperLang,descrOperLang,descrTextModuleOperLang,triggerOfEnt,businessPartner,productListElem,purchSalesTrans,intProcess,editor,editor^descrOperLang,date,currTime,purchSalesTrans,purchSalesTransExt";

        public const string URI_TASK = "/obj/data/86:6";
        public const string URI_TASK_HEADFIELDS = "id,descrOperLang,prio^descrOperLang,prio,endDate,confirm,confirm^descrOperLang,swd,descrTextModuleOperLang,editor,editor^descrOperLang,businessPartner,status,purchSalesTrans,purchSalesTrans^swd";

        public const string TABLE_CUSTOMER = "contacts";
        public const string URI_CUSTOMER = "/obj/data/0:1";
        public const string URI_CUSTOMER_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,swd,webSiteURL,emailAddr,contactPerson,targetCustomer,addr,street,town,ctryCode,stateOfTaxOffice,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,rep,repDescr,inhouseContact,inhouseContactDescr,industry,characteristic1,characteristic2,characteristic3,characteristic4,characteristic5,characteristic6,characteristic1^descrOperLang,characteristic2^descrOperLang,characteristic3^descrOperLang,characteristic4^descrOperLang,characteristic5^descrOperLang,characteristic6^descrOperLang,characteristicIdentifier1,characteristicIdentifier2,characteristicIdentifier3,characteristicIdentifier4,characteristicIdentifier5,characteristicIdentifier6,comments";

        public const string URI_PROSPECT = "/obj/data/0:6";
        public const string URI_PROSPECT_HEADFIELDS= "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,swd,webSiteURL,emailAddr,contactPerson,targetCustomer,addr,street,town,ctryCode,stateOfTaxOffice,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,rep,repDescr,inhouseContact,inhouseContactDescr,industry,characteristic1,characteristic2,characteristic3,characteristic4,characteristic5,characteristic6,characteristic1^descrOperLang,characteristic2^descrOperLang,characteristic3^descrOperLang,characteristic4^descrOperLang,characteristic5^descrOperLang,characteristic6^descrOperLang,characteristicIdentifier1,characteristicIdentifier2,characteristicIdentifier3,characteristicIdentifier4,characteristicIdentifier5,characteristicIdentifier6,comments";

        public const string URI_CONTACT_CUSTOMER = "/obj/data/0:2";
        public const string URI_CONTACT_CUSTOMER_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,swd,webSiteURL,emailAddr,contactPerson,targetCustomer,addr,street,town,ctryCode,stateOfTaxOffice,zipCode,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,zipCode2,companyARAP,companyARAP^rep,inhouseContact,inhouseContactDescr,comments";

        public const string URI_CONTACT_PROSPECT = "/obj/data/0:7";
        public const string URI_CONTACT_PROSPECT_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,swd,webSiteURL,emailAddr,contactPerson,targetCustomer,addr,street,town,ctryCode,stateOfTaxOffice,zipCode,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,zipCode2,companyARAP,companyARAP^rep,inhouseContact,inhouseContactDescr,comments";

        public const string URI_SALE_OPPORTUNITIES = "/obj/data/3:30";
        public const string URI_SALE_QUOTATIONS = "/obj/data/3:21";
        public const string URI_SALE_ORDERS = "/obj/data/3:22";
        public const string URI_SALE_HEADFIELDS = "id,idno,customerDescr,customerDescr^descrOperLang,totalNetAmt,totalGrossAmtDom,curr,dateFrom,customer,goodsRecipient,comments,transLock,payTerm,payTerm^descrOperLang,rep,repDescr";


        public const string URI_SALE_PRODUCT_HEADFIELDS = "id,head,product,product^descrOperLang,unitQty,tradeUnit,price,percent,itemValEntCurr,productDescr,recordNo,rowNo,startDateTime";
        public const string URI_SALE_PRODUCT = "/obj/data/3:2";

        public const string URI_ENUM_LIST = "/obj/data/107:1/";

        //Enum detail table 109:2

        public const string URI_PRODUCT = "/obj/data/2:1";
        public const string URI_PRODUCT_HEADFIELDS = "id,idno,descrOperLang,salesTradeUnit,purchTradeUnit,SU,purchPrice,searchExt,ysynccrm";

              
            
        public const string URI_CA = "/obj/data/0:3";
        public const string URI_CA_HEADFIELDS = "mainObj,FY,origBal,turnoverPeriod,turnoverPeriod2,turnoverPeriod3,turnoverPeriod4,closingBalTurnover,month1,month2,month3,month4,month5,month6,month7,month8,month9,month10,month11,month12";


        public const string URI_TERMS_OF_PAYMENT = "/obj/data/12:8";

        public const string URI_SUMMARY = "/obj/data/12:3";

        public const string URI_UNIT = "/obj/data/62:1";
        public const string URI_UNIT_HEADFIELDS = "id,descrOperLang,unitIdentifier";


    }
}

