﻿using System;
using Abas_Shared_Xamarin.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;

namespace Testing
{
    [TestClass]
    public class WebUserLogin
    {
        [TestMethod]
        public void TestFindUser()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                WebUser kek = new WebUser();
                kek =await myService.Find<WebUser>("login","webtest");
                Assert.IsTrue(kek.login.Equals("webtest"));
            }).GetAwaiter().GetResult();

        }

        [TestMethod]
        public void TestGetHash()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                string kek = await myService.GetPasswordHashAsync("test");
                Assert.IsTrue(kek.Equals("wQ8.VHMHY9rR5kG0UHjt90"));
                await myService.CancelNewWebUserWorkspace();
            }).GetAwaiter().GetResult();

        }

        [TestMethod]
        public void TestLogin()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);
                try
                {
                     bool kek = await myService.UserLoginAsync("webtest", "test");
                    Assert.IsTrue(kek);
                }
                catch(System.IO.FileNotFoundException e)
                {
                    Assert.IsTrue(true);
                }
                catch(Exception e)
                {
                    Assert.IsTrue(false);
                }
            }).GetAwaiter().GetResult();

        }
    }
}
