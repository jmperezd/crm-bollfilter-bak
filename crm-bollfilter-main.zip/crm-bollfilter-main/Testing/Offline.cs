﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Abas_Shared_Xamarin.Services;
using LiteDB;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Testing
{
    // Basic example
    public class CustomerFoo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string[] Phones { get; set; }
        public bool IsActive { get; set; }
    }

    [TestClass]
    public class LiteDB
    {
        [TestMethod]
        public void TestOpenDB()
        {
            try
            { // Open database (or create if not exits)
                using (var db = new LiteDatabase(@"MyData.db"))
                {
                    // Get customer collection
                    var customers = db.GetCollection<CustomerFoo>("customers");

                    CustomerFoo lel = new CustomerFoo
                    {
                        Id = 3,
                        Name = "Rocky3"
                    };
                    
                    customers.Update(lel);
                    customers.EnsureIndex(x => x.Name);

                    // Use Linq to query documents
                    var results = customers.Find(x => true);
                    Assert.IsTrue(true);
                }
            }
            catch(Exception e)
            {
                Assert.IsTrue(false);
            }
           
        }

        [TestMethod]
        public void TestOpenCollectionName()
        {
            try
            { // Open database (or create if not exits)
                using (var db = new LiteDatabase(@"TestData.db"))
                {

                    // Get customer collectionC
                    var customers = db.GetCollection<CustomerFoo>((new CustomerFoo()).GetType().Name);
                    Assert.IsTrue(true);
                }
            }
            catch (Exception e)
            {
                Assert.IsTrue(false);
            }
        }

        class TestClass
        {
            [ForeignKeyID]
            public string Fk1;
            [ForeignKeyID]
            public string Fk2;

            public string NotFk1;
            public string NotFk2;
        }
        [TestMethod]
        public void TestSubstituteForeignKeys()
        {
            try
            {
                TestClass testObject = new TestClass()
                {
                    Fk1 = "test1",
                    Fk2 = "test2",
                    NotFk1 = "test3",
                    NotFk2 = "test4"
                };
                Dictionary<string, string> substitutions = new Dictionary<string, string>();
                substitutions.Add("test1", "test1b");
                substitutions.Add("test3", "test3b");

                Utils.ReplaceForeignKeys(substitutions, testObject);
                Assert.IsTrue(testObject.Fk1.Equals("test1b")&& testObject.NotFk1.Equals("test3"));
            }
            catch (Exception e)
            {
                Assert.IsTrue(false);
            }
        }

        [TestMethod]
        public void TestEnqueueRequest()
        {
            try
            {
                System.Threading.Tasks.Task.Run(async () =>
                {
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    myService.InitOfflineDB();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);
                    myService.SwitchToOffline();

                    Abas_Shared_Xamarin.Models.Task lel = new Abas_Shared_Xamarin.Models.Task();
                    lel.swd = "DEQUEUE2";

                    lel.editor = "(181,11,0)";
                    lel.descrOperLang = "TEZSXQ";
                    lel.confirm = "(181,11,0)";
                    lel.endDate = new DateTime(2019, 02, 01);
                    lel.descrTextModuleOperLang = "Test unitaire du défilage " + DateTime.Now;

                    await myService.Create(lel);
                }).GetAwaiter().GetResult();
            }
            catch (Exception e)
            {
                Assert.IsTrue(false);
            }
        }
        
        [TestMethod]
        public void TestDequeuing() //Ce test échoue sur ordinateur car Xamarin.Forms n'est pas dispo
        {
            try
            {
                System.Threading.Tasks.Task.Run(async () =>
                {
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    myService.InitOfflineDB();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);
                    myService.SwitchToOffline();
                    Abas_Shared_Xamarin.Models.Task lel = new Abas_Shared_Xamarin.Models.Task();
                    lel.swd = "DEQUEUE1";

                    lel.editor = "(181,11,0)";
                    lel.descrOperLang = "TEZSXQ";
                    lel.confirm = "(181,11,0)";
                    lel.endDate = new DateTime(2019, 02, 01);
                    lel.descrTextModuleOperLang = "Test unitaire du défilage 2 " + DateTime.Now;

                    await myService.Create(lel);
                    await myService.SwitchToOnline();
                }).GetAwaiter().GetResult();
            }
            catch (Exception e)
            {
                Assert.IsTrue(false);
            }
        }

        [TestMethod]
        public void TestPopulateDB()
        {
            try
            {
                System.Threading.Tasks.Task.Run(async () =>
                {
                    // Actual test code here.
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    myService.InitOfflineDB();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                    await myService.PopulateDB();
                }).GetAwaiter().GetResult();
            }
            catch (Exception e)
            {
                Assert.IsTrue(false);
            }
        }
    }
}
