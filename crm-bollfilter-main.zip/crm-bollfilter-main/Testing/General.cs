﻿using System;
using Abas_Shared_Xamarin.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;

namespace Testing
{
    [TestClass]
    public class General
    {
        [TestMethod]
        public void TestConnectivity()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                Assert.IsTrue(await myService.PingApi());
            }).GetAwaiter().GetResult();
        }
        [TestMethod]
        public void TestGetDate()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                await myService.GetERPDateAsync();

                Assert.IsTrue(true);
            }).GetAwaiter().GetResult();

        }
    }
}
