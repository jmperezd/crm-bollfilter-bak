﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WFramework_Xamarin.Table;

namespace Testing
{
    [TestClass]
    public class Infosys
    {
        [TestMethod]
        public void InfosysTest()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                try
                {
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);
                    List<GridField> lel = new List<GridField>();

                    lel.Add(new GridField("id", "", GridField.SortOrder.None));
                    lel.Add(new GridField("idno", "", GridField.SortOrder.None));
                    lel.Add(new GridField("swd", "", GridField.SortOrder.Asc));
                    lel.Add(new GridField("searchExt", "", GridField.SortOrder.None));

                    dynamic kek = await myService.RunInfosystem<Customer>(lel);
                    Assert.IsTrue(true);
                }
                catch (WebException e)
                {
                    using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                    }
                    Assert.IsTrue(false);
                }
                catch (Exception e)
                {
                    Assert.IsTrue(false);
                }
            }).GetAwaiter().GetResult();
        }
    }
}
