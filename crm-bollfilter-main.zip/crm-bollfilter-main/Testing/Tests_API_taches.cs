﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using AppCRM;
using Abas_Shared_Xamarin.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WFramework_Xamarin.Table;

namespace Testing
{
    [TestClass]
    public class Tests_API_taches
    {
        [TestMethod]
        public void Auth()
        {
            Task.Run(async () =>
            {
                Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);
                Assert.IsTrue(myService.IsAuthenticated());

            }).GetAwaiter().GetResult();
        }

        [TestMethod]
        public void CRUDTask()
        {
            try
            {
                Task.Run(async () =>
                {
                    // Actual test code here.
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                    Abas_Shared_Xamarin.Models.Task lel = new Abas_Shared_Xamarin.Models.Task();
                    lel.swd = "testunitLOL";

                    lel.editor = "(181,11,0)";
                    lel.descrOperLang = "TEZSXQ";
                    lel.confirm = "(181,11,0)";
                    lel.endDate = new DateTime(2019, 02, 01);
                    lel.descrTextModuleOperLang = "Test unitaire lel";
                    //string lelid = await myService.AddTaskAsync(lel);
                    //Abas_Shared_Xamarin.Models.Task lelcomp = await myService.GetTaskAsync(lelid);
                    //Assert.IsTrue(lelcomp.editor == lel.editor);
                    //await myService.DeleteTaskAsync(lelid);
                }).GetAwaiter().GetResult();
            }
            catch (Exception e)
            {
                Assert.IsTrue(false);
            }
        }

        [TestMethod]
        public void GetEmployeeName()
        {
            Task.Run(async () =>
            {
                try
                {
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);

                    //string lel = await myService.GetEmployeeNameAsync("(181,11,0)");
                    //Assert.IsTrue(lel == "Grégory DOUGUET");
                }
                catch (WebException e)
                {
                    using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                    }
                    Assert.IsTrue(false);
                }
            }).GetAwaiter().GetResult();
        }

        [TestMethod]
        public void TestGeneralRead()
        {
            Task.Run(async () =>
            {
                try
                {
                    Abas_Shared_Xamarin.Services.AbasService myService = new Abas_Shared_Xamarin.Services.AbasService();
                    await myService.LoginAsync(AppCRM.Constants.DEV_SERVER_URL, AppCRM.Constants.DEV_INSTANCE_PATH, AppCRM.Constants.DEV_USERNAME, AppCRM.Constants.DEV_PASSWORD);
                    Abas_Shared_Xamarin.Models.Task kek = await myService.Read<Abas_Shared_Xamarin.Models.Task>("(153,86,0)");
                    Assert.IsTrue(kek.swd == "TEST");
                }
                catch (WebException e)
                {
                    using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                    }
                    Assert.IsTrue(false);
                }
            }).GetAwaiter().GetResult();
        }

        [TestMethod]
        public void SandBox()
        {
            Task.Run(async () =>
            {
                try
                {
                    string id = "lrl";

                    var obj = new { id };
                    Console.WriteLine(obj);
                    Assert.IsTrue(true);
                }
                catch (WebException e)
                {
                    using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                    }
                    Assert.IsTrue(false);
                }
            }).GetAwaiter().GetResult();
        }
    }
}
