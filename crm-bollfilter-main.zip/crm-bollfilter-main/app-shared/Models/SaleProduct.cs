﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class SaleProduct : Model, IModel
    {
        public SaleProduct()
        {
            base.DefaultHeadFieldsString = Constants.URI_SALE_PRODUCT_HEADFIELDS;
        }

        public SaleProduct(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_SALE_PRODUCT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [ForeignKeyID]
        public string head { get; set; }

        public bool ShouldSerializeid()
        {
            return false;
        }
        
        public string product { get; set; }
        public string serviceEngineer { get; set; }
        public string recordType { get; set; }
        [JsonProperty(PropertyName = "product^grpNo")]
        public string product_grpNo { get; set; }
        [JsonProperty(PropertyName = "product^swd")]
        public string product_swd { get; set; }
        public string type { get; set; }
        [JsonProperty(PropertyName = "product^descr4")]
        public string product_descr4 { get; set; }
        public string status { get; set; }
        [JsonProperty(PropertyName = "serviceProduct^swd")]
        public string serviceProduct_swd { get; set; }
        [JsonProperty(PropertyName = "serviceProductDescr^swd")]
        public string serviceProductDescr_swd { get; set; }
        [JsonProperty(PropertyName = "product^descrOperLang")]
        public string product_descrOperLang { get; set; }
        public bool ShouldSerializeproduct_descrOperLang()
        {
            return false;
        }
        public string objectGrpNo { get; set; }
        public string rowNo { get; set; }
        public bool ShouldSerializerowNo()
        {
            return false;
        }

        public string unitQty { get; set; }
        public string tradeUnit { get; set; }
        /*[JsonProperty(PropertyName = "tradeUnit^descrOperLang")]
        public string tradeUnit_descrOperLang { get; set; }
        public bool ShouldSerializetradeUnit_descrOperLang()
        {
            return false;
        }*/
        public string price { get; set; }
        public bool ShouldSerializeprice()
        {
            return false;
        }
        public string percent { get; set; }
       
        public string itemValEntCurr { get; set; }
        public bool ShouldSerializeitemValEntCurr()
        {
            return false;
        }
        public string productDescr { get; set; }
        public bool ShouldSerializeproductDescr()
        {
            return false;
        }
        public string recordNo { get; set; }
        public bool ShouldSerializerecordNo()
        {
            return false;
        }
        public DateTime startDateTime { get; set; }
        public DateTime? deadline { get; set; }
        public bool ShouldSerializestartDateTime()
        {
            return false;
        }

        public string itemFreeText { get; set; }

        public string serviceProduct { get; set; }

        public string serviceProductDescr { get; set; }


        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("head");
                defaultIndexes.Add("product_descrOperLang");
                return defaultIndexes;
            }
        }
    }
}
