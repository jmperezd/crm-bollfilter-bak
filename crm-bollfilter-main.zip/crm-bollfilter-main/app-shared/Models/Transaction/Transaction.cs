﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using WFramework_Xamarin;

namespace Abas_Shared_Xamarin.Models
{
    public abstract class Transaction : Model, IModel
    {
        [JsonIgnore]
        public string all
        {
            get
            {
                return this.idno + " " + this.customerDescr_descrOperLangLower + " " + this.totalNetAmt + " " + this.totalGrossAmtDom;
            }
        }


        //Transaction
        public int? idno { get; set; } //N° d'identité
        public string customerDescr { get; set; }
        public bool ShouldSerializecustomerDescr()
        {
            return false;
        }
        [JsonProperty(PropertyName = "customerDescr^descrOperLang")]
        public string customerDescr_descrOperLang { get; set; }

        public string responsOperator { get; set; }        

        public bool ShouldSerializecustomerDescr_descrOperLang()
        {
            return false;
        }
        [JsonIgnore]
        public string customerDescr_descrOperLangLower
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.customerDescr_descrOperLang) ? this.customerDescr_descrOperLang.ToLower() : string.Empty;
            }
        }
        public bool ShouldSerializecustomerDescr_descrOperLangLower()
        {
            return false;
        }
        public string totalNetAmt { get; set; }
        public bool ShouldSerializetotalNetAmt()
        {
            return false;
        }
        public string totalGrossAmtDom { get; set; }
        public bool ShouldSerializetotalGrossAmtDom()
        {
            return false;
        }
        public string curr { get; set; }

        /*
        [JsonProperty(PropertyName = "dateFrom")]
        public string dateFromString
        {
            get
            {
                return this.dateFrom.ToString("yy-MM-dd");
            }
        }
        */

        [BsonIgnore]
        [JsonIgnore]
        public DateTime? dateFromDate
        {
            get
            {
                return this._dateFrom;
            }
            set
            {
                this._dateFrom = value;
            }
        }

        [BsonIgnore]
        [JsonIgnore]
        private DateTime? _dateFrom;
        public string dateFrom
        {
            set
            {
                this._dateFrom = ToolsHelper.FormatDate(value);
            }
            get
            {
                if (this._dateFrom.HasValue)
                {
                    return this._dateFrom.Value.ToString("yyyy-MM-dd");
                }
                else
                {
                    return null;
                }
            }
        }


        public string customer { get; set; }
        public string goodsRecipient { get; set; }
        public string comments { get; set; }
        public bool transLock { get; set; }
        public string payTerm { get; set; }

        [JsonProperty(PropertyName = "payTerm^descrOperLang")]
        public string payTerm_descrOperLang { get; set; }
        public bool ShouldSerializepayTerm_descrOperLang()
        {
            return false;
        }

        public string ysignataire { get; set; }
        public string rep { get; set; }
        public string repDescr { get; set; }

        public string serviceEngineer { get; set; }//Service ingénieur


        public string probability { get; set; }
        public string yfcustsign { get; set; }
        public string ycustsign { get; set; }


        [BsonIgnore]
        [JsonIgnore]
        public DateTime timeCreated { get; set; }
        [BsonIgnore]
        [JsonIgnore]
        public string nameSocioComercial { get; set; }
        [BsonIgnore]
        [JsonIgnore]
        public string nameDestinatarioMercancias { get; set; }

        [BsonIgnore]
        [JsonIgnore]
        public bool HasSubItems { get { return true; } }


        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                return l;
            }
        }

        //les lignes dans une table
    }
}
