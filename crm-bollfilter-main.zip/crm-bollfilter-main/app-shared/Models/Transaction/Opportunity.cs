﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Opportunity : Transaction, IModel
    {
        public Opportunity()
        {
            base.DefaultHeadFieldsString = Constants.URI_SALE_HEADFIELDS + ",dataValidFrom,dataValidUntil,salesOrderDate,probability,refusalReason,refusalReason^descrOperLang";
        }

        public DateTime? dataValidFrom { get; set; }
        public DateTime? dataValidUntil { get; set; }
        public DateTime? salesOrderDate { get; set; }
        public string refusalReason { get; set; }
        [JsonProperty(PropertyName = "refusalReason^descrOperLang")]
        public string refusalReason_descrOperLang { get; set; }
        public bool ShouldSerializerefusalReason_descrOperLang()
        {
            return false;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_SALE_OPPORTUNITIES;
            }
        }

        [JsonIgnore]
        public OfflineItems offlineInfo { get; set; }
        public bool ShouldSerializeofflineInfo()
        {
            return false;
        }
    }
}
