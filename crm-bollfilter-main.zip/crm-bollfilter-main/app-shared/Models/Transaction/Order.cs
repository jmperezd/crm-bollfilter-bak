﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Order : Transaction, IModel
    {
        public Order()
        {
            base.DefaultHeadFieldsString = Constants.URI_SALE_HEADFIELDS + ",address,address2,delivTerms,delivTerms^descrOperLang,inhouseContact,inhouseContactDescr";
        }

        public string address { get; set; }
        public string address2 { get; set; }
        public string delivTerms { get; set; }
        [JsonProperty(PropertyName = "delivTerms^descrOperLang")]
        public string delivTerms_descrOperLang { get; set; }
        public bool ShouldSerializedelivTerms_descrOperLang()
        {
            return false;
        }
        public string inhouseContact { get; set; }
        public string inhouseContactDescr { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_SALE_ORDERS;
            }
        }

        [JsonIgnore]        
        public OfflineItems offlineInfo { get; set; }
        public bool ShouldSerializeofflineInfo()
        {
            return false;
        }
    }
}
