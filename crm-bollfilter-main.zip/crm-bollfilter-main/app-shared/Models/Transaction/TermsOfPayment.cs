﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class TermsOfPayment : Model, IModel
    {
        public TermsOfPayment()
        {
            base.DefaultHeadFieldsString = "id,descrOperLang";
        }

        public string descrOperLang { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_TERMS_OF_PAYMENT;
            }
        }
    }
}
