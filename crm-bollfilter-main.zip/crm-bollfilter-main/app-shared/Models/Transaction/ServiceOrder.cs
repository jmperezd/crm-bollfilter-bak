﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class ServiceOrder : Transaction, IModel
    {
        public ServiceOrder()
        {
            base.DefaultHeadFieldsString = Constants.URI_SALE_HEADFIELDS + ",dataValidFrom,dataValidUntil,salesOrderDate,address,address2,delivTerms,delivTerms^descrOperLang,inhouseContact,inhouseContactDescr";
            base.DefaultTableFieldsString = "*,product^descr4,product^swd,serviceProduct^swd,recordType";
        }

        public DateTime? dataValidFrom { get; set; }
        public DateTime? dataValidUntil { get; set; }
        public DateTime? salesOrderDate { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public string delivTerms { get; set; }
        [JsonProperty(PropertyName = "delivTerms^descrOperLang")]
        public string delivTerms_descrOperLang { get; set; }
        public bool ShouldSerializedelivTerms_descrOperLang()
        {
            return false;
        }
        public string inhouseContact { get; set; }
        public string inhouseContactDescr { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_SERVICE_ORDER;
            }
        }

    }
}
