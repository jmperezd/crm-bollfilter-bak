﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class ServiceReservation : Model, IModel
    {
        public ServiceReservation()
        {
            base.DefaultHeadFieldsString = Constants.URI_SERVICE_RESERVATION_HEADFIELDS;            
        }
        public ServiceReservation(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_SERVICE_RESERVATION;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public DateTime startDateExec { get; set; }
        public DateTime deadlineExec { get; set; }

        public string itemText { get; set; }
        public string swd { get; set; }

        [JsonProperty(PropertyName = "serviceEngineerDescr^descrOperLang")]
        public string serviceEngineerDescr_descrOperLang { get; set; }

        public string descr { get; set; }

        public string serviceEngineer { get; set; }

        public string serviceResType { get; set; }

        public string customer { get; set; }

        public string serviceOrderItem { get; set; }

        [JsonProperty(PropertyName = "serviceOrderItem^head^id")]
        public string serviceOrderItem_head_id { get; set; }

        [JsonProperty(PropertyName = "serviceOrderItem^serviceProduct^idno")]
        public string serviceOrderItem_serviceProduct_idno { get; set; }        

        public string status { get; set; }

        public string serviceProduct { get; set; }

        public bool IsService { get; set; }

        [JsonProperty(PropertyName = "customer^descrOperLang")]
        public string customer_descrOperLang { get; set; }

        [JsonProperty(PropertyName = "service^yhexcolor")]
        public string service_yhexcolor { get; set; }        

        [JsonProperty(PropertyName = "customer^zipCode")]
        public string customer_zipCode { get; set; }

        [JsonProperty(PropertyName = "customer^town")]
        public string customer_town { get; set; }

        [JsonProperty(PropertyName = "customer^emailAddr")]
        public string customer_emailAddr { get; set; }

        [JsonProperty(PropertyName = "customer^emailAddr2")]
        public string customer_emailAddr2 { get; set; }

        [JsonProperty(PropertyName = "serviceOrderItem^serviceProduct^zipCode")]
        public string serviceOrderItem_serviceProduct_zipCode { get; set; }

        [JsonProperty(PropertyName = "serviceOrderItem^serviceProduct^town")]
        public string serviceOrderItem_serviceProduct_town { get; set; }
        [JsonProperty(PropertyName = "serviceOrderItem^serviceProduct^ymarque")]
        public string serviceOrderItem_serviceProduct_ymarque { get; set; }
        [JsonProperty(PropertyName = "serviceOrderItem^serviceProduct^ymodele")]
        public string serviceOrderItem_serviceProduct_ymodele { get; set; }
        public string idno { get; set; }

        public bool ShouldSerializecustomer_descrOperLang()
        {
            return false;
        }

        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("startDateExec");
                defaultIndexes.Add("deadlineExec");
                return defaultIndexes;
            }
        }


        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;//new List<FilterField>() { new FilterField() { FieldName = "ysynccrm", Operator = "==", Value = "True" } };

            }
        }


        [JsonIgnore]
        [BsonIgnore]
        public SaleProduct SaleProduct { get; set; }


        [JsonIgnore]
        [BsonIgnore]
        public EngineerCompletionConfirmation EngineerCompletionConfirmation { get; set; }

    }
}
