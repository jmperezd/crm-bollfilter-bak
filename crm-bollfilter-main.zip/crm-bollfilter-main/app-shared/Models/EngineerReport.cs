﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;
using Xamarin.Forms;

namespace Abas_Shared_Xamarin.Models
{
    public class EngineerReport : Model, IModel
    {
        public EngineerReport()
        {            
            base.DefaultHeadFieldsString = Constants.URI_ENGINEER_REPORT_HEADFIELDS;            
        }
        
        public EngineerReport(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_ENGINEER_REPORT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public int idno { get; set; }
        public bool ShouldSerializeidno()
        {
            return false;
        }

        public string serviceQuotOrder { get; set; }

        public string serviceEngineer { get; set; }

        [JsonProperty(PropertyName = "serviceEngineer^descrOperLang")]
        public string serviceEngineer_descrOperLang { get; set; }
        public bool ShouldSerializeserviceEngineer_descrOperLang()
        {
            return false;
        }

        //public string doc { get; set; } //PAS LE PDF 

        //POUR IMPRESSION : XML.MASKEN.P

        public DateTime dateFrom { get; set; }
        public bool ShouldSerializecreationDate()
        {
            return false;
        }
        public DateTime creationDate { get; set; }
        public bool ShouldSerializedateFrom()
        {
            return false;
        }

        public string ysummary { get; set; } //Résumé de l'intervention
        public string ycustcom { get; set; } //Commentaire client
        public string yaddserv { get; set; } //Additional service

        public string ycustname { get; set; } //nom signataire client
        public string ycustsign { get; set; } //signature client
        public DateTime ysigndate { get; set; } //date de signature

        public string yengsign { get; set; } //signature technicien

        public string yfengsign { get; set; } //signature technicien
        public string yfcustsign { get; set; } //signature client


        //SOFTICA
        //public bool ybilansecu { get; set; } // Type d'impression
        public bool ybilansecu { get; set; }
        public string yprotouv { get; set; }  // Protection ouverture
        public string yprotferm { get; set; }
        public string ycell { get; set; }
        public string yfeuclign { get; set; }
        public string yfeuzone { get; set; }
        public string yparachute { get; set; }
        public string ymarqusol { get; set; }
        public string ybandvisu { get; set; }
        public string ycourroie { get; set; }
        public string yressort { get; set; }
        public string ygalets { get; set; }
        public string ychariot { get; set; }
        public string ycable { get; set; }
        public string yrailroul { get; set; }
        public string ytransautre { get; set; }
        public string ycapot { get; set; }
        public string yvantaux { get; set; }
        public string yjoints { get; set; }
        public string yarticul { get; set; }
        public string yjambage { get; set; }
        public string yradar { get; set; }
        public string yselect { get; set; }
        public string ycomautre { get; set; }
        public string yantipani { get; set; }
        public string ysandow { get; set; }
        public string ymotor { get; set; }
        public string ylogicom { get; set; }
        public string yverrou { get; set; }
        public string ybutferm { get; set; }
        public string ybutouv { get; set; }
        public string youlie { get; set; }
        public string yfincourse { get; set; }
        public string ymecaautre { get; set; }
        public bool yverifvit { get; set; }
        public bool yverifconnect { get; set; }
        public bool yreouv { get; set; }
        public string yremgen { get; set; }
        public string yremenvi { get; set; }
        public string ypiecechang { get; set; }

        //SOFTICA END



        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("serviceQuotOrder");
                return l;
            }
        }

        




        [JsonIgnore]
        [BsonIgnore]
        public string ClientSignaturePath { get; set; }
        [JsonIgnore]
        [BsonIgnore]
        public string TechnicianSignaturePath { get; set; }


    }
}
