﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class ServiceReservationSAV : Model, IModel
    {
        public ServiceReservationSAV()
        {
            base.DefaultHeadFieldsString = "id,idno,swd,customer,wOrderFormatEndTime,serviceAssignmentDateTo,fromTime,deadline,serviceProduct^descrOperLang,productDescr,serviceEngineerDescr^descrOperLang,head^idno,status,recTypeHeader";
            
        }
        public ServiceReservationSAV(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return "/obj/data/3:2";
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string serviceAssignmentDateTo { get; set; }
        public string wOrderFormatEndTime { get; set; }
        public DateTime deadline { get; set; }

        public string swd { get; set; }
        public string idno { get; set; }
        public string customer { get; set; }
        public string fromTime { get; set; }
        public string productDescr { get; set; }
        [JsonProperty(PropertyName = "serviceEngineerDescr^descrOperLang")]
        public string serviceEngineerDescr_descrOperLang { get; set; }
        public string status { get; set; }

        [JsonProperty(PropertyName = "head^idno")]
        public string head_idno { get; set; }

        [JsonProperty(PropertyName = "serviceProduct^descrOperLang")]
        public string serviceProduct_descrOperLang { get; set; }
        public string recTypeHeader { get; set; }

        public bool ShouldSerializecustomer_descrOperLang()
        {
            return false;
        }

        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("startDateExec");
                defaultIndexes.Add("deadlineExec");
                return defaultIndexes;
            }
        }


        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;
            }
        }
    }
}
