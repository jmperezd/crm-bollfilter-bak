﻿using LiteDB;
using Newtonsoft.Json;

namespace Abas_Shared_Xamarin.Models
{
    public class BasicEngineerReport : Model, IModel
    {
        public BasicEngineerReport()
        {
            base.DefaultHeadFieldsString = "swd,id,searchExt,idno,yengsign,ycustsign,serviceEngineer,costCenter,wageGrp,serviceQuotOrder,ysummary,ycustcom,yaddserv,ycustname,ybilansecu,yprotouv,yprotferm,ycell,yfeuclign,yfeuzone,yparachute,ymarqusol,ybandvisu,ycourroie,yressort,ygalets,ychariot,ycable,yrailroul,ytransautre,ycapot,yvantaux,yjoints,yarticul,yjambage,yradar,yselect,ycomautre,yantipani,ysandow,ymotor,ylogicom,yverrou,ybutferm,ybutouv,youlie,yfincourse,ymecaautre,yverifvit,yverifconnect,yverifconnect,yreouv,yremgen,yremenvi,ypiecechang";
        }

        public BasicEngineerReport(string _id) : this()
        {
            id = _id;
        }

        public string swd { get; set; }
        public string id { get; set; }
        public string searchExt { get; set; }
        public string idno { get; set; }
        public string yengsign { get; set; }
        public string ycustsign { get; set; }
        public string ycustname { get; set; }
        public string serviceEngineer { get; set; }
        public string costCenter { get; set; }
        public string wageGrp { get; set; }
        public string serviceQuotOrder { get; set; }
        public string ysummary { get; set; }
        public string ycustcom { get; set; }
        public string yaddserv { get; set; }
        public string ybilansecu { get; set; }
        public string yprotouv { get; set; }
        public string yprotferm { get; set; }
        public string ycell { get; set; }
        public string yfeuclign { get; set; }
        public string yfeuzone { get; set; }
        public string yparachute { get; set; }
        public string ymarqusol { get; set; }
        public string ybandvisu { get; set; }
        public string ycourroie { get; set; }
        public string yressort { get; set; }
        public string ychariot { get; set; }
        public string ygalets { get; set; }
        public string ycable { get; set; }
        public string yrailroul { get; set; }
        public string ytransautre { get; set; }
        public string ycapot { get; set; }
        public string yvantaux { get; set; }
        public string yjoints { get; set; }
        public string yarticul { get; set; }
        public string yjambage { get; set; }
        public string yradar { get; set; }
        public string yselect { get; set; }
        public string ycomautre { get; set; }
        public string yantipani { get; set; }
        public string ysandow { get; set; }
        public string ymotor { get; set; }
        public string ylogicom { get; set; }
        public string yverrou { get; set; }
        public string ybutferm { get; set; }
        public string ybutouv { get; set; }
        public string youlie { get; set; }
        public string yfincourse { get; set; }
        public string ymecaautre { get; set; }
        public string yverifvit { get; set; }
        public string yverifconnect { get; set; }
        public string yreouv { get; set; }
        public string yremgen { get; set; }
        public string yremenvi { get; set; }
        public string ypiecechang { get; set; }
        
        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_ENGINEER_REPORT;
            }
        }

    }
}
