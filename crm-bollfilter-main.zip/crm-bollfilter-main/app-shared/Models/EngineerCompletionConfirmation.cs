﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;
using System.Runtime.CompilerServices;
using System.ComponentModel;
using System.Globalization;
using WFramework_Xamarin;

namespace Abas_Shared_Xamarin.Models
{
    public class EngineerCompletionConfirmation : Model, IModel, INotifyPropertyChanged
    {
        public EngineerCompletionConfirmation()
        {
            base.DefaultHeadFieldsString = Constants.URI_ENGINEER_COMPLETION_CONFIRMATION_HEADFIELDS;
        }

        public EngineerCompletionConfirmation(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_ENGINEER_COMPLETION_CONFIRMATION;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public int idno { get; set; }
        public bool ShouldSerializeidno()
        {
            return false;
        }

        public string serviceReservation { get; set; }
        public bool ShouldSerializeserviceReservation()
        {
                return false;
        }

        public string serviceOrderItem { get; set; }
        public bool ShouldSerializeserviceOrderItem()
        {
            return false;
        }

        public string serviceDuration { get; set; } // Durée du temps de travail à poster
        public bool ShouldSerializeserviceDuration()
        {
            if (!string.IsNullOrWhiteSpace(this.serviceDuration))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string serviceProduct { get; set; }

        public string product { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public string openServiceDuration { get; set; } // Temps de travail restant à ne pas saisifr

        public string status { get; set; } //* si terminé
        public bool ShouldSerializestatus()
        {
            if (!string.IsNullOrWhiteSpace(this.status))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public double entQty { get; set; } //Qté à comptabiliser
        public bool ShouldSerializeentQty()
        {
            if (this.entQty > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public double openQtyTradeUnit { get; set; } //Qté non soldée

        public string productBOMUpdateStatus { get; set; } //renseigner par défaut à "sans mise à jour" () par défaut pour les lignes articles

        public string adoptText1 { get; set; } //commentaire 

        [JsonIgnore]
        [BsonIgnore]
        public double requiredQtySalesOrder { get; set; } //Qté commandée à ne pas saisir

        public string engineerReport { get; set; }


        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("serviceReservation");
                return l;
            }
        }





        /* Pour interface */


        [JsonIgnore]
        [BsonIgnore]
        public bool statusCheck = false;
        [JsonIgnore]
        [BsonIgnore]
        public bool StatusCheck
        {
            get
            {
                return statusCheck;
            }
            set
            {
                this.statusCheck = value;
                if (value)
                {
                    this.status = "*";
                }
                else
                {
                    this.status = string.Empty;
                }

                OnPropertyChanged("StatusCheck");
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public double passed = 0;
        [JsonIgnore]
        [BsonIgnore]
        public double Passed
        {
            get
            {
                return passed;
            }
            set
            {
                this.passed = value;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public string TradeUnit
        {
            get; set;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string Remaining
        {
            get
            {
                if (this.TradeUnit == "(HUR)")
                {
                    double remaining = this.requiredQtySalesOrder - this.Passed;

                    int hours;
                    int minutes;
                    if (int.TryParse(this.entryHours, out hours))
                    {
                        
                        remaining -= hours;
                        TimeSpan result = TimeSpan.FromHours(remaining);
                        string fromTimeString = result.ToString("hh' h 'mm' m'");
                    }
                    if (int.TryParse(this.entryMinutes, out minutes))
                    {
                        remaining -= minutes / 60.0;
                        TimeSpan result = TimeSpan.FromHours(remaining);
                        string fromTimeString = result.ToString("hh' h 'mm' m'");
                    }

                    string[] tabRemaining = remaining.ToString().Split(new string[] { "." }, StringSplitOptions.RemoveEmptyEntries);

                    if (tabRemaining.Length > 1)
                    {
                        double test = Convert.ToDouble(tabRemaining[0]);
                        if (test < 0)
                        {
                            string ttt = string.Format("{0}h{1}m", tabRemaining[0].PadLeft(2, '0'), (Math.Round(double.Parse("0." + tabRemaining[1]) * 60)).ToString().PadLeft(2, '0'));
                            return "00 h 00 m";
                        }
                        else
                        {
                            TimeSpan result = TimeSpan.FromHours(test);
                            string fromTimeString = result.ToString("hh' h 'mm' m'");
                            
                            string ttt = string.Format("{0}h{1}m", tabRemaining[0].PadLeft(2, '0'), (Math.Round(double.Parse("0." + tabRemaining[1]) * 60)).ToString().PadLeft(2, '0'));
                            return fromTimeString;
                        }
                    }
                    else
                    {
                        double test = Convert.ToDouble(tabRemaining[0]);
                        if (test < 0)
                        {
                            string ttt = string.Format("{0}h{1}m", tabRemaining[0].PadLeft(2, '0'), "00");
                            return "00 h 00 m";

                        }
                        else
                        {
                            TimeSpan result = TimeSpan.FromHours(test);
                            string fromTimeString = result.ToString("hh' h 'mm' m'");
                            
                            string ttt = string.Format("{0}h{1}m", tabRemaining[0].PadLeft(2, '0'), "00");
                            return fromTimeString;
                        }
                    }
                }
                else if (this.TradeUnit == "(PCE)")
                {
                    double remaining = 0 - passed - this.entQty;
                    TimeSpan result = TimeSpan.FromHours(remaining);
                    string fromTimeString = result.ToString("hh' h 'mm' m'");
                    if (remaining < 0)
                    {
                        fromTimeString = "- " + fromTimeString;
                    }

                    //string ttt = string.Format("{0}h{1}m", tabRemaining[0].PadLeft(2, '0'), (Math.Round(double.Parse("0." + tabRemaining[1]) * 60)).ToString().PadLeft(2, '0'));
                    //return fromTimeString;

                    //string remainingString = 
                    //double remaining = this.requiredQtySalesOrder - passed - this.entQty;
                    //return remaining.ToString();
                    return fromTimeString;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public string entryHours;
        [JsonIgnore]
        [BsonIgnore]
        public string EntryHours
        {
            get
            {
                return entryHours;
            }
            set
            {
                this.entryHours = value;
                this.ReloadServiceDuration();
                OnPropertyChanged("EntryHours");
                OnPropertyChanged("Remaining");
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public string entryMinutes;
        [JsonIgnore]
        [BsonIgnore]
        public string EntryMinutes
        {
            get
            {
                return entryMinutes;
            }
            set
            {
                this.entryMinutes = value;
                this.ReloadServiceDuration();
                OnPropertyChanged("EntryMinutes");
                OnPropertyChanged("Remaining");
            }

        }

        [JsonIgnore]
        [BsonIgnore]
        public string entryQuantity;
        [JsonIgnore]
        [BsonIgnore]
        public string EntryQuantity
        {
            get
            {
                return entryQuantity;
            }
            set
            {
                this.entryQuantity = value;
                double quantity;                
                string val = ToolsHelper.ReplaceDotsString(value); ;                
                if (double.TryParse(val, out quantity))
                {
                    this.entQty = quantity;
                }
                else
                {
                    this.entQty = 0;
                }
                OnPropertyChanged("EntryQuantity");
                OnPropertyChanged("Remaining");
            }

        }

        [JsonIgnore]
        [BsonIgnore]
        public bool Changed
        {
            get
            {
                if (!string.IsNullOrEmpty(this.EntryHours)
                    || !string.IsNullOrEmpty(EntryMinutes)
                    || this.entQty > 0
                    || !string.IsNullOrEmpty(this.status))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public string FormattedTime
        {
            get
            {
                int hours;
                int minutes;
                if (!int.TryParse(this.entryHours, out hours))
                {
                    hours = 0;
                }
                if (!int.TryParse(this.entryMinutes, out minutes))
                {
                    minutes = 0;
                }

                return string.Format("{0}{1}", hours, minutes.ToString().PadLeft(2, '0'));
            }
        }

        public void ReloadServiceDuration()
        {
            if (!string.IsNullOrWhiteSpace(this.EntryHours) && !string.IsNullOrWhiteSpace(this.EntryMinutes))
            {
                this.serviceDuration = string.Format("{0}h{1}m", this.EntryHours, this.EntryMinutes);
            }
            else if (!string.IsNullOrWhiteSpace(this.EntryHours))
            {
                this.serviceDuration = string.Format("{0}h", this.EntryHours);
            }
            else if (!string.IsNullOrWhiteSpace(this.EntryMinutes))
            {
                this.serviceDuration = string.Format("{0}m",this.EntryMinutes);
            }
            else
            {
                this.serviceDuration = string.Empty;
            }
        }



        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion


        /* Fin Pour interface */


    }

}
