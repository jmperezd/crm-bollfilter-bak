﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using Abas_Shared_Xamarin.Classes;

namespace Abas_Shared_Xamarin.Models
{
    public class Product : Model, IModel
    {
        public Product()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRODUCT_HEADFIELDS;
            if(Constants.VERSION_SOFTICA)
            {
                base.DefaultHeadFieldsString += ",ysynccrm";
            }
        }
        public Product(string _id) : this()
        {
            id = _id;
        }
        
        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_PRODUCT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [JsonIgnore]
        public string all {
            get { return this.swd + " " + this.searchExtLower + " " + this.descrOperLangLower; }
        }

        public string idno { get; set; }
        public string swd { get; set; }
        public string descrOperLang { get; set; }
        public string type { get; set; }
        [JsonIgnore]
        public string descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.descrOperLang) ? this.descrOperLang.ToLower() : string.Empty; } }
        public string salesTradeUnit { get; set; } //Unité à proposer par défaut
        public string purchPriceUnit { get; set; } //
        public string SU { get; set; } // 
        public double purchPrice { get; set; }
        public double salesPrice2 { get; set; }
        public bool ysynccrm { get; set; }
        public string searchExt { get; set; }
        [JsonIgnore]
        public string searchExtLower { get { return !string.IsNullOrWhiteSpace(this.searchExt) ? this.searchExt.ToLower() : string.Empty; } }

        //Fields for the article Page        
        public string globalTradeItemNo { get; set; }
        public string weight { get; set; }
        public string packDimLength { get; set; }
        public string packDimWidth { get; set; }
        public string packDimHeight { get; set; }
        public string salesPrice { get; set; }
        public string salesPriceUnit { get; set; }
        [JsonProperty(PropertyName = "salesCurr^descr")]
        public string salesCurr_descr { get; set; }

        public string warrantyPer { get; set; }
        public string catalogMeta { get; set; }


        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("descrOperLang");
                defaultIndexes.Add("searchExtLower");
                defaultIndexes.Add("all");
                return defaultIndexes;
            }
        }

        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;                
            }
        }

        //Calcul du prix
        //http://rdp.abas-france.fr:10080/mw/r/demo/workspace/ws-151/wip/ep-4d9cb71c-dcd0-436d-bf73-697a8436ebda?variableLanguage=EN
        //http://rdp.abas-france.fr:10080/mw/r/demo/sys/typeCmd/(PriceInformation)
        //Id du client dans custVendor
        //Id product dans product
        //quantité dans unitQty
        //unité de vente dans tradeUnit

        //Date de conditionnement condDate
    }
}
