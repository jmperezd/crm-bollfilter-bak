﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public enum CustomerTypes
    {
        CUSTOMER,
        PROSPECT,
        CONTACT_CUSTOMER,
        CONTACT_PROSPECT,
        ALL
    }
}
