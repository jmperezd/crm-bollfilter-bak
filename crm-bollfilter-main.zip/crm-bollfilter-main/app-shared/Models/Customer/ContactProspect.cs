﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class ContactProspect : Tiers, IModel
    {
        public ContactProspect()
            : base("7")
        {
            base.DefaultHeadFieldsString = Constants.URI_CONTACT_PROSPECT_HEADFIELDS;
        }

        public ContactProspect(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_CONTACT_PROSPECT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }

        public string companyARAP { get; set; }
        [JsonProperty(PropertyName = "companyARAP^rep")]
        public string companyARAP_rep { get; set; }
        public bool ShouldSerializecompanyARAP_rep()
        {
            return false;
        }
        [JsonIgnore]
        public string rep { get { return this.companyARAP_rep; } }

    }
}
