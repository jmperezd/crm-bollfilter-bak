﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class CustomerProspect : Tiers, IModel
    {
        public CustomerProspect()
            : base(new List<String> { "1", "6" })
        {
            base.DefaultHeadFieldsString = Constants.URI_CUSTOMER_HEADFIELDS;
        }

        public CustomerProspect(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_CUSTOMER;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }


        public string rep { get; set; }//Representant

        /*
        [JsonIgnore]
        public string InfoSysPath
        {
            get
            {
                return "/st/LKU";
            }
        }

        [JsonIgnore]
        public string InfoSysMember
        {
            get
            {
                return "tnum";
            }
        }
        */

    }
}
