﻿using static Abas_Shared_Xamarin.Services.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using LiteDB;
using WFramework_Xamarin;

namespace Abas_Shared_Xamarin.Models
{
    public class Tiers : Model, IModel
    {
        public Tiers()
        {

        }

        public Tiers(String groupToGet)
        {
            this.grpNo = groupToGet;
        }

        public Tiers(List<String> groupToGets) {
            this.grpNos = groupToGets;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return null;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("grpNo");
                l.Add("swdLower");
                l.Add("all");
                return l;
            }
        }


        [JsonIgnore]
        [BsonIgnore]
        public List<string> grpNos
        {
            get; private set;
        }

        [ForeignKeyID]
        public string id { get; set; }
        public string grpNo { get; set; }
        public string idno { get; set; } //N° d'identité
        public bool ShouldSerializeidno()
        {
            return false;
        }
        [JsonIgnore]
        public string Descr
        {
            get
            {
                return
                    (descr != "" ? descr :
                    (descr1 != "" ? descr1 :
                    (descr2 != "" ? descr2 :
                    (descr3 != "" ? descr3 :
                    descr4))));
            }
            set
            {
                descr = value;
            }
        }

        [JsonIgnore]
        public string all{
            get { return this.swdLower + " " + this.idno + " " + this.descrOperLangLower + " " + this.addrFullLower + " " + this.ctryCodeLower + " " + this.phoneNo + " " + this.cellPhoneNo; }
        }

        public string descr { get; set; }
        public bool ShouldSerializedescr()
        {
            return false;
        }
        public string descr1 { get; set; }
        public bool ShouldSerializedescr1()
        {
            return false;
        }
        public string descr2 { get; set; }
        public bool ShouldSerializedescr2()
        {
            return false;
        }
        public string descr3 { get; set; }
        public bool ShouldSerializedescr3()
        {
            return false;
        }
        public string descr4 { get; set; }
        public bool ShouldSerializedescr4()
        {
            return false;
        }
        public string descrOperLang { get; set; }
        [JsonIgnore]
        public string descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.descrOperLang) ? this.descrOperLang.ToLower().DeleteAccentMarks() : string.Empty; } }
        public string swd { get; set; } //Clé de recherche
        [JsonIgnore]
        public string swdLower { get { return !string.IsNullOrWhiteSpace(this.swd) ? this.swd.ToLower().DeleteAccentMarks() : string.Empty; } } //Clé de recherche
        public string webSiteURL { get; set; }
        public string emailAddr { get; set; }
        public string contactPerson { get; set; } //Contact
        //public string targetCustomer { get; set; } //True if customer
        [ForeignKeyID]
        public string inhouseContact { get; set; }
        public string inhouseContactDescr { get; set; }
        public bool ShouldSerializeinhouseContactDescr()
        {
            return false;
        }

        public string zipCode { get; set; }
        [JsonIgnore]
        public string zipCodeLower { get { return !string.IsNullOrWhiteSpace(this.town) ? this.town.ToLower() : string.Empty; } }
        public string addr { get; set; }
        [JsonIgnore]
        public string addrLower { get { return !string.IsNullOrWhiteSpace(this.addr) ? this.addr.ToLower() : string.Empty; } }
        [JsonIgnore]
        public string addrFullLower { get { return !string.IsNullOrWhiteSpace(this.addr) && !string.IsNullOrWhiteSpace(this.street) && !string.IsNullOrWhiteSpace(this.town) && !string.IsNullOrWhiteSpace(this.zipCodeLower) ? this.addr.ToLower().DeleteAccentMarks() + " " + this.street.ToLower().DeleteAccentMarks() + " " + this.town.ToLower().DeleteAccentMarks() + " " + this.zipCodeLower.DeleteAccentMarks() : string.Empty; } }
        public string street { get; set; }
        public string town { get; set; }
        [JsonIgnore]
        public string townLower { get { return !string.IsNullOrWhiteSpace(this.town) ? this.town.ToLower() : string.Empty; } }
        public string stateOfTaxOffice { get; set; }
        public string phoneNo { get; set; }
        public string cellPhoneNo { get; set; }
        public string faxNo { get; set; }
        public string longitude { get; set; }
        public string latitude { get; set; }
        public string ctryCode { get; set; }
        [JsonIgnore]
        public string ctryCodeLower { get { return !string.IsNullOrWhiteSpace(this.ctryCode) ? this.ctryCode.ToLower().DeleteAccentMarks() : string.Empty; } }


        public string zipCode2 { get; set; }
        public string addr2 { get; set; }
        public string street2 { get; set; }
        public string town2 { get; set; }
        public string stateOfTaxOffice2 { get; set; }
        public string phoneNo2 { get; set; }
        public string cellPhoneNo2 { get; set; }
        public string faxNo2 { get; set; }
        public string emailAddr2 { get; set; }
        public string webSiteURL2 { get; set; }

        //public string industry { get; set; }

        public string characteristicIdentifier1 { get; set; }
        public bool ShouldSerializecharacteristicIdentifier1()
        {
            return false;
        }
        public string characteristicIdentifier2 { get; set; }
        public bool ShouldSerializecharacteristicIdentifier2()
        {
            return false;
        }
        public string characteristicIdentifier3 { get; set; }
        public bool ShouldSerializecharacteristicIdentifier3()
        {
            return false;
        }
        public string characteristicIdentifier4 { get; set; }
        public bool ShouldSerializecharacteristicIdentifier4()
        {
            return false;
        }
        public string characteristicIdentifier5 { get; set; }
        public bool ShouldSerializecharacteristicIdentifier5()
        {
            return false;
        }
        public string characteristicIdentifier6 { get; set; }
        public bool ShouldSerializecharacteristicIdentifier6()
        {
            return false;
        }

        public string characteristic1 { get; set; }
        [JsonProperty(PropertyName = "characteristic1^descrOperLang")]
        public string characteristic1_descrOperLang { get; set; }
        public bool ShouldSerializecharacteristic1_descrOperLang()
        {
            return false;
        }
        public string characteristic2 { get; set; }
        [JsonProperty(PropertyName = "characteristic2^descrOperLang")]
        public string characteristic2_descrOperLang { get; set; }
        public bool ShouldSerializecharacteristic2_descrOperLang()
        {
            return false;
        }
        public string characteristic3 { get; set; }
        [JsonProperty(PropertyName = "characteristic3^descrOperLang")]
        public string characteristic3_descrOperLang { get; set; }
        public bool ShouldSerializecharacteristic3_descrOperLang()
        {
            return false;
        }
        public string characteristic4 { get; set; }
        [JsonProperty(PropertyName = "characteristic4^descrOperLang")]
        public string characteristic4_descrOperLang { get; set; }
        public bool ShouldSerializecharacteristic4_descrOperLang()
        {
            return false;
        }
        public string characteristic5 { get; set; }
        [JsonProperty(PropertyName = "characteristic5^descrOperLang")]
        public string characteristic5_descrOperLang { get; set; }
        public bool ShouldSerializecharacteristic5_descrOperLang()
        {
            return false;
        }
        public string characteristic6 { get; set; }
        [JsonProperty(PropertyName = "characteristic6^descrOperLang")]
        public string characteristic6_descrOperLang { get; set; }
        public bool ShouldSerializecharacteristic6_descrOperLang()
        {
            return false;
        }

        public string comments { get; set; }

        public string rep { get; set; }//Representant
    }
}
