﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Customer : Tiers, IModel
    {
        public Customer() : base("1")
        {            
            base.DefaultHeadFieldsString = Constants.URI_CUSTOMER_HEADFIELDS;            
        }

        public Customer(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_CUSTOMER;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }


        //public string rep { get; set; }//Representant
        public string repDescr { get; set; }
        public string yagence { get; set; }
        public bool ShouldSerializerepDescr()
        {
            return false;
        }

        public string serviceEngineer { get; set; }//Service ingénieur

        /*
        [JsonIgnore]
        public string InfoSysPath
        {
            get
            {
                return "/st/LKU";
            }
        }

        [JsonIgnore]
        public string InfoSysMember
        {
            get
            {
                return "tnum";
            }
        }
*/
    }
}
