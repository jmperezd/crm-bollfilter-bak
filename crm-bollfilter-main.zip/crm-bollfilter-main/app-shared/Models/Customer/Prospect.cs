﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Prospect : Tiers, IModel
    {
        public Prospect()
            : base("6")
        {
			base.DefaultHeadFieldsString = Constants.URI_PROSPECT_HEADFIELDS;
        }

		public Prospect(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_PROSPECT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CUSTOMER;
            }
        }

        public string repDescr { get; set; }
        public bool ShouldSerializerepDescr()
        {
            return false;
        }

        [JsonIgnore]
        public OfflineItems offlineInfo { get; set; }
        public bool ShouldSerializeofflineInfo()
        {
            return false;
        }

    }
}
