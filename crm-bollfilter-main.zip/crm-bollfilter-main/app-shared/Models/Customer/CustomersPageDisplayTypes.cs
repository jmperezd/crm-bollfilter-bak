﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public enum CustomersPageDisplayTypes
    {
        ALL, //Customer, prospect, contacts
        CUSTOMER_PROSPECT, //Customer, prospect
        CUSTOMER, 
        PROSPECT,
        CUSTOMER_CONTACT,
        PROSPECT_CONTACT,
        CUSTOMER_AND_CONTACT,
        PROSPECT_AND_CONTACT
    }
}
