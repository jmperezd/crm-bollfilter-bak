﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Abas_Shared_Xamarin.Models
{

    public class Raw
    {
        public string mode { get; set; } = "raw";
        //[JsonProperty] 
        public string raw { get; set; }

    }

}