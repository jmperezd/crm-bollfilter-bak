﻿using System; 
namespace Abas_Shared_Xamarin.Models 
{ 
    public class Table 
    { 
        public int tabsvorkommen { get; set; } 
        public double tnettowert { get; set; } 
        public string tvktypa { get; set; } 
    } 
} 