﻿using System; 
namespace Abas_Shared_Xamarin.Models 
{ 
    public class ActionActivity
    { 
        public string _type { get; set; } 
        public string fieldName { get; set; } 
        public string value { get; set; }
        public string rowSpec { get; set; }

        private ActionActivity() 
        { 
 
        } 
 
        public static ActionActivity New(string value, string fieldName, string type) 
        { 
            ActionActivity actionMan = new ActionActivity() 
            { 
                value = value, 
                fieldName = fieldName, 
                _type = type 
            }; 
            return actionMan;
        }

        public static ActionActivity New(string value, string fieldName, string type, string row)
        {
            ActionActivity actionMan = new ActionActivity()
            {
                value = value,
                fieldName = fieldName,
                _type = type,
                rowSpec = row
            };
            return actionMan;
        }

        public static ActionActivity NewSolo(string type) 
        { 
            ActionActivity actionMan = new ActionActivity() 
            { 
                _type = type 
            }; 
            return actionMan; 
        } 
    } 
} 