﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public class XvisemaInfosystem : Model, IModel
    {
        public String BasePath
        {
            get
            {
                return Constants.URI_INFOSYS + Constants.URI_INFOSYS_XVISEMA;
            }
        }        
    }
}