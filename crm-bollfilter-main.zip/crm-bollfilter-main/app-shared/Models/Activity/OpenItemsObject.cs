﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using LiteDB;

namespace Abas_Shared_Xamarin.Models
{ 
    public class OpenItemsObject : Model, IModel
    { 
        public int echu1_30 { get; set; } 
        public int echu31_60 { get; set; } 
        public int echu61_90 { get; set; } 
        public int echu90 { get; set; } 
        public int echeance0_29 { get; set; } 
        public int echeance30_59 { get; set; } 
        public int echeance60_89 { get; set; } 
        public int echeance89 { get; set; } 
        public int total { get; set; } 
        public int totalUntilNow { get; set; } 

        public String BasePath
        {
            get
            {
                return Constants.URI_INFOSYS + Constants.URI_INFOSYS_OPEN_ITEMS;
            }
        }


        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return "openitems";
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;
            }
        }

        public OpenItemsObject()
        {
            base.DefaultHeadFieldsString = Constants.URI_OPEN_ITEMS_HEADFIELDS;
        }

        public OpenItemsObject(dynamic d) : this()
        {
            try
            {
                this.echu1_30 = d.head.f2betr1;
                this.echu31_60 = d.head.f2betr2;
                this.echu61_90 = d.head.f2betr3;
                this.echu90 = d.head.f2betr4;
                this.echeance0_29 = d.head.fbetr1;
                this.echeance30_59 = d.head.fbetr2;
                this.echeance60_89 = d.head.fbetr3;
                this.echeance89 = d.head.fbetr4;
                this.total = d.head.fgesamt;
                this.totalUntilNow = d.head.f2betr1 + d.head.f2betr2 + d.head.f2betr3 + d.head.f2betr4;
            }
            catch (Exception ex)
            {

            }
            
        }
    } 
} 