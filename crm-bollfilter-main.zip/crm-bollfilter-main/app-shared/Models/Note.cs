﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Note : Model, IModel
    {
        public Note()
        {
            base.DefaultHeadFieldsString = Constants.URI_NOTE_HEADFIELDS;
        }
        
        public Note(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_NOTE;
            }
        }

        [JsonIgnore]
        public string all
        {
            get { return this.swdLower + " " + this.idno.ToString() + " " + this.dateLower + " " + this.typeLower + " " + this.type_descrOperLangLower + " " + this.descrOperLangLower + " " + this.businessPartner_descrOperLangLower; }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public int idno { get; set; }
        public bool ShouldSerializeidno()
        {
            return false;
        }
        public string swd { get; set; }
        [JsonIgnore]
        public string swdLower { get { return !string.IsNullOrWhiteSpace(this.swd) ? this.swd.ToLower() : string.Empty; } } //Clé de recherche

        public string type { get; set; }
        [JsonIgnore]
        public string typeLower { get { return !string.IsNullOrWhiteSpace(this.type) ? this.type.ToLower() : string.Empty; } }

        public bool ShouldSerializetype()
        {
            if (string.IsNullOrWhiteSpace(type))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        [JsonProperty(PropertyName = "type^descrOperLang")]
        public string type_descrOperLang { get; set; }

        [JsonIgnore]
        public string type_descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.type_descrOperLang) ? this.type_descrOperLang.ToLower() : string.Empty; } }

        public bool ShouldSerializetype_descrOperLang()
        {
            return false;
        }

        public string descrOperLang { get; set; }
        [JsonIgnore]
        public string descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.descrOperLang) ? this.descrOperLang.ToLower() : string.Empty; } }

        public string descrTextModuleOperLang { get; set; }
        [ForeignKeyID]
        public string triggerOfEnt { get; set; }
        [ForeignKeyID]
        public string businessPartner { get; set; }
        public bool ShouldSerializebusinessPartner()
        {
            if (string.IsNullOrWhiteSpace(businessPartner))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        [ForeignKeyID]
        public string productListElem { get; set; }
        [ForeignKeyID]
        public string purchSalesTrans { get; set; }
        public string purchSalesTransExt { get; set; }

        public string intProcess { get; set; }
        [ForeignKeyID]
        public string editor { get; set; }


        [JsonProperty(PropertyName = "editor^descrOperLang")]
        public string editor_descrOperLang { get; set; }
        [JsonIgnore]
        public string editor_descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.editor_descrOperLang) ? this.editor_descrOperLang.ToLower() : string.Empty; } }


        [JsonProperty(PropertyName = "businessPartner^descrOperLang")]
        public string businessPartner_descrOperLang { get; set; }
        [JsonIgnore]
        public string businessPartner_descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.businessPartner_descrOperLang) ? this.businessPartner_descrOperLang.ToLower() : string.Empty; } }

        

        public bool ShouldSerializeeditor_descrOperLang()
        {
            return false;
        }

        public string prio { get; set; }
        public DateTime date { get; set; }
        [JsonIgnore]
        public string dateLower { get { return !string.IsNullOrWhiteSpace(this.date.ToShortDateString()) ? this.date.ToShortDateString().ToLower() : string.Empty; } }

        public bool ShouldSerializedate()
        {
            return false;
        }
        public DateTime currTime { get; set; }
        public bool ShouldSerializecurrTime()
        {
            return false;
        }


        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("all");
                l.Add("swdLower");
                return l;
            }
        }


        [JsonIgnore]
        public OfflineItems offlineInfo { get; set; }
        public bool ShouldSerializeofflineInfo()
        {
            return false;
        }
    }
}
