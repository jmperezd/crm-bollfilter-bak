﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class WebUser : Model, IModel
    {
        public WebUser()
        {
            base.DefaultHeadFieldsString = "login,pwd,id,webRoleList,swd";
        }

        public WebUser(string _id) : this()
        {
            id = _id;
        }

        public override string BasePath
        {
            get
            {
                return Constants.URI_WEBUSERS;
            }
        }

        public string login { get; set; }
        public string pwd { get; set; }
        public string swd { get; set; }
        public string webRoleList { get; set; }
        public string employeeSwd { get; set; }

        [JsonIgnore]
        public string RoleSalesTeamLeader { get; set; } // Team Leader associé au rôle /!\ pointe vers la table des employés
        [JsonIgnore]
        public string RoleEmployee { get; set; } // Employé associé au rôle pointe vers la table employee
        [JsonIgnore]
        public string RoleSalesRep { get; set; } // Commercial associé au rôle /!\ pointe vers la table des clients
        [JsonIgnore]
        public string RoleServiceEngineer { get; set; } // Technicien associé au rôle /!\ pointe vers la table des employés
        [JsonIgnore]
        [JsonProperty(PropertyName = "RoleServiceEngineer^swd")]
        public string RoleServiceEngineer_swd { get; set; }
        [JsonIgnore]
        public string EngineerId { get; set; }

        [JsonIgnore]
        public string costCenter { get; set; }
    }
}
