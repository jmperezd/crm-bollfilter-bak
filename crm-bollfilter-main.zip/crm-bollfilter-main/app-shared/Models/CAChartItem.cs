﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public class CAChartItem : ChartItem
    {
        public string Month { get; set; }
    }
}
