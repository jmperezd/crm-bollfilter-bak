﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Employee : Model, IModel
    {
        public Employee()
        {
            base.DefaultHeadFieldsString = Constants.URI_EMPLOYEE_HEADFIELDS;
        }
        public Employee(string _id) : this()
        {
            id = _id;
        }
        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_EMPLOYEE;
            }
        }

        public string Descr {
            get {
                return
                    (descr != "" ? descr :
                    (descr1 != "" ? descr1 :
                    (descr2 != "" ? descr2 :
                    (descr3 != "" ? descr3 :
                    descr4))));
            }
            set {
                descr = value;
            }
        }
        public string descr { get; set; }
        public string descr1 { get; set; }
        public string descr2 { get; set; }
        public string descr3 { get; set; }
        public string descr4 { get; set; }
        public string wage { get; set; }

    }
}
