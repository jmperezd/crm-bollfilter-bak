﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Task : Model, IModel
    {
        public Task()
        {
            base.DefaultHeadFieldsString = Constants.URI_TASK_HEADFIELDS;
        }

        public Task(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_TASK;
            }
        }

        [JsonIgnore]
        public string all
        {
            get { return this.swdLower + " " + this.descrOperLangLower + " " + this.prioLower + " " + this.endDateLower + " " + this.prio_descrOperLangLower + " " + this.editorLower + " " + this.editor_descrOperLangLower; }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string status { get; set; }
        public string swd { get; set; } //clé de recherche
        public string idno { get; set; } 
        [JsonIgnore]
        public string swdLower { get { return !string.IsNullOrWhiteSpace(this.swd) ? this.swd.ToLower() : string.Empty; } } //Clé de recherche
        public string keyWord { get; set; } //Mot-clé
        public string descrOperLang { get; set; } //Titre
        [JsonIgnore]
        public string descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.descrOperLang) ? this.descrOperLang.ToLower() : string.Empty; } } 
        public string prio { get; set; } //Priorité
        [JsonIgnore]
        public string prioLower { get { return !string.IsNullOrWhiteSpace(this.prio) ? this.prio.ToLower() : string.Empty; } }

        [JsonProperty(PropertyName = "prio^descrOperLang")]
        public string prio_descrOperLang {get; set;}
        [JsonIgnore]
        public string prio_descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.prio_descrOperLang) ? this.prio_descrOperLang.ToLower() : string.Empty; } }
        public bool ShouldSerializeprio_descrOperLang()
        {
            return false;
        }

        [ForeignKeyID]
        public string purchSalesTrans { get; set; }
        [JsonProperty(PropertyName = "purchSalesTrans^purchSalesTrans")]
        public string purchSalesTrans_purchSalesTrans { get; set; }
        public bool ShouldSerializepurchSalesTrans_purchSalesTrans()
        {
            return false;
        }

        public DateTime endDate { get; set; } //Date
        [JsonIgnore]
        public string endDateLower { get { return !string.IsNullOrWhiteSpace(this.endDate.ToShortDateString()) ? this.endDate.ToShortDateString().ToLower() : string.Empty; } }
        [ForeignKeyID]
        public string confirm { get; set; } //Responsable (planifié par?)
        [JsonProperty(PropertyName = "confirm^descrOperLang")]
        public string confirm_descrOperLang { get; set; }
        public bool ShouldSerializeconfirm_descrOperLang()
        {
            return false;
        }

        //Utiles dans l'écran d'édition :
        public string descrTextModuleOperLang { get; set; } //Description

        public string editor { get; set; }//Opérateur (planifié pour?)
        [JsonIgnore]
        public string editorLower { get { return !string.IsNullOrWhiteSpace(this.editor) ? this.editor.ToLower() : string.Empty; } }

        [JsonProperty(PropertyName = "editor^descrOperLang")]
        public string editor_descrOperLang { get; set; }
        [JsonIgnore]
        public string editor_descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.editor_descrOperLang) ? this.editor_descrOperLang.ToLower() : string.Empty; } }

        public bool ShouldSerializeeditor_descrOperLang()
        {
            return false;
        }

        public string businessPartner { get; set; } //Partenaire commercial (contact ?)


        [JsonProperty(PropertyName = "businessPartner^descrOperLang")]
        public string businessPartner_descrOperLang { get; set; }
        public bool ShouldSerializebusinessPartner_descrOperLang()
        {
            return false;
        }

       
        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("all");
                l.Add("swdLower");
                return l;
            }
        }

        [JsonIgnore]
        public OfflineItems offlineInfo { get; set; }
        public bool ShouldSerializeofflineInfo()
        {
            return false;
        }


    }
}
