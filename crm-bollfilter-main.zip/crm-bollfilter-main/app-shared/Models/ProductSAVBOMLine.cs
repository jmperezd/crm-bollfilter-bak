﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class ProductSAVBOMLine : Model, IModel
    {
        public ProductSAVBOMLine()
        {
           //base.DefaultHeadFieldsString = Constants.URI_PRODUCT_SAV_BOM_HEADFIELDS;
        }
        public ProductSAVBOMLine(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_PRODUCT_SAV_BOM + "_line";
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [JsonIgnore]
        public string all {
            get { return this.idno + " " + this.elemDescrLower; }
        }

        public string idno { get; set; }
        public string elemDescr { get; set; }
        [JsonIgnore]
        public string elemDescrLower { get { return !string.IsNullOrWhiteSpace(this.elemDescr) ? this.elemDescr.ToLower() : string.Empty; } }
        /*
        public string product { get; set; }
               
        public string searchExt { get; set; }
        [JsonIgnore]
        public string searchExtLower { get { return !string.IsNullOrWhiteSpace(this.searchExt) ? this.searchExt.ToLower() : string.Empty; } }
        */       

        public DateTime creationDate { get; set; }

        public string elemQty { get; set; }
        public string elemSU { get; set; }

        public DateTime serviceProductImplFrom { get; set; }
        public DateTime serviceProductImplTo { get; set; }

        /*
        [JsonProperty(PropertyName = "elemSU^descrOperLang")]
        public string elemSU_descrOperLang { get; set; }
        */

        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("elemDescrLower");
                //defaultIndexes.Add("searchExtLower");
                defaultIndexes.Add("all");
                return defaultIndexes;
            }
        }

        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;

            }
        }
    }
}
