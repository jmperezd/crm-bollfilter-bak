﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Agence : Tiers, IModel
    {
        public Agence() : base("1")
        {
            base.DefaultHeadFieldsString = Constants.URI_AGENCY_HEADFIELDS;
            base.DefaultTableFieldsString = Constants.URI_AGENCY_TABLEFIELDS;            
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_AGENCY;
            }
        }
            
        public List<ErpDataObject> erpDataObjects { get; set; }
    }

    public class HeadAgency
    {
        public string id { get; set; }
        public string swd { get; set; }
    }

    public class TableAgence
    {
        public string ytech { get; set; }
        public string ysecteur { get; set; }
    }

    public class ErpDataObject
    {        
        public HeadAgency head { get; set; }
        public List<TableAgence> table { get; set; }
    } 
}
