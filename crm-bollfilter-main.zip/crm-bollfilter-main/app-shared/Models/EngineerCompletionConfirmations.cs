﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class EngineerCompletionConfirmations : EngineerReport, IModel
    {
        public EngineerCompletionConfirmations()
        {
            base.DefaultHeadFieldsString = Constants.URI_ENGINEER_COMPLETION_CONFIRMATIONS_HEADFIELDS;
        }

        public EngineerCompletionConfirmations(string _id) : this()
        {
            id = _id;
        }


        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_ENGINEER_COMPLETION_CONFIRMATIONS;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public int idno { get; set; }
        public bool ShouldSerializeidno()
        {
            return false;
        }

        public int serviceReservationIdno { get; set; }
        public bool ShouldSerializeserviceReservationIdno()
        {
            return false;
        }

        public string serviceQuotOrder { get; set; }

        public string costCenter { get; set; }

        //public string status { get; set; }

        public string wageGrp { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                //l.Add("serviceReservation");
                return l;
            }
        }


        public EngineerCompletionConfirmations Copy()
        {
            EngineerCompletionConfirmations copy = new EngineerCompletionConfirmations();
            copy.serviceEngineer = this.serviceEngineer;
            copy.dateFrom = this.dateFrom;
            copy.serviceQuotOrder = this.serviceQuotOrder;
            copy.costCenter = this.costCenter;
            copy.wageGrp = this.wageGrp;
           

            copy.ysummary = this.ysummary;
            copy.ycustcom = this.ycustcom;
            copy.yaddserv = this.yaddserv;
            copy.yfengsign = this.yfengsign;
            copy.yfcustsign = this.yfcustsign;
            copy.ysigndate = this.ysigndate;
            copy.ycustname = this.ycustname;

            copy.SubItems = new List<object>();

            foreach(EngineerCompletionConfirmation engineerCompletionConfirmation in this.SubItems)
            {
                if (engineerCompletionConfirmation.Changed)
                {
                    EngineerCompletionConfirmation deepCopy = new EngineerCompletionConfirmation();
                    deepCopy.adoptText1 = engineerCompletionConfirmation.adoptText1;
                    deepCopy.entQty = engineerCompletionConfirmation.entQty;
                    deepCopy.serviceDuration = engineerCompletionConfirmation.serviceDuration;
                    deepCopy.serviceProduct = engineerCompletionConfirmation.serviceProduct;
                    deepCopy.product = engineerCompletionConfirmation.product;
                    deepCopy.status = engineerCompletionConfirmation.status;


                    //Ne fonctionne pas
                    deepCopy.serviceOrderItem = engineerCompletionConfirmation.serviceOrderItem;
                    //Ne fonctionne pas
                    deepCopy.serviceReservation = engineerCompletionConfirmation.serviceReservation;

                    copy.SubItems.Add(deepCopy);
                }
            }

            return copy;
        }



        [BsonIgnore]
        [JsonIgnore]
        public bool HasSubItems { get { return true; } }
    }






}
