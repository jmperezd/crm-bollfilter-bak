﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class CompletionConfirmations : Model, IModel
    {
        public CompletionConfirmations()
        {
            base.DefaultHeadFieldsString = Constants.URI_COMPLETION_CONFIRMATIONS_HEADFIELDS;
        }
        
        public CompletionConfirmations(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_COMPLETION_CONFIRMATIONS;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public int idno { get; set; }
        public bool ShouldSerializeidno()
        {
            return false;
        }

        public double timeRequired { get; set; }

        public string serviceReservation { get; set; } // Durée du temps de travail à poster


        [JsonIgnore]
        [BsonIgnore]
        public override List<string> DefaultIndexes
        {
            get
            {
                var l = base.DefaultIndexes;
                l.Add("serviceReservation");
                return l;
            }
        }


        /*
        [JsonIgnore]
        [BsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                List<FilterField> filterFields = new List<FilterField>();
                filterFields.Add(new FilterField() { FieldName = "@filingmode", Value = "(Both)", Operator = "=" });
                return filterFields;
            }
        }
        */
    }
}
