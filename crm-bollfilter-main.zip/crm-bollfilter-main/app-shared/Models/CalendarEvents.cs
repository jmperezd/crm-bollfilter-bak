﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using WFramework_Xamarin;

namespace Abas_Shared_Xamarin.Models
{
    public class CalendarEvents : Model, IModel
    {

        public CalendarEvents()
        {

        }

        public CalendarEvents(string _id) : this()
        {
            id = _id;
        }

        public string Title { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Description { get; set; }
        public string Zip { get; set; }
        public string Town { get; set; }
        public object Object { get; set; }
        public string ColorBackground { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName
        {
            get
            {
                return Constants.TABLE_CALENDAR_EVENTS;
            }
        }

    }
}
