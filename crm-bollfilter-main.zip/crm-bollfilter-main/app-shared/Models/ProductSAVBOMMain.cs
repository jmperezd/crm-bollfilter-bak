﻿using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class ProductSAVBOM : Model, IModel
    {
        public ProductSAVBOM()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRODUCT_SAV_BOM_HEADFIELDS;
        }
        public ProductSAVBOM(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_PRODUCT_SAV_BOM;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string serviceProduct { get; set; }

        public bool HasSubItems
        {
            get { return true; }
        }

        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("serviceProduct");
                return defaultIndexes;
            }
        }


        public DateTime warrantyTil { get; set; }


        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;

            }
        }
    }
}
