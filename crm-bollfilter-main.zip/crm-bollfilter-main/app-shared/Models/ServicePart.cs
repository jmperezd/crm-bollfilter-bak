﻿using System;
using Newtonsoft.Json;
using LiteDB;
namespace Abas_Shared_Xamarin.Models
{
    public class ServicePart : Model, IModel
    {
        public ServicePart() 
        {
            base.DefaultHeadFieldsString = Constants.URI_SERVICEPART_HEADFIELDS;
        }


        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_SERVICEPART;
            }
        }

        
        public string id { get; set; }
        public string idno { get; set; }
        public string swd { get; set; }
        public string descrOperLang { get; set; }
        public string salesTradeUnit { get; set; } //Unité à proposer par défaut
        public string purchTradeUnit { get; set; }
        public string SU { get; set; } //
        public string purchPriceUnit { get; set; } //
        public string type { get; set; } //


        public string userDefinedVersion { get; set; }
        public string searchExt { get; set; } //

        public string objectGrpNo { get; set; }
        public string characBar { get; set; }



        public double salesPrice { get; set; }
        public double purchPrice { get; set; }
        public string product { get; set; }
        public string status { get; set; }
    }
}
