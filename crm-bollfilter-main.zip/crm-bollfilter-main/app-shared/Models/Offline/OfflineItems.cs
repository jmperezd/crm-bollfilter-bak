﻿using System;
using System.Collections.Generic;
using LiteDB;
using Newtonsoft.Json;

namespace Abas_Shared_Xamarin.Models
{    
    public class OfflineItems : Model, IModel
    {

        public OfflineItems()
        {
            base.DefaultHeadFieldsString = "";
        }

        public OfflineItems(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_SALE_PRODUCT;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        public string Title {get; set;}
        public string SocioComercial { get; set; }
        public string DestinatarioMercancias { get; set; }        
        public DateTime Time { get; set; }
        public List<SaleProduct> listArticles { get; set; }
    }
}

