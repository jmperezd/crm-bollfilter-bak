﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class Characteristic1 : EnumReference, IModel
    {
        public Characteristic1()
        {
            base.DefaultTableFieldsString = "enumIdentifier,refToEnumElem^descrOperLang";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(169,107,0)";
            }
        }


    }
}
