﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class Characteristic2 : EnumReference, IModel
    {
        public Characteristic2()
        {
            base.DefaultTableFieldsString = "enumIdentifier,refToEnumElem^descrOperLang";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(170,107,0)";
            }
        }


    }
}
