﻿using LiteDB;
using Newtonsoft.Json;
using System;

namespace Abas_Shared_Xamarin.Models
{
    public class ClientSector : EnumReference, IModel
    {
        public ClientSector()
        {
            base.DefaultTableFieldsString = "enumIdentifier,refToEnumElem^descrOperLang";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "KDBRANCHE";
            }
        }
    }
}
