﻿using LiteDB;
using Newtonsoft.Json;
using System;

namespace Abas_Shared_Xamarin.Models
{
    public class ClientType : EnumReference, IModel
    {
        public ClientType()
        {
            base.DefaultTableFieldsString = "enumIdentifier,refToEnumElem^descrOperLang";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "KDMERKMAL2";
            }
        }
    }
}
