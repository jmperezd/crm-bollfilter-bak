﻿using System;
using LiteDB;
using Newtonsoft.Json;

namespace Abas_Shared_Xamarin.Models
{
    public class EnumReference : Model
    {
        
        public string enumIdentifier { get; set; }
        public string enumDescr { get; set; }
        [JsonProperty(PropertyName = "refToEnumElem^descrOperLang")]
        public string refToEnumElem_descrOperLang { get; set; }
        
        [JsonIgnore]
        public string id
        {
            get { return this.enumIdentifier; }
            set { }
        }

        [JsonIgnore]
        [BsonIgnore]
        public string enumIdentifierComplete
        {
            get
            {
                return "(" + this.enumIdentifier + ")";
            }
        }

    }
}

