﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class Type : EnumReference, IModel
    {
        public Type()
        {
            base.DefaultTableFieldsString = "enumIdentifier,enumDescr,refToEnumElem^descrOperLang";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "NOTIZART";
            }
        }
    }
}
