﻿using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Models
{
    public class Characteristic3 : EnumReference, IModel
    {
        public Characteristic3()
        {
            base.DefaultTableFieldsString = "enumIdentifier,refToEnumElem^descrOperLang";
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_ENUM_LIST + "(171,107,0)";
            }
        }


    }
}
