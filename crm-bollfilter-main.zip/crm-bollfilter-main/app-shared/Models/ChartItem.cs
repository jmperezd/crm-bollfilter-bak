﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public class ChartItem
    {
        public string Label { get; set; }
        public double Value { get; set; }
    }
}
