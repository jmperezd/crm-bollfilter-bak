﻿using System;
using Newtonsoft.Json;
using WFramework_Xamarin.Table;
using System.Collections.Generic;
using LiteDB;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin.Models
{
    public class Turnover : Model, IModel
    {
        public Turnover()
        {
            base.DefaultHeadFieldsString = Constants.URI_CA_HEADFIELDS + "";
        }

        public Turnover(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public String BasePath
        {
            get
            {
                return Constants.URI_CA;
            }
        }

        public string FY { get; set; }
        public string mainObj { get; set; }
        public int origBal { get; set; }
        public int turnoverPeriod { get; set; }
        public int turnoverPeriod2 { get; set; }
        public int turnoverPeriod3 { get; set; }
        public int turnoverPeriod4 { get; set; }
        public int closingBalTurnover { get; set; }
        public int month1 { get; set; }
        public int month2 { get; set; }
        public int month3 { get; set; }
        public int month4 { get; set; }
        public int month5 { get; set; }
        public int month6 { get; set; }
        public int month7 { get; set; }
        public int month8 { get; set; }
        public int month9 { get; set; }
        public int month10 { get; set; }
        public int month11 { get; set; }
        public int month12 { get; set; }

    }

}