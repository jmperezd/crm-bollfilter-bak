﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public class PrintLayout : Model, IModel
    {
        public PrintLayout()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRINTLAYOUT_HEADFIELS;
        }


        public string BasePath
        {
            get
            {
                return Constants.URI_PRINTLAYOUT;
            }
        }

        public string id { get; set; }
        public int idno { get; set; }
        public string swd { get; set; }
        public string descroperLang { get; set; }
    }
}
