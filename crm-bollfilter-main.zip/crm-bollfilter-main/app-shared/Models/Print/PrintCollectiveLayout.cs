﻿using System;
namespace Abas_Shared_Xamarin.Models.Print
{
    public class PrintCollectiveLayout : Model, IModel
    {
        public PrintCollectiveLayout()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRINTLAYOUT_HEADFIELS;
        }
        public PrintCollectiveLayout(string _id) : this()
        {
            id = _id;
        }

        public string BasePath
        {
            get
            {
                return Constants.URI_PRINTCOLLECTIVELAYOUT;
            }
        }

        public string id { get; set; }
        public int idno { get; set; }
        public string swd { get; set; }
        public string descroperLang { get; set; }
        public string layoutContext { get; set; }



    }
}