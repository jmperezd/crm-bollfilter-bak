﻿using System;
namespace Abas_Shared_Xamarin.Models
{
    public class OpenItemChartItem : ChartItem
    {
        public string ValueLabel { get; set; }
    }
}
