using Newtonsoft.Json;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using WFramework_Xamarin;
using Xamarin.Forms;

namespace Abas_Shared_Xamarin.Models
{
    public class ProductSAV : Model, IModel
    {
        public ProductSAV()
        {
            base.DefaultHeadFieldsString = Constants.URI_PRODUCT_SAV_HEADFIELDS;            
        }
        public ProductSAV(string _id) : this()
        {
            id = _id;
        }

        [JsonIgnore]
        [BsonIgnore]
        public string BasePath
        {
            get
            {
                return Constants.URI_PRODUCT_SAV;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [JsonIgnore]
        public string all
        {
            get { return this.idno + " " + this.searchExtLower.DeleteAccentMarks() + "" + customer_descrOperLang.ToLower().DeleteAccentMarks() + " " + this.descrOperLangLower.DeleteAccentMarks() + " " + this.addrFullLower.DeleteAccentMarks() + this.ymarqueLower.DeleteAccentMarks() + this.ymodeleLower.DeleteAccentMarks(); }
        }

        public string idno { get; set; }
        public string descrOperLang { get; set; }
        public string descr { get; set; }
        [JsonIgnore]
        public string descrOperLangLower { get { return !string.IsNullOrWhiteSpace(this.descrOperLang) ? this.descrOperLang.ToLower() : string.Empty; } }
        [JsonProperty(PropertyName = "customer^descrOperLang")]
        public string customer_descrOperLang { get; set; }
        [JsonProperty(PropertyName = "customer^serviceEngineer")]
        public string customer_serviceEngineer { get; set; }
        [JsonProperty(PropertyName = "customer^emailAddr")]
        public string customer_emailAddr { get; set; }
        [JsonProperty(PropertyName = "customer^emailAddr2")]
        public string customer_emailAddr2 { get; set; }
        [JsonProperty(PropertyName = "customer^companyARAP")]
        public string customer_companyARAP { get; set; }
        public string salesOrderCust { get; set; }
        public string customer { get; set; }
        public string ysecteur { get; set; }
        public string lotNo { get; set; }
        public string searchExt { get; set; }
        [JsonIgnore]

        public string searchExtLower { get { return !string.IsNullOrWhiteSpace(this.searchExt) ? this.searchExt.ToLower() : string.Empty; } }

        [JsonProperty(PropertyName = "workOrder^idno")]
        public string workOrder_idno { get; set; }

        public DateTime delivDate { get; set; }

        public string longitude { get; set; }
        public string latitude { get; set; }
        [JsonIgnore]
        public string locationGPS
        {
            get
            {
                return FormatLocation(latitude) + "," + FormatLocation(longitude);
            }
        }

        private string FormatLocation(string position)
        {
            int decimalStart = position.IndexOf(".");
            int length = decimalStart + 4;
            if (position.Length >= length)
            {
                return position.Substring(0, length);
            }
            else
            {
                return position;
            }
        }

        public string zipCode { get; set; }
        [JsonIgnore]
        public string zipCodeLower { get { return !string.IsNullOrWhiteSpace(this.town) ? this.town.ToLower() : string.Empty; } }
        public string addr { get; set; }
        [JsonIgnore]
        public string addrLower { get { return !string.IsNullOrWhiteSpace(this.addr) ? this.addr.ToLower() : string.Empty; } }
        [JsonIgnore]
        public string addrFullLower { get { return !string.IsNullOrWhiteSpace(this.addr) && !string.IsNullOrWhiteSpace(this.street) && !string.IsNullOrWhiteSpace(this.town) && !string.IsNullOrWhiteSpace(this.zipCodeLower) ? this.addr.ToLower() + " " + this.street.ToLower() + " " + this.town.ToLower() + " " + this.zipCodeLower : string.Empty; } }
        public string street { get; set; }
        public string town { get; set; }
        [JsonIgnore]
        public string townLower { get { return !string.IsNullOrWhiteSpace(this.town) ? this.town.ToLower() : string.Empty; } }
        public string phoneNo { get; set; }
        public string ylastvisitdate { get; set; }
        [JsonProperty(PropertyName = "ylastvisittype^descrOperLang")]
        public string ylastvisittype_descrOperLang { get; set; }
        public string ysylastvisittype { get; set; }
        [JsonProperty(PropertyName = "ytylastvisittype^idno")]
        public string ytylastvisittype_idno { get; set; }
        [JsonProperty(PropertyName = "ytylastvisittype^descrOperLang")]
        public string ytylastvisittype_descrOperLang { get; set; }
        public string ytylastvisittype { get; set; }
        public string ynextvisitdate { get; set; }
        public string ynextvisittype { get; set; }
        [JsonProperty(PropertyName = "ynextvisittype^descrOperLang")]
        public string ynextvisittype_descrOperLang { get; set; }
        public string ysynextvisittype { get; set; }
        [JsonProperty(PropertyName = "ytynextvisittype^idno")]
        public string ytynextvisittype_idno { get; set; }
        [JsonProperty(PropertyName = "ytynextvisittype^descrOperLang")]
        public string ytynextvisittype_descrOperLang { get; set; }
        public string ytynextvisittype { get; set; }
        public string ycontracttype { get; set; }
        public string ysycontracttype { get; set; }
        [JsonProperty(PropertyName = "ytycontracttype^descrOperLang")]
        public string ytycontracttype_descrOperLang { get; set; }
        public string yoptiontype { get; set; }
        public string ysyoptiontype { get; set; }
        public string ytyoptiontype { get; set; }
        [JsonProperty(PropertyName = "ytyoptiontype^descrOperLang")]
        public string ytyoptiontype_descrOperLang { get; set; }
        public string yvisitsnumber { get; set; }
        public DateTime ydgarantie { get; set; }
        public string ymarque { get; set; }
        public string ymodele { get; set; }

        [JsonIgnore]
        public string CustomerIDForMail { get; set; }

        [JsonIgnore]
        public string ymarqueLower { get { return !string.IsNullOrWhiteSpace(this.ymarque) ? this.ymarque.ToLower() : string.Empty; } }
        [JsonIgnore]
        public string ymodeleLower { get { return !string.IsNullOrWhiteSpace(this.ymodele) ? this.ymodele.ToLower() : string.Empty; } }

        [JsonIgnore]
        public List<string> DefaultIndexes
        {
            get
            {
                List<string> defaultIndexes = base.DefaultIndexes;
                defaultIndexes.Add("descrOperLang");
                defaultIndexes.Add("searchExtLower");
                defaultIndexes.Add("all");
                return defaultIndexes;
            }
        }

        [JsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;

            }
        }

        #region Code Colors
        [JsonIgnore]
        public string codeColor
        {
            get { return this.GetCodeColor(); }
        }

        private string GetCodeColor()
        {
            string code = "";
            int weeksNextVisit = 10;

            if (this.ysecteur == Context.Instance.SecteurGlobal)
            {
                code = "0in";
            }
            else
            {
                code = "0out";
            }

            if (!string.IsNullOrEmpty(ylastvisitdate) && !string.IsNullOrEmpty(yvisitsnumber) && int.Parse(yvisitsnumber) > 0)
            {
                int numberVisitsYear = 365 / int.Parse(yvisitsnumber);
                DateTime nextVisitDate = DateTime.Parse(ylastvisitdate).AddDays(numberVisitsYear);

                if (nextVisitDate <= DateTime.Now)
                {
                    return code = "4in";
                }
                weeksNextVisit = (int)((nextVisitDate - DateTime.Now).TotalDays / 7);

                if (weeksNextVisit <= 4)
                {
                    if (this.ysecteur == Context.Instance.SecteurGlobal)
                    {
                        code = "4in";
                    }
                    else
                    {
                        code = "4out";
                    }
                }
                else if (weeksNextVisit <= 8)
                {
                    if (this.ysecteur == Context.Instance.SecteurGlobal)
                    {
                        code = "8in";
                    }
                    else
                    {
                        code = "8out";
                    }
                }
                
            }
            return code;
        }

        [JsonIgnore]
        public Color color
        {
            get { return this.GetColor(); }
        }

        private Color GetColor()
        {
            Color color = Color.FromRgb(125, 125, 127);            
            int weeksNextVisit = 10;
            if (this.ysecteur == Context.Instance.SecteurGlobal)
            {
                color = Color.FromRgb(23, 187, 162);
            }

            if (!string.IsNullOrEmpty(ylastvisitdate) && !string.IsNullOrEmpty(yvisitsnumber) && int.Parse(yvisitsnumber) > 0)
            {
                int numberVisitsYear = 365 / int.Parse(yvisitsnumber);
                DateTime nextVisitDate = DateTime.Parse(ylastvisitdate).AddDays(numberVisitsYear);

                if (nextVisitDate <= DateTime.Now)
                {
                    color = Color.FromRgb(255, 0, 0);
                }
                else
                {
                    weeksNextVisit = (int)((nextVisitDate - DateTime.Now).TotalDays / 7);

                    if (weeksNextVisit <= 4)
                    {
                        if (this.ysecteur == Context.Instance.SecteurGlobal)
                        {
                            color = Color.FromRgb(255, 0, 0);
                        }
                        else
                        {
                            color = Color.FromRgb(198, 217, 241);
                        }
                    }
                    else if (weeksNextVisit <= 8)
                    {
                        if (this.ysecteur == Context.Instance.SecteurGlobal)
                        {
                            color = Color.FromRgb(255, 192, 0);
                        }
                        else
                        {
                            color = Color.FromRgb(125, 125, 127);
                        }
                    }
                }
            }
            return color;
        }
        #endregion
    }
}
