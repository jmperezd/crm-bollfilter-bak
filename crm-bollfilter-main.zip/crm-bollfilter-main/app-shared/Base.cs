﻿using System;
using Xamarin.Forms;
using System.Globalization;

namespace Abas_Shared_Xamarin
{
    public class Base
	{
		public static void Init(CultureInfo ci)
        {
            Abas_Shared_Xamarin.Resx.AppResources.Culture = ci; // set the RESX for resource localization
        }
	}
}
