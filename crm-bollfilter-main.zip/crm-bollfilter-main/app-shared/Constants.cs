﻿using System;
using System.Globalization;
using WFramework_Xamarin;

namespace Abas_Shared_Xamarin
{
    public class Constants
    {

        //public const string DEV_SERVER_URL = "http://10.0.30.138:8080";
        //public const string DEV_SERVER_URL = "http://rdp.abas-france.fr:10080";
#if DEBUG
        public const string DEV_SERVER_URL_DEBUG = "http://wessix:10080";
        public const string DEV_INSTANCE_PATH_DEBUG = "/mw/r/demo";
#endif
        public const string DEV_SERVER_URL = "http://168.119.230.205:8080";//"http://168.119.230.205:8080";//"http://10.0.30.157:8080";//"http://168.119.230.205:8080"; // "http://wessix.abas-france.local:10080";//"http://6.188.0.84:8080";
        public const string DEV_INSTANCE_PATH = "/mw/r/newtech";
        public const string DEV_USERNAME = "_abas_";
        public const string DEV_PASSWORD = "hOtline";
        public const string CURRENT_WORKSPACE = "null";
        public const string DEV_WEBUSER = "(183,11,0)";
        public const string LIMIT_CALENDAR = "7";
        public const bool VERSION_SOFTICA = false; 
        public const bool ONLINEACTIVE = false;

        public const string URI_EMPLOYEE_ROLE_HEADFIELDS = "id,employee,costCenter";
        public const string URI_EMPLOYEE_ROLE = "/obj/data/117:1";

        public const string ABAS_TEXT_PLAIN = "text/plain";
        public const string ABAS_JSON = "application/json";
        public const string ABAS_SIMPLE_JSON = "application/abas.objects.simple+json";  
        public const string ABAS_SIMPLE_PDF = "application/pdf";
        //public const string ABAS_JSON = "application/json";
        public const string ABAS_SIMPLE_JSON_APPLICATION = "application/abas.objects.simple+json";
        public const string ABAS_SIMPLE_JSON_OBJECTS = "application/abas.objects+json";

        public const string URI_INFOSYS = "/infosys/data";
        public const string URI_INFOSYS_ACTIVITY = "/ev/BELEGVORKOMMEN";
        public const string URI_INFOSYS_OPEN_ITEMS = "/op/LOP";
        public const string URI_INFOSYS_XVISEMA = "/owis/XVISEMA";

        public const string URI_INFOSYS_ACTIVITY_HEADFIELDS = "";
        public const string URI_INFOSYS_ACTIVITY_TABLEFIELDS = "tabsvorkommen,tnettowert,tvktypa";

        public const string URI_PRINTLAYOUT_HEADFIELS = "id,idno,descrOperLang,swd,layoutContext";
        public const string URI_PRINTCOLLECTIVELAYOUT = "/obj/data/88:2";
        public const string URI_PRINTLAYOUT = "/obj/data/88:3";
        public const string URI_PRINTPARAMETERLAYOUT = "/obj/data/88:8";

        public const string URI_TYPE_PRINTLAYOUT_HEADFIELS = "id,idno,descrOperLang,swd";
        public const string URI_TYPE_PRINTLAYOUT = "/obj/data/91:1";        


        public const string URI_OPEN_ITEMS_HEADFIELDS = "fgesamt,fbetr1,fbetr2,fbetr3,fbetr4,f2betr1,f2betr2,f2betr3,f2betr4";


        public const string WEBREQUEST_GET = "GET";
        public const string WEBREQUEST_POST = "POST";
        public const string WEBREQUEST_PUT = "PUT";
        public const string WEBREQUEST_DELETE = "DELETE";
        public const string WEBREQUEST_CONTENT_TYPE = ABAS_SIMPLE_JSON;
        public const string WEBREQUEST_ACCEPT = ABAS_SIMPLE_JSON;
        public static string WEBREQUEST_ACCEPT_LANGUAGE { get
            {
                if(Abas_Shared_Xamarin.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToLower() == "fr"
                   || Abas_Shared_Xamarin.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToLower() == "en"
                   || Abas_Shared_Xamarin.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToLower() == "es")
                {
                    return Abas_Shared_Xamarin.Resx.AppResources.Culture.TwoLetterISOLanguageName.ToUpper();
                }
                else
                {
                    return "EN";
                }
            }
        }
        public const string WEBREQUEST_AUTH_BASIC = "Basic";

        public const string URI_PARAM_LANGUAGE = "variableLanguage=EN";

        public const string URI_WEBUSERS = "/obj/data/93:1";

        public const string URI_EMPLOYEE = "/obj/data/11:1";
        public const string URI_EMPLOYEE_HEADFIELDS = "id,descr,descr1,descr2,descr3,descr4,wage";

        public const string URI_SERVICEPART = "/obj/data/2:5";
        public const string URI_SERVICEPART_HEADFIELDS = "swd,id,idno,userDefinedVersion,purchTradeUnit,descrOperLang,characBar,salesTradeUnit,purchPriceUnit,SU,purchPrice,objectGrpNo,searchExt,salesPrice,type";
        
        public const string URI_NOTE = "/obj/data/134:1";
        public const string URI_NOTE_HEADFIELDS = "id,idno,swd,type,type^descrOperLang,descrOperLang,descrTextModuleOperLang,triggerOfEnt,businessPartner,productListElem,purchSalesTrans,intProcess,editor,editor^descrOperLang,date,currTime,purchSalesTrans,purchSalesTransExt,businessPartner^descrOperLang";

        public const string URI_TASK = "/obj/data/86:6";
        public const string URI_TASK_HEADFIELDS = "id,descrOperLang,prio^descrOperLang,prio,endDate,confirm,confirm^descrOperLang,swd,descrTextModuleOperLang,editor,editor^descrOperLang,businessPartner,status,purchSalesTrans,purchSalesTrans^swd,idno,businessPartner^descrOperLang";

        public const string TABLE_CUSTOMER = "contacts";
        public const string URI_CUSTOMER = "/obj/data/0:1";
        public const string URI_CUSTOMER_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,descr4,swd,webSiteURL,emailAddr,contactPerson,addr,street,town,ctryCode,stateOfTaxOffice,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,rep,repDescr,serviceEngineer,inhouseContact,inhouseContactDescr,characteristic1,characteristic2,characteristic3,characteristic4,characteristic5,characteristic6,characteristic1^descrOperLang,characteristic2^descrOperLang,characteristic3^descrOperLang,characteristic4^descrOperLang,characteristic5^descrOperLang,characteristic6^descrOperLang,characteristicIdentifier1,characteristicIdentifier2,characteristicIdentifier3,characteristicIdentifier4,characteristicIdentifier5,characteristicIdentifier6,comments,zipCode"; //industry
        
        public const string URI_AGENCY = "/obj/data/73:10";
        public const string URI_AGENCY_HEADFIELDS = "id,swd";
        public const string URI_AGENCY_TABLEFIELDS = "ytech,ysecteur";        

        public const string URI_PROSPECT = "/obj/data/0:6";
        public const string URI_PROSPECT_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,descr4,swd,webSiteURL,emailAddr,contactPerson,addr,street,town,ctryCode,stateOfTaxOffice,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,rep,repDescr,serviceEngineer,inhouseContact,inhouseContactDescr,characteristic1,characteristic2,characteristic3,characteristic4,characteristic5,characteristic6,characteristic1^descrOperLang,characteristic2^descrOperLang,characteristic3^descrOperLang,characteristic4^descrOperLang,characteristic5^descrOperLang,characteristic6^descrOperLang,characteristicIdentifier1,characteristicIdentifier2,characteristicIdentifier3,characteristicIdentifier4,characteristicIdentifier5,characteristicIdentifier6,comments,zipCode"; //industry

        public const string URI_CONTACT_CUSTOMER = "/obj/data/0:2";
        public const string URI_CONTACT_CUSTOMER_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,descr4,swd,webSiteURL,emailAddr,contactPerson,addr,street,town,ctryCode,stateOfTaxOffice,zipCode,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,zipCode2,companyARAP,companyARAP^rep,inhouseContact,inhouseContactDescr,comments,characteristic1,emailAddr2,webSiteURL2";

        public const string URI_CONTACT_PROSPECT = "/obj/data/0:7";
        public const string URI_CONTACT_PROSPECT_HEADFIELDS = "grpNo,id,idno,descrOperLang,descr,descr1,descr2,descr3,descr4,swd,webSiteURL,emailAddr,contactPerson,addr,street,town,ctryCode,stateOfTaxOffice,zipCode,phoneNo,cellPhoneNo,faxNo,longitude,latitude,addr2,street2,town2,stateOfTaxOffice2,phoneNo2,cellPhoneNo2,faxNo2,zipCode2,companyARAP,companyARAP^rep,inhouseContact,inhouseContactDescr,comments,characteristic1";

        public const string URI_SERVICE_ORDER = "/obj/data/3:28";
        public const string URI_SERVICE_QUOTATIONS = "/obj/data/3:27";
        public const string URI_SALE_OPPORTUNITIES = "/obj/data/3:30";
        public const string URI_SALE_QUOTATIONS = "/obj/data/3:21";
        public const string URI_SALE_ORDERS = "/obj/data/3:22";
        public const string URI_SALE_HEADFIELDS = "id,idno,customerDescr,customerDescr^descrOperLang,customer^serviceEngineer,totalNetAmt,totalGrossAmtDom,curr,dateFrom,customer,goodsRecipient,comments,transLock,payTerm,payTerm^descrOperLang,rep,repDescr";


        public const string URI_SALE_PRODUCT_HEADFIELDS = "id,head,product,product^descrOperLang,unitQty,tradeUnit,price,percent,itemValEntCurr,productDescr,recordNo,rowNo,startDateTime,itemFreeText,serviceProduct^swd,serviceProduct,serviceProductDescr,serviceProductDescr^swd,type,objectGrpNo,product^grpNo,serviceEngineer";//,serviceProduct^swd,serviceProduct,serviceProductDescr,serviceProductDescr^swd
        public const string URI_SALE_PRODUCT = "/obj/data/3:2";


        public const string URI_PRODUCT_SAV = "/obj/data/116:1";
        public const string URI_PRODUCT_SAV_HEADFIELDS = "id,idno,descr,descrOperLang,customer,customer^descrOperLang,customer^serviceEngineer,workOrder^idno,lotNo,searchExt,longitude,latitude,zipCode,addr,street,town,phoneNo,delivDate";

        public const string URI_PRODUCT_SAV_BOM = "/obj/data/116:3";
        public const string URI_PRODUCT_SAV_BOM_HEADFIELDS = "id,serviceProduct,warrantyTil";//"id,idno,elemDescr,elemQty,elemSU,serviceProductImplFrom,serviceProductImplTo";

        public const string URI_ENUM_LIST = "/obj/data/107:1/";

        //Enum detail table 109:2

        public const string URI_PRODUCT = "/obj/data/2:1";
        public const string URI_PRODUCT_HEADFIELDS = "id,idno,swd,descrOperLang,salesTradeUnit,purchTradeUnit,SU,purchPrice,salesPrice2,searchExt,globalTradeItemNo,weight,packDimLength,packDimWidth,packDimHeight,salesPrice,salesPriceUnit,salesCurr^descr,warrantyPer,catalogMeta,type";


        public const string URI_CA = "/obj/data/0:3";
        public const string URI_CA_HEADFIELDS = "mainObj,FY,origBal,turnoverPeriod,turnoverPeriod2,turnoverPeriod3,turnoverPeriod4,closingBalTurnover,month1,month2,month3,month4,month5,month6,month7,month8,month9,month10,month11,month12";


        public const string URI_TERMS_OF_PAYMENT = "/obj/data/12:8";

        public const string URI_SUMMARY = "/obj/data/12:3";

        public const string URI_UNIT = "/obj/data/62:1";
        public const string URI_UNIT_HEADFIELDS = "id,swd,descrOperLang,unitOperLang";

        //SAV
        public const string URI_SERVICE_RESERVATION = "/obj/data/118:1";
        public const string URI_SERVICE_RESERVATION_HEADFIELDS = "id,idno,customer,customer^descrOperLang,startDateExec,deadlineExec,itemText,descr,serviceEngineer,serviceOrderItem,status,customer^zipCode,customer^town,serviceOrderItem^serviceProduct^zipCode,serviceOrderItem^serviceProduct^town,serviceResType,serviceOrderItem^head^id,swd,serviceEngineerDescr^descrOperLang"; // ,serviceProduct

        public const string URI_ENGINEER_COMPLETION_CONFIRMATION = "/obj/data/118:4";
        public const string URI_ENGINEER_COMPLETION_CONFIRMATION_HEADFIELDS = "id,serviceReservation,serviceDuration,openServiceDuration,status,entQty,requiredQtySalesOrder,openQtyTradeUnit,engineerReport,productBOMUpdateStatus,adoptText1";

        public const string URI_ENGINEER_COMPLETION_CONFIRMATIONS = "/obj/data/118:6";
        public const string URI_ENGINEER_COMPLETION_CONFIRMATIONS_HEADFIELDS = "id,serviceQuotOrder,costCenter,wageGrp";

        public const string URI_ENGINEER_REPORT = "/obj/data/118:5";
        public const string URI_ENGINEER_REPORT_HEADFIELDS = "id,serviceQuotOrder,serviceEngineer,serviceEngineer^descrOperLang,serviceQuotOrder,doc,dateFrom,ysummary,ycustcom,yaddserv,ycustname,ysigndate,yengsign,ycustsign,yfengsign,yfcustsign,creationDate";

        public const string URI_COMPLETION_CONFIRMATIONS = "/obj/data/9:2";
        public const string URI_COMPLETION_CONFIRMATIONS_HEADFIELDS = "id,idno,serviceReservation,timeRequired";

        public const string TABLE_CALENDAR_EVENTS = "calendarevents";
        //END SAV


        //OFFLINE TABLES
        public const string TABLE_ORDERS_OFFLINE = "ordersbd";
    }
}

