﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Abas_Shared_Xamarin.Services
{
    public partial class AbasService
    {
        class IdSubstitution
        {
            [BsonId]
            public string id { get; set; }
            public string newId { get; set; }
        }

        public void AddSubstitutionPersistant(string id, string newId)
        {
            LiteCollection<IdSubstitution> coll = db.GetCollection<IdSubstitution>("IDSubstitutions");

            coll.Upsert(new IdSubstitution() { id = id, newId = newId });
        }
        public void RemoveSubstitutionPersistant(string id)
        {
            LiteCollection<IdSubstitution> coll = db.GetCollection<IdSubstitution>("IDSubstitutions");

            coll.Delete(id);
        }

        public void ReplaceForeignKeyPersistance(dynamic o)
        {
            LiteCollection<IdSubstitution> coll = db.GetCollection<IdSubstitution>("IDSubstitutions");

            Dictionary<string, string> substitutions = new Dictionary<string, string>();
            var table = coll.FindAll();
            foreach (IdSubstitution e in table)
            {
                substitutions.Add(e.id, e.newId);
            }

            Utils.ReplaceForeignKeys(substitutions, o);
        }
    }
}
