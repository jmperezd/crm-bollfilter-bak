﻿using System;
using System.Collections.Generic;

using Abas_Shared_Xamarin.Models;
using System.Threading.Tasks;

using WFramework_Xamarin.Table;

namespace Abas_Shared_Xamarin.Services
{
    public interface IAbasService
    {
        string Username { get; }

        void DropDatabase();

        bool IsAuthenticated();
        Task<bool> LoginAsync(string serverUrl, string instancePath, string username, string password);

        Task<string> Create<T>(T o, bool addLocally = false)
            where T : IModel, new();
        Task<string> Create<T, U>(T o, int timeout = 0, bool throwException = false)
            where T : IModel, new()
            where U : IModel, new();
        Task<T> Read<T>(string id)
            where T : IModel, new();
        Task<T> Read<T, U>(string id)
          where T : IModel, new()
            where U : IModel, new();
        Task<T> ReadOffline<T>(string id)
            where T : IModel, new();
        Task<T> ReadOffline<T,U>(string id)
            where T : IModel, new()
            where U : IModel, new();
        Task<Object> ReadRaw<T>(string id, string headFields = null, string tableFields = null)
            where T : IModel, new();
        Task<List<T>> ReadList<T>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<List<T>> ReadList<T,U>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<List<T>> ReadListOffline<T>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<EntityTable> ReadTable<T>(List<GridField> gridFields, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<EntityTable> ReadTableOffline<T>(List<GridField> gridFields, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<EntityTable> ReadTable<T>(List<GridField> gridFields, string search = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<dynamic> RunInfosystem<T>(List<GridField> gridFields, string search = null, int requestedPage = 0, int count = 0)
            where T : IModel, new();
        Task<T> Find<T>(string field, string value)
            where T : IModel, new();
        System.Threading.Tasks.Task Update<T>(T o, bool standarUpdate = true)
            where T : IModel, new();
        System.Threading.Tasks.Task Update<T, U>(T o)
            where T : IModel, new()
            where U : IModel, new();
        System.Threading.Tasks.Task Upsert<T>(List<T> o)
            where T : IModel, new();
        System.Threading.Tasks.Task Delete<T>(string id)
            where T : IModel, new();
        System.Threading.Tasks.Task AddRowToObject<T>(string id, string _idProduct, string _unitQty)
            where T : IModel, new();
        System.Threading.Tasks.Task DeleteRowFromObject<T>(string id, string num)
            where T : IModel, new();
        System.Threading.Tasks.Task CancelRowInObject<T>(string id, string num)
            where T : IModel, new();
        System.Threading.Tasks.Task InitTransactionWorkspace<T>(string id)
                  where T : IModel, new();
        System.Threading.Tasks.Task CommitAndCloseTransactionWorkspace();



        Task<string> GetPasswordHashAsync(string password);
        Task<bool> UserLoginAsync(string user, string password);
        System.Threading.Tasks.Task CancelNewWebUserWorkspace();

        Task<List<T>> GetEnumAsync<T>()
            where T : IModel, new();

        Task<Models.User> GetCurrentUserAsync();

        Task<ActivityObject> GetActivity(string ID);
        System.Threading.Tasks.Task<OpenItemsObject> GetOpenItems(string ID);

        Task<Uri> PrintImpression<T>(string id)
        where T : IModel, new();

        System.Threading.Tasks.Task CommandAction<T>(string id, string ActionType)
        where T : IModel, new();

        System.Threading.Tasks.Task SaveEngineerCompletionConfirmations<T>(EngineerCompletionConfirmations engineerCompletionConfirmations)
        where T : IModel, new();

        #region Offline

        System.Threading.Tasks.Task SwitchToOnline();
        System.Threading.Tasks.Task PopulateDB();

        System.Threading.Tasks.Task ReloadTransactions();
        System.Threading.Tasks.Task ReloadNotes();
        System.Threading.Tasks.Task ReloadTiers();
        System.Threading.Tasks.Task ReloadTasks();
        

        void InitOfflineDB();

        List<OfflineItems> GetListPendingUploadItems();
        #endregion
    }
}
