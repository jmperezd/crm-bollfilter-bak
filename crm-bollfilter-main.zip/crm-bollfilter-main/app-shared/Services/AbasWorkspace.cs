﻿using Abas_Shared_Xamarin.Classes.Requests;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;

[assembly: Xamarin.Forms.Dependency(typeof(Abas_Shared_Xamarin.Services.AbasService))]
namespace Abas_Shared_Xamarin.Services
{
    public class AbasWorkspace
    {
        public AbasWorkspace(string hostname, string login, string pass)
        {
            _hostname = hostname;
            _login = login;
            _pass = pass;
        }

        string _login;
        string _pass;
        string _hostname;
        string _wip;
        public Models.RootObject RootObject = new Models.RootObject(); 

        public async Task InitWorkspaceAsync(string commandNewPath)
        {
            await InitWorkspaceAsync(new Uri(_hostname + commandNewPath));
        }

        public async Task InitWorkspaceAsync(Uri commandNewPath)
        {
            WebRequest request = AbasRequests.PrepareAbasRequest(commandNewPath, _login, _pass);
            request.Method = Constants.WEBREQUEST_POST;
            WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
            string responseBody = AbasRequests.ReadWebResponse(response);

            dynamic responseObject = JsonConvert.DeserializeObject(responseBody);
            _wip = responseObject.meta.link.href;
        }

        public async Task<Object> ActionSetFieldValueAsync(string _field, string _value)
        {
            return await ActionAsync(new
            {
                actions = new Object[]
                    {
                        new {
                            _type = "SetFieldValue",
                            fieldName = _field,
                            value = _value
                        }
                    }
            });
        }

        public async Task<Object> ActionAsync(Object body)
        {
            BetterUri uri = new BetterUri(_hostname + _wip);
            uri.AddParam(Constants.URI_PARAM_LANGUAGE);
            WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _login, _pass);
            request.Method = Constants.WEBREQUEST_POST;
            AbasRequests.WriteRequestBody(ref request, JsonConvert.SerializeObject(
                body));
            WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
            string responseBody = AbasRequests.ReadWebResponse(response);

            dynamic responseObject = JsonConvert.DeserializeObject(responseBody);
            return responseObject;
        }

        public async Task CancelWorkspaceAsync()
        {
            await ExecuteWsCommandAsync("CANCEL");
        }

        public async Task ExecuteWsCommandAsync(string command)
        {
            string wsPath = _wip.Split(new string[] { "/wip/" }, StringSplitOptions.None)[0];

            BetterUri uri = new BetterUri(_hostname + wsPath + $"/commands/{command}");
            uri.AddParam(Constants.URI_PARAM_LANGUAGE);
            WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _login, _pass);
            request.Method = Constants.WEBREQUEST_POST;
            await AbasRequests.ExecuteRequestAsync(request);
        }

        public async Task ExecuteWipCommandAsync(string command)
        {
            BetterUri uri = new BetterUri(_hostname + _wip + $"/commands/{command}");
            uri.AddParam(Constants.URI_PARAM_LANGUAGE);
            WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _login, _pass);
            request.Method = Constants.WEBREQUEST_POST;
            await AbasRequests.ExecuteRequestAsync(request);
        }
    }
}
