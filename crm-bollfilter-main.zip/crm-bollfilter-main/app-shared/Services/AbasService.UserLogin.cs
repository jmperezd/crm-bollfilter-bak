﻿using Abas_Shared_Xamarin.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using System.Linq;

[assembly: Xamarin.Forms.Dependency(typeof(Abas_Shared_Xamarin.Services.AbasService))]
namespace Abas_Shared_Xamarin.Services
{
    public partial class AbasService
    {
        AbasWorkspace NewWebUserWorkspace = null;

        //Cette fonction renvoie le hash de password en passant par l'api -_-, en passant par un workspace (avec l'utilitaire AbasWorkspace)
        public async Task<string> GetPasswordHashAsync(string password)
        {
            if(NewWebUserWorkspace == null)
            {
                CheckAuthenticated();
                NewWebUserWorkspace = new AbasWorkspace(_serverUrl, _username, _password);
                await NewWebUserWorkspace.InitWorkspaceAsync(Context.InstancePath + "/obj/data/93:1/commands/NEW");
            }

            dynamic response = await NewWebUserWorkspace.ActionSetFieldValueAsync("printFilePwd", password);
            return response.head.pwd;
        }

        public async System.Threading.Tasks.Task CancelNewWebUserWorkspace()
        {
            if (NewWebUserWorkspace == null)
            {
                return;
            }
            await NewWebUserWorkspace.CancelWorkspaceAsync();
            return;
        }

        //Cette fonction gère le login des utilisateurs de l'appli (pas les identifiants d'API, qui doivent déjà être initialisés). Elle retourne un booléen sur la réussite
        public async Task<bool> UserLoginAsync(string user, string password)
        {
            // Récupère dans la LiteDB hors-ligne les infos sur l'utilisateur si il y en a
            string tableName = this.getTableName<WebUser>();

            LiteDB.LiteCollection<WebUser> coll = db.GetCollection<WebUser>(tableName);//"_loginUsers");
            WebUser offlineUser = coll.FindOne(LiteDB.Query.EQ("login", user));
            
            string hash = BCrypt.Net.BCrypt.HashPassword(_password);

            if (Context.Instance.IsConnected) //Si on est en ligne
            {
                if (offlineUser == null)
                {
                    offlineUser = new WebUser();
                }
                //On récupère les infos de l'utilisateur renseigné si il existe, via l'API
                WebUser userObject = new WebUser();
                userObject = await Find<WebUser>("login", user);
                if (userObject == null)
                {
                    return false;
                }
                // On va requêter grâce à l'API le hash du mdp de cet utilisateur
                if (!userObject.pwd.Equals(await GetPasswordHashAsync(password)))
                {
                    return false;
                }
                await NewWebUserWorkspace.CancelWorkspaceAsync();
                NewWebUserWorkspace = null;
                
                Tuple<string, string, string, string, string> roles = await GetWebUserRolesAsync(userObject.webRoleList);
                userObject.RoleEmployee = roles.Item1;
                userObject.RoleSalesRep = roles.Item2;
                userObject.RoleServiceEngineer = roles.Item3;
                userObject.RoleSalesTeamLeader = roles.Item4;
                userObject.RoleServiceEngineer_swd = roles.Item5;

                Context.Instance.CurrentWebUser = userObject;

                try
                {
                    if(!String.IsNullOrEmpty(roles.Item3))
                    {
                        List<FilterField> filterFields = new List<FilterField>();
                        FilterField filterField = new FilterField() { FieldName = "employee", Operator = "==", Value = roles.Item3 };
                        filterFields.Add(filterField);

                        List<EmployeeRole> employeeRoles = await this.ReadList<EmployeeRole>(null, filterFields);
                        if(employeeRoles != null && employeeRoles.Count > 0)
                        {
                            userObject.EngineerId = employeeRoles.First().id;
                            userObject.costCenter = employeeRoles.First().costCenter;
                        }
                    }
                }
                catch(Exception e)
                {

                }
                


                //Mise à jour de l'utilisateur offline si connection réussie
                if (offlineUser != null)
                {
                    offlineUser.login = user;
                    offlineUser.id = userObject.id;
                    offlineUser.pwd = hash;
                    offlineUser.RoleEmployee = roles.Item1;
                    offlineUser.RoleSalesRep = roles.Item2;
                    offlineUser.RoleServiceEngineer = roles.Item3;
                    offlineUser.RoleSalesTeamLeader = roles.Item4;
                    offlineUser.RoleServiceEngineer_swd = roles.Item5;
                    coll.Upsert(offlineUser);
                }
                return true;
            }
            else
            {
                if (null == offlineUser || hash.Equals(offlineUser.pwd))
                {
                    //le mdp ne correspond pas avec l'offline ou l'utilisateur n'est pas trouvé
                    return false;
                }
                Context.Instance.CurrentWebUser = offlineUser;
                return true;
            }
            
        }

        public async Task<DateTime> GetERPDateAsync()
        {
            CheckAuthenticated();
            Uri uri = new Uri(BaseUriString + "/about");
            WebRequest request = AbasRequests.PrepareAbasRequest(uri, _username, _password);
            request.Method = Constants.WEBREQUEST_GET;
            string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
            dynamic aboutObject = JsonConvert.DeserializeObject(response);

            return aboutObject.erpDateTime.Value;
        }

        public async Task<Tuple<string, string, string, string, string>> GetWebUserRolesAsync(string id)
        {
            dynamic response = await ReadRaw<WebRoleList>(id,"id", "roleRef,roleRef^swd,userTab,userTab^swd");

            
            string RoleEmployee = String.Empty;
            string RoleSalesRep = String.Empty;
            string RoleServiceEngineer = String.Empty;
            string RoleServiceEngineer_swd = String.Empty;
            string RoleSalesTeamLeader = String.Empty;

            if (response.table == null)
            {
                return Tuple.Create(String.Empty, String.Empty, String.Empty, String.Empty, String.Empty);
            }

            List<WebRole> responseTable = response.table.ToObject<List<WebRole>>();

            foreach(WebRole row in responseTable)
            {
                
                if (row.roleRef_swd.Equals("CRM-EMPLOYEE"))
                {
                    RoleEmployee = row.userTab;
                }
                if (row.roleRef_swd.Equals("CRM-SALESREP"))
                {
                    RoleSalesRep = row.userTab;
                }
                if(row.roleRef_swd.Equals("SERVICE-ENG"))
                {
                    RoleServiceEngineer = row.userTab;
                    RoleServiceEngineer_swd = row.userTab_swd;
                }
                if (row.roleRef_swd.Equals("CRM-SALESTL"))
                {
                    RoleSalesTeamLeader = "fill";
                }
            }
            return Tuple.Create(RoleEmployee, RoleSalesRep, RoleServiceEngineer, RoleSalesTeamLeader, RoleServiceEngineer_swd);
        }
    }
}
