﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Abas_Shared_Xamarin.Services
{
    public static class Utils
    {
        [AttributeUsage(AttributeTargets.All)]
        public class ForeignKeyID : Attribute
        {
        }
        //Prend un objet, regarde les champs notés [ForeignKeyID] et effectue les substitutions si il y en a (substitutions de chaînes de caractères)
        public static void ReplaceForeignKeys(Dictionary<string, string> substitutions, dynamic o)
        {
            Type t = o.GetType();
            FieldInfo[] MyMemberInfo = t.GetFields(BindingFlags.Instance | BindingFlags.NonPublic);
            // Loop through all members in this class that are in the
            // MyMemberInfo array.
            for (int i = 0; i < MyMemberInfo.Length; i++)
            {
                ForeignKeyID att;
                att = (ForeignKeyID)Attribute.GetCustomAttribute(MyMemberInfo[i], typeof(ForeignKeyID));
                if (att != null)
                {
                    object memberValue = MyMemberInfo[i].GetValue(o);
                   
                    string newValue;
                    if (substitutions.TryGetValue(memberValue.ToString(), out newValue))
                    {
                        MyMemberInfo[i].SetValue(o, newValue);
                    }
                }
            }
        }

        static public void MergeObjects<T>(T target, T source)
        {
            Type t = typeof(T);

            var properties = t.GetProperties().Where(prop => prop.CanRead && prop.CanWrite);

            foreach (var prop in properties)
            {
                var value = prop.GetValue(source, null);
                if (value != null)
                    prop.SetValue(target, value, null);
            }
        }
    }
}
