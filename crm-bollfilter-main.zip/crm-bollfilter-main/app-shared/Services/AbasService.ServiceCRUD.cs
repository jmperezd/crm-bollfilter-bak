﻿using Abas_Shared_Xamarin.Classes.Requests;
using LiteDB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WFramework_Xamarin;
using WFramework_Xamarin.Table;

[assembly: Xamarin.Forms.Dependency(typeof(Abas_Shared_Xamarin.Services.AbasService))]
namespace Abas_Shared_Xamarin.Services
{
    public partial class AbasService
    {

        void CheckAuthenticated()
        {
            if (!IsAuthenticated())
            {
                throw new NullReferenceException("You must be authenticated with Login before ExecuteRequest");
            }
        }

        //On retourne l'identifiant de l'objet après l'avoir créé
        public async Task<string> Create<T>(T o, bool offline = false)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>();
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_POST;
                if (o.HasSubItems)
                {
                    AbasRequests.WriteRequestBodyFromHeadAndTableObject(ref request, o, o.SubItems);
                }
                else
                {
                    AbasRequests.WriteRequestBodyFromHeadObject(ref request, o);
                }
                try
                {
                    WebResponse response = await AbasRequests.ExecuteRequestAsync(request);

                    Context.Instance.ChangeToDisplay = true;

                    var id = response.Headers.Get("Location").ToString().Split(new string[] { "/" }, StringSplitOptions.None).Last();

                    T foo = new T();
                    foo = await Read<T>(id);
                    var tableName = getTableName<T>();
                    var coll = db.GetCollection<T>(tableName);
                    coll.Upsert(foo);

                    return id;
                }
                catch (WebException e)
                {
                    using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                    {
                        string result = streamReader.ReadToEnd();
                        throw e;
                    }
                }
            }
            else
            {
                try
                {
                    var tableName = getTableName<T>();
                    if (!string.IsNullOrEmpty(tableName))
                    {                     
                        o.id = o.GetHashCode().ToString() + DateTime.Now.ToString();
                        //coll.Upsert(o);
                        QueueRequest(new AbstractRequest { Action = AbstractRequest.ActionType.Create, requestObject = o });

                        Context.Instance.ChangeToDisplay = true;

                        return o.id;
                    }
                    else
                    {
                        throw new Exception("tableNameEmpty");
                    }
                }
                catch (Exception e)
                {
                    throw (e);
                }
            }
        }

        //On retourne l'identifiant de l'objet après l'avoir créé
        public async Task<string> Create<T, U>(T o, int timeout = 0, bool throwException = false)
            where T : IModel, new()
            where U : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>();
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_POST;
                if (o.HasSubItems)
                {

                    AbasRequests.WriteRequestBodyFromHeadAndTableObject(ref request, o, o.SubItems);
                }
                else
                {
                    AbasRequests.WriteRequestBodyFromHeadObject(ref request, o);
                }
                try
                {
                    if (timeout != 0)
                    {
                        request.Timeout = timeout;
                    }
                    WebResponse response = await AbasRequests.ExecuteRequestAsync(request);

                    Context.Instance.ChangeToDisplay = true;

                    if (!throwException)
                    {
                        var id = response.Headers.Get("Location").ToString().Split(new string[] { "/" }, StringSplitOptions.None).Last();

                        T foo = new T();
                        foo = await this.Read<T, U>(id);
                        var tableName = getTableName<T>();
                        var coll = db.GetCollection<T>(tableName);
                        coll.Upsert(foo);
                        if (foo.HasSubItems && foo.SubItems != null)
                        {
                            var tableNameSubItems = getTableName<U>();
                            var collSubItems = db.GetCollection<U>(tableNameSubItems);
                            try
                            {
                                foreach (U subItem in foo.SubItems)
                                {
                                    collSubItems.Upsert(subItem);
                                }
                            }
                            catch (Exception e)
                            {
                                var error = e.Message;
                            }
                        }
                        return id;
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
                catch (WebException e)
                {
                    throw new Exception("timeout");
                }
            }
            else
            {
                
                var tableName = getTableName<T>();
                o.id = o.GetHashCode().ToString() + DateTime.Now.ToString();                
                QueueRequest(new AbstractRequest { Action = AbstractRequest.ActionType.Create, requestObject = o });

                if (o.SubItems != null)
                {
                    try
                    {
                        var tableNameSubItems = getTableName<U>();
                        var collSubItems = db.GetCollection<U>(tableNameSubItems);
                        foreach (U subItem in o.SubItems)
                        {
                            if (subItem is Models.SaleProduct)
                            {
                                (subItem as Models.SaleProduct).head = o.id;
                                (subItem as Models.SaleProduct).id = subItem.GetHashCode().ToString() + DateTime.Now.ToString();
                            }
                            collSubItems.Upsert(subItem);
                        }
                    }
                    catch(Exception e)
                    {

                    }
                }


                Context.Instance.ChangeToDisplay = true;                
                 
                return null;
            }

        }


        public async Task<T> Read<T, U>(string id)
      where T : IModel, new()
        where U : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();

                BetterUri uri = BetterUri.GetUri<T>(id);
                T foo = new T();
                uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
                if (foo is Abas_Shared_Xamarin.Models.ServiceQuotation)
                {
                    List<FilterField> test = new List<FilterField>() { new FilterField() { FieldName = "1:type", Operator = "==", Value = "(SOPOItemPOS)" } };
                    uri.AddParam(AbasRequests.GetCriteriaParam(test));
                }
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                dynamic j = JsonConvert.DeserializeObject(response);

                if (j.head == null)
                {
                    throw new NullReferenceException("Response 'head' field is not defined");
                }

                List<U> list = new List<U>();
                if (foo.HasSubItems && j.table != null)
                {
                    T obj = j.head.ToObject<T>();
                    var e = j.table;

                    foreach (dynamic item in e)
                    {
                        try
                        {
                            list.Add(item.ToObject<U>());
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                    obj.SubItems = list.Cast<object>().ToList();
                    return obj;
                }
                else
                {
                    return j.head.ToObject<T>();
                }
            }
            else
            {
                return await ReadOffline<T, U>(id);
            }
        }

        //    List<U> list = new List<U>();
        //    if (j.head != null)
        //    {
        //        if (foo.HasSubItems && j.table != null)
        //        {
        //            T obj = j.head.ToObject<T>();
        //            var e = j.table;

        //            foreach (dynamic item in e)
        //            {
        //                try
        //                {
        //                    list.Add(item.ToObject<U>());
        //                }
        //                catch (Exception ex)
        //                {

        //                }
        //            }
        //            obj.SubItems = list.Cast<object>().ToList();
        //            return obj;
        //        }
        //        else
        //        {
        //            throw new NullReferenceException("Response 'head' field is not defined");
        //        }
        //    }
        //    else if (j.erpDataObjects != null)
        //    {
        //        var t = j.erpDataObjects;
        //        T obj = t[0].head.ToObject<T>();


        //            var e = t[0].table;

        //            foreach (dynamic item in e)
        //            {
        //                try
        //                {
        //                    list.Add(item.ToObject<U>());
        //                }
        //                catch (Exception ex)
        //                {

        //                }
        //            }
        //            obj.SubItems = list.Cast<object>().ToList();
        //            return obj;
        //    }
        //    else
        //    {
        //        return j.head.ToObject<T>();
        //    }
        //}

        public async Task<T> Read<T>(string id)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>(id);
                T foo = new T();
                uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                dynamic j = JsonConvert.DeserializeObject(response);

                if (j.head == null)
                {
                    if (j.erpDataObjects[0].head != null)
                    {
                        return j.erpDataObjects[0].head.ToObject<T>();
                    }
                    else
                    {
                        throw new NullReferenceException("Response 'head' field is not defined");
                    }
                }
                return j.head.ToObject<T>();
            }
            else
            {
                return await ReadOffline<T>(id);
            }
        }

        public async Task<T> ReadOffline<T>(string id)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected && Constants.ONLINEACTIVE)
            {
                return await this.Read<T>(id);
            }
            else
            {
                var tableName = getTableName<T>();
                LiteCollection<T> coll = db.GetCollection<T>(tableName);
                T res = coll.FindOne(Query.EQ("_id", id));
                if (res == null)
                {
                    throw new KeyNotFoundException($"Object {id} not found in offline database");
                }
                return res;
            }
        }

        public async Task<T> ReadOffline<T, U>(string id)
            where T : IModel, new()
            where U : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                return await this.Read<T, U>(id);
            }
            else
            {
                var tableName = getTableName<T>();
                LiteCollection<T> coll = db.GetCollection<T>(tableName);
                T res = coll.FindOne(Query.EQ("_id", id));
                if (res == null)
                {
                    throw new KeyNotFoundException($"Object {id} not found in offline database");
                }
                if (res.HasSubItems)
                {
                    List<U> list = await this.ReadListOffline<U>(null, new List<FilterField>() { new FilterField() { FieldName = "head", Operator = "==", Value = res.id } });
                    res.SubItems = list.Cast<object>().ToList();
                }
                return res;
            }
        }

        public async Task<Object> ReadRaw<T>(string id, string headFields = null, string tableFields = null)
            where T : IModel, new()
        {
            CheckAuthenticated();
            BetterUri uri = BetterUri.GetUri<T>(id);
            T foo = new T();
            uri.AddParam($"headFields={(String.IsNullOrEmpty(headFields) ? "-" : headFields)}");
            uri.AddParam($"tableFields={(String.IsNullOrEmpty(headFields) ? "-" : tableFields)}");
            WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
            request.Method = Constants.WEBREQUEST_GET;
            string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
            dynamic j = JsonConvert.DeserializeObject(response);

            return j;
        }

        public async Task<List<T>> ReadList<T>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetRichUri<T>(gridFields, filterFields, requestedPage, count);
                T foo = new T();
                if (gridFields == null)
                {
                    uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
                }

                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = string.Empty;
                try
                {
                    response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                }
                catch (Exception ex)
                {
                    var aux = ex;
                }
                dynamic j = JsonConvert.DeserializeObject(response);
                if (j.erpDataObjects == null)
                {
                    throw new NullReferenceException("Response 'erpDataObjects' field is not defined");
                }
                var e = j.erpDataObjects;
                List<T> tab = new List<T>();

                foreach (dynamic item in e)
                {
                    if (item.head == null)
                    {
                        throw new NullReferenceException("Response item 'head' field is not defined");
                    }
                    try
                    {
                        tab.Add(item.head.ToObject<T>());
                    }
                    catch (Exception ex)
                    {

                    }
                }
                return tab;
            }
            else
            {
                var tableName = getTableName<T>();
                LiteCollection<T> coll = db.GetCollection<T>(tableName);
                filterFields = completeFilterFieldsIfNeeded<T>(filterFields);

                List<T> res;
                if (count > 0)
                {
                    res = coll.Find(FilterFieldListToQuery(gridFields, filterFields), count * requestedPage, count).ToList();
                }
                else
                {
                    res = coll.Find(FilterFieldListToQuery(gridFields, filterFields)).ToList();
                }
                if (res == null)
                {
                    throw new KeyNotFoundException($"Request to offline database failed");
                }
                return res;
            }
        }

        public async Task<List<T>> ReadList<T, U>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
           where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetRichUri<T>(gridFields, filterFields, requestedPage, count);
                T foo = new T();
                if (gridFields == null)
                {
                    uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
                }



                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = string.Empty;
                try
                {
                    response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                }
                catch (Exception ex)
                {

                }
                dynamic j = JsonConvert.DeserializeObject(response);
                if (j.erpDataObjects == null)
                {
                    throw new NullReferenceException("Response 'erpDataObjects' field is not defined");
                }
                var e = j.erpDataObjects;
                List<T> tab = new List<T>();

                foreach (dynamic item in e)
                {
                    if (item.head == null)
                    {
                        throw new NullReferenceException("Response item 'head' field is not defined");
                    }
                    try
                    {
                        T obj = item.head.ToObject<T>();
                        List<U> list = new List<U>();
                        if (foo.HasSubItems && item.table != null)
                        {
                            var f = item.table;

                            foreach (dynamic subItem in f)
                            {
                                list.Add(subItem.ToObject<U>());
                            }
                            obj.SubItems = list.Cast<object>().ToList();
                        }
                        tab.Add(obj);
                    }
                    catch (Exception ex)
                    {

                    }
                }
                return tab;
            }
            else
            {
                var tableName = getTableName<T>();
                LiteCollection<T> coll = db.GetCollection<T>(tableName);
                filterFields = completeFilterFieldsIfNeeded<T>(filterFields);

                List<T> res;
                if (count > 0)
                {
                    res = coll.Find(FilterFieldListToQuery(gridFields, filterFields), count * requestedPage, count).ToList();
                }
                else
                {
                    res = coll.Find(FilterFieldListToQuery(gridFields, filterFields)).ToList();
                }
                if (res == null)
                {
                    throw new KeyNotFoundException($"Request to offline database failed");
                }
                return res;
            }
        }


        public async Task<List<T>> ReadListOffline<T>(List<GridField> gridFields = null, List<FilterField> filterFields = null, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {            
            FormatGridFieldsOffline(gridFields);
            var tableName = getTableName<T>();
            LiteCollection<T> coll = db.GetCollection<T>(tableName);

            filterFields = completeFilterFieldsIfNeeded<T>(filterFields);
            IEnumerable<T> res = null;
            var filters = FilterFieldListToQuery(gridFields, filterFields);                
            var orFilters = getOrFilterFieldsIfNeeded<T>();
            if (orFilters != null)
            {
                var queryListOr = orFilters.ConvertAll<Query>(x => x.ToLiteDBQuery());
                var orFiltersOr = Query.Or(queryListOr.ToArray());

                res = coll.Find(Query.And(filters, orFiltersOr));
            }
            else
            {
                res = coll.Find(filters);
            }
            if (res == null)
            {
                throw new KeyNotFoundException($"Request to offline database failed");
            }
            if (gridFields == null)
            {
                gridFields = new List<GridField>();
            }
            var res2 = res.OrderBy(x => orderAscIfNeeded<T>(GridField.SortOrder.Asc, gridFields, x));
            var res3 = res2.OrderByDescending(x => orderAscIfNeeded<T>(GridField.SortOrder.Desc, gridFields, x));
            if (count > 0)
            {
                try
                {
                    var res4 = res3.Skip(count * requestedPage).Take(count).ToList();
                    return res4;
                }
                catch (Exception ex)
                {
                    var res4 = res3.Skip(count * requestedPage).Take(count).ToList();
                    return res4;
                }
            }
            else
            {
                return res3.ToList();
            }            
        }

        private dynamic orderAscIfNeeded<T>(GridField.SortOrder order, List<GridField> gridFields, T x) where T : IModel, new()
        {
            try
            {
                if (x is Models.Tiers)
                {
                    var obj = x as Models.Tiers;
                    if (obj != null)
                    {
                        foreach (var gf in gridFields)
                        {
                            if (gf.Order == order)
                            {
                                switch (gf.FieldName)
                                {
                                    case "id":
                                        return obj.id;
                                    case "idno":
                                        return obj.idno;
                                    case "descrOperLang":
                                        return obj.descrOperLang;
                                    case "swd":
                                        return obj.swd;
                                }
                            }
                        }
                    }
                }
                else if (x is Models.Task)
                {
                    var obj = x as Models.Task;
                    if (obj != null)
                    {
                        foreach (var gf in gridFields)
                        {
                            if (gf.Order == order)
                            {
                                switch (gf.FieldName)
                                {
                                    case "descrOperLang":
                                        return obj.descrOperLang;
                                    case "prio_descrOperLang":
                                        return obj.prio_descrOperLang;
                                    case "endDate":
                                        return obj.endDate;
                                    case "confirm_descrOperLang":
                                        return obj.confirm_descrOperLang;
                                    case "status":
                                        return obj.status;
                                }
                            }
                        }
                    }
                }
                else if (x is Models.Note)
                {
                    var obj = x as Models.Note;
                    if (obj != null)
                    {
                        foreach (var gf in gridFields)
                        {
                            if (gf.Order == order)
                            {
                                switch (gf.FieldName)
                                {
                                    case "descrOperLang":
                                        return obj.descrOperLang;
                                    case "date":
                                        return obj.date;
                                    case "type_descrOperLang":
                                        return obj.type_descrOperLang;
                                    case "editor_descrOperLang":
                                        return ToolsHelper.ConvertToDouble(obj.editor_descrOperLang);
                                }
                            }
                        }
                    }
                }
                else if (x is Models.ProductSAV)
                {
                    var obj = x as Models.ProductSAV;
                    if (obj != null)
                    {
                        foreach (var gf in gridFields)
                        {
                            if (gf.Order == order)
                            {
                                switch (gf.FieldName)
                                {
                                    case "customer_descrOperLang":
                                        return obj.customer_descrOperLang;
                                    case "id":
                                        return obj.id;
                                    case "lotNo":
                                        return obj.lotNo;
                                }
                            }
                        }
                    }
                }
                else if (x is Models.Transaction)
                {
                    var obj = x as Models.Transaction;
                    if (obj != null)
                    {
                        foreach (var gf in gridFields)
                        {
                            if (gf.Order == order)
                            {
                                switch (gf.FieldName)
                                {
                                    case "customerDescr_descrOperLang":
                                        return obj.customerDescr_descrOperLang;
                                    case "idno":
                                        return obj.idno;
                                    case "dateFrom":
                                        return obj.dateFrom;
                                    case "totalNetAmt":
                                        return ToolsHelper.ConvertToDouble(obj.totalNetAmt);
                                    case "probability":
                                        return int.Parse(obj.probability);
                                }
                            }
                        }
                    }
                }
                else if (x is Models.SaleProduct)
                {
                    var obj = x as Models.SaleProduct;
                    if (obj != null)
                    {
                        foreach (var gf in gridFields)
                        {
                            if (gf.Order == order)
                            {
                                switch (gf.FieldName)
                                {
                                    case "productDescr":
                                        return obj.productDescr;
                                    case "unitQty":
                                        return ToolsHelper.ConvertToDouble(obj.unitQty);
                                    case "tradeUnit":
                                        return obj.tradeUnit;
                                    case "price":
                                        return ToolsHelper.ConvertToDouble(obj.price);
                                    case "percent":
                                        return int.Parse(obj.percent);
                                    case "itemValEntCurr":
                                        return obj.itemValEntCurr;
                                    case "rowNo":
                                        return obj.rowNo;
                                    case "startDateTime":
                                        return obj.startDateTime;
                                    case "product":
                                        return obj.product;
                                }
                            }
                        }
                    }
                }
                

                //"productDescr", "unitQty", "tradeUnit", "price", "percent", "itemValEntCurr", "rowNo", "startDateTime", "product"
            }
            catch (Exception e)
            {
                return null;
            }

            return null;
        }

        private List<FilterField> completeFilterFieldsIfNeeded<T>(List<FilterField> filterFields) where T : IModel, new()
        {
            var t = new T();
            var tiers = t as Models.Tiers;
            if (tiers != null)
            {
                if (tiers.grpNos != null)
                {

                }
                else if (tiers.grpNo != null)
                {
                    if (filterFields == null)
                        filterFields = new List<FilterField>();
                    filterFields.Add(new FilterField { FieldName = "grpNo", Operator = "==", Value = tiers.grpNo });
                }
            }
            return filterFields;
        }

        private List<FilterField> getOrFilterFieldsIfNeeded<T>() where T : IModel, new()
        {
            var t = new T();
            var tiers = t as Models.Tiers;
            if (tiers != null)
            {
                if (tiers.grpNos != null)
                {
                    var filterFields = new List<FilterField>();
                    foreach (var n in tiers.grpNos)
                    {
                        filterFields.Add(new FilterField { FieldName = "grpNo", Operator = "==", Value = n });
                    }
                    return filterFields;
                }
            }
            return null;
        }

        public async Task<dynamic> RunInfosystem<T>(List<GridField> gridFields, string search = null, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {
            CheckAuthenticated();
            T foo = new T();

            BetterUri uri = new BetterUri(BaseUriString);
            uri.Path += Constants.URI_INFOSYS + foo.InfoSysPath;
            uri.AddParam(Constants.URI_PARAM_LANGUAGE);
            WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
            request.Method = Constants.WEBREQUEST_POST;

            Models.RootObject rootObject = new Models.RootObject();
            rootObject.actions = AbasRequests.GetInfosysAction(gridFields, requestedPage, count);

            string tableFields = string.Empty;
            tableFields = foo.DefaultHeadFields.Aggregate(string.Empty, (acc, x) => ($"{acc}" + foo.InfoSysMember + $"^{x},")); //génère les tableFields qui vont chercher via tnum^ les champs des sous-objets
            rootObject.tableFields = tableFields.Substring(0, tableFields.Length - 1);

            String bodyString = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            AbasRequests.WriteRequestBody(ref request, bodyString);

            WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
            string responseString = AbasRequests.ReadWebResponse(response);
            dynamic j = JsonConvert.DeserializeObject(responseString);


            return j;
        }

        public async Task<EntityTable> ReadTable<T>(List<GridField> gridFields, List<FilterField> filterFields, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetRichUri<T>(gridFields, filterFields, requestedPage, count);
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                dynamic j = JsonConvert.DeserializeObject(response);

                EntityTable entityTable = null;
                entityTable = new EntityTable(j, gridFields);

                return entityTable;
            }
            else
            {
                List<T> result = await this.ReadListOffline<T>(gridFields, filterFields, requestedPage, count);


                EntityTable entityTable = null;
                entityTable = new EntityTable(result, gridFields);

                return entityTable;
                //throw new NotImplementedException("Besoin de générer une EntityTable à partir d'une liste d'objets");
            }
        }

        public async Task<EntityTable> ReadTableOffline<T>(List<GridField> gridFields, List<FilterField> filterFields, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {
            FormatGridFieldsOffline(gridFields);
            List<T> result = await this.ReadListOffline<T>(gridFields, filterFields, requestedPage, count);
            EntityTable entityTable = new EntityTable(result, gridFields);
            return entityTable;                        
        }

        private void FormatGridFieldsOffline(List<GridField> gridFields)
        {
            if (gridFields != null)
            {
                foreach (GridField gridField in gridFields)
                {
                    gridField.FieldName = gridField.FieldName.Replace("^", "_");
                }
            }
        }

        public async Task<T> Find<T>(string field, string value)
        where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>();
                uri.AddParam($"criteria={field}={value}");
                T foo = new T();
                uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                dynamic j = JsonConvert.DeserializeObject(response);
                var e = j.erpDataObjects;

                foreach (dynamic item in e)
                {
                    if (item.head == null)
                    {
                        throw new NullReferenceException("Response item 'head' field is not defined");
                    }
                    return item.head.ToObject<T>();
                }
                return default(T);
            }
            else
            {
                var tableName = getTableName<T>();
                LiteCollection<T> coll = db.GetCollection<T>(tableName);
                T res = coll.FindOne(Query.EQ("_" + field, value));
                if (res == null)
                {
                    throw new KeyNotFoundException($"Request to offline database failed");
                }
                return res;
            }
        }

        public async Task<EntityTable> ReadTable<T>(List<GridField> gridFields, string search = null, int requestedPage = 0, int count = 0)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetRichUri<T>(gridFields, search, requestedPage, count);
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_GET;
                string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));
                dynamic j = JsonConvert.DeserializeObject(response);

                EntityTable entityTable = null;
                entityTable = new EntityTable(j, gridFields);

                return entityTable;
            }
            else
            {
                return await ReadTable<T>(gridFields, default(List<FilterField>), requestedPage, count); //default donne du null mais le type permet de lever l'ambiguité (pour éviter la récursion infinie)
            }
        }

        //Dans cette méthode, on regarde o.id pour avoir l'identifiant de l'objet à mettre à jour
        public async Task Update<T>(T o, bool updateStandar = true)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>(o.id);
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_POST;
                //dynamic testt = o;
                //dynamic bla = JsonConvert.SerializeObject(testt);
                if (o.HasSubItems && updateStandar)
                {
                    AbasRequests.WriteRequestBodyFromHeadAndTableObject(ref request, o, o.SubItems);
                }
                else
                {
                    AbasRequests.WriteRequestBodyFromHeadObject(ref request, o);
                }
                try
                {
                    await AbasRequests.ExecuteRequestAsync(request);
                    Context.Instance.ChangeToDisplay = true;
                }
                catch (WebException e)
                {
                    using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                    {
                        string result = streamReader.ReadToEnd();
                        throw e;
                    }
                }

                var foo = await Read<T>(o.id);
                UpdateObjectRequest<T>(o.id, foo);

            }
            else
            {
                UpdateObjectRequest<T>(o.id, o);
                QueueRequest(new AbstractRequest
                {
                    requestObject = o,
                    Action = AbstractRequest.ActionType.Update
                });
            }
            Context.Instance.ChangeToDisplay = true;
        }

        //Dans cette méthode, on regarde o.id pour avoir l'identifiant de l'objet à mettre à jour
        public async Task Update<T, U>(T o)
            where T : IModel, new()
            where U : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>(o.id);
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_POST;
                //dynamic testt = o;
                //dynamic bla = JsonConvert.SerializeObject(testt);
                if (o.HasSubItems)
                {
                    AbasRequests.WriteRequestBodyFromHeadAndTableObject(ref request, o, o.SubItems);
                }
                else
                {
                    AbasRequests.WriteRequestBodyFromHeadObject(ref request, o);
                }
                try
                {
                    await AbasRequests.ExecuteRequestAsync(request);
                    Context.Instance.ChangeToDisplay = true;

                    T foo = new T();
                    foo = await Read<T, U>(o.id);
                    var tableName = getTableName<T>();
                    var coll = db.GetCollection<T>(tableName);
                    UpdateObjectRequest<T>(o.id, o);
                    if (foo.HasSubItems && foo.SubItems != null)
                    {
                        var tableNameSubItems = getTableName<U>();
                        var collSubItems = db.GetCollection<U>(tableNameSubItems);

                        //Supprime tous les subItems qui n'existent plus
                        var currentSubItems = collSubItems.Find(Query.EQ("head", o.id));
                        foreach (U currentSubItem in currentSubItems)
                        {
                            var res = foo.SubItems.Exists(x => (x as IModel).id == currentSubItem.id);
                            if (!res)
                            {
                                collSubItems.Delete(currentSubItem.id);
                            }
                        }

                        //Met à jour tous les subItems
                        foreach (U subItem in foo.SubItems)
                        {
                            if (!UpdateObjectRequest<U>(subItem.id, subItem))
                            {
                                collSubItems.Upsert(subItem);
                            }
                        }
                    }
                }
                catch (WebException e)
                {
                    throw new Exception(e.Message);                    
                }
            }
            else
            {
                UpdateObjectRequest<T>(o.id, o);
                QueueRequest(new AbstractRequest
                {
                    requestObject = o,
                    Action = AbstractRequest.ActionType.Update
                });

                if (o.HasSubItems && o.SubItems != null)
                {
                    var tableNameSubItems = getTableName<U>();
                    var collSubItems = db.GetCollection<U>(tableNameSubItems);

                    //Supprime tous les subItems qui n'existent plus
                    var currentSubItems = collSubItems.Find(Query.EQ("head", o.id));
                    foreach (U currentSubItem in currentSubItems)
                    {
                        var res = o.SubItems.Exists(x => (x as IModel).id == currentSubItem.id);
                        if (!res)
                        {
                            collSubItems.Delete(currentSubItem.id);
                        }
                    }

                    //Met à jour tous les subItems
                    foreach (U subItem in o.SubItems)
                    {
                        (subItem as Models.SaleProduct).head = o.id;
                        if (string.IsNullOrWhiteSpace((subItem as Models.SaleProduct).id))
                        {
                            (subItem as Models.SaleProduct).id = subItem.GetHashCode().ToString() + DateTime.Now.ToString();
                            collSubItems.Upsert(subItem);
                        }
                        else
                        {
                            UpdateObjectRequest<U>(subItem.id, subItem);
                        }
                    }
                }

            }
            Context.Instance.ChangeToDisplay = true;
        }

        public async Task Upsert<T>(List<T> o) where T : IModel, new()
        {
            if (o != null && o.Count > 0)
            {
                UpdateObjectRequest<T>(o.FirstOrDefault().id, o.FirstOrDefault());
                QueueRequest(new AbstractRequest
                {
                    requestObject = o,
                    Action = AbstractRequest.ActionType.Update
                });

                var tableNameSubItems = getTableName<T>();
                db.DropCollection(tableNameSubItems);
                var collSubItems = db.GetCollection<T>(tableNameSubItems);

                try
                {
                    foreach (T subItem in o)
                    {
                        if (!UpdateObjectRequest<T>(subItem.id, subItem))
                        {
                            collSubItems.Upsert(subItem);
                        }
                    }
                    var results = collSubItems.FindAll();
                }
                catch (Exception e)
                {

                }
            }
        }

        public async Task InitTransactionWorkspace<T>(string id)
            where T : IModel, new()
        {
            CheckAuthenticated();
            this.TransactionWorkspace = new AbasWorkspace(_serverUrl, _username, _password);
            BetterUri pathToUpdateCommand = BetterUri.GetUri<T>(id);
            pathToUpdateCommand.Path += "/commands/UPDATE";
            await this.TransactionWorkspace.InitWorkspaceAsync(pathToUpdateCommand.Uri);
        }

        public async Task CommitAndCloseTransactionWorkspace()
        {
            await this.TransactionWorkspace.ExecuteWipCommandAsync("COMMIT");
            await this.TransactionWorkspace.ExecuteWsCommandAsync("CLOSE");
        }

        private async Task CancelTransactionWorkspace()
        {
            await this.TransactionWorkspace.CancelWorkspaceAsync();
        }

        private AbasWorkspace TransactionWorkspace { get; set; }

        //Attention, cette fonction ne marche vraiment que sur des objets de type "Sale" (Opportunity, Quotation), où les lignes ajoutées sont des produits
        public async Task AddRowToObject<T>(string id, string _idProduct, string _unitQty)
            where T : IModel, new()
        {
            CheckAuthenticated();
            try
            {
                dynamic response1 = await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                        {
                                new {
                                    _type = "InsertRow",
                                    rowSpec="!0"
                                }
                        }
                });
                string editRowId = response1.meta.editRowId;
                dynamic response2 = await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                    {
                        new {
                            _type = "SetFieldValue",
                            fieldName ="product",
                            value =_idProduct,
                            rowSpec=editRowId
                        },
                        new {
                            _type = "SetFieldValue",
                            fieldName ="unitQty",
                            value =_unitQty,
                            rowSpec=editRowId
                        }
                    }
                });
            }
            catch (WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    string result = streamReader.ReadToEnd();
                }

                await this.CancelTransactionWorkspace(); //Si on a une erreur dans les actions, on annule le workspace pour ne pas avoir de blocage de l'objet
                throw e;
            }
            catch (Exception e)
            {
                await this.CancelTransactionWorkspace(); //Si on a une erreur dans les actions, on annule le workspace pour ne pas avoir de blocage de l'objet
                throw e;
            }
        }

        public async Task DeleteRowFromObject<T>(string id, string num)
            where T : IModel, new()
        {
            CheckAuthenticated();
            try
            {
                /*dynamic response1 = await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                        {
                        new {
                            _type = "DeleteRows",//TableRowDelete
                            rowNo=num //rowSpec=num
                        },
                        new {
                                _type = "SaveAndReload"
                            }
                        }
                });

                string editRowId = response1.meta.editRowId;*/
                dynamic response = await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                        {
                        new {
                            _type = "TableRowDelete",
                            rowNo=num //rowSpec=num
                        }/*,
                        new {
                                _type = "SaveAndReload"
                            }*/
                        }
                });
            }
            catch (WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    string result = streamReader.ReadToEnd();
                }

                await this.CancelTransactionWorkspace();
            }
            catch (Exception e)
            {
                await this.CancelTransactionWorkspace();
            }
        }

        public async Task CancelRowInObject<T>(string id, string num)
            where T : IModel, new()
        {
            CheckAuthenticated();
            try
            {
                /*
                dynamic response = await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                    {
                        new {
                            _type="SetFieldValue",
                            fieldName="status",
                            value="A",
                            rowSpec=num
                        }
                    }
                });
                string editRowId = response.meta.editRowId;*/
                dynamic response2 = await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                    {
                        new {
                            _type="SetFieldValue",
                            fieldName="status",
                            value="A",
                            rowSpec=num
                        }
                    }
                });
                /*
                await this.TransactionWorkspace.ActionAsync(new
                {
                    actions = new Object[]
                        {
                        new {
                            _type = "DeleteRows",//TableRowDelete
                            rowNo=num //rowSpec=num
                        },
                        new {
                                _type = "SaveAndReload"
                            }
                        }
                });*/
            }
            catch (WebException e)
            {
                using (var streamReader = new StreamReader(e.Response.GetResponseStream()))
                {
                    string result = streamReader.ReadToEnd();
                }

                await this.CancelTransactionWorkspace();
            }
            catch (Exception e)
            {
                await this.CancelTransactionWorkspace();
            }
        }

        public async Task Delete<T>(string id)
            where T : IModel, new()
        {
            if (Context.Instance.IsConnected)
            {
                CheckAuthenticated();
                BetterUri uri = BetterUri.GetUri<T>(id);
                WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                request.Method = Constants.WEBREQUEST_DELETE;
                await AbasRequests.ExecuteRequestAsync(request);
                Context.Instance.ChangeToDisplay = true;
            }
            else
            {
                var tableName = getTableName<T>();
                LiteCollection<T> coll = db.GetCollection<T>(tableName);
                if (!coll.Delete(id))
                {
                    throw new KeyNotFoundException($"Object {id} not found in offline database");
                }
                QueueRequest(new AbstractRequest
                {
                    Action = AbstractRequest.ActionType.Delete,
                    requestObject = new { id }
                });
            }
        }


        public async Task<List<T>> GetEnumAsync<T>()
             where T : IModel, new()
        {
            List<T> tab = new List<T>();
            try
            {
                if (Context.Instance.IsConnected)
                {

                    CheckAuthenticated();
                    BetterUri uri = BetterUri.GetUri<T>();

                    WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
                    WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
                    string pageContent = AbasRequests.ReadWebResponse(response);

                    dynamic j = JsonConvert.DeserializeObject(pageContent);
                    var e = j.table;

                    foreach (dynamic item in e)
                    {
                        T obj = item.ToObject<T>();
                        tab.Add(item.ToObject<T>());
                        //list.Add("(" + item.enumIdentifier.ToString() + ")", item.enumDescr.ToString());
                    }
                }
                else
                {
                    var items = await this.ReadListOffline<T>();

                    return items;
                }
            }
            catch (Exception ex)
            {

            }
            return tab;
        }

        public void DropDatabase()
        {
            try
            {
                db.DropCollection("11-1"); // Employee table
                db.DropCollection("3-22"); // Order table
                db.DropCollection("3-2"); // SaleProduct table
                db.DropCollection("169-107-0"); // Characteristics1 table
                db.DropCollection("170-107-0"); // Characteristics2 table
                db.DropCollection("171-107-0"); // Characteristics3 table
                db.DropCollection("172-107-0"); // Characteristics4 table
                db.DropCollection("173-107-0"); // Characteristics5 table
                db.DropCollection("174-107-0"); // Characteristics6 table
                db.DropCollection("contacts"); // Customer table
                db.DropCollection("2-5"); // ServicePart table
                db.DropCollection("116-1"); // ProductSAV table
                db.DropCollection("62-1"); // Unit table
                db.DropCollection("2-1"); // Product table

                db.DropCollection("168-107-0"); // Type table                
                db.DropCollection("0-3");
                db.DropCollection("134-1");
                db.DropCollection("86-6");
                db.DropCollection("3-30");
                db.DropCollection("3-21");

            }
            catch (Exception ex)
            {

            }
        }

        public async System.Threading.Tasks.Task<Models.OpenItemsObject> GetOpenItems(string ID)
        {
            if (Context.Instance.IsConnected)
            {
                AbasInfoSystem abasInfoSystem = new AbasInfoSystem(_username, _password);
                abasInfoSystem.ActionSetFieldValueAsync("bervon", ID);
                dynamic j = await abasInfoSystem.Execute<Models.OpenItemsObject>();

                Models.OpenItemsObject openItemsObject = new Models.OpenItemsObject(j);
                openItemsObject.id = ID;
                return openItemsObject;
            }
            else
            {
                return await this.Read<Models.OpenItemsObject>(ID);
            }
        }
    }
}
