﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using Abas_Shared_Xamarin.Models;
using Newtonsoft.Json;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using System.Globalization;

[assembly: Xamarin.Forms.Dependency(typeof(Abas_Shared_Xamarin.Services.AbasService))]
namespace Abas_Shared_Xamarin.Services
{
    public partial class AbasService : IAbasService
    {
        private static string _serverUrl = null;
        private static string _instancePath = null;
        public string _username = null;
        private string _password = null;
        public static string BaseUriString { get { return _serverUrl + _instancePath; } }

        public string Username
        {
            get { return this._username; }
        }

        #region Common

        public bool IsAuthenticated()
        {
            return !String.IsNullOrWhiteSpace(_serverUrl)
                   && !String.IsNullOrWhiteSpace(_instancePath)
                   && !String.IsNullOrWhiteSpace(_username)
                   && !String.IsNullOrWhiteSpace(_password);
        }

        #endregion

        #region Authentication
        private Uri GetLoginUri() { return new Uri(BaseUriString); }
        public async System.Threading.Tasks.Task<bool> LoginAsync(string serverUrl, string instancePath, string username, string password)
        {
#if DEBUG
            // En mode debug si on ne passe pas un des 3 arguments on le prérempli
            if (String.IsNullOrWhiteSpace(serverUrl))
            {
                serverUrl = Constants.DEV_SERVER_URL;
            }
            if (String.IsNullOrWhiteSpace(instancePath))
            {
                instancePath = Constants.DEV_INSTANCE_PATH;
            }
            if (String.IsNullOrWhiteSpace(username))
            {
                username = Constants.DEV_USERNAME;
            }
            if (String.IsNullOrWhiteSpace(password))
            {
                password = Constants.DEV_PASSWORD;
            }
#endif

            if (String.IsNullOrWhiteSpace(serverUrl))
            {
                throw new ArgumentNullException(nameof(serverUrl));
            }
            else if (String.IsNullOrWhiteSpace(instancePath))
            {
                throw new ArgumentNullException(nameof(instancePath));
            }
            else if (String.IsNullOrWhiteSpace(username))
            {
                throw new ArgumentNullException(nameof(username));
            }
            else if (String.IsNullOrWhiteSpace(password))
            {
                throw new ArgumentNullException(nameof(password));
            }

            _serverUrl = serverUrl;
            _instancePath = instancePath;
            this._username = username;
            this._password = password;

            if (Context.Instance.IsConnected)
            {
                Uri myUri = new Uri(serverUrl + instancePath);

                //Création de la requète à l'aide du webRequest avec différentes propriétés
                var request = WebRequest.Create(myUri);
                request.ContentType = Constants.WEBREQUEST_CONTENT_TYPE;

                ((HttpWebRequest)request).Accept = Constants.WEBREQUEST_ACCEPT;
                request.Headers.Set(HttpRequestHeader.AcceptLanguage, Constants.WEBREQUEST_ACCEPT_LANGUAGE);
                request.Method = Constants.WEBREQUEST_GET;


                //Ajout d'identifiants de connexion à l'API
                NetworkCredential myNetworkCredentials = new NetworkCredential(username, password);
                CredentialCache myCredentialCache = new CredentialCache
                {
                    { myUri, Constants.WEBREQUEST_AUTH_BASIC, myNetworkCredentials }
                };
                request.Credentials = myCredentialCache;
                request.PreAuthenticate = true;

                try
                {
                    //Récupération de la réponse depuis l'API.            
                    WebResponse myResponse = await request.GetResponseAsync();
                    Stream responseStream = myResponse.GetResponseStream();
                    StreamReader myStreamReader = new StreamReader(responseStream, Encoding.Default);


                    //Stockage de la réponse dans une variable string et fermeture des flux
                    string pageContent = myStreamReader.ReadToEnd();
                    responseStream.Close();
                    myResponse.Close();
                }
                catch (Exception e)
                {
                    return false;
                }


            }
            else
            {
                return true;
            }

            return true;
        }

        /*
        private Uri GetCA(string id, int annee)
        {
            return new Uri(GetBaseUriString() + Constants.URI_CA + Constants.URI_CA_PARAMS + Constants.URI_CA_CRITERIA + "mainObj==" + id + ";" + "FY=" + annee);
        }

        public async System.Threading.Tasks.Task<Models.turnover> GetTurnoverAsync(string id, int annee)
        {
            string pageContent = await ExecuteGetRequestAsync(this.GetCA(id, annee));
            dynamic j = JsonConvert.DeserializeObject(pageContent);
            dynamic a = j.erpDataObjects[0];
            turnover test = a.head.ToObject<Models.turnover>();
            return test;
        }
        */

        #endregion Authentication API

        private Uri GetUserUri() { return new Uri(BaseUriString + "/userInfo"); }

        public async System.Threading.Tasks.Task<Models.User> GetCurrentUserAsync()
        {
            WebRequest request = AbasRequests.PrepareAbasRequest(GetUserUri(), _username, _password);
            WebResponse response = await AbasRequests.ExecuteRequestAsync(request);
            string pageContent = AbasRequests.ReadWebResponse(response);  // ExecuteGetRequestAsync(this.GetUserUri());
            dynamic j = JsonConvert.DeserializeObject(pageContent);
            User test = j.ToObject<Models.User>();
            return test;
        }





        #region Activity

        public async System.Threading.Tasks.Task<ActivityObject> GetActivity(string ID = null)
        {
            ActivityObject activityObject;
            if (Context.Instance.IsConnected)
            {
                AbasInfoSystem abasInfoSystem = new AbasInfoSystem(_username, _password);
                abasInfoSystem.ActionSetFieldValueAsync("chko", "true");
                abasInfoSystem.ActionSetFieldValueAsync("vkanko", "true");
                abasInfoSystem.ActionSetFieldValueAsync("vkabko", "true");
                abasInfoSystem.ActionSetFieldValueAsync("vomvom", "");
                abasInfoSystem.ActionSetFieldValueAsync("vombis", "");
                if (ID != null)
                {
                    abasInfoSystem.ActionSetFieldValueAsync("vkpartner", ID);
                }
                abasInfoSystem.ActionSetFieldValueAsync("betreuer", "");
                dynamic j = await abasInfoSystem.Execute<ActivityObject>();

                dynamic table = j.table;
                activityObject = new ActivityObject(table);
            }
            else
            {
                activityObject = new ActivityObject();

                var opportunities = await this.ReadList<Opportunity>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "customer", Operator = "==", Value = ID } });
                activityObject.Opportunites = opportunities.Count;
                try
                {
                    activityObject.OpportunitesValeur = opportunities.Sum(o => int.Parse(o.totalGrossAmtDom));
                }
                catch (Exception e)
                {

                }


                var quotations = await this.ReadList<Quotation>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "customer", Operator = "==", Value = ID } });
                activityObject.Offres = quotations.Count;
                try
                {
                    activityObject.OffresValeur = quotations.Sum(o => int.Parse(o.totalGrossAmtDom));
                }
                catch (Exception e)
                {

                }


                var orders = await this.ReadList<Order>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "customer", Operator = "==", Value = ID } });
                activityObject.Commandes = orders.Count;
                try
                {
                    activityObject.CommandesValeur = orders.Sum(o => int.Parse(o.totalGrossAmtDom));
                }
                catch (Exception e)
                {

                }

                //TODO: remplir les valeurs avec les données hors ligne
            }

            var notes = await this.ReadList<Note>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "businessPartner", Operator = "==", Value = ID } });
            activityObject.Notes = notes.Count;

            var taches = await this.ReadList<Abas_Shared_Xamarin.Models.Task>(new List<GridField>() { new GridField("id", string.Empty, GridField.SortOrder.None) }
                                                  , new List<FilterField>() { new FilterField() { FieldName = "businessPartner", Operator = "==", Value = ID } });
            activityObject.Taches = taches.Count;

            return activityObject;
        }

        #endregion


        #region Commands Abas

        private Uri GetObjectCommandUri(string UriEcran, string id, string ActionType) { return new Uri(BaseUriString + UriEcran + "/" + id + "/commands/" + ActionType); }
        //private Uri GetWorkspaceUri(string UriEcran, string id, string ActionType) { return new Uri(BaseUriString + UriEcran + "/" + id + "/commands/" + ActionType); }


        public async System.Threading.Tasks.Task CommandAction<T>(string id, string ActionType)
        where T : IModel, new()
        {
            string linkSecure = "";
            T foo = new T();
            try
            {
                WebRequest request = AbasRequests.PrepareAbasRequest(GetObjectCommandUri(foo.BasePath, id, ActionType), this._username, this._password);
                request.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
                ((HttpWebRequest)request).Accept = Constants.ABAS_SIMPLE_JSON;
                request.Method = "POST";
                WebResponse Webresponse = await AbasRequests.ExecuteRequestAsync(request);
                string response = AbasRequests.ReadWebResponse(Webresponse);
                dynamic reponse1deserialise = JsonConvert.DeserializeObject(response);
                string link1 = reponse1deserialise.meta.link.href;
                linkSecure = reponse1deserialise.meta.link.href;

                RootObject ro = new RootObject();
                ro.actions.Add(ActionActivity.New(Context.Instance.CurrentWebUser.RoleServiceEngineer_swd, "zeich", "SetFieldValue"));
                ro.actions.Add(ActionActivity.New(".", "vom", "SetFieldValue"));
                WebRequest request2 = AbasRequests.PrepareAbasRequest(GetOpenEngineerCompletionConfirmationsViewUri(link1), this._username, this._password);
                request2.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
                ((HttpWebRequest)request2).Accept = Constants.ABAS_SIMPLE_JSON;
                request2.Method = "POST";
                string body2 = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
                AbasRequests.WriteRequestBody(ref request2, body2);
                WebResponse Webresponse2 = await AbasRequests.ExecuteRequestAsync(request2);
                string response2 = AbasRequests.ReadWebResponse(Webresponse2);
                dynamic reponse2deserialise = JsonConvert.DeserializeObject(response2);
                string link2 = reponse2deserialise.meta.link.href;


                ro = new RootObject();
                ro.actions.Add(ActionActivity.New(null, null, "Commit"));
                WebRequest requestCommit = AbasRequests.PrepareAbasRequest(GetOpenEngineerCompletionConfirmationsViewUri(link2), this._username, this._password);
                requestCommit.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
                ((HttpWebRequest)requestCommit).Accept = Constants.ABAS_SIMPLE_JSON;
                requestCommit.Method = "POST";
                string bodyCommit = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
                AbasRequests.WriteRequestBody(ref requestCommit, bodyCommit);
                WebResponse WebresponseCommit = await AbasRequests.ExecuteRequestAsync(requestCommit);

                //string CurrentWorkspace = reponse1deserialise.meta.workingSetId;
                //WebRequest request5 = AbasRequests.PrepareAbasRequest(new Uri(BaseUriString + "/workspace/" + CurrentWorkspace + "/commands/CANCEL"), this.Username, this._password);
                //request5.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
                //((HttpWebRequest)request5).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
                //request5.Method = "POST";
                //WebResponse Webresponse5 = await AbasRequests.ExecuteRequestAsync(request5);

                //Uri LastLink = reponse3deserialise.content.document.link;
            }
            catch (Exception ex)
            {

                //string CurrentWorkspace = reponse1deserialise.meta.workingSetId;
                WebRequest request5 = AbasRequests.PrepareAbasRequest(new Uri(BaseUriString + "/workspace/" + linkSecure + "/commands/CANCEL"), this.Username, this._password);
                request5.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
                ((HttpWebRequest)request5).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
                request5.Method = "POST";
                WebResponse Webresponse5 = await AbasRequests.ExecuteRequestAsync(request5);

            }
        }

        #endregion

        #region Impression

        //Déclaration des Uri à utiliser

        private Uri GetOpenCustomerViewUri(string UriEcran, string id) { return new Uri(BaseUriString + UriEcran + "/" + id + "/commands/VIEW?filterHeadFields=budruck"); }
        private Uri GetOpenPrintViewUri(string UriEcranPrint) { return new Uri(_serverUrl + UriEcranPrint + "/fields/head/budruck/commands/SUBEDIT?filterHeadFields=layout,datname,drucker"); }
        private Uri GetOpenLinkFilesUri(string UriEcranPrintLink) { return new Uri(_serverUrl + UriEcranPrintLink); }

        // Récupération du lien de la fenêtre d'impression de l'écran souhaité
        /// <summary>
        /// Prints the impression.
        /// </summary>
        /// <returns>The impression.</returns>
        /// <param name="id">Correspond à l'id de l'objet demandé</param>
        /// <typeparam name="T">The 1st type parameter.</typeparam>
        public async Task<Uri> PrintImpression<T>(string id)
        where T : IModel, new()
        {
            T foo = new T();
            // Récupération du lien de la fenêtre d'impression de l'écran souhaité
            //---------------------------------------------------------------------------------------------------
            WebRequest request = AbasRequests.PrepareAbasRequest(GetOpenCustomerViewUri(foo.BasePath, id), this._username, this._password);
            request.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request).Accept = Constants.ABAS_SIMPLE_JSON;
            request.Method = "POST";
            WebResponse Webresponse = await AbasRequests.ExecuteRequestAsync(request);
            string response = AbasRequests.ReadWebResponse(Webresponse);
            dynamic reponse1deserialise = JsonConvert.DeserializeObject(response);
            string link1 = reponse1deserialise.meta.link.href;
            //---------------------------------------------------------------------------------------------------


            // Ouverture de la fenêtre de selection de la mise en page et des paramètres voulus
            //---------------------------------------------------------------------------------------------------
            WebRequest request2 = AbasRequests.PrepareAbasRequest(GetOpenPrintViewUri(link1), this._username, this._password);
            request2.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request2).Accept = Constants.ABAS_SIMPLE_JSON;
            request2.Method = "POST";
            WebResponse Webresponse2 = await AbasRequests.ExecuteRequestAsync(request2);
            string response2 = AbasRequests.ReadWebResponse(Webresponse2);
            dynamic reponse2deserialise = JsonConvert.DeserializeObject(response2);
            string link2 = reponse2deserialise.meta.link.href;
            //---------------------------------------------------------------------------------------------------


            // Récupération du lien menant à la fenetre contenant le lien du dl
            //---------------------------------------------------------------------------------------------------
            Uri linkDl = GetOpenLinkFilesUri(link2);
            RootObject
            ro = new RootObject();

            string LayoutValue()
            {
                if (foo.BasePath == "/obj/data/3:21")
                {
                    //ParametersViewModel parameters = new ParametersViewModel();
                    //if (CultureInfo.CurrentCulture.Name.Contains("es"))
                    //{
                    //    return "(807,88,0)";
                    //}
                    return AppParameters.QuotationLayout != null ? AppParameters.QuotationLayout : "XMASTER";
                }
                else if (foo.BasePath == "/obj/data/3:22" || foo.BasePath == "/obj/data/3:27")
                {
                    //if (CultureInfo.CurrentCulture.Name.Contains("es"))
                    //{
                    //    return "(808,88,0)";
                    //}
                    return AppParameters.SaleOrderLayout != null ? AppParameters.SaleOrderLayout : "XMASTER";
                }
                else
                {
                    return CultureInfo.CurrentCulture.Name.Contains("es") ? "MASTER" : "XMASTER";
                }
            }

            ro.actions.Add(ActionActivity.New(LayoutValue(), "layout", "SetFieldValue"));
            //ro.actions.Add(ActionActivity.New("(166,88,0)", "kanal", "SetFieldValue"));
            //ro.actions.Add(ActionActivity.New("1", "aktiv", "SetFieldValue"));
            if (foo is EngineerReport || foo is ServiceQuotation)
            {
                ro.actions.Add(ActionActivity.New("ECRAN", "drucker", "SetFieldValue"));  //ECRAN
            }
            else
            {
                ro.actions.Add(ActionActivity.New(AppParameters.PrintType != null ? AppParameters.PrintType : "11001", "drucker", "SetFieldValue"));  //DATEI
            }
            
            ro.actions.Add(ActionActivity.New("test", "datname", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(null, null, "Commit"));

            WebRequest request3 = AbasRequests.PrepareAbasRequest(GetOpenLinkFilesUri(link2), this._username, this._password);
            request3.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            ((HttpWebRequest)request3).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            request3.Method = "POST";
            string body = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref request3, body);
            WebResponse Webresponse3 = await AbasRequests.ExecuteRequestAsync(request3);
            string response3 = AbasRequests.ReadWebResponse(Webresponse3);
            dynamic reponse3deserialise = JsonConvert.DeserializeObject(response3);
            string link3 = reponse3deserialise.content.document.link.href;
            //---------------------------------------------------------------------------------------------------


            //Exécution de la requête GET afin de télecharger le PDF
            //---------------------------------------------------------------------------------------------------
            WebRequest request4 = AbasRequests.PrepareAbasRequest(GetOpenLinkFilesUri(link3), this._username, this._password);
            request4.ContentType = null;
            ((HttpWebRequest)request4).Accept = Constants.ABAS_SIMPLE_PDF;
            WebResponse Webresponse4 = await AbasRequests.ExecuteRequestAsync(request4);
            //---------------------------------------------------------------------------------------------------


            //Fermeture du WorkSpace généré
            //---------------------------------------------------------------------------------------------------
            string CurrentWorkspace = reponse1deserialise.meta.workingSetId;
            WebRequest request5 = AbasRequests.PrepareAbasRequest(new Uri(BaseUriString + "/workspace/" + CurrentWorkspace + "/commands/CANCEL"), this.Username, this._password);
            request5.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            ((HttpWebRequest)request5).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            request5.Method = "POST";
            WebResponse Webresponse5 = await AbasRequests.ExecuteRequestAsync(request5);
            //---------------------------------------------------------------------------------------------------


            //Valeur de retour : Url du pdf
            //---------------------------------------------------------------------------------------------------
            return Webresponse4.ResponseUri;

        }
        #endregion



        #region Rapport d'intervention


        //Déclaration des Uri à utiliser

        private Uri GetOpenEngineerCompletionConfirmationsViewUriNew(string UriEcran)
        {
            return new Uri(BaseUriString + UriEcran + "/commands/NEW");
        }

        private Uri GetOpenEngineerCompletionConfirmationsViewUri(string UriEcran) { return new Uri(_serverUrl + UriEcran); }
        //private Uri GetOpenLinkFilesUri(string UriEcranPrintLink) { return new Uri(_serverUrl + UriEcranPrintLink); }

        // Récupération du lien de la fenêtre d'impression de l'écran souhaité
        /// <summary>
        /// Prints the impression.
        /// </summary>
        /// <returns>The impression.</returns>
        /// <typeparam name="T">The 1st type parameter.</typeparam>
        public async System.Threading.Tasks.Task SaveEngineerCompletionConfirmations<T>(EngineerCompletionConfirmations engineerCompletionConfirmations)
        where T : IModel, new()
        {
            T foo = new T();
            //Récupération du lien de la fenêtre de consultation
            //---------------------------------------------------------------------------------------------------
            WebRequest request = AbasRequests.PrepareAbasRequest(GetOpenEngineerCompletionConfirmationsViewUriNew(foo.BasePath), this._username, this._password);

            //AbasWorkspace NewWebUserWorkspace = null;
            //NewWebUserWorkspace = new AbasWorkspace(_serverUrl, _username, _password);
            //await NewWebUserWorkspace.InitWorkspaceAsync(Context.InstancePath + "/obj/data/118:6/commands/NEW");


            request.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request).Accept = Constants.ABAS_SIMPLE_JSON;
            request.Method = "POST";
            WebResponse Webresponse = await AbasRequests.ExecuteRequestAsync(request);
            string response = AbasRequests.ReadWebResponse(Webresponse);
            dynamic reponse1deserialise = JsonConvert.DeserializeObject(response);
            string link1 = reponse1deserialise.meta.link.href;
            //---------------------------------------------------------------------------------------------------


            // 
            //---------------------------------------------------------------------------------------------------
            RootObject ro = new RootObject();
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.serviceEngineer, "techniker", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.costCenter, "kstelle", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.wageGrp, "lgr", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.serviceReservationIdno.ToString(), "servau", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New("true", "ladetab", "SetFieldValue"));


            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.ysummary, "ysummary", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.ycustcom, "ycustcom", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.yaddserv, "yaddserv", "SetFieldValue"));
            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmations.ycustname, "ycustname", "SetFieldValue"));



            WebRequest request2 = AbasRequests.PrepareAbasRequest(GetOpenEngineerCompletionConfirmationsViewUri(link1), this._username, this._password);
            request2.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request2).Accept = Constants.ABAS_SIMPLE_JSON;
            request2.Method = "POST";
            string body2 = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref request2, body2);
            WebResponse Webresponse2 = await AbasRequests.ExecuteRequestAsync(request2);
            string response2 = AbasRequests.ReadWebResponse(Webresponse2);
            dynamic reponse2deserialise = JsonConvert.DeserializeObject(response2);
            string link2 = reponse2deserialise.meta.link.href;
            //---------------------------------------------------------------------------------------------------

            // 
            //---------------------------------------------------------------------------------------------------
            ro = new RootObject();
            
            foreach (EngineerCompletionConfirmation engineerCompletionConfirmation in engineerCompletionConfirmations.SubItems)
            {
                

                for (int i = reponse2deserialise.table.Count - 1; i >= 0; i--)
                {
                    dynamic row = reponse2deserialise.table[i];
                    if (row.serres == engineerCompletionConfirmation.serviceReservation)
                    {
                        //Ajouter le temps si c'est une ligne de temps
                        if (!string.IsNullOrWhiteSpace(engineerCompletionConfirmation.serviceDuration))
                        {
                            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmation.serviceDuration, "dauer", "SetFieldValue", Convert.ToString(row.zn)));
                        }

                        //Ajouter la quanité si c'est une ligne de temps
                        if (engineerCompletionConfirmation.entQty != 0.0)
                        {
                            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmation.entQty.ToString(), "aumge", "SetFieldValue", Convert.ToString(row.zn)));
                        }

                        if (!string.IsNullOrWhiteSpace(engineerCompletionConfirmation.adoptText1))
                        {
                            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmation.adoptText1, "erbtext1", "SetFieldValue", Convert.ToString(row.zn)));
                        }

                        if (!string.IsNullOrWhiteSpace(engineerCompletionConfirmation.status))
                        {
                            ro.actions.Add(ActionActivity.New(engineerCompletionConfirmation.status, "status", "SetFieldValue", Convert.ToString(row.zn)));
                        }


                        break;
                    }
                }
            }

            WebRequest request3 = AbasRequests.PrepareAbasRequest(GetOpenEngineerCompletionConfirmationsViewUri(link2), this._username, this._password);
            request3.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)request3).Accept = Constants.ABAS_SIMPLE_JSON;
            request3.Method = "POST";
            string body3 = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref request3, body3);
            WebResponse Webresponse3 = await AbasRequests.ExecuteRequestAsync(request3);

            //Customer
            Raw rawCustSign = new Raw() { raw = engineerCompletionConfirmations.yfcustsign };
            WebRequest requestCustSign = AbasRequests.PrepareAbasRequestTextPlain(GetOpenEngineerCompletionConfirmationsViewUri(link2 + "/fields/head/yfcustsign/value"), this._username, this._password);
            requestCustSign.ContentType = Constants.ABAS_TEXT_PLAIN;
            ((HttpWebRequest)requestCustSign).Accept = Constants.ABAS_SIMPLE_JSON;
            requestCustSign.Method = "PUT";
            //string bodyCustSign = JsonConvert.SerializeObject(rawCustSign, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref requestCustSign, engineerCompletionConfirmations.yfcustsign);
            WebResponse WebresponseCustSign = await AbasRequests.ExecuteRequestAsync(requestCustSign);

            //Technical
            Raw rawEngSign = new Raw() { raw = engineerCompletionConfirmations.yfengsign };
            WebRequest requestEngSign = AbasRequests.PrepareAbasRequestTextPlain(GetOpenEngineerCompletionConfirmationsViewUri(link2 + "/fields/head/yfengsign/value"), this._username, this._password);
            requestEngSign.ContentType = Constants.ABAS_TEXT_PLAIN;
            ((HttpWebRequest)requestEngSign).Accept = Constants.ABAS_SIMPLE_JSON;
            requestEngSign.Method = "PUT";
            //string bodyEngSign = JsonConvert.SerializeObject(rawEngSign, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref requestEngSign, engineerCompletionConfirmations.yfengsign);
            WebResponse WebresponseEngSign = await AbasRequests.ExecuteRequestAsync(requestEngSign);

            // 
            //---------------------------------------------------------------------------------------------------
            ro = new RootObject();
            ro.actions.Add(ActionActivity.New(null, null, "Commit"));
            WebRequest requestCommit = AbasRequests.PrepareAbasRequest(GetOpenEngineerCompletionConfirmationsViewUri(link2), this._username, this._password);
            requestCommit.ContentType = Constants.ABAS_SIMPLE_JSON_APPLICATION;
            ((HttpWebRequest)requestCommit).Accept = Constants.ABAS_SIMPLE_JSON;
            requestCommit.Method = "POST";
            string bodyCommit = JsonConvert.SerializeObject(ro, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            AbasRequests.WriteRequestBody(ref requestCommit, bodyCommit);
            WebResponse WebresponseCommit = await AbasRequests.ExecuteRequestAsync(requestCommit);

            //Fermeture du WorkSpace généré
            //---------------------------------------------------------------------------------------------------
            
            string CurrentWorkspace = reponse1deserialise.meta.workingSetId;
            WebRequest requestFinale = AbasRequests.PrepareAbasRequest(new Uri(BaseUriString + "/workspace/" + CurrentWorkspace + "/commands/CANCEL"), this.Username, this._password);
            ServicePoint sp = ServicePointManager.FindServicePoint(requestFinale.RequestUri);
            sp.ConnectionLimit = 10000;
            ServicePointManager.DefaultConnectionLimit = 10000;
            requestFinale.ContentType = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            ((HttpWebRequest)requestFinale).Accept = Constants.ABAS_SIMPLE_JSON_OBJECTS;
            requestFinale.Method = "POST";
            WebResponse Webresponse5 = await AbasRequests.ExecuteRequestAsync(requestFinale);
            //---------------------------------------------------------------------------------------------------
        }
        #endregion


    }

}