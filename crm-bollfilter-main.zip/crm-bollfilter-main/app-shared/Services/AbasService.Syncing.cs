using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using System.Net;
using LiteQueue;
using System.Linq;
using Xamarin.Forms;
using System.Runtime;
using Abas_Shared_Xamarin.Classes;
using Newtonsoft.Json;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using Abas_Shared_Xamarin.Models;
using Task = System.Threading.Tasks.Task;

namespace Abas_Shared_Xamarin.Services
{
    // We cannot stack raw HTTP requests, because in some cases the offline actions are more complex(row insertion in the table)
    // So here is an abstraction of an action, which can be adapted to different cases (to transform into an interface / to inherit later?)
    public class AbstractRequest
    {
        public object requestObject { get; set; }
        public ActionType Action { get; set; }
        public enum ActionType
        {
            Create,
            Update,
            Delete
        }
    }

    public partial class AbasService
    {

        Models.Agence agence = null;
        List<string> SecteursList = new List<string>();

        private void QueueRequest(AbstractRequest item)
        {
            var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
            offlineRequests.Enqueue(item);
        }

        private AbstractRequest DequeueRequest()
        {
            var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
            var req = offlineRequests.Dequeue();
            offlineRequests.Commit(req);
            return req.Payload;
        }

        private AbstractRequest PeekRequest()
        {
            var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
            var req = offlineRequests.Dequeue();
            offlineRequests.Abort(req);
            return req.Payload;
        }

        async Task ExecRequest(AbstractRequest r)
        {
            ReplaceForeignKeyPersistance(r.requestObject);
            switch (r.Action)
            {
                case (AbstractRequest.ActionType.Create):
                    {
                        dynamic o = (dynamic)r.requestObject;
                        string oldId = o.id;
                        o.id = null;
                        // On utilise la réflection pour appeller les méthodes génériques de CRUD
                        string id = string.Empty;
                        if (o is Models.Transaction)
                        {
                            var tableNameSubItems = getTableName<Models.SaleProduct>();
                            var collSubItems = db.GetCollection<Models.SaleProduct>(tableNameSubItems);
                            var res = collSubItems.Find(LiteDB.Query.EQ("head", oldId));
                            (o as IModel).SubItems = res.ToList<object>();
                            (o as IModel).SubItems.ForEach(x => (x as IModel).id = null);
                            (o as IModel).SubItems.ForEach(x => (x as Models.SaleProduct).head = null);

                            if (o is Models.Opportunity)
                            {
                                id = await Create<Models.Opportunity, Models.SaleProduct>(o, 3500, true);
                            }
                            else if (o is Models.Quotation)
                            {
                                id = await Create<Models.Quotation, Models.SaleProduct>(o, 3500, true);
                            }
                            if (o is Models.Order)
                            {
                                id = await Create<Models.Order, Models.SaleProduct>(o, 3500, true);
                            }

                            if (res != null)
                            {
                                //Supprime tous les subItems (puiqu'ils n'ont pas le bon id et ne servaient qu'à l'affichage horsligne)
                                foreach (Models.SaleProduct currentSubItem in res)
                                {
                                    collSubItems.Delete(currentSubItem.id);
                                }
                            }
                        }
                        else
                        {
                            id = await Create(o, true);
                        }
                        AddSubstitutionPersistant(oldId, id);
                    }
                    break;
                case (AbstractRequest.ActionType.Update):
                    {
                        dynamic o = (dynamic)r.requestObject;
                        // On utilise la réflection pour appeller les méthodes génériques de CRUD
                        if (o is Models.Transaction)
                        {
                            var tableNameSubItems = getTableName<Models.SaleProduct>();
                            var collSubItems = db.GetCollection<Models.SaleProduct>(tableNameSubItems);
                            var res = collSubItems.Find(LiteDB.Query.EQ("head", (o as IModel).id));
                            (o as IModel).SubItems = res.ToList<object>();

                            var newItems = (o as IModel).SubItems.Where(x => (x as Models.SaleProduct).id.Length > 15);
                            newItems.ToList().ForEach(x => (x as Models.SaleProduct).head = null);
                            newItems.ToList().ForEach(x => (x as IModel).id = null);

                            if (o is Models.Opportunity)
                            {
                                await Update<Models.Opportunity, Models.SaleProduct>(o);
                            }
                            else if (o is Models.Quotation)
                            {
                                await Update<Models.Quotation, Models.SaleProduct>(o);
                            }
                            if (o is Models.Order)
                            {
                                await Update<Models.Order, Models.SaleProduct>(o);
                            }
                        }
                        else
                        {
                            await Update(o);
                        }
                    }
                    break;
                case (AbstractRequest.ActionType.Delete):
                    {
                        dynamic o = (dynamic)r.requestObject;
                        //o.id = null;
                        // On utilise la réflection pour appeller les méthodes génériques de CRUD
                        //string id = 
                        await Delete(o);
                    }
                    break;
            }
        }

        
        public List<OfflineItems> GetListPendingUploadItems()
        {
            List<OfflineItems> listOfflineItems = new List<OfflineItems>();
            if (db != null)
            {                
                List<AbstractRequest> listAbstractRequest = this.GetLiteQueueDuplicate();

                foreach (AbstractRequest req in listAbstractRequest)
                {
                    OfflineItems item = GetOfflineItem(req);
                    listOfflineItems.Add(item);
                }                
            }
            return listOfflineItems;
        }

        private List<AbstractRequest> GetLiteQueueDuplicate()
        {
            LiteQueue<AbstractRequest> listLiteQueue = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");

            List<AbstractRequest> listAbstractRequest = new List<AbstractRequest>();

            while (listLiteQueue.Count() > 0)
            {
                var req = listLiteQueue.Dequeue();

                bool itemDuplicated = false;
                foreach (AbstractRequest absReq in listAbstractRequest)
                {
                    if (absReq.Action == AbstractRequest.ActionType.Create)
                    {
                        dynamic o = (dynamic)absReq.requestObject;
                        dynamic actualItem = (dynamic)req.Payload.requestObject;

                        if (o.id == actualItem.id)
                        {
                            itemDuplicated = true;
                        }
                    }
                }

                if (!itemDuplicated)
                {
                    listAbstractRequest.Add(req.Payload);
                }
                listLiteQueue.Commit(req);
            }

            foreach (AbstractRequest req in listAbstractRequest)
            {
                listLiteQueue.Enqueue(req);                
            }

            return listAbstractRequest;
        }

        private OfflineItems GetOfflineItem(AbstractRequest req)
        {
            OfflineItems offlineitem = new OfflineItems();
            switch (req.Action)
            {
                case (AbstractRequest.ActionType.Create):
                    {
                        dynamic o = (dynamic)req.requestObject;
                        string oldId = o.id;
                        o.id = null;                        
                        string id = string.Empty;
                        if (o is Models.Transaction)
                        {                                                        
                            if (o is Opportunity)
                            {
                                Opportunity opportunity = (Opportunity)o;
                                offlineitem = opportunity.offlineInfo;
                            }
                            else if (o is Quotation)
                            {
                                Quotation quotation = (Quotation)o;
                                offlineitem = quotation.offlineInfo;
                            }
                            if (o is Order)
                            {
                                Order order = (Order)o;
                                offlineitem = order.offlineInfo;
                            }
                        }
                        else if (o is Note)
                        {
                            Note note = (Note)o;
                            offlineitem = note.offlineInfo;
                        }
                        else if (o is Prospect)
                        {
                            Prospect prospect = (Prospect)o;
                            offlineitem = prospect.offlineInfo;
                        }
                        else if (o is Models.Task)
                        {
                            Models.Task task = (Models.Task)o;
                            offlineitem = task.offlineInfo;
                        }
                    }
                    break;
            }
            return offlineitem;
        }

        public async Task SwitchToOnline()
        {
            if (db != null)
            {
                //TODO : This is the upload to server if something was changed offline or without connection, we need to do complete this
                try
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        Context.Instance.SynchronisationUpRunning = true;
                    });

                    var offlineRequests = new LiteQueue<AbstractRequest>(db, "AbstractRequestsQueue");
                    while (offlineRequests.Count() > 0)
                    {
                        //Instead of using PeekRequest, you can directly use the LiteQueue feature which allows you to cancel the dequeue afterwards (abort)
                        AbstractRequest r = PeekRequest();                        
                        await ExecRequest(r);
                        DequeueRequest();
                    }

                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        Context.Instance.SynchronisationUpRunning = false;
                    });

                }
                //TODO: if fail, maybe we need to try again?
                catch (InvalidOperationException)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        Context.Instance.SynchronisationUpRunning = false;
                    });
                    return;
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        Context.Instance.SynchronisationUpRunning = false;
                    });
                }
            }
        }

        public void SwitchToOffline()
        {

        }
        #region Reload Partials BD
        public async Task ReloadTransactions()
        {
            try
            {
                Context.Instance.SynchronisationRunning = true;
                DateTime beginSyncDate = await GetERPDateAsync();
                await SyncTable<Models.Order>();
                await SyncTable<Models.Quotation>();
                await SyncTable<Models.Opportunity>();
                Context.Instance.SynchronisationRunning = false;
                SetPersistantPreference("_lastSyncDate", beginSyncDate.ToString());
            }
            catch (Exception e)
            {
                Context.Instance.SynchronisationRunning = false;
            }
        }

        public async Task ReloadNotes()
        {
            try
            {
                Context.Instance.SynchronisationRunning = true;
                DateTime beginSyncDate = await GetERPDateAsync();
                await SyncTable<Models.Note>();                
                Context.Instance.SynchronisationRunning = false;
                SetPersistantPreference("_lastSyncDate", beginSyncDate.ToString());
            }
            catch (Exception e)
            {
                Context.Instance.SynchronisationRunning = false;
            }
        }

        public async Task ReloadTiers()
        {
            try
            {
                Context.Instance.SynchronisationRunning = true;
                DateTime beginSyncDate = await GetERPDateAsync();
                await SyncTable<Models.Prospect>();
                Context.Instance.SynchronisationRunning = false;
                SetPersistantPreference("_lastSyncDate", beginSyncDate.ToString());
            }
            catch (Exception e)
            {
                Context.Instance.SynchronisationRunning = false;
            }
        }

        public async Task ReloadTasks()
        {
            try
            {
                Context.Instance.SynchronisationRunning = true;
                DateTime beginSyncDate = await GetERPDateAsync();
                await SyncTable<Models.Task>();
                Context.Instance.SynchronisationRunning = false;
                SetPersistantPreference("_lastSyncDate", beginSyncDate.ToString());
            }
            catch (Exception e)
            {
                Context.Instance.SynchronisationRunning = false;
            }
        }
        #endregion


        public async Task PopulateDB()
        {
            try
            {
                Context.Instance.SynchronisationRunning = true;

                DateTime beginSyncDate = await GetERPDateAsync();

                await SyncTable<Models.Customer>(); // CRM & CS
                await SyncTable<Models.ContactCustomer>();

                await SyncTable<Models.Employee>();
                await SyncTable<Models.Order>();
                await SyncTable<Models.Unit>();                
                await SyncTable<Models.SaleProduct>();
                await SyncTable<Models.Type>();
                await SyncTable<Models.ClientSector>();
                await SyncTable<Models.Characteristic1>();
                await SyncTable<Models.Characteristic2>();
                await SyncTable<Models.Characteristic3>();
                await SyncTable<Models.Characteristic4>();
                await SyncTable<Models.Characteristic5>();
                await SyncTable<Models.Characteristic6>();

                await SyncTable<Models.Prospect>();
                await SyncTable<Models.ContactProspect>();
                await SyncTable<Models.Turnover>();
                await SyncTable<Models.Note>();
                await SyncTable<Models.Task>();
                await SyncTable<Models.Opportunity>(); // CRM
                await SyncTable<Models.Quotation>();
                await SyncTable<Models.TermsOfPayment>(); // CRM
                await SyncTable<Models.Priority>(); // CRM
                await SyncTable<Models.RefusalReason>(); // CRM

                await SyncTable<Models.ProductSAVBOM, Models.ProductSAVBOMLine>();
                await SyncTable<Models.Product>();
                //Enum refs

                //await SyncTable<Models.Status>(); //TODO: vraie enum à récupérer

                Context.Instance.SynchronisationRunning = false;

                SetPersistantPreference("_lastSyncDate", beginSyncDate.ToString()); //On met en mémoire la date de dernière synchronisation (à faire par table ?)
            }
            catch (Exception e)
            {
                Context.Instance.SynchronisationRunning = false;
            }
        }

        //Retourne un nom de table propre à un modèle, du type (30-1)
        private string getTableName<T>() where T : IModel, new()
        {
            try
            {
                var t = new T();
                if (String.IsNullOrEmpty(t.CustomTableName))
                {
                    if (t is Models.EnumReference)
                    {
                        var lel = t.BasePath.Split(new string[] { "/" }, StringSplitOptions.None);
                        return lel[lel.Length - 1].Replace(',', '-').Replace("(", "").Replace(")", "");
                    }
                    else
                    {
                        var lel = t.BasePath.Split(new string[] { "/" }, StringSplitOptions.None);
                        return lel[lel.Length - 1].Replace(':', '-');
                    }
                }
                else
                {
                    return t.CustomTableName;
                }
            }
            catch (Exception e)
            {
                return null;
            }
        }

        #region Softica
        private async Task<Models.Agence> RetrieveOfficesAndSectorsFromServiceEngineerId(string engineerID, string typeCriteria = "ytech=")
        {
            CheckAuthenticated();
            BetterUri uri = BetterUri.GetUri<Models.Agence>();
            Models.Agence foo = new Models.Agence();
            uri.AddParam(AbasRequests.GetHeadFieldsParam(foo.DefaultHeadFields));
            uri.AddParam($"criteria="+ typeCriteria + engineerID);
            WebRequest request = AbasRequests.PrepareAbasRequest(uri.Uri, _username, _password);
            request.Method = Constants.WEBREQUEST_GET;
            string response = AbasRequests.ReadWebResponse(await AbasRequests.ExecuteRequestAsync(request));

            if (!typeCriteria.Contains("ytech"))
            {
                dynamic j = JsonConvert.DeserializeObject(response);

                if (j.erpDataObjects[0].table == null)
                {
                    throw new NullReferenceException("Response 'head' field is not defined");
                }
            }

            return JsonConvert.DeserializeObject<Models.Agence>(response);

        }

        #endregion
        
        public async Task SyncTable<T>(int pageSize = 3000)
            where T : IModel, new()
        {
            if (!Context.Instance.IsConnected)
            {
                throw new Exception("La synchronisation ne peut pas avoir lieu hors-ligne !");
            }
            var tableName = getTableName<T>();
            LiteDB.LiteCollection<T> collection = db.GetCollection<T>(tableName);

            //TODO: remettre limitation mise à jour
            //String lastSyncString = null;
            String lastSyncString = GetPersistantPreference("_lastSyncDate", null);

            T foo = new T();

            List<FilterField> filterFields = new List<FilterField>();

           
            if (foo is Models.Turnover)
            {
                filterFields.Add(new FilterField() { FieldName = "FY", Operator = ">=", Value = DateTime.Now.AddYears(-1).ToString("yy") });
            }
            if (foo is Models.Product)
            {                    
                if (Constants.VERSION_SOFTICA)
                {
                    filterFields.Add(new FilterField() { FieldName = "ysynccrm", Operator = "==", Value = Boolean.TrueString });
                }
            }
            if (foo is Models.Task)
            {
                filterFields.Add(new FilterField() { FieldName = "status", Operator = "<>", Value = "(Done)" });
            }
           
            

            if (!String.IsNullOrEmpty(lastSyncString))
            {
                //filterFields.Add(new FilterField { FieldName = "version", Operator = ">", Value = DateTimeToVersionn(DateTime.Parse(lastSyncString)) });

            }


            int page = 0;
            while (true)
            {
                List<T> objects = null;
                if (foo is Models.EnumReference)
                {
                    try
                    {
                        objects = await GetEnumAsync<T>();
                    }
                    catch (Exception e)
                    {

                    }
                }
                else
                {
                    //TODO filters for sync
                    objects = await ReadList<T>(null, filterFields, page, pageSize);
                }
                if (objects == null)
                {
                    return;
                };

                if (foo is Models.Turnover)
                {
                    objects.ForEach(o => o.id = (o as Models.Turnover).mainObj + "_" + (o as Models.Turnover).FY);
                }
                try
                {
                    objects.ForEach(o => collection.Upsert(o));
                    //TODO: Enlever la limitation à 5
                    if (objects.Count != pageSize) //|| page == 5
                    {
                        break;
                    }
                    page++;
                }

                catch (IndexOutOfRangeException ex)
                {

                }
                catch (Exception ex)
                {
                    break;
                }
            }

            foreach (string defaultIndex in new T().DefaultIndexes)
            {
                collection.EnsureIndex(defaultIndex);
            }
        }

        public async Task SyncTableOpenItems()
        {
            if (!Context.Instance.IsConnected)
            {
                throw new Exception("La synchronisation ne peut pas avoir lieu hors-ligne !");
            }
            var tableName = getTableName<Models.OpenItemsObject>();
            LiteDB.LiteCollection<Models.OpenItemsObject> collection = db.GetCollection<Models.OpenItemsObject>(tableName);

            foreach (Models.Tiers tiers in ReadListOffline<Models.Customer>(null, null).Result)
            {
                try
                {
                    var openItemObject = await GetOpenItems(tiers.id);

                    if (openItemObject != null)
                    {
                        collection.Upsert(openItemObject);
                    };
                }
                catch (Exception e)
                {

                }
            }

            foreach (string defaultIndex in (new Models.OpenItemsObject()).DefaultIndexes)
            {
                collection.EnsureIndex(defaultIndex);
            }
        }

        public async Task SyncTable<T, U>(int pageSize = 200)
            where T : IModel, new()
            where U : IModel, new()
        {
            if (!Context.Instance.IsConnected)
            {
                throw new Exception("La synchronisation ne peut pas avoir lieu hors-ligne !");
            }
            var tableName = getTableName<T>();
            var coll = db.GetCollection<T>();
            LiteDB.LiteCollection<T> collection = db.GetCollection<T>(tableName);

            T foo = new T();
            var tableNameSubItems = getTableName<U>();
            LiteDB.LiteCollection<U> collectionSubItems = null;
            if (foo.HasSubItems)
            {
                collectionSubItems = db.GetCollection<U>(tableNameSubItems);
            }

            FilterField filterByDate = null;

            //TODO: remettre limitation mise à jour
            //String lastSyncString = null;//GetPersistantPreference("_lastSyncDate", null);
            String lastSyncString = GetPersistantPreference("_lastSyncDate", null);

            if (!String.IsNullOrEmpty(lastSyncString))
            {
                filterByDate = new FilterField { FieldName = "version", Operator = ">", Value = DateTimeToVersionn(ToolsHelper.FormatDate(lastSyncString)) };
            }

            int page = 0;
            while (true)
            {
                //TODO filters for sync
                List<T> objects = await ReadList<T, U>(null, (filterByDate != null ? new List<FilterField> { filterByDate } : null), page, pageSize);
                if (objects == null)
                {
                    return;
                }
                foreach (T o in objects)
                {
                    collection.Upsert(o);
                    if (o.HasSubItems && o.SubItems != null)
                    {
                        o.SubItems.Cast<U>().ToList().ForEach(sub => collectionSubItems.Upsert(sub));
                    }
                }
                try
                {
                    //TODO: Enlever la limitation à 5
                    if (objects.Count != pageSize) //|| page == 5
                    {
                        break;
                    }
                    page++;
                }
                catch (Exception ex)
                {

                }

            }

            foreach (string defaultIndex in new T().DefaultIndexes)
            {
                collection.EnsureIndex(defaultIndex);
            }
        }
    }
}