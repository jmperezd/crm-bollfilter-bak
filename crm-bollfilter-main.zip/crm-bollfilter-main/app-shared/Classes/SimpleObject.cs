﻿using System;
using WFramework_Xamarin.Components;

namespace Abas_Shared_Xamarin
{
    public class SimpleObject : IItemList
    {

        public string Text { get; set; }
        public string Id { get; set; }

        public SimpleObject(string text, string id)
        {
            this.Text = text;
            this.Id = id;
        }
    }
}
