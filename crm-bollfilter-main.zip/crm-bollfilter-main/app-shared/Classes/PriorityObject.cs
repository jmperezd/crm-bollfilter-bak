﻿using System;
using WFramework_Xamarin.Components;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin
{
    public class PriorityObject : IItemList
    {
        
        public string Text { get; set;}
        [ForeignKeyID]
        public string Id { get; set; }

        public PriorityObject(string text, string id)
        {
            this.Text = text;
            this.Id = id;
        }
    }
}
