﻿using System;
namespace Abas_Shared_Xamarin
{
    public enum CompileClientTargets
    {
        SOFTICA,
        NONE
    }
}
