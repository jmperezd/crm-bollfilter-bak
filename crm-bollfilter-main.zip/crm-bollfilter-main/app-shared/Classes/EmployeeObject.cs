﻿using System;
using WFramework_Xamarin.Components;

namespace Abas_Shared_Xamarin
{
    public class EmployeeObject : IItemList
    {

        public string Text { get; set;}
        public string Id { get; set; }

        public EmployeeObject(string text, string id)
        {
            this.Text = text;
            this.Id = id;
        }
    }
}
