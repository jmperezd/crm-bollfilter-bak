﻿using System;
using WFramework_Xamarin.Components;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin
{
    public class CustomerObject : IItemList
    {

        public string Text { get; set;}
        [ForeignKeyID]
        public string Id { get; set; }
        public string Swd { get; set; }

        public CustomerObject(string text, string id)
        {
            this.Text = text;
            this.Id = id;
        }
    }
}
