﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abas_Shared_Xamarin.Classes.Requests
{
    class AbasType
    {
        public string _type { get; set; }
		public string fieldName { get; set; }
		public string value { get; set; }
    }
}
