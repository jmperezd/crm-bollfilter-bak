﻿using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using Newtonsoft.Json;
using LiteDB;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin
{
    public class Model
    {
        [BsonIgnore]
        [JsonIgnore]
        public string DefaultHeadFieldsString { get; set; }

        [BsonIgnore]
        [JsonIgnore]
        public virtual string DefaultTableFieldsString { get; set; }

        [BsonIgnore]
        [JsonIgnore]
        public virtual List<string> DefaultHeadFields
        {
            get
            {
                return new List<string>(this.DefaultHeadFieldsString.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries));
            }
        }

        [BsonIgnore]
        [JsonIgnore]
        public List<string> DefaultTableFields
        {
            get
            {
                return new List<string>(this.DefaultTableFieldsString.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries));
            }
        }

        [BsonIgnore]
        [JsonIgnore]
        public virtual List<string> DefaultIndexes
        {
            get
            {
                return new List<string>() { "id" };
            }
        }

        [BsonIgnore]
        [JsonIgnore]
        public string InfoSysPath
        {
            get
            {
                return null;
            }
        }

        [BsonIgnore]
        [JsonIgnore]
        public string InfoSysMember
        {
            get
            {
                return null;
            }
        }

        [ForeignKeyID]
        public string id { get; set; }

        [JsonIgnore]
        [BsonIgnore]
        public virtual String BasePath
        {
            get
            {
                return string.Empty;
            }
        }

        [JsonIgnore]
        [BsonIgnore]
        public String CustomTableName => null;

        [JsonIgnore]
        [BsonIgnore]
        public List<FilterField> DefaultFilters
        {
            get
            {
                return null;
            }
        }

        [BsonIgnore]
        [JsonIgnore]
        public bool HasSubItems { get { return false; } }

        [BsonIgnore]
        [JsonIgnore]
        public List<object> SubItems { get; set; }
    }
}
