﻿using System;
using System.Collections.Generic;
using System.Text;
using WFramework_Xamarin.Table;
using static Abas_Shared_Xamarin.Services.Utils;

namespace Abas_Shared_Xamarin
{
    public interface IModelEnum
    {
        String Uri { get; }
        String TableFields { get; }

        String InfoSysPath { get; }
        [ForeignKeyID]
        String id { get; set; }
        String CustomTableName { get; }

        string DefaultHeadFieldsString { get; set; }
        string DefaultTableFieldsString { get; set; }
        List<string> DefaultHeadFields { get; }
        List<string> DefaultTableFields { get; }
        List<FilterField> DefaultFilters { get; }
        List<string> DefaultIndexes { get; }
    }
}
