﻿using System;
using Xamarin.Forms;
using System.Globalization;
using Abas_Shared_Xamarin.Classes;

namespace Abas_Shared_Xamarin
{
    public class AppParameters
    {        
        public AppParameters()
        {
        }

        public static string QuotationLayout
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("PRINT_QuotationLayout"))
                {
                    return Application.Current.Properties["PRINT_QuotationLayout"] as string;
                }
                else
                {
                    return "XMASTER";
                }
            }
            set
            {
                Application.Current.Properties["PRINT_QuotationLayout"] = value;
            }
        }

        public static string LimitServiceReservations
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("LIMIT_ServiceReservations"))
                {
                    return Application.Current.Properties["LIMIT_ServiceReservations"] as string;
                }
                else
                {
                    //2 days by default
                    return "2";
                }
            }
            set
            {
                Application.Current.Properties["LIMIT_ServiceReservations"] = value;                
            }
        }

        public static bool? ZipTown
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SHOW_ZipTown"))
                {
                    return Application.Current.Properties["SHOW_ZipTown"] as bool?;
                }
                else
                {                    
                    return true;
                }
            }
            set
            {
                Application.Current.Properties["SHOW_ZipTown"] = value;
            }
        }

        //Will be sorted descendent?
        public static bool? SortEngineerReports
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("SORT_EngineerReports"))
                {
                    return Application.Current.Properties["SORT_EngineerReports"] as bool?;
                }
                else
                {
                    return true;
                }
            }
            set
            {
                Application.Current.Properties["SORT_EngineerReports"] = value;
            }
        }        

        public static string SaleOrderLayout
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("PRINT_SaleOrderLayout"))
                {
                    return Application.Current.Properties["PRINT_SaleOrderLayout"] as string;
                }
                else
                {
                    return "XMASTER";
                }
            }
            set
            {
                Application.Current.Properties["PRINT_SaleOrderLayout"] = value;
            }
        }

        public static string PrintType
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("PRINT_PrintType"))
                {
                    return Application.Current.Properties["PRINT_PrintType"] as string;
                }
                else
                {
                    return "11001";
                }
            }
            set
            {
                Application.Current.Properties["PRINT_PrintType"] = value;
            }
        }

        

    }
}
