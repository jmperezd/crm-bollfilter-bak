﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using Abas_Shared_Xamarin.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;
using Xamarin.Forms;

namespace AppCRM.Services
{
    public static class CRMHelper
    {
        private static IAbasService Service => DependencyService.Get<IAbasService>() ?? new AbasService();

        /// <summary>
        /// Try to look for the Customer with the given id, if doesn't exist look for Prospect with the given id.
        /// </summary>
        /// <param name="id">Cusomer/Prospect id</param>
        /// <returns>Founded Customer or Prospect, null if doesent exist in both tables</returns>
        public static async Task<Tiers> GetCustomerProspect(string id, CustomerTypes CustomersType = CustomerTypes.ALL)
        {
            Tiers retVal;

            try
            {
                if (CustomersType == CustomerTypes.PROSPECT)
                {
                    retVal = await Service.ReadOffline<Prospect>(id);
                }
                else
                {
                    retVal = await Service.ReadOffline<Customer>(id);
                }
            }
            catch (Exception e)
            {
                retVal = await Service.ReadOffline<Prospect>(id);
            }

            return retVal;
        }



        #region LoadDatas
        public static EntityTable LoadDatas<T>(IAbasService service, List<GridField> gridFields, List<FilterField> requiredFilterFields, List<string> fieldsToSearch, int requestedPage, int elementsPerPage, string globalSearchedString = null)
            where T : IModel, new()
        {
            EntityTable entityTable;
            if (string.IsNullOrEmpty(globalSearchedString))
            {
                entityTable = GetUnfilteredData<T>(service, gridFields, requiredFilterFields, requestedPage, elementsPerPage);
            }
            else
            {
                entityTable = GetFilteredData<T>(service, gridFields, requiredFilterFields, fieldsToSearch, requestedPage, elementsPerPage, globalSearchedString.ToLower());
            }

            return entityTable;
        }

        private static EntityTable GetUnfilteredData<T>(IAbasService service, List<GridField> gridFields, List<FilterField> requiredFilterFields, int requestedPage, int elementsPerPage)
            where T : IModel, new()
        {
            EntityTable retVal;
            if (Constants.ONLINEACTIVE)
            {
                retVal = service.ReadTable<T>(gridFields, requiredFilterFields, requestedPage, elementsPerPage).Result;
            }
            else
            {
                retVal = service.ReadTableOffline<T>(gridFields, requiredFilterFields, requestedPage, elementsPerPage).Result;
            }
            return retVal;
        }

        private static EntityTable GetFilteredData<T>(IAbasService service, List<GridField> gridFields, List<FilterField> requiredFilterFields, List<string> fieldsToSearch, int requestedPage, int elementsPerPage, string globalSearchedString)
            where T : IModel, new()
        {
            EntityTable retVal;
            EntityTable currentData;
            Dictionary<string, EntityColumn> columns = new Dictionary<string, EntityColumn>();
            List<EntityRow> distinctRows = new List<EntityRow>();
            List<EntityRow> rows = new List<EntityRow>();
            List<FilterField> searchFilterFields = SetFilterFieldsSearch(fieldsToSearch, globalSearchedString);
            List<FilterField> filterFields;

            foreach (FilterField filterField in searchFilterFields)
            {
                try
                {
                    filterFields = new List<FilterField>();
                    filterFields.Add(filterField);
                    filterFields.AddRange(requiredFilterFields);
                    if (Constants.ONLINEACTIVE)
                    {
                        currentData = service.ReadTable<T>(gridFields, filterFields, requestedPage, elementsPerPage).Result;
                    }
                    else
                    {
                        currentData = service.ReadTableOffline<T>(gridFields, filterFields, requestedPage, elementsPerPage).Result;
                    }
                    if (currentData != null)
                    {
                        columns = currentData.Columns;
                        rows.AddRange(currentData.Rows);
                    }
                }
                catch (Exception ex)
                {
                    continue;
                }
            }

            retVal = RemoveDuplicates(columns, distinctRows, rows);

            return retVal;
        }

        /// <summary>
        /// Remove the duplicates founded in the multiple calls
        /// </summary>
        /// <param name="columns"></param>
        /// <param name="distinctRows"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        private static EntityTable RemoveDuplicates(Dictionary<string, EntityColumn> columns, List<EntityRow> distinctRows, List<EntityRow> rows)
        {
            EntityTable retVal;
            bool exist;
            foreach (EntityRow row in rows)
            {
                exist = distinctRows.Where(x => x.Cells.Values.FirstOrDefault().Value == row.Cells.Values.FirstOrDefault().Value).FirstOrDefault() != null;
                if (!exist)
                {
                    distinctRows.Add(row);
                }
            }

            retVal = new EntityTable(columns, distinctRows);
            return retVal;
        }

        /// <summary>
        /// Return the FilterField list, depending on it have connection or not.
        /// </summary>
        /// <param name="fieldsToSearch">Fields where you want to search</param>
        /// <param name="globalSearchedString"></param>
        /// <returns></returns>
        private static List<FilterField> SetFilterFieldsSearch(List<string> fieldsToSearch, string globalSearchedString)
        {
            List<FilterField> retVal = new List<FilterField>();
            if (!string.IsNullOrEmpty(globalSearchedString))
            {
                if (Context.Instance.IsConnected && Constants.ONLINEACTIVE)
                {
                    // For dates, we replace the "/" for "."
                    globalSearchedString = globalSearchedString.Replace("/", ".");
                    foreach (string field in fieldsToSearch)
                    {
                        retVal.Add(new FilterField() { FieldName = field, Operator = "=", Value = globalSearchedString });
                    }
                }
                else
                {
                    retVal.Add(new FilterField() { FieldName = App.ItemSearch, Operator = "~/", Value = globalSearchedString });
                }
            }

            return retVal;
        }
        #endregion
    }
}
