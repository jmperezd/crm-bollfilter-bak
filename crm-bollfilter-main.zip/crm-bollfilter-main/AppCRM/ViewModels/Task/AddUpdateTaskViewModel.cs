﻿using System;
using Xamarin.Forms;
using Abas_Shared_Xamarin.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using AppCRM.Resx;
using Abas_Shared_Xamarin;
using AppCRM.Services;
using System.Linq;

namespace AppCRM.ViewModels
{
    public class AddUpdateTaskViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }
        public Command LoadEmployeeObjectsCommand { get; set; }
        public Command LoadPriorityObjectsCommand { get; set; }
        public Command LoadStatusObjectsCommand { get; set; }

        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCustomer;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;

        public delegate void OnListObjectsLoadedDelegate();
        public event OnListObjectsLoadedDelegate OnEmployeeObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnPriorityObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnStatusObjectsLoaded;

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;
        public string BusinessPartnerSwd { get; set; }

        private Task task;
        public Task Task
        {
            get
            {
                return task;
            }
            set
            {
                SetProperty(ref task, value);
            }
        }

        private bool showTiersSelection = true;
        public bool ShowTiersSelection
        {
            get { return this.showTiersSelection; }
            set { SetProperty(ref showTiersSelection, value); }
        }

        private ObservableCollection<IItemList> employeeObjects;
        public ObservableCollection<IItemList> EmployeeObjects
        {
            get { return this.employeeObjects; }
            set { SetProperty(ref employeeObjects, value); }
        }

        private ObservableCollection<IItemList> priorityObjects;
        public ObservableCollection<IItemList> PriorityObjects
        {
            get { return this.priorityObjects; }
            set { SetProperty(ref priorityObjects, value); }
        }

        private ObservableCollection<IItemList> statusObjects;
        public ObservableCollection<IItemList> StatusObjects
        {
            get { return this.statusObjects; }
            set { SetProperty(ref statusObjects, value); }
        }

        private EmployeeObject selectedEmployeeObject;
        public EmployeeObject SelectedEmployeeObject
        {
            get
            {
                return this.selectedEmployeeObject;
            }
            set
            {
                this.Task.editor = value.Id;
                SetProperty(ref selectedEmployeeObject, value);
            }
        }

        private EmployeeObject selectedEmployeeConfirmObject;
        public EmployeeObject SelectedEmployeeConfirmObject
        {
            get
            {
                return this.selectedEmployeeConfirmObject;
            }
            set
            {
                this.Task.confirm = value.Id;
                SetProperty(ref selectedEmployeeConfirmObject, value);
            }
        }

        private PriorityObject selectedPriorityObject;
        public PriorityObject SelectedPriorityObject
        {
            get
            {
                return this.selectedPriorityObject;
            }
            set
            {
                this.Task.prio = value.Id;
                SetProperty(ref selectedPriorityObject, value);
            }
        }

        SimpleObject selectedStatusObject;
        public SimpleObject SelectedStatusObject
        {
            get
            {
                return this.selectedStatusObject;
            }
            set
            {
                this.Task.status = value.Id;
                SetProperty(ref selectedStatusObject, value);
            }
        }

        private string confirmName = String.Empty;
        public string ConfirmName
        {
            get { return confirmName; }
            private set { SetProperty(ref confirmName, value); }
        }


        public AddUpdateTaskViewModel(string idObj, Task obj = null, string idTiers = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.LoadEmployeeObjectsCommand = new Command(async () => await ExecuteLoadEmployeesObjects());
            this.LoadPriorityObjectsCommand = new Command(async () => await ExecuteLoadPrioritiesObjects());
            this.LoadStatusObjectsCommand = new Command(async () => await ExecuteLoadStatusesObjects());

            if (obj == null)
            {

                this.Page = AppResources.Tache.ToLower();
                this.Prefix = AppResources.Creer_une;
                this.Task = new Task() { endDate = DateTime.Now, confirm = Context.Instance.CurrentWebUser.RoleEmployee, editor = Context.Instance.CurrentWebUser.RoleEmployee };
            }
            else
            {

                this.Page = AppResources.Tache.ToLower();
                this.Prefix = AppResources.Modifier_une;
                this.Task = obj;
            }
            if (!string.IsNullOrWhiteSpace(idTiers))
            {
                this.Task.businessPartner = idTiers;
                this.ShowTiersSelection = false;
            }

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.ConfirmName = (await this.Service.Read<Employee>(this.Task.confirm)).Descr;
            });

            //Title = "Tâches";
        }

        public void Init()
        {

            System.Threading.Tasks.Task.Run(async () =>
            {
                if (!string.IsNullOrEmpty(this.Task.businessPartner))
                {
                    await this.ExecuteLoadCustomer(this.Task.businessPartner);
                }

                this.LoadEmployeeObjectsCommand.Execute(null);
                this.LoadPriorityObjectsCommand.Execute(null);
                this.LoadStatusObjectsCommand.Execute(null);

                /*
                this.CustomerObjects = new ObservableCollection<IItemList>();
                this.LoadCustomerObjectsCommand = new Command(async () => await ExecuteLoadCustomersObjects(string search));
                this.LoadCustomerObjectsCommand.Execute(null);
                */
            });
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            await System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        if (!string.IsNullOrWhiteSpace(this.Task.id))
                        {
                            //Update
                            var task = System.Threading.Tasks.Task.Run(async () => {
                                try {
                                    await this.Service.Update<Task>(this.Task);
                                    Device.BeginInvokeOnMainThread(() =>
                                    {
                                        DependencyService.Get<IMessage>().LongAlert(AppResources.UpdatedData);
                                    });
                                }
                                catch(Exception e)
                                {
                                    Device.BeginInvokeOnMainThread(() =>
                                    {
                                        DependencyService.Get<IMessage>().LongAlert(AppResources.Error + ": "+e.Message);
                                    });
                                }
                            });
                            task.Wait();
                        }
                        else
                        {
                            //Create
                            this.Task.swd = this.BusinessPartnerSwd;
                            var task = System.Threading.Tasks.Task.Run(async () => {
                                try
                                {
                                    OfflineItems offlineItem = new OfflineItems()
                                    {
                                        Title = "Tasks",
                                        Time = DateTime.Now,
                                        DestinatarioMercancias = this.Task.descrTextModuleOperLang,
                                        SocioComercial = this.Task.descrOperLang,
                                    };                                    
                                    this.Task.offlineInfo = offlineItem;
                                    await this.Service.Create<Task>(this.Task);
                                    Device.BeginInvokeOnMainThread(() =>
                                    {
                                        DependencyService.Get<IMessage>().LongAlert(AppResources.UpdatedData);
                                    });
                                }
                                catch (Exception e)
                                {
                                    Device.BeginInvokeOnMainThread(() =>
                                    {
                                        DependencyService.Get<IMessage>().LongAlert(AppResources.Error + ": " + e.Message);
                                    });
                                }

                            });
                            task.Wait();
                        }
                        
                    }
                    else
                    {
                        this.OnError(AppResources.CustomerEmpty);
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }

        private bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Task.businessPartner);
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadEmployeesObjects()
        {
            this.EmployeeObjects = new ObservableCollection<IItemList>();
            List<Employee> employees = this.Service.ReadList<Employee>().Result;

            EmployeeObject employee;
            foreach (Employee item in employees)
            {
                employee = new EmployeeObject(item.Descr, item.id);
                this.EmployeeObjects.Add(employee);
                if (employee.Id == this.Task.editor)
                {
                    this.SelectedEmployeeObject = employee;
                }

                if (employee.Id == this.Task.confirm)
                {
                    this.SelectedEmployeeConfirmObject = employee;
                }
            }

            if (this.OnEmployeeObjectsLoaded != null)
            {
                this.OnEmployeeObjectsLoaded();
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadPrioritiesObjects()
        {
            this.PriorityObjects = new ObservableCollection<IItemList>();
            List<Priority> priorities = await this.Service.GetEnumAsync<Priority>();

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();
            PriorityObject priority;
           
            foreach (Priority item in priorities)
            {
                priority = new PriorityObject(item.enumDescr != null ? item.enumIdentifier : item.refToEnumElem_descrOperLang, item.enumIdentifierComplete);
                this.PriorityObjects.Add(priority);

                if (priority.Id == this.Task.prio)
                {
                    this.SelectedPriorityObject = priority;
                }
            }

            if (this.OnPriorityObjectsLoaded != null)
            {
                this.OnPriorityObjectsLoaded();
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadStatusesObjects()
        {
            this.StatusObjects = new ObservableCollection<IItemList>();
            //It's not setted on the ERP enums, so, let's do it manually

            List<Status> priorities = new List<Status>()
            {
                new Status() { enumIdentifier = "Entered", enumDescr = AppResources.Entered, refToEnumElem_descrOperLang = AppResources.Entered},
                new Status() { enumIdentifier = "Prioritized", enumDescr = AppResources.Prioritized, refToEnumElem_descrOperLang = AppResources.Prioritized},
                new Status() { enumIdentifier = "Active", enumDescr = AppResources.Active, refToEnumElem_descrOperLang = AppResources.Active},
                new Status() { enumIdentifier = "Done", enumDescr = AppResources.Done, refToEnumElem_descrOperLang = AppResources.Done},
                new Status() { enumIdentifier = "Confirmed", enumDescr = AppResources.Confirmed, refToEnumElem_descrOperLang = AppResources.Confirmed},
                new Status() { enumIdentifier = "Canceled", enumDescr = AppResources.Canceled, refToEnumElem_descrOperLang = AppResources.Canceled},
            };
            
            SimpleObject status;
            foreach (Status item in priorities)
            {
                status = new SimpleObject(item.enumDescr, item.enumIdentifierComplete);
                this.StatusObjects.Add(status);

                if (status.Id == this.Task.status)
                {
                    this.SelectedStatusObject = status;
                }
            }

            if (this.OnStatusObjectsLoaded != null)
            {
                this.OnStatusObjectsLoaded();
            }
            
        }

        async System.Threading.Tasks.Task ExecuteLoadCustomer(string id)
        {
            Tiers tiers = await CRMHelper.GetCustomerProspect(id);

            if (this.OnLoadCustomer != null)
            {
                this.OnLoadCustomer(tiers);
            }
        }


    }
}