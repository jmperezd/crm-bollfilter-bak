﻿using Abas_Shared_Xamarin.Models;
using Xamarin.Forms;
using System;
//using Plugin.LocalNotifications;
using Plugin.Notifications;
using System.Collections.Generic;
using System.Linq;
using AppCRM.Resx;
using Plugin.Calendars;
using Plugin.Calendars.Abstractions;
using Abas_Shared_Xamarin;
using AppCRM.CRMModels;
using AppCRM.Services;

namespace AppCRM.ViewModels
{

    public class TaskViewModel : BaseViewModel
    {
        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command ValidateCommand { get; set; }
        public event EventHandler OnValidate;

        public Command CreateNotificationCommand { get; set; }
        public event EventHandler OnCreateNotification;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;

        private Abas_Shared_Xamarin.Models.Task task;
        public Abas_Shared_Xamarin.Models.Task Task
        {
            get { return task; }
            set { SetProperty(ref task, value); }
        }

        private string confirmName = String.Empty;
        public string ConfirmName
        {
            get { return confirmName; }
            private set { SetProperty(ref confirmName, value); }
        }

        private string editorName = String.Empty;
        public string EditorName
        {
            get { return editorName; }
            private set { SetProperty(ref editorName, value); }
        }

        string statusName = String.Empty;
        public string StatusName
        {
            get { return statusName; }
            private set { SetProperty(ref statusName, value); }
        }

        private string businessPartnerName = String.Empty;
        public string BusinessPartnerName
        {
            get { return businessPartnerName; }
            private set { SetProperty(ref businessPartnerName, value); }
        }

        //HACK: validateButton is invisible for the moment
        public bool IsValidateButtonVisible
        {
            get
            {
                //bool retVal = false;
                //if (Device.RuntimePlatform != Device.Android)
                //{ 
                //    if (this.Task != null && base.ShowAddEditButton)
                //    {
                //        if (this.Task.status == CRMConstants.TaskStatus.ENTERED && (this.Task.editor == Context.Instance.CurrentWebUser.RoleEmployee || this.Task.confirm == Context.Instance.CurrentWebUser.RoleEmployee))
                //        {
                //            retVal = true;
                //        }
                //        else
                //        {
                //            retVal = false;
                //        }
                //    }
                //}

                return false;
            }
        }

        bool isReminderButtonVisible = true;
        public bool IsReminderButtonVisible
        {
            get
            {
                if (Device.RuntimePlatform == Device.Android)
                {
                    SetProperty(ref isReminderButtonVisible, false);
                }
                else
                {
                    if (this.Task != null && base.ShowAddEditButton)
                    {
                        if (this.Task.endDate > DateTime.Now)
                        {
                            SetProperty(ref isReminderButtonVisible, true);
                        }
                        else
                        {
                            SetProperty(ref isReminderButtonVisible, false);
                        }
                    }
                    else
                    {
                        SetProperty(ref isReminderButtonVisible, false);
                    }
                }

                return isReminderButtonVisible;
            }
        }


        private string reminderText = AppResources.Rappel.ToUpper();
        public string ReminderText
        {
            get { return reminderText; }
            private set { SetProperty(ref reminderText, value); }
        }

        public string ValidateText
        {
            get
            {
                if (this.Task != null)
                {

                    if (this.Task.status == "(Entered)")
                    {
                        if (this.Task.confirm == Context.Instance.CurrentWebUser.RoleEmployee)
                        {
                            return AppResources.Valider.ToUpper();
                        }
                        else
                        {
                            return AppResources.Terminer.ToUpper();
                        }
                    }
                    else if (this.Task.status == "(Done)")
                    {
                        if (this.Task.confirm == Context.Instance.CurrentWebUser.RoleEmployee)
                        {
                            return AppResources.Valider.ToUpper();
                        }
                        else if (this.Task.editor == Context.Instance.CurrentWebUser.RoleEmployee)
                        {
                            return AppResources.Terminee.ToUpper();
                        }
                    }
                }
                return string.Empty;
            }
        }

        private string TaskId { get; set; }

        public TaskViewModel(string id)
        {
            this.TaskId = id;
            this.EditCommand = new Command(async () => await ExecuteEditCommand());
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CreateNotificationCommand = new Command(async () => await ExecuteCreateNotificationCommand());

            var task = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
            task.Wait();
        }

        public async System.Threading.Tasks.Task Refresh()
        {
            this.Task = await this.Service.Read<CRMTask>(this.TaskId);
            this.Prefix = AppResources.Tache;
            this.Page = this.task.idno;
            OnPropertyChanged("ValidateText");
            OnPropertyChanged("IsValidateButtonVisible");
            OnPropertyChanged("IsReminderButtonVisible");

            this.StatusName = TransalateStatusToView(this.Task.status);
            //this.SetCurrentReminderText();

            await System.Threading.Tasks.Task.Run(async () =>
            {
                Tiers customer = await CRMHelper.GetCustomerProspect(this.Task.businessPartner);

                this.BusinessPartnerName = customer?.descrOperLang;
            });

            await System.Threading.Tasks.Task.Run(async () =>
            {
                this.ConfirmName = ((Employee)await this.Service.Read<Employee>(this.Task.confirm)).Descr;
            });

            await System.Threading.Tasks.Task.Run(async () =>
            {
                this.EditorName = ((Employee)await this.Service.Read<Employee>(this.Task.editor)).Descr;
            });
        }

        private string TransalateStatusToView(string status)
        {
            string retVal = string.Empty;
            switch (status)
            {
                case CRMConstants.TaskStatus.ACTIVE: { retVal = AppResources.Active; break; }
                case CRMConstants.TaskStatus.CANCELED: { retVal = AppResources.Canceled; break; }
                case CRMConstants.TaskStatus.CONFIRMED: { retVal = AppResources.Confirmed; break; }
                case CRMConstants.TaskStatus.ENTERED: { retVal = AppResources.Entered; break; }
                case CRMConstants.TaskStatus.DONE: { retVal = AppResources.Done; break; }
                case CRMConstants.TaskStatus.PRIORITIZED: { retVal = AppResources.Prioritized; break; }
            }
            return retVal;
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (IsBusy)
                return;
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }


        //Si l'utilisateur est l'opérateur (confirm), passe en done
        //Si l'utilisateur est le responsable (editor) (PRIORITAIRE)
        //Alors mise à jour du champs editor avec l'utilisateur du WS 
        //Et mise à jour à (confirmed) en même temps
        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            await System.Threading.Tasks.Task.Run(() =>
             {
                 string currentStatus = this.Task.status;
                 try
                 {
                     if (this.Task.status == CRMConstants.TaskStatus.ENTERED &&
                        (this.Task.editor == Context.Instance.CurrentWebUser.RoleEmployee || this.Task.confirm == Context.Instance.CurrentWebUser.RoleEmployee))
                     {
                         this.Task.status = CRMConstants.TaskStatus.DONE;
                         var taskMaj = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Task>(this.Task); });
                         taskMaj.Wait();
                     }

                     if (this.OnBusy != null)
                     {
                         this.OnBusy(false);
                     }

                     if (this.OnValidate != null)
                     {
                         this.OnValidate(this, null);
                     }
                 }
                 catch (Exception e)
                 {
                     this.Task.status = currentStatus;
                     if (this.OnBusy != null)
                     {
                         this.OnBusy(false);
                     }
                 }
             });
        }

        private bool addReminderRunning = false;
        async System.Threading.Tasks.Task ExecuteCreateNotificationCommand()
        {
            if (!this.addReminderRunning)
            {
                this.addReminderRunning = true;
                if (this.OnBusy != null)
                {
                    this.OnBusy(true);
                }

                await System.Threading.Tasks.Task.Run(async () =>
                {
                    try
                    {
                        var calendars = await CrossCalendars.Current.GetCalendarsAsync();

                        if (calendars.Count >= 1)
                        {
                            var selectedCalendar = calendars.First(c => c.CanEditEvents);

                            if (selectedCalendar != null)
                            {
                                // ...figure out which calendar to use, e.g. by prompting the user and considering the CanEditEvents property...

                                var calendarEvent = new CalendarEvent
                                {
                                    Name = "abas CRM - " + this.Task.descrOperLang + (!string.IsNullOrWhiteSpace(this.Task.descrTextModuleOperLang) ? " - " + this.Task.descrTextModuleOperLang : string.Empty),
                                    Start = this.Task.endDate.AddHours(12),
                                    End = this.Task.endDate.AddHours(12).AddMinutes(30),
                                    Reminders = new List<CalendarEventReminder> { new CalendarEventReminder() { TimeBefore = new TimeSpan(-8, 0, 0) } },
                                    AllDay = true
                                };


                                await CrossCalendars.Current.AddOrUpdateEventAsync(selectedCalendar, calendarEvent);

                                /*
                                Notification notification = await this.GetCurrentTaskNotification();
                                int reference = this.GetTaskReference();
                                if (notification == null)
                                {
                                    */
                                //await CrossNotifications.Current.Send(new Notification() { Title = "Tâche à traiter", Message = "Tâche: " + this.Task.descrOperLang + "\r\n" + "Description: " + this.Task.descrTextModuleOperLang, Vibrate = true, Date = this.Task.endDate });// Id = reference, Vibrate = true, Date = this.Task.endDate });//, When = TimeSpan.FromSeconds(5) });//, Date = Task.endDate });
                                await CrossNotifications.Current.Send(new Notification() { Title = AppResources.RappelCreeTitle, Message = AppResources.RappelCree, When = TimeSpan.FromSeconds(1) });
                            }
                            else
                            {
                                await CrossNotifications.Current.Send(new Notification() { Title = AppResources.RappelNonAjouteTitle, Message = AppResources.RappelNonAjoute, When = TimeSpan.FromSeconds(1) });
                            }
                        }

                        this.addReminderRunning = false;
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    }
                    catch (Exception e)
                    {
                        this.addReminderRunning = false;
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    }
                });
            }
            //var list = await CrossNotifications.Current.GetScheduledNotifications();
            /*
            }
            else
            {
                await CrossNotifications.Current.Cancel(notification.Id.Value);
            }

            OnPropertyChanged("ReminderText");
            */
        }

        /*
        private async System.Threading.Tasks.Task<Notification> GetCurrentTaskNotification()
        {
            if (this.Task != null)
            {
                var list = await CrossNotifications.Current.GetScheduledNotifications();
                Notification notification = list.FirstOrDefault(x => x.Id == 1);//this.GetTaskReference());
                return notification;
            }
            else
            {
                return null;
            }
        }

        private async System.Threading.Tasks.Task SetCurrentReminderText()
        {
            Notification notification = await this.GetCurrentTaskNotification();
            if (notification != null)
            {
                this.ReminderText = "Annuler".ToUpper();
            }
            else
            {
                this.ReminderText = "Rappel".ToUpper();
            }

        }
        */

        private int GetTaskReference()
        {
            int reference = -1;
            if (this.Task != null)
            {
                if (!int.TryParse(this.Task.id.Replace("(", "").Replace(")", "").Replace(",", ""), out reference))
                {
                    reference = 999;
                }
            }
            return reference;
        }
    }
}
