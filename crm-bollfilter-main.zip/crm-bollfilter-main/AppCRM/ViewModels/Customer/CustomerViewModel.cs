﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Xamarin.Forms;
using System;
using AppCRM.Resx;
using WFramework_Xamarin.Components;
using AppCRM.Services;

namespace AppCRM.ViewModels
{

    public class CustomerViewModel : BaseViewModel
    {
        public string CustomerId { get; private set; }

        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command NewObjectCommand { get; set; }
        public event EventHandler OnNewObject;

        public Command ShowTurnoverCommand { get; set; }
        public event EventHandler OnShowTurnover;

        public Command ShowContactsCommand { get; set; }
        public event EventHandler OnShowContacts;

        private Customer customer;
        public Customer Customer
        {
            get { return customer; }
            set
            {
                SetProperty(ref customer, value);
                this.OnPropertyChanged("DisplayAddress");
                this.OnPropertyChanged("DisplayAddress2");
            }
        }

        private ActivityObject activity;
        public ActivityObject Activity
        {
            get { return activity; }
            set
            {
                SetProperty(ref activity, value);
            }
        }

        string repName = String.Empty;
        public string RepName
        {
            get { return repName; }
            private set { SetProperty(ref repName, value); }
        }

        string inhouseContactName = String.Empty;
        public string InhouseContactName
        {
            get { return inhouseContactName; }
            private set { SetProperty(ref inhouseContactName, value); }
        }

        public bool DisplayAddress
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Customer.addr);
            }
        }

        public bool DisplayAddress2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Customer.addr2);
            }
        }

        public bool DisplayCharacteristic2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristicIdentifier2);
            }
        }
        public bool DisplayCharacteristic3
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristicIdentifier3);
            }
        }
        public bool DisplayCharacteristic4
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic4);
            }
        }
        public bool DisplayCharacteristic5
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic5);
            }
        }
        public bool DisplayCharacteristic6
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Customer.characteristic6);
            }
        }

        public CustomerViewModel(string id)
        {
            this.CustomerId = id;

            var task = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
            task.Wait();
        }

        public async System.Threading.Tasks.Task Refresh()
        {
            this.Customer = await this.Service.ReadOffline<Customer>(this.CustomerId);
            this.Prefix = AppResources.Client;
            this.Page = string.IsNullOrEmpty(this.Customer.descrOperLang)? this.Customer.swd : this.Customer.descrOperLang;
            this.ShowTurnoverCommand = new Command(async () => await ExecuteShowTurnoverCommand());
            this.ShowContactsCommand = new Command(async () => await ExecuteShowContactsCommand());
            this.NewObjectCommand = new Command(async () => await ExecuteNewObjectCommand());
            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            await System.Threading.Tasks.Task.Run(async () =>
            {
                this.Activity = await this.Service.GetActivity(this.CustomerId);
            });

            await System.Threading.Tasks.Task.Run(async () =>
            {
                string employeeDescr = string.Empty;
                if (!string.IsNullOrEmpty(this.Customer.inhouseContact))
                {
                    Employee employee = await this.Service.Read<Employee>(this.Customer.inhouseContact);
                    employeeDescr = employee.Descr;
                }
                this.InhouseContactName = employeeDescr;
            });

            await System.Threading.Tasks.Task.Run(async () =>
            {
                string repName = string.Empty;
                if (!string.IsNullOrEmpty(this.Customer.rep))
                {
                    Tiers tiers = await CRMHelper.GetCustomerProspect(this.Customer.rep);
                    repName = tiers?.descrOperLang;
                }
                this.RepName = repName;
            });
        }

        async System.Threading.Tasks.Task ExecuteShowTurnoverCommand()
        {
            if (IsBusy)
                return;
            if (this.OnShowTurnover != null)
            {
                this.OnShowTurnover(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteShowContactsCommand()
        {
            if (IsBusy)
                return;
            if (this.OnShowContacts != null)
            {
                this.OnShowContacts(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }
    }
}
