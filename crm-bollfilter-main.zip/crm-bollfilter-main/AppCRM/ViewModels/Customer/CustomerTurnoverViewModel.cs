﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using System;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using AppCRM.Resx;
using System.Globalization;
using System.Linq;

namespace AppCRM.ViewModels
{
    
    public class CustomerTurnoverViewModel : BaseViewModel
    {

        public Command ShowPreviousCACommand { get; set; }
        public Command ShowNextCACommand { get; set; }

        public delegate void OnLoadDatasDelegate();
        public event OnLoadDatasDelegate OnLoadDatas;
        public event OnLoadDatasDelegate OnLoadOpenItemsDatas;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public event OnBusyDelegate OnBusyOpenItems;


        private bool isTurnoversVisible = false;
        public bool IsTurnoversVisible
        {
            get { return this.isTurnoversVisible; }
            set { SetProperty(ref isTurnoversVisible, value); }
        }

        private List<CAChartItem> turnovers;
        public List<CAChartItem> Turnovers
        {
            get { return this.turnovers; }
            set { SetProperty(ref turnovers, value); }
        }

        private double closingBalTurnover;
        public double ClosingBalTurnover
        {
            get { return this.closingBalTurnover; }
            set
            {
                SetProperty(ref closingBalTurnover, value);
                OnPropertyChanged("ClosingBalTurnoverDisplay");
            }
        }
        public string ClosingBalTurnoverDisplay
        {
            get { return DisplayTools.FormatAmount(this.ClosingBalTurnover, ""); }
        }

        private bool isTurnoversMinusVisible = false;
        public bool IsTurnoversMinusVisible
        {
            get { return this.isTurnoversMinusVisible; }
            set { SetProperty(ref isTurnoversMinusVisible, value); }
        }

        private List<CAChartItem> turnoversMinus;
        public List<CAChartItem> TurnoversMinus
        {
            get { return this.turnoversMinus; }
            set { SetProperty(ref turnoversMinus, value); }
        }

        private double closingBalTurnoverMinus;
        public double ClosingBalTurnoverMinus
        {
            get { return this.closingBalTurnoverMinus; }
            set
            {
                SetProperty(ref closingBalTurnoverMinus, value);
                OnPropertyChanged("ClosingBalTurnoverMinusDisplay");
            }
        }
        public string ClosingBalTurnoverMinusDisplay
        {
            get { return DisplayTools.FormatAmount(this.ClosingBalTurnoverMinus, ""); }
        }

        private List<OpenItemChartItem> entriesBar;
        public List<OpenItemChartItem> EntriesBar
        {
            get { return this.entriesBar; }
            set { SetProperty(ref entriesBar, value); }
        }

        private double total;
        public double Total
        {
            get { return total; }
            set
            {
                SetProperty(ref total, value);
                this.OnPropertyChanged("DisplayTotal");
            }
        }

        public string DisplayTotal
        {
            get { return DisplayTools.FormatAmount(this.Total, ""); }
        }

        private double totalUntilNow;
        public double TotalUntilNow
        {
            get { return totalUntilNow; }
            set
            {
                SetProperty(ref totalUntilNow, value);
                this.OnPropertyChanged("DisplayTotalUntilNow");
            }
        }

        public string DisplayTotalUntilNow
        {
            get { return DisplayTools.FormatAmount(this.TotalUntilNow, ""); }
        }

        private DateTime currentCADatetime = DateTime.Now;
        private DateTime CurrentCADatetime
        {
            get
            {
                return this.currentCADatetime;
            }
            set
            {
                SetProperty(ref currentCADatetime, value);
                this.OnPropertyChanged("CurrentCAYear");
                this.OnPropertyChanged("PreviousCAYear");
            }
        }
        public string CurrentCAYear
        {
            get
            {
                return AppResources.Exercice + " " + this.CurrentCADatetime.ToString("yyyy");
            }
        }
        public string PreviousCAYear
        {
            get
            {
                return AppResources.Exercice + " " + this.CurrentCADatetime.AddYears(-1).ToString("yyyy");
            }
        }
        private string CustomerId { get; set; }


        public CustomerTurnoverViewModel(string id)
        {
            this.Prefix = "";
            this.Page = AppResources.Indicateurs;

            this.CustomerId = id;

            this.ShowNextCACommand = new Command(async () => await ExecuteShowNextCACommand());
            this.ShowPreviousCACommand = new Command(async () => await ExecuteShowPreviousCACommand());

        }


        async System.Threading.Tasks.Task ExecuteShowNextCACommand()
        {
            this.LoadCA(this.CurrentCADatetime.AddYears(1));
        }

        async System.Threading.Tasks.Task ExecuteShowPreviousCACommand()
        {
            this.LoadCA(this.CurrentCADatetime.AddYears(-1));
        }

        public void Init()
        {
            this.LoadCA(this.CurrentCADatetime);
            this.LoadOpenItems();
        }

        private Dictionary<string, Turnover> DicoTurnovers { get; set; } = new Dictionary<string, Turnover>();

        public async System.Threading.Tasks.Task LoadCA(DateTime date)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                if (this.OnBusy != null)
                {
                    this.OnBusy(true);
                }
            });

            this.CurrentCADatetime = date;

            List<FilterField> filterFields = new List<FilterField>();
            filterFields.Add(new FilterField() { FieldName = "mainObj", Operator = "==", Value = this.CustomerId });
            filterFields.Add(new FilterField() { FieldName = "FY", Operator = "==", Value = this.CurrentCADatetime.ToString("yy") });

            try
            {
                if (!this.DicoTurnovers.ContainsKey(this.CurrentCADatetime.ToString("yy")))
                {
                    var res = await this.Service.ReadList<Turnover>(null, filterFields, 0, 0);
                    this.DicoTurnovers.Add(this.CurrentCADatetime.ToString("yy"), res.First());
                }
                Turnover turnover = this.DicoTurnovers[this.CurrentCADatetime.ToString("yy")];
                this.Turnovers = new List<CAChartItem>();
                this.Turnovers.Add(new CAChartItem() { Month = "1", Label = new DateTime(2010, 1, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month1 });
                this.Turnovers.Add(new CAChartItem() { Month = "2", Label = new DateTime(2010, 2, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month2 });
                this.Turnovers.Add(new CAChartItem() { Month = "3", Label = new DateTime(2010, 3, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month3 });
                this.Turnovers.Add(new CAChartItem() { Month = "4", Label = new DateTime(2010, 4, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month4 });
                this.Turnovers.Add(new CAChartItem() { Month = "5", Label = new DateTime(2010, 5, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month5 });
                this.Turnovers.Add(new CAChartItem() { Month = "6", Label = new DateTime(2010, 6, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month6 });
                this.Turnovers.Add(new CAChartItem() { Month = "7", Label = new DateTime(2010, 7, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month7 });
                this.Turnovers.Add(new CAChartItem() { Month = "8", Label = new DateTime(2010, 8, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month8 });
                this.Turnovers.Add(new CAChartItem() { Month = "9", Label = new DateTime(2010, 9, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month9 });
                this.Turnovers.Add(new CAChartItem() { Month = "10", Label = new DateTime(2010, 10, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month10 });
                this.Turnovers.Add(new CAChartItem() { Month = "11", Label = new DateTime(2010, 11, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month11 });
                this.Turnovers.Add(new CAChartItem() { Month = "12", Label = new DateTime(2010, 12, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month12 });
                this.ClosingBalTurnover = turnover.closingBalTurnover;
                this.IsTurnoversVisible = true;
            }
            catch(Exception e)
            {
                this.IsTurnoversVisible = false;
            }


            filterFields = new List<FilterField>();
            filterFields.Add(new FilterField() { FieldName = "mainObj", Operator = "==", Value = this.CustomerId });
            filterFields.Add(new FilterField() { FieldName = "FY", Operator = "==", Value = this.CurrentCADatetime.AddYears(-1).ToString("yy") });

            try
            {
                if (!this.DicoTurnovers.ContainsKey(this.CurrentCADatetime.AddYears(-1).ToString("yy")))
                {
                    var res = await this.Service.ReadList<Turnover>(null, filterFields, 0, 0);
                    this.DicoTurnovers.Add(this.CurrentCADatetime.AddYears(-1).ToString("yy"), res.First());
                }
                Turnover turnover = this.DicoTurnovers[this.CurrentCADatetime.AddYears(-1).ToString("yy")];
                this.TurnoversMinus = new List<CAChartItem>();
                this.TurnoversMinus.Add(new CAChartItem() { Month = "1", Label = new DateTime(2010, 1, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month1 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "2", Label = new DateTime(2010, 2, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month2 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "3", Label = new DateTime(2010, 3, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month3 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "4", Label = new DateTime(2010, 4, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month4 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "5", Label = new DateTime(2010, 5, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month5 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "6", Label = new DateTime(2010, 6, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month6 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "7", Label = new DateTime(2010, 7, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month7 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "8", Label = new DateTime(2010, 8, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month8 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "9", Label = new DateTime(2010, 9, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month9 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "10", Label = new DateTime(2010, 10, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month10 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "11", Label = new DateTime(2010, 11, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month11 });
                this.TurnoversMinus.Add(new CAChartItem() { Month = "12", Label = new DateTime(2010, 12, 1).ToString("MMMM", CultureInfo.CurrentCulture), Value = turnover.month12 });
                this.ClosingBalTurnoverMinus = turnover.closingBalTurnover;
                this.IsTurnoversMinusVisible = true;
            }
            catch (Exception e)
            {
                this.IsTurnoversMinusVisible = false;
            }

            if (this.OnLoadDatas != null)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.OnLoadDatas();
                    if (this.OnBusy != null)
                    {
                        this.OnBusy(false);
                    }
                });
            }

        }

        public async System.Threading.Tasks.Task LoadOpenItems()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                if (this.OnBusyOpenItems != null)
                {
                    this.OnBusyOpenItems(true);
                }
            });

            try
            {
                OpenItemsObject openItemsObject = await this.Service.GetOpenItems(this.CustomerId);



                this.EntriesBar = new List<OpenItemChartItem>();
                this.EntriesBar.Add(new OpenItemChartItem() { Label = ">90", Value = openItemsObject.echu90, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echu90, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = "90-61", Value = openItemsObject.echu61_90, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echu61_90, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = "60-31", Value = openItemsObject.echu31_60, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echu31_60, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = "30-1", Value = openItemsObject.echu1_30, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echu1_30, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = "0-29", Value = openItemsObject.echeance0_29, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echeance0_29, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = "30-59", Value = openItemsObject.echeance30_59, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echeance30_59, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = "60-89", Value = openItemsObject.echeance60_89, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echeance60_89, "00", "K€") });
                this.EntriesBar.Add(new OpenItemChartItem() { Label = ">89", Value = openItemsObject.echeance89, ValueLabel = DisplayTools.FormatAmount(openItemsObject.echeance89, "00", "K€") });

                this.Total = openItemsObject.total;
                this.TotalUntilNow = openItemsObject.totalUntilNow;

            }
            catch (Exception e)
            {
                
            }



            if (this.OnLoadOpenItemsDatas != null)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.OnLoadOpenItemsDatas();
                    if (this.OnBusyOpenItems != null)
                    {
                        this.OnBusyOpenItems(false);
                    }
                });
            }

        }


        //DisplayTools.FormatAmount
    }
}
