﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.Resx;
using AppCRM.Services;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using Xamarin.Forms;

namespace AppCRM.ViewModels
{

    public class CustomersViewModel : BaseViewModel, ITableViewModel
    {
        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public string IdClient { get; private set; }
        public CustomersPageDisplayTypes CustomersPageDisplayTypes { get; private set; } = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;
        public Command DisplayMap { get; set; }
        public event EventHandler OnDisplayMap;

        public delegate void DialogEventHandler(string title, string msg);
        public event DialogEventHandler DialogEvent;

        public bool ShowNewObjectButton
        {
            get
            {
                return this.LastShowedCustomerTab == CustomerTypes.PROSPECT ? true : false;
                //bool retVal = false;
                //if (base.ShowAddEditButton)
                //{
                //    switch (this.LastShowedCustomerTab)
                //    {
                //        case CustomerTypes.PROSPECT:
                //            retVal = true;
                //            break;
                //        case CustomerTypes.CUSTOMER:
                //        default:
                //            retVal = false;
                //            break;
                //    }
                //}
                //return retVal;
                
            }
        }

        private CustomerTypes lastShowedCustomerTab = CustomerTypes.CUSTOMER;
        public CustomerTypes LastShowedCustomerTab
        {
            get
            {
                return this.lastShowedCustomerTab;
            }
            set
            {
                SetProperty(ref lastShowedCustomerTab, value);

            }
        }

        public CustomersViewModel(string idClient = null, CustomersPageDisplayTypes customersPageDisplayTypes = CustomersPageDisplayTypes.CUSTOMER_PROSPECT)
        {
            this.IdClient = idClient;
            this.CustomersPageDisplayTypes = customersPageDisplayTypes;

            switch (this.CustomersPageDisplayTypes)
            {
                case CustomersPageDisplayTypes.CUSTOMER:
                    this.Page = AppResources.Clients;
                    break;
                case CustomersPageDisplayTypes.PROSPECT:
                    this.Page = AppResources.Prospects;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    this.Page = AppResources.Clients_et_prospects;
                    break;
            }
            this.Prefix = string.Empty;

            this.DisplayMap = new Command(ExecuteDisplayMapCommand);
            this.NewObject = new Command(ExecuteNewObjectCommand);

            this.InitGridFields();
        }

        public void Init()
        {
            this.OnPropertyChanged("ShowNewObjectButton");
        }

        private void ExecuteDisplayMapCommand()
        {
            if (this.OnDisplayMap != null)
            {
                this.OnDisplayMap(this, null);
            }
        }

        private List<string> ListGridFields = new List<string> { "id", "idno", "swd", "grpNo", "descrOperLang" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "idno", "swd", "grpNo", "descrOperLang" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;

        public bool LazyLoading { get; set; } = true;

        public int NbElementsPerPage { get; set; }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdClient))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }


            foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "idno")
                {
                    gridField.Order = GridField.SortOrder.Asc;
                }
                if (gridField.FieldName == "descrOperLang")
                {
                    gridField.DisplayedName = AppResources.Designation;
                }
            }
        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            EntityTable entityTable = null;

            switch (this.LastShowedCustomerTab)
            {
                case CustomerTypes.CUSTOMER:

                    entityTable = CRMHelper.LoadDatas<Customer>(Service, GridFields, SetRequiredFilterFields(), ListGridFields, requestedPage, NbElementsPerPage, globalSearchedString);
                    break;
                case CustomerTypes.PROSPECT:
                    entityTable = CRMHelper.LoadDatas<Prospect>(Service, GridFields, SetRequiredFilterFields(), ListGridFields, requestedPage, NbElementsPerPage, globalSearchedString);
                    break;
            }

            return entityTable;
        }

        private List<FilterField> SetRequiredFilterFields()
        {
            List<FilterField> retVal = new List<FilterField>();

            if (string.IsNullOrWhiteSpace(Context.CurrentWebUser.RoleSalesTeamLeader))
            {
                if (string.IsNullOrWhiteSpace(this.IdClient))
                {
                    retVal.Add(new FilterField() { FieldName = "rep", Operator = "==", Value = Context.Instance.CurrentWebUser.RoleSalesRep });
                }
                else
                {
                    retVal.Add(new FilterField() { FieldName = "companyARAP", Operator = "==", Value = this.IdClient });
                }
            }

            return retVal;
        }

        public String GetTiersType(TableTools tools, String id)
        {
            for (int i = 0; i <= tools.CurrentPage; i++)
            {
                var res = tools.DicoTables[i].Rows.Find(r => r.Cells["id"].Value == id);
                if (res != null)
                {
                    return res.Cells["grpNo"].Value;
                }
            }
            return null;
        }

        public String GetTiersTypeMobile(TableToolsMobile tools, String id)
        {
            for (int i = 0; i <= tools.CurrentPage; i++)
            {
                var res = tools.DicoTables[i].Rows.Find(r => r.Cells["id"].Value == id);
                if (res != null)
                {
                    return res.Cells["grpNo"].Value;
                }
            }
            return null;
        }

        private void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }
    }
}
