﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Xamarin.Forms;
using System;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class ProspectViewModel : BaseViewModel
    {
        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command NewObjectCommand { get; set; }
        public event EventHandler OnNewObject;

        public Command ShowContactsCommand { get; set; }
        public event EventHandler OnShowContacts;

        public string IdProspect { get; private set; }

        private Prospect prospect;
        public Prospect Prospect
        {
            get { return prospect; }
            set
            {
                SetProperty(ref prospect, value);
                this.OnPropertyChanged("DisplayAddress");
                this.OnPropertyChanged("DisplayAddress2");
            }
        }

        private ActivityObject activity;
        public ActivityObject Activity
        {
            get { return activity; }
            set
            {
                SetProperty(ref activity, value);
            }
        }

        string repName = String.Empty;
        public string RepName
        {
            get { return repName; }
            private set { SetProperty(ref repName, value); }
        }

        string inhouseContactName = String.Empty;
        public string InhouseContactName
        {
            get { return inhouseContactName; }
            private set { SetProperty(ref inhouseContactName, value); }
        }

        public bool DisplayAddress
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Prospect.addr);
            }
        }

        public bool DisplayAddress2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Prospect.addr2);
            }
        }

        public bool DisplayCharacteristic2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Prospect.characteristicIdentifier2);
            }
        }
        public bool DisplayCharacteristic3
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Prospect.characteristicIdentifier3);
            }
        }
        public bool DisplayCharacteristic4
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Prospect.characteristic4);
            }
        }
        public bool DisplayCharacteristic5
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Prospect.characteristic5);
            }
        }
        public bool DisplayCharacteristic6
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this?.Prospect.characteristic6);
            }
        }

        public ProspectViewModel(string id)
        {
            this.IdProspect = id;

            this.ShowContactsCommand = new Command(async () => await ExecuteShowContactsCommand());
            this.NewObjectCommand = new Command(async () => await ExecuteNewObjectCommand());
            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            var task = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
            task.Wait();
        }


        public async System.Threading.Tasks.Task Refresh()
        {
            this.Prospect = await this.Service.ReadOffline<Prospect>(this.IdProspect);
            this.Prefix = AppResources.Prospect;
            this.Page = this.prospect.descrOperLang;

            await System.Threading.Tasks.Task.Run(async () =>
            {
                this.Activity = await this.Service.GetActivity(this.IdProspect);
            });
        }


        async System.Threading.Tasks.Task ExecuteShowContactsCommand()
        {
            if (IsBusy)
                return;
            if (this.OnShowContacts != null)
            {
                this.OnShowContacts(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }


    }
}
