﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.Resx;
using AppCRM.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using Xamarin.Forms;

namespace AppCRM.ViewModels
{
    public class AddUpdateCustomerViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;
        public delegate void DialogEventHandler(string title, string msg);
        public event DialogEventHandler DialogEvent;


        public delegate void OnListObjectsLoadedDelegate();
        public event OnListObjectsLoadedDelegate OnEmployeeObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnCustomerObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnCharacteristicObjectsLoaded;

        public delegate void OnLoadContactDelegate(Tiers tiers);
        public event OnLoadContactDelegate OnLoadContact;

        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCompany;

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        public CustomerTypes CustomersType { get; private set; }

        private Tiers tiers;
        public Tiers Tiers
        {
            get
            {
                return tiers;
            }
            set
            {
                SetProperty(ref tiers, value);
            }
        }

        private ObservableCollection<IItemList> customerObjects;
        public ObservableCollection<IItemList> CustomerObjects
        {
            get { return this.customerObjects; }
            set { SetProperty(ref customerObjects, value); }
        }

        private CustomerObject selectedCustomerObject;
        public CustomerObject SelectedCustomerObject
        {
            get
            {
                return this.selectedCustomerObject;
            }
            set
            {
                this.Tiers.rep = value.Id;
                SetProperty(ref selectedCustomerObject, value);
            }
        }

        private ObservableCollection<IItemList> employeeObjects;
        public ObservableCollection<IItemList> EmployeeObjects
        {
            get { return this.employeeObjects; }
            set { SetProperty(ref employeeObjects, value); }
        }

        private EmployeeObject selectedEmployeeObject;
        public EmployeeObject SelectedEmployeeObject
        {
            get
            {
                return this.selectedEmployeeObject;
            }
            set
            {
                this.Tiers.rep = value.Id;
                SetProperty(ref selectedEmployeeObject, value);
            }
        }

        private EmployeeObject selectedInhouseContactObject;
        public EmployeeObject SelectedInhouseContactObject
        {
            get
            {
                return this.selectedInhouseContactObject;
            }
            set
            {
                this.Tiers.inhouseContact = value.Id;
                SetProperty(ref selectedInhouseContactObject, value);
            }
        }

        private ObservableCollection<IItemList> characteristic1Objects;
        public ObservableCollection<IItemList> Characteristic1Objects
        {
            get { return this.characteristic1Objects; }
            set { SetProperty(ref characteristic1Objects, value); }
        }
        private SimpleObject selectedCharacteristic1Object;
        public SimpleObject SelectedCharacteristic1Object
        {
            get
            {
                return this.selectedCharacteristic1Object;
            }
            set
            {
                this.Tiers.characteristic1 = value.Id;
                SetProperty(ref selectedCharacteristic1Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic2Objects;
        public ObservableCollection<IItemList> Characteristic2Objects
        {
            get { return this.characteristic2Objects; }
            set { SetProperty(ref characteristic2Objects, value); }
        }
        private SimpleObject selectedCharacteristic2Object;
        public SimpleObject SelectedCharacteristic2Object
        {
            get
            {
                return this.selectedCharacteristic2Object;
            }
            set
            {
                this.Tiers.characteristic2 = value.Id;
                SetProperty(ref selectedCharacteristic2Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic3Objects;
        public ObservableCollection<IItemList> Characteristic3Objects
        {
            get { return this.characteristic3Objects; }
            set { SetProperty(ref characteristic3Objects, value); }
        }
        private SimpleObject selectedCharacteristic3Object;
        public SimpleObject SelectedCharacteristic3Object
        {
            get
            {
                return this.selectedCharacteristic3Object;
            }
            set
            {
                this.Tiers.characteristic3 = value.Id;
                SetProperty(ref selectedCharacteristic3Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic4Objects;
        public ObservableCollection<IItemList> Characteristic4Objects
        {
            get { return this.characteristic4Objects; }
            set { SetProperty(ref characteristic4Objects, value); }
        }
        private SimpleObject selectedCharacteristic4Object;
        public SimpleObject SelectedCharacteristic4Object
        {
            get
            {
                return this.selectedCharacteristic4Object;
            }
            set
            {
                this.Tiers.characteristic4 = value.Id;
                SetProperty(ref selectedCharacteristic4Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic5Objects;
        public ObservableCollection<IItemList> Characteristic5Objects
        {
            get { return this.characteristic5Objects; }
            set { SetProperty(ref characteristic5Objects, value); }
        }
        private SimpleObject selectedCharacteristic5Object;
        public SimpleObject SelectedCharacteristic5Object
        {
            get
            {
                return this.selectedCharacteristic5Object;
            }
            set
            {
                this.Tiers.characteristic5 = value.Id;
                SetProperty(ref selectedCharacteristic5Object, value);
            }
        }

        private ObservableCollection<IItemList> characteristic6Objects;
        public ObservableCollection<IItemList> Characteristic6Objects
        {
            get { return this.characteristic6Objects; }
            set { SetProperty(ref characteristic6Objects, value); }
        }
        private SimpleObject selectedCharacteristic6Object;
        public SimpleObject SelectedCharacteristic6Object
        {
            get
            {
                return this.selectedCharacteristic6Object;
            }
            set
            {
                this.Tiers.characteristic6 = value.Id;
                SetProperty(ref selectedCharacteristic6Object, value);
            }
        }

        string repName = String.Empty;
        public string RepName
        {
            get { return repName; }
            private set { SetProperty(ref repName, value); }
        }

        public bool DisplayCharacteristics
        {
            get
            {
                bool retVal = DisplayCharacteristic1
                            || DisplayCharacteristic2
                            || DisplayCharacteristic3
                            || DisplayCharacteristic4
                            || DisplayCharacteristic5
                            || DisplayCharacteristic6;
                return retVal;
            }
        }

        private bool displayCharacteristic1;
        public bool DisplayCharacteristic1
        {
            get
            {
                return displayCharacteristic1;
            }
            set
            {
                SetProperty(ref displayCharacteristic1, value);
            }
        }

        private bool displayCharacteristic2;
        public bool DisplayCharacteristic2
        {
            get
            {
                return displayCharacteristic2;
            }
            set
            {
                SetProperty(ref displayCharacteristic2, value);
            }
        }

        private bool displayCharacteristic3;
        public bool DisplayCharacteristic3
        {
            get
            {
                return displayCharacteristic3;
            }
            set
            {
                SetProperty(ref displayCharacteristic3, value);
            }
        }

        private bool displayCharacteristic4;
        public bool DisplayCharacteristic4
        {
            get
            {
                return displayCharacteristic4;
            }
            set
            {
                SetProperty(ref displayCharacteristic4, value);
            }
        }

        private bool displayCharacteristic5;
        public bool DisplayCharacteristic5
        {
            get
            {
                return displayCharacteristic5;
            }
            set
            {
                SetProperty(ref displayCharacteristic5, value);
            }
        }

        private bool displayCharacteristic6;
        public bool DisplayCharacteristic6
        {
            get
            {
                return displayCharacteristic6;
            }
            set
            {
                SetProperty(ref displayCharacteristic6, value);
            }
        }

        public string ClientOrProspect
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        return AppResources.Client;
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        return AppResources.Prospect;
                        break;
                    default:
                        return string.Empty;
                        break;
                }
            }
        }

        public bool ShowContactSelection
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                    case CustomerTypes.PROSPECT:
                        return true;
                        break;
                    default:
                        return false;

                }
            }
        }
        public bool ShowCompanySelection
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                    case CustomerTypes.CONTACT_PROSPECT:
                        return true;
                        break;
                    default:
                        return false;

                }
            }
        }

        public bool DisplayAddress
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                    case CustomerTypes.CONTACT_PROSPECT:
                        return true;
                        break;
                    default:
                        return false;

                }
            }
        }
        public bool ShowAddress
        {
            get
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.PROSPECT:
                        return false;
                        break;
                    default:
                        return true;

                }
            }
        }

        public AddUpdateCustomerViewModel(CustomerTypes customerType, string idObj, Tiers obj = null, string idTiers = null)
        {
            this.CustomersType = customerType;

            var task = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh(idObj, obj, idTiers);
            });
            task.Wait();
        }

        public async System.Threading.Tasks.Task Refresh(string idObj, Tiers obj = null, string idTiers = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());

            if (obj == null)
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                        this.Page = AppResources.Client.ToLower();
                        this.Tiers = new Customer() { rep = Context.Instance.CurrentWebUser.RoleSalesRep };
                        break;
                    case CustomerTypes.PROSPECT:
                        this.Page = AppResources.Prospect.ToLower();
                        this.Tiers = new Prospect() { rep = Context.Instance.CurrentWebUser.RoleSalesRep };
                        break;
                }
                this.Prefix = AppResources.Creer_un;
            }
            else
            {
                if (obj.GetType().Name == "Prospect")
                {
                    this.tiers = CRMHelper.GetCustomerProspect(obj.id, CustomerTypes.PROSPECT).Result;
                }
                else
                {
                    this.tiers = CRMHelper.GetCustomerProspect(obj.id).Result;
                }
                switch (this.CustomersType)
                {
                    case CustomerTypes.CUSTOMER:
                        this.Page = AppResources.Client.ToLower();
                        break;
                    case CustomerTypes.PROSPECT:
                        this.Page = AppResources.Prospect.ToLower();
                        break;
                }
                this.Prefix = AppResources.Modifier_un;
            }

            //await System.Threading.Tasks.Task.Run(async () =>
            //{
            //    string repName = string.Empty;
            //    if (!string.IsNullOrEmpty(this.Tiers.rep))
            //    {
            //        Tiers tiers = await CRMHelper.GetCustomerProspect(this.Tiers.rep);
            //        repName = tiers?.descrOperLang;
            //    }
            //    this.RepName = repName;
            //});
        }

        public void Init()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                await this.ExecuteLoadCustomersObjects();
                await this.ExecuteLoadEmployeesObjects();
                await this.ExecuteLoadCharacteristicObjects();
            });
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            await System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        if (SelectedCharacteristic1Object == null)
                        {
                            this.OnError(AppResources.SecteurClientEmpty);
                            if (this.OnBusy != null)
                            {
                                this.OnBusy(false);
                            }
                            return;
                        }
                        System.Threading.Tasks.Task task = null;
                        this.FormatSWD();
                        if (!string.IsNullOrWhiteSpace(this.Tiers.id))
                        {
                            switch (this.CustomersType)
                            {
                                case CustomerTypes.CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Customer>(this.Tiers as Customer); });
                                    break;
                                case CustomerTypes.PROSPECT:                                    
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Prospect>(this.Tiers as Prospect); });                                    
                                    break;
                            }
                        }
                        else
                        {
                            switch (this.CustomersType)
                            {
                                case CustomerTypes.PROSPECT:
                                    Prospect prospect = (Prospect)this.Tiers;
                                    OfflineItems offlineItem = new OfflineItems()
                                    {
                                        Title = "Prospect",
                                        Time = DateTime.Now,
                                        SocioComercial = prospect.descrOperLang,
                                        DestinatarioMercancias = prospect.contactPerson,
                                    };                                    
                                    prospect.offlineInfo = offlineItem;

                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<Prospect>(this.Tiers as Prospect, true); });
                                    break;
                            }
                        }
                        Device.BeginInvokeOnMainThread(() =>
                        {                            
                            DependencyService.Get<IMessage>().LongAlert(AppResources.UpdatedData);
                        });
                        task.Wait();
                    }
                    else
                    {
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            //DialogEvent(AppResources.Error, e.Message);
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {                                                        
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }


        bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Tiers.descrOperLang);
        }

        private void FormatSWD()
        {
            if (string.IsNullOrEmpty(this.Tiers.swd))
            {
                this.Tiers.swd = this.Tiers.descrOperLang.Trim().Replace(" ", "");
            }
            if (this.Tiers.swd.Length > 8)
            {
                this.Tiers.swd = this.Tiers.swd.Substring(0, 8);
            }
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }



        async System.Threading.Tasks.Task ExecuteLoadCustomersObjects()
        {
            List<Customer> customers = this.Service.ReadList<Customer>().Result;

            ObservableCollection<IItemList> obsListCustomers = new ObservableCollection<IItemList>();

            foreach (Customer customer in customers)
            {
                obsListCustomers.Add(new CustomerObject(customer.Descr, customer.id));
            }
            this.CustomerObjects = obsListCustomers;

            foreach (CustomerObject obj in this.CustomerObjects)
            {
                if (obj.Id == this.Tiers.rep)
                {
                    this.SelectedCustomerObject = obj;

                }
            }

            if (this.OnCustomerObjectsLoaded != null)
            {
                this.OnCustomerObjectsLoaded();
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadEmployeesObjects()
        {
            List<Employee> employees = await this.Service.ReadList<Employee>();
            this.EmployeeObjects = new ObservableCollection<IItemList>();

            EmployeeObject employee;
            foreach (Employee item in employees)
            {
                employee = new EmployeeObject(item.Descr, item.id);
                this.EmployeeObjects.Add(employee);
                if (employee.Id == this.Tiers.rep)
                {
                    this.SelectedEmployeeObject = employee;
                }
                if (employee.Id == this.Tiers.inhouseContact)
                {
                    this.SelectedInhouseContactObject = employee;
                }
            }

            if (this.OnEmployeeObjectsLoaded != null)
            {
                this.OnEmployeeObjectsLoaded();
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadCompany(string id)
        {
            Tiers tiers = await this.Service.ReadOffline<Tiers>(id);
            if (this.OnLoadCompany != null)
            {
                this.OnLoadCompany(tiers);
            }
        }

        /*
        async System.Threading.Tasks.Task ExecuteLoadInhouseContact(string id)
        {
            Employee employee = await this.Service.Read<Employee>(id);
            if (this.OnLoadInhouseContact != null)
            {
                this.OnLoadInhouseContact(employee);
            }
        }
        */

        /*
        async System.Threading.Tasks.Task ExecuteLoadContactObjects()
        {
            List<Tiers> tiers;

            switch(this.CustomersType)
            {
                case CustomerTypes.CUSTOMER:
                    tiers = await this.Service.ReadList<ContactCustomer>());
                    break;
                case CustomerTypes.PROSPECT:
                    break;
            }

            ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();

            foreach (Abas_Shared_Xamarin.Models.Type type in types)
            {
                obsList.Add(new TypeObject(type.enumDescr, type.enumIdentifierComplete));
            }
            this.TypeObjects = obsList;
            
            if (this.OnTypeObjectsLoaded != null)
            {
                this.OnTypeObjectsLoaded();
            }

            foreach (TypeObject obj in this.TypeObjects)
            {
                if (obj.Id == this.Tiers.type)
                {
                    this.SelectedTypeObject = obj;
                    break;
                }
            }

        }
        */
        /*
        public void LoadProductsObjects(string search)
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                this.ExecuteLoadProductsObjects(search);
            });
        }

        async System.Threading.Tasks.Task ExecuteLoadProductsObjects(string search, int page = 0)
        {
            try
            {
                int limit = 100;

                List<FilterField> filterFields = new List<FilterField>();
                if (!string.IsNullOrWhiteSpace(search))
                {
                    filterFields.Add(new FilterField() { FieldName = "descrOperLang", Operator = "~/", Value = search });
                }
                List<Product> products = await this.Service.ReadList<Product>(null, filterFields, page, limit);

                //ObservableCollection<IItemList> obsList = new ObservableCollection<IItemList>();
                this.ProductObjects.Clear();

                foreach (Product product in products)
                {
                    //obsList.Add(new ProductObject(product.descrOperLang, product.id));
                    ProductObject productObject = new ProductObject(product.descrOperLang, product.id);
                    this.ProductObjects.Add(productObject);
                    if (productObject.Id == this.Tiers.productListElem)
                    {
                        this.SelectedProductObject = productObject;
                    }
                }
                //this.ProductObjects = obsList;
                //this.ProductObjects.Add()

                if (this.OnProductObjectsLoaded != null)
                {
                    this.OnProductObjectsLoaded();
                }

                if (products.Count == limit)
                {
                    //this.ExecuteLoadProductsObjects(search, page + 1);
                }
            }
            catch(Exception e)
            {
                
            }
        }
        */

        async System.Threading.Tasks.Task ExecuteLoadCharacteristicObjects()
        {
            await this.LoadClientSector();
            await this.LoadClientType();
            await this.LoadClientABC();

            if (this.OnCharacteristicObjectsLoaded != null)
            {
                this.OnCharacteristicObjectsLoaded();
            }
        }

        private async System.Threading.Tasks.Task LoadClientSector()
        {
            List<ClientSector> characteristics = await this.Service.GetEnumAsync<ClientSector>();
            DisplayCharacteristic1 = (characteristics != null && characteristics.Count > 0 );
            this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics), ref this.characteristic1Objects, ref this.selectedCharacteristic1Object, this.Tiers.characteristic1);
        }
        private async System.Threading.Tasks.Task LoadClientType()
        {
            List<ClientType> characteristics = await this.Service.GetEnumAsync<ClientType>();
            DisplayCharacteristic2 = (characteristics != null && characteristics.Count > 0 && !string.IsNullOrWhiteSpace(this?.Tiers.characteristicIdentifier2));
            this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics), ref this.characteristic2Objects, ref this.selectedCharacteristic2Object, this.Tiers.characteristic2);
        }
        private async System.Threading.Tasks.Task LoadClientABC()
        {
            List<ClientABC> characteristics = await this.Service.GetEnumAsync<ClientABC>();
            DisplayCharacteristic3 = (characteristics != null && characteristics.Count > 0 && !string.IsNullOrWhiteSpace(this?.Tiers.characteristicIdentifier3));
            this.FillCaracteristic(new ObservableCollection<EnumReference>(characteristics), ref this.characteristic3Objects, ref this.selectedCharacteristic3Object, this.Tiers.characteristic3);
        }

        private void FillCaracteristic(ObservableCollection<EnumReference> characteristics, ref ObservableCollection<IItemList> localList, ref SimpleObject selectedObject, string value)
        {
            localList = new ObservableCollection<IItemList>();
            SimpleObject obj;
            foreach (EnumReference enumeReference in characteristics)
            {
                obj = new SimpleObject(enumeReference.refToEnumElem_descrOperLang, enumeReference.enumIdentifierComplete);

                if (obj.Id == value)
                {
                    selectedObject = obj;
                }
                localList.Add(obj);
            }
        }
    }
}