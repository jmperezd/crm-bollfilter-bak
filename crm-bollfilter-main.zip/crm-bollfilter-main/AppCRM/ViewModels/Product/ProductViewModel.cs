﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Xamarin.Forms;
using System;
using AppCRM.Resx;
using WFramework_Xamarin.Components;

namespace AppCRM.ViewModels
{
    public class ProductViewModel : BaseViewModel
    {
        public string IdNumber { get; private set; }
        public string SearchTerm { get; private set; }
        public string Description { get; private set; }
        public string GTIN { get; private set; }
        public string Weight { get; private set; }
        public string Long { get; private set; }
        public string Wide { get; private set; }
        public string Height { get; private set; }
        public string Pvp { get; private set; }
        public string Warranty { get; private set; }
        public string Catalog { get; private set; }
        public string SalesPriceUnit { get; private set; }


        public ProductViewModel(Product product)
        {
            this.IdNumber = product.idno;
            this.SearchTerm = product.swd;
            this.Description = product.descrOperLangLower;
            this.GTIN = product.globalTradeItemNo;
            this.Weight = product.weight + " Kg";
            this.Long = "";
            if (product.packDimLength != null)
            {
                this.Long = product.packDimLength + " mm";
            }
            this.Wide = "";
            if (product.packDimWidth != null)
            {
                this.Wide = product.packDimWidth + " mm";
            }
            this.Height = "";
            if (product.packDimHeight != null)
            {
                this.Height = product.packDimHeight + " mm";
            }
            this.Pvp = product.salesPrice + " " + product.salesCurr_descr + " / " + (product.salesPriceUnit.ToLower().Contains("pce") ? AppResources.Units : product.salesPriceUnit);
            this.Warranty = "";
            if (product.warrantyPer != null)
            {
                this.Warranty = product.warrantyPer + " " + AppResources.Days;
            }
            this.Catalog = product.catalogMeta;
        }
    }
}
