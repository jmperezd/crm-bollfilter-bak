﻿using Abas_Shared_Xamarin.Models;
using AppCRM.Resx;
using AppCRM.Services;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using WFramework_Xamarin.Table;

namespace AppCRM.ViewModels
{

    public class ProductsViewModel : BaseViewModel, ITableViewModel
    {
        private List<string> ListGridFieldsComplete = new List<string> { "id", "idno","descrOperLang", "salesPrice", "salesTradeUnit" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = true;
        public bool LazyLoading { get; set; } = true;

        public string IdClient { get; private set; } = null;

        public int NbElementsPerPage { get; set; }

        public ProductsViewModel(string idClient)
        {
            this.InitGridFields();
            this.IdClient = idClient;
            this.Page = AppResources.Articles;
            this.Prefix = string.Empty;
        }



        private void InitGridFields()
        {
            foreach (string stringGridField in this.ListGridFieldsComplete)
            {
                GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                this.GridFields.Add(gridField);
            }


            /*foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "descrOperLang")
                {
                    gridField.Order = GridField.SortOrder.Asc;
                }
            }*/

        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            if (!Abas_Shared_Xamarin.Context.Instance.IsConnected)
            {
                foreach (GridField gridField in this.GridFields)
                {
                    gridField.FieldName = gridField.FieldName.Replace("^", "_");
                }
            }

            List<FilterField> filterFields = new List<FilterField>();
            if (!string.IsNullOrWhiteSpace(globalSearchedString))
            {
                filterFields.Add(new FilterField() { FieldName = "all", Operator = "~/", Value = globalSearchedString.ToLower() });
            }

            EntityTable entityTable = this.Service.ReadTableOffline<Product>(this.GridFields, filterFields, requestedPage, 25).Result;
            List<Unit> listUnit = Service.ReadListOffline<Unit>(null, null).Result;

            foreach (EntityRow row in entityTable.Rows)
            {
                foreach (KeyValuePair<string, EntityCell> kvp in row.Cells)
                {
                    if (kvp.Key.ToLower().Equals("salestradeunit"))
                    {                        
                        Unit unit = listUnit.FirstOrDefault(s => s.swd == kvp.Value.Value.Replace("(", "").Replace(")", ""));
                        if (unit != null)
                        {
                            string result = unit.descrOperLang;
                            if (CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "es")
                            {
                                result = unit.unitOperLang;
                            }

                            if (!string.IsNullOrEmpty(result))
                            {
                                kvp.Value.Value = result;
                            }
                            break;
                        }
                    }
                }
            }

            return entityTable;
        }

        public async Task<Product> GetProduct(string id)
        {
            return await this.Service.ReadOffline<Product>(id);
        }
    }
}
