﻿using System;
using Xamarin.Forms;
using Abas_Shared_Xamarin.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using AppCRM.Resx;
using Abas_Shared_Xamarin;
using AppCRM.Services;
using System.Globalization;
using AppCRM.CRMModels;

namespace AppCRM.ViewModels
{
    public class AddUpdateNoteViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }
        public Command LoadTypeObjectsCommand { get; set; }

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;

        public delegate void OnListObjectsLoadedDelegate();
        public event OnListObjectsLoadedDelegate OnProductObjectsLoaded;
        public event OnListObjectsLoadedDelegate OnTypeObjectsLoaded;

        public delegate void OnLoadCustomerDelegate(Tiers tiers);
        public event OnLoadCustomerDelegate OnLoadCustomer;

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        private Note note;
        public Note Note
        {
            get
            {
                return note;
            }
            set
            {
                SetProperty(ref note, value);
            }
        }

        private bool showTiersSelection = true;
        public bool ShowTiersSelection
        {
            get { return this.showTiersSelection; }
            set { SetProperty(ref showTiersSelection, value); }
        }

        private ObservableCollection<IItemList> typeObjects;
        public ObservableCollection<IItemList> TypeObjects
        {
            get { return this.typeObjects; }
            set { SetProperty(ref typeObjects, value); }
        }

        private ObservableCollection<IItemList> productObjects = new ObservableCollection<IItemList>();
        public ObservableCollection<IItemList> ProductObjects
        {
            get { return this.productObjects; }
            set { SetProperty(ref productObjects, value); }
        }

        private TypeObject selectedTypeObject;
        public TypeObject SelectedTypeObject
        {
            get
            {
                return this.selectedTypeObject;
            }
            set
            {
                this.Note.type = value.Id;
                SetProperty(ref selectedTypeObject, value);
            }
        }

        private ProductObject selectedProductObject;
        public ProductObject SelectedProductObject
        {
            get
            {
                return this.selectedProductObject;
            }
            set
            {
                this.Note.productListElem = value.Id;
                SetProperty(ref selectedProductObject, value);
            }
        }


        private string editorName = String.Empty;
        public string EditorName
        {
            get { return editorName; }
            private set { SetProperty(ref editorName, value); }
        }

        public string BusinessPartnerSwd { get; set; }


        public AddUpdateNoteViewModel(string idObj, Note obj = null, string idTiers = null)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.LoadTypeObjectsCommand = new Command(async () => await ExecuteLoadTypesObjects());

            if (obj == null)
            {

                this.Page = AppResources.Note.ToLower();
                this.Prefix = AppResources.Creer_une;
                this.Note = new Note() { date = DateTime.Now, currTime = DateTime.Now, editor = Context.Instance.CurrentWebUser.RoleEmployee };
            }
            else
            {

                this.Page = AppResources.Note.ToLower();
                this.Prefix = AppResources.Modifier_une;
                this.Note = obj;
            }
            if (!string.IsNullOrWhiteSpace(idTiers))
            {
                this.Note.businessPartner = idTiers;
                this.ShowTiersSelection = false;
            }

            System.Threading.Tasks.Task.Run(async () =>
            {
                this.EditorName = (await this.Service.Read<Employee>(this.Note.editor)).Descr;
            });


        }

        public void Init()
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                if (!string.IsNullOrEmpty(this.Note.businessPartner))
                {
                    await this.ExecuteLoadCustomer(this.Note.businessPartner);
                }
                //this.ExecuteLoadProductsObjects(string.Empty);
                this.LoadTypeObjectsCommand.Execute(null);
            });
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            await System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {

                    if (this.ValidateMandatory())
                    {
                        //TODO: When entering the business partner or article, the system initializes the note search key with that of the business partner / article.
                        //See how to reproduce this behavior in creation from the app. In theory, the API behaves the same.

                        //this.Note.swd = this.Note.descrOperLang.Replace(" ", "");
                        string businessPartner = Note.businessPartner_descrOperLang;
                        this.Note.businessPartner_descrOperLang = null;
                        if (!string.IsNullOrWhiteSpace(this.Note.id))
                        {
                            //Update
                            var task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<Note>(this.Note); });
                            task.Wait();
                        }
                        else
                        {
                            //Create
                            OfflineItems offlineItem = new OfflineItems()
                            {
                                Title = "Note",
                                Time = DateTime.Now,
                                DestinatarioMercancias = Note.descrOperLang,
                                SocioComercial = Note.descrTextModuleOperLang,
                            };                                                        
                            this.Note.offlineInfo = offlineItem;                            
                            this.Note.swd = this.BusinessPartnerSwd;
                            var task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<Note>(this.Note); });
                            task.Wait();
                        }
                        this.Note.businessPartner_descrOperLang = businessPartner;
                        Device.BeginInvokeOnMainThread(() =>
                        {                            
                            DependencyService.Get<IMessage>().LongAlert(AppResources.UpdatedData);
                        });
                    }
                    else
                    {
                        OnError(AppResources.CustomerEmpty);
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }


        bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Note.businessPartner);
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }


        async System.Threading.Tasks.Task ExecuteLoadCustomer(string id)
        {
            Tiers tiers = await CRMHelper.GetCustomerProspect(id);
            if (this.OnLoadCustomer != null)
            {
                this.OnLoadCustomer(tiers);
            }
        }

        async System.Threading.Tasks.Task ExecuteLoadTypesObjects()
        {
            this.TypeObjects = new ObservableCollection<IItemList>();
            List<Abas_Shared_Xamarin.Models.Type> types = await this.Service.GetEnumAsync<Abas_Shared_Xamarin.Models.Type>();

            TypeObject type;
            foreach (Abas_Shared_Xamarin.Models.Type item in types)
            {                
                type = new TypeObject(item.refToEnumElem_descrOperLang, item.enumIdentifierComplete);
                this.TypeObjects.Add(type);
                if (type.Id == this.Note.type)
                {
                    this.SelectedTypeObject = type;
                }
            }

            if (this.OnTypeObjectsLoaded != null)
            {
                this.OnTypeObjectsLoaded();
            }
        }
    }
}