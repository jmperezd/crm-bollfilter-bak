﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using Abas_Shared_Xamarin.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;
using System.Linq;
using AppCRM.Services;
using System.Globalization;

namespace AppCRM.ViewModels
{

    public class TransactionProductsViewModel : BaseViewModel, ITableViewModel
    {
        public string IdTransaction { get; private set; }
        public Transaction Transaction { get; private set; }
        public bool EditView { get; set; } = false;

        private List<string> ListGridFields = new List<string> { "id", "productDescr", "unitQty", "tradeUnit", "price", "percent", "itemValEntCurr", "rowNo", "startDateTime", "product" };
        private List<string> ListGridFieldsComplete = new List<string> { "id", "productDescr", "unitQty", "tradeUnit", "price", "percent", "itemValEntCurr", "rowNo", "startDateTime", "product" };
        public List<GridField> GridFields { get; set; } = new List<GridField>();

        public bool MultiPage { get; set; } = false;
        public bool LazyLoading { get; set; } = false;

        public int NbElementsPerPage { get; set; }

        public TransactionProductsViewModel(string idTransaction = null, Transaction transaction = null)
        {
            if (idTransaction != null)
            {
                this.IdTransaction = idTransaction;
            }
            if (transaction != null)
            {
                this.IdTransaction = transaction.id;
                this.Transaction = transaction;
            }


            this.InitGridFields();

            //this.Page = "Products";
            //this.Prefix = string.Empty;         
        }

        public void ReInit()
        {
            this.Transaction = null;
        }

        private void InitGridFields()
        {
            if (!string.IsNullOrWhiteSpace(this.IdTransaction))
            {
                foreach (string stringGridField in this.ListGridFields)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }
            else
            {
                foreach (string stringGridField in this.ListGridFieldsComplete)
                {
                    GridField gridField = new GridField(stringGridField, string.Empty, GridField.SortOrder.None);
                    this.GridFields.Add(gridField);
                }
            }


            foreach (GridField gridField in this.GridFields)
            {
                if (gridField.FieldName == "recordNo")
                {
                    gridField.Order = GridField.SortOrder.Desc;
                }
            }
        }

        public EntityTable LoadDatas(int requestedPage, string globalSearchedString = null)
        {
            EntityTable entityTable = null;
            if (this.Transaction == null)
            {
                entityTable = CRMHelper.LoadDatas<SaleProduct>(Service, GridFields, SetRequiredFilterFields(), ListGridFields, requestedPage, NbElementsPerPage, globalSearchedString);
                if (EditView)
                {

                    List<EntityRow> subRows = new List<EntityRow>();
                    foreach (EntityRow item in entityTable.Rows)
                    {
                        SaleProduct saleProduct = (SaleProduct)item.Object;
                        if (saleProduct.status != "A" && (saleProduct.recordType != null && saleProduct.recordType.Contains("SOPOItemPOS") || saleProduct.recordType == null))
                        {
                            subRows.Add(item);
                        }
                    }
                    entityTable.Rows = subRows;
                }
            }
            else
            {
                if (this.Transaction.SubItems == null)
                {
                    this.Transaction.SubItems = new List<object>();
                }

                List<SaleProduct> subItemsToDisplay = new List<SaleProduct>();
                foreach (SaleProduct saleProduct in this.Transaction.SubItems)
                {   
                    if (saleProduct.status != "A" )
                    {
                        if (EditView && (saleProduct.recordType != null && saleProduct.recordType.Contains("SOPOItemPOS") || saleProduct.recordType == null))
                        {                            
                            subItemsToDisplay.Add(saleProduct);                         
                        }
                        if(!EditView)
                        {
                            subItemsToDisplay.Add(saleProduct);
                        }                        
                    }
                }
                entityTable = new EntityTable(subItemsToDisplay, this.GridFields);
            }

            foreach (EntityRow row in entityTable.Rows)
            {
                foreach (KeyValuePair<string, EntityCell> kvp in row.Cells)
                {
                    if (kvp.Key.ToLower().Equals("salestradeunit"))
                    {

                        List<Unit> listUnit = Service.ReadList<Unit>(null, null).Result;

                        Unit unit = listUnit.SingleOrDefault(s => s.swd == kvp.Value.Value.Replace("(", "").Replace(")", ""));
                        if (unit != null)
                        {
                            string result = unit.descrOperLang;
                            if (CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "es")
                            {
                                result = unit.unitOperLang;
                            }

                            if (!string.IsNullOrEmpty(result))
                            {
                                kvp.Value.Value = result;
                            }
                            break;
                        }
                    }
                }
            }
            return entityTable;
        }

        private List<FilterField> SetRequiredFilterFields()
        {
            List<FilterField> retVal = new List<FilterField>();

            if (!string.IsNullOrWhiteSpace(this.IdTransaction))
            {
                retVal.Add(new FilterField() { FieldName = "head", Operator = "==", Value = this.IdTransaction });
                retVal.Add(new FilterField() { FieldName = "status", Operator = "<>", Value = "A" });
            }

            return retVal;
        }
    }
}