﻿using System;
using System.Windows.Input;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using Abas_Shared_Xamarin.Models;
using System.Collections.ObjectModel;
using System.Diagnostics;
using WFramework_Xamarin.Table;
using AppCRM;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{
    public class TransactionsViewModel : BaseViewModel
    {
        public Command NewObject { get; set; }
        public event EventHandler OnNewObject;

        public TransactionsViewModel()
        {
            this.Page = AppResources.Transactions;
            this.Prefix = string.Empty;

            this.NewObject = new Command(ExecuteNewObjectCommand);
        }

        public static TransactionTypes LastShowedTransactionTab
        {
            get
            {
                if (Application.Current.Properties.ContainsKey("APP_LastShowedTransactionTab"))
                {
                    return (TransactionTypes)Enum.Parse(typeof(TransactionTypes), Application.Current.Properties["APP_LastShowedTransactionTab"] as string);
                }
                else
                {
                    return TransactionTypes.OPPORTUNITY;
                }
            }
            set
            {
                Application.Current.Properties["APP_LastShowedTransactionTab"] = value.ToString();
            }
        }

        private void ExecuteNewObjectCommand()
        {
            if (this.OnNewObject != null)
            {
                this.OnNewObject(this, null);
            }
        }
    }

    public enum TransactionTypes
    {
        OPPORTUNITY,
        QUOTATION,
        ORDER
    }
}
