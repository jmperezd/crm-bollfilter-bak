﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Xamarin.Forms;
using System;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using System.Net;
using System.IO;
using System.Text;
using AppCRM.Resx;
using Abas_Shared_Xamarin;
using System.Globalization;
using Plugin.Permissions.Abstractions;
using Plugin.Permissions;
using AppCRM.Services;

namespace AppCRM.ViewModels
{

    public class TransactionViewModel : BaseViewModel
    {

        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public Command EditPDFCommand { get; set; }
        public event EventHandler OnEditPDF;

        public delegate void OnErrorEventHandler(string title, string msg);
        public event OnErrorEventHandler OnError;

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;

        private string TransactionId { get; set; }
        public TransactionTypes TransactionType { get; private set; }

        private PopupBusy PopupBusy { get; set; }

        private bool showAnalysis;
        public bool ShowAnalysis
        {
            get
            {
                if (this.TransactionType != TransactionTypes.ORDER)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                if (this.TransactionType != TransactionTypes.ORDER)
                {
                    SetProperty(ref showAnalysis, true);
                }
                else
                {
                    SetProperty(ref showAnalysis, false);
                }
                
            }
        }

        public bool ShowContact
        {
            get
            {
                if (this.TransactionType == TransactionTypes.ORDER)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool ShowEditPDF
        {
            get
            {
                if (this.TransactionType != TransactionTypes.OPPORTUNITY)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public string DisplayProbability
        {
            get
            {
                return this.Transaction != null ? (!string.IsNullOrWhiteSpace(this.Transaction.probability) ? this.Transaction.probability + "%" : string.Empty) : string.Empty;
            }
        }

        public string DisplayTotalHT
        {
            get
            {
                double res = 0;
                this.Transaction.totalNetAmt = ToolsHelper.ReplaceDotsString(this.Transaction.totalNetAmt);

                if (this.Transaction != null && double.TryParse(this.Transaction.totalNetAmt, out res))
                {
                    return DisplayTools.FormatAmount(res);
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public string DisplayTransLock
        {
            get
            {
                if (this.Transaction != null)
                {
                    return this.Transaction.transLock ? AppResources.Oui.ToLower() : AppResources.Non.ToLower();
                }
                else
                {
                    return string.Empty;
                }

            }
        }

        string repName = String.Empty;
        public string RepName
        {
            get { return repName; }
            private set { SetProperty(ref repName, value); }
        }

        string inhouseContactName = String.Empty;
        public string InhouseContactName
        {
            get { return inhouseContactName; }
            private set { SetProperty(ref inhouseContactName, value); }
        }

        string customerName = String.Empty;
        public string CustomerName
        {
            get { return customerName; }
            private set { SetProperty(ref customerName, value); }
        }

        string goodsRecipentName = String.Empty;
        public string GoodsRecipentName
        {
            get { return goodsRecipentName; }
            private set { SetProperty(ref goodsRecipentName, value); }
        }




        private Transaction transaction;
        public Transaction Transaction
        {
            get { return transaction; }
            set
            {
                SetProperty(ref transaction, value);
                ShowAnalysis = false;
                this.OnPropertyChanged("ShowAnalysis");
                this.OnPropertyChanged("DisplayProbability");
                this.OnPropertyChanged("DisplayTotalHT");
                this.OnPropertyChanged("DisplayTransLock");
            }
        }

        public TransactionViewModel(string id, TransactionTypes transactionType)
        {
            this.EditPDFCommand = new Command(async () => await ExecuteEditPDFCommand());
            this.EditCommand = new Command(async () => await ExecuteEditCommand());

            this.TransactionId = id;
            this.TransactionType = transactionType;


            var taskResfresh = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
            taskResfresh.Wait();

        }


        public async System.Threading.Tasks.Task Refresh()
        {

            switch (this.TransactionType)
            {
                case TransactionTypes.OPPORTUNITY:
                    this.Prefix = AppResources.Opportunite;
                    this.Transaction = await this.Service.Read<Opportunity, SaleProduct>(this.TransactionId);
                    break;
                case TransactionTypes.QUOTATION:
                    this.Prefix = AppResources.Offre;
                    this.Transaction = await this.Service.Read<Quotation, SaleProduct>(this.TransactionId);
                    break;
                case TransactionTypes.ORDER:
                    this.Prefix = AppResources.Commande;
                    this.Transaction = await this.Service.Read<Order, SaleProduct>(this.TransactionId);

                    await System.Threading.Tasks.Task.Run(async () =>
                    {
                        Employee employee = await this.Service.Read<Employee>((this.Transaction as Order).inhouseContact);
                        this.InhouseContactName = employee.Descr;
                    });

                    await System.Threading.Tasks.Task.Run(async () =>
                    {
                        Tiers tiers = await CRMHelper.GetCustomerProspect(this.Transaction.rep);
                        this.RepName = tiers.descrOperLang;
                    });

                    break;
            }
            this.Page = this.Transaction.idno.ToString();

            this.CustomerName = this.Transaction.customerDescr_descrOperLang;

            await System.Threading.Tasks.Task.Run(async () =>
            {
                Tiers tiers = await CRMHelper.GetCustomerProspect(this.Transaction.goodsRecipient);
                this.GoodsRecipentName = tiers.descrOperLang;
            });

        }

        async System.Threading.Tasks.Task ExecuteEditPDFCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }

            try
            {
                Uri uriPdf = new Uri("http://vide.com");
                switch (this.TransactionType)
                {
                    case TransactionTypes.OPPORTUNITY:
                        uriPdf = await Service.PrintImpression<Opportunity>(this.TransactionId);
                        break;
                    case TransactionTypes.QUOTATION:
                        uriPdf = await Service.PrintImpression<Quotation>(this.TransactionId);
                        break;
                    case TransactionTypes.ORDER:
                        uriPdf = await Service.PrintImpression<Order>(this.TransactionId);
                        break;
                }
                if (uriPdf.AbsoluteUri != "http://vide.com")
                {


                    var webClient = new WebClient();

                    webClient.Proxy = WebRequest.DefaultWebProxy;
                    webClient.Credentials = new NetworkCredential(App.ServerUserName, App.ServerPassword);
                    webClient.Encoding = Encoding.UTF8;

                    if (Device.RuntimePlatform == Device.Android)
                    {
                        webClient.DownloadDataCompleted += (s, e) =>
                        {
                            var data = e.Result;

                            Device.BeginInvokeOnMainThread(async () =>
                            {
                                var intentHelper = DependencyService.Get<IIntentHelper>();
                                var permissionStatus = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                                if (permissionStatus == PermissionStatus.Denied)
                                {
                                    intentHelper.SetPermissions();
                                    OnError(AppResources.Info, AppResources.Permission_denied);
                                    return;
                                }
                                intentHelper.File(data);
                            });
                        };
                        webClient.DownloadDataAsync(uriPdf);
                    }
                    else
                    {
                        var bytes = webClient.DownloadData(uriPdf);
                        var text = bytes; // get the downloaded text
                        bool exists = false;
                        string localFilename = "abas.pdf";
                        string localPath;
                        string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                        localPath = Path.Combine(documentsPath, localFilename);
                        File.WriteAllBytes(localPath, text); // writes to local storage
                        exists = File.Exists(localPath);

                        if (exists)
                        {
                            Device.BeginInvokeOnMainThread(async () =>
                            {
                                var intentHelper = DependencyService.Get<IIntentHelper>();
                                intentHelper.File(localPath);
                            });
                        }
                    }

                }

                if (this.OnEditPDF != null)
                {
                    this.OnEditPDF(this, null);
                }
                if (this.OnBusy != null)
                {
                    this.OnBusy(false);
                }
            }
            catch (Exception e)
            {
                if (this.OnBusy != null)
                {
                    this.OnBusy(false);
                }
                OnError("Error", e.Message);
            }
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (IsBusy)
                return;
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }

    }
}
