﻿using System;
using Xamarin.Forms;
using AppCRM.Resx;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using System.Linq;
using Abas_Shared_Xamarin.Models.Print;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using Abas_Shared_Xamarin;

namespace AppCRM.ViewModels
{
    public class ParametersViewModel : BaseViewModel
    {

        const string AllUser = "PARAM_AllUser";
        const string UpdateContact = "PARAM_UpdateContact";
        const string SearchTerm = "PARAM_SearchTerm";
        const string Number = "PARAM_Number";
        const string SearchWord = "PARAM_SearchWord";
        const string InternalContact = "PARAM_InternalContact";
        const string Name = "PARAM_Name";
        const string Address = "PARAM_Address";
        const string City = "PARAM_City";
        const string PostalCode = "PARAM_PostalCode";
        const string Country = "PARAM_Country";
        const string Phone = "PARAM_Phone";
        const string MobilePhone = "PARAM_MobilePhone";




        private ObservableCollection<IItemList> printQuotationObjects;
        public ObservableCollection<IItemList> PrintQuotationObjects
        {
            get { return this.printQuotationObjects; }
            set { SetProperty(ref printQuotationObjects, value); }
        }

        private ObservableCollection<IItemList> printSaleOrderObjects;
        public ObservableCollection<IItemList> PrintSaleOrderObjects
        {
            get { return this.printSaleOrderObjects; }
            set { SetProperty(ref printSaleOrderObjects, value); }
        }

        private ObservableCollection<IItemList> layoutSource;
        public ObservableCollection<IItemList> LayoutSource
        {
            get { return this.layoutSource; }
            set { SetProperty(ref layoutSource, value); }
        }

        private ObservableCollection<IItemList> layoutSource2;
        public ObservableCollection<IItemList> LayoutSource2
        {
            get { return this.layoutSource2; }
            set { SetProperty(ref layoutSource2, value); }
        }

        private ObservableCollection<IItemList> layoutSource3;
        public ObservableCollection<IItemList> LayoutSource3
        {
            get { return this.layoutSource3; }
            set { SetProperty(ref layoutSource3, value); }
        }

        private ObservableCollection<IItemList> layoutSource4;
        public ObservableCollection<IItemList> LayoutSource4
        {
            get { return this.layoutSource4; }
            set { SetProperty(ref layoutSource4, value); }
        }

        private SimpleObject selectedQuotationPrintLayoutObject;
        public SimpleObject SelectedQuotationPrintLayoutObject
        {
            get
            {
                return this.selectedQuotationPrintLayoutObject;
            }
            set
            {
                AppParameters.QuotationLayout = value.Id;
                SetProperty(ref selectedQuotationPrintLayoutObject, value);
            }
        }

        private SimpleObject selectedItemSearchObject;
        public SimpleObject SelectedItemSearchObject
        {
            get
            {
                return this.selectedItemSearchObject;
            }
            set
            {
                App.ItemSearch = value.Id;
                SetProperty(ref selectedItemSearchObject, value);
            }
        }

        private SimpleObject selectedPrinterSearchObject;
        public SimpleObject SelectedPrinterSearchObject
        {
            get
            {
                return this.selectedPrinterSearchObject;
            }
            set
            {
                AppParameters.PrintType = value.Id;
                SetProperty(ref selectedPrinterSearchObject, value);
            }
        }

        private SimpleObject selectedSalesPrintLayoutObject;
        public SimpleObject SelectedSalesPrintLayoutObject
        {
            get
            {
                return this.selectedSalesPrintLayoutObject;
            }
            set
            {
                AppParameters.SaleOrderLayout = value.Id;
                SetProperty(ref selectedSalesPrintLayoutObject, value);
            }
        }


        public ParametersViewModel()
        {
            this.Page = AppResources.Parametres;
        }


        #region box
        public bool? CheckBoxAllUser
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(AllUser))
                {
                    return Application.Current.Properties[AllUser] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[AllUser] = value;
            }
        }

        public bool? CheckBoxUpdateContact
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(UpdateContact))
                {
                    return Application.Current.Properties[UpdateContact] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[UpdateContact] = value;
            }
        }

        public bool? CheckBoxSearchTerm
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(SearchTerm))
                {
                    return Application.Current.Properties[SearchTerm] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[SearchTerm] = value;
            }
        }

        public bool? CheckBoxNumber
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(Number))
                {
                    return Application.Current.Properties[Number] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[Number] = value;
            }
        }
        public bool? CheckBoxSearchWord
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(SearchWord))
                {
                    return Application.Current.Properties[SearchWord] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[SearchWord] = value;
            }
        }
        public bool? CheckBoxInternalContact
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(InternalContact))
                {
                    return Application.Current.Properties[InternalContact] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[InternalContact] = value;
            }
        }
        public bool? CheckBoxName
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(Name))
                {
                    return Application.Current.Properties[Name] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[Name] = value;
            }
        }
        public bool? CheckBoxAddress
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(Address))
                {
                    return Application.Current.Properties[Address] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[Address] = value;
            }
        }
        public bool? CheckBoxCity
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(City))
                {
                    return Application.Current.Properties[City] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[City] = value;
            }
        }
        public bool? CheckBoxPostalCode
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(PostalCode))
                {
                    return Application.Current.Properties[PostalCode] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[PostalCode] = value;
            }
        }
        public bool? CheckBoxCountry
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(Country))
                {
                    return Application.Current.Properties[Country] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[Country] = value;
            }
        }
        public bool? CheckBoxPhone
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(Phone))
                {
                    return Application.Current.Properties[Phone] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[Phone] = value;
            }
        }
        public bool? CheckBoxMobilePhone
        {
            get
            {
                if (Application.Current.Properties.ContainsKey(MobilePhone))
                {
                    return Application.Current.Properties[MobilePhone] as bool?;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                Application.Current.Properties[MobilePhone] = value;
            }
        }


        #endregion

        //public PrintCollectiveLayout PrintCollectiveLayout
        //{
        //    get;
        //    set;
        //}

        public async System.Threading.Tasks.Task ExecuteLoadQuotationPrintLayout()
        {
            List<FilterField> filterFields = new List<FilterField>();
            FilterField filterField = new FilterField() { FieldName = "layoutContext", Operator = "==", Value = "V%20V-03-21" };
            FilterField filterField2 = new FilterField() { FieldName = "active", Operator = "==", Value = "1" };
            FilterField filterField3 = new FilterField() { FieldName = "outChannel", Operator = "==", Value = "JASPERREPORTS" };
            filterFields.Add(filterField);
            filterFields.Add(filterField2);
            filterFields.Add(filterField3);

            ObservableCollection<IItemList> obsList1 = new ObservableCollection<IItemList>();

            var PrintCollectiveLayout = await Service.ReadList<PrintCollectiveLayout>(null, filterFields);

            foreach (var item in PrintCollectiveLayout)
            {
                obsList1.Add(new SimpleObject(item.swd, item.id));
            }

            var res = obsList1.FirstOrDefault(x => x.Text == App.QuotationLayout);
            if (res != null)
            {
                this.SelectedQuotationPrintLayoutObject = res as SimpleObject;
            }


            this.LayoutSource = obsList1;

        }

        public async System.Threading.Tasks.Task ExecuteLoadSalesPrintLayout()
        {

            List<FilterField> filterFields = new List<FilterField>();
            FilterField filterField = new FilterField() { FieldName = "layoutContext", Operator = "==", Value = "V%20V-03-22" };
            FilterField filterField2 = new FilterField() { FieldName = "active", Operator = "==", Value = "1" };
            FilterField filterField3 = new FilterField() { FieldName = "outChannel", Operator = "==", Value = "JASPERREPORTS" };
            filterFields.Add(filterField);
            filterFields.Add(filterField2);
            filterFields.Add(filterField3);



            ObservableCollection<IItemList> obsList2 = new ObservableCollection<IItemList>();

            var PrintCollectiveLayout = await Service.ReadList<PrintCollectiveLayout>(null, filterFields);



            foreach (var item in PrintCollectiveLayout)
            {
                obsList2.Add(new SimpleObject(item.swd, item.id));
            }


            var res = obsList2.FirstOrDefault(x => x.Text == App.SaleOrderLayout);
            if (res != null)
            {
                this.SelectedSalesPrintLayoutObject = res as SimpleObject;
            }

            this.layoutSource2 = obsList2;

        }

        public async System.Threading.Tasks.Task ExecuteLoadItemSearch()
        {

            Dictionary<string, string> ListItemSearch = new Dictionary<string, string>();
            ListItemSearch.Add(AppResources.Tous, "all");
            ListItemSearch.Add(AppResources.Numero, "idno");
            ListItemSearch.Add(AppResources.Mot_de_recherche, "swdLower");
            //ListItemSearch.Add("Contact interne", "inhouseContact^descrOperLang");
            ListItemSearch.Add(AppResources.Nom, "descrOperLangLower");
            ListItemSearch.Add(AppResources.Adresse, "addrLower");
            ListItemSearch.Add(AppResources.Ville, "townLower");
            ListItemSearch.Add(AppResources.Code_postal, "zipCode");
            ListItemSearch.Add(AppResources.Pays, "ctryCodeLower");
            ListItemSearch.Add(AppResources.Telephone_fixe, "phoneNo");
            ListItemSearch.Add(AppResources.Telephone_mobile, "cellPhoneNo");

            ObservableCollection<IItemList> obsList3 = new ObservableCollection<IItemList>();

            //var PrintCollectiveLayout = await Service.ReadList<PrintCollectiveLayout>(null, filterFields);

            foreach (KeyValuePair<string, string> item in ListItemSearch)
            {
                obsList3.Add(new SimpleObject(item.Key, item.Value));
            }


            var res = obsList3.FirstOrDefault(x => x.Id == App.ItemSearch);
            if (res != null)
            {
                this.selectedItemSearchObject = res as SimpleObject;
            }

            this.LayoutSource3 = obsList3;

        }

        public async System.Threading.Tasks.Task ExecuteLoadPrinterSearch()
        {

            List<FilterField> filterFields = new List<FilterField>();            
            FilterField filterField2 = new FilterField() { FieldName = "active", Operator = "==", Value = "1" };
            filterFields.Add(filterField2);

            ObservableCollection<IItemList> obsList4 = new ObservableCollection<IItemList>();

            var PrintCollectiveLayout = await Service.ReadList<PrintType>(null, filterFields);



            foreach (var item in PrintCollectiveLayout)
            {
                obsList4.Add(new SimpleObject(item.swd, item.idno.ToString()));
            }


            var res = obsList4.FirstOrDefault(x => x.Text == App.PrintType);
            if (res != null)
            {
                this.SelectedPrinterSearchObject = res as SimpleObject;
            }

            this.LayoutSource4 = obsList4;

        }
        

    }

}

