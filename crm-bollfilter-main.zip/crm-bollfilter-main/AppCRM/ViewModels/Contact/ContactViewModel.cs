﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using Abas_Shared_Xamarin;
using Xamarin.Forms;
using System;
using AppCRM.Resx;
using AppCRM.CRMModels;

namespace AppCRM.ViewModels
{

    public class ContactViewModel : BaseViewModel
    {
        public Command EditCommand { get; set; }
        public event EventHandler OnEdit;

        public CustomerTypes CustomerType { get; private set; }
        public string IdCustomer { get; private set; }

        private Tiers tiers;
        public Tiers Tiers
        {
            get { return tiers; }
            set
            {
                SetProperty(ref tiers, value);
                this.OnPropertyChanged("DisplayAddress");
                this.OnPropertyChanged("DisplayAddress2");
            }
        }

        private ActivityObject activity;
        public ActivityObject Activity
        {
            get { return activity; }
            set
            {
                SetProperty(ref activity, value);
            }
        }

        public bool DisplayAddress
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Tiers.addr);
            }
        }

        public bool DisplayAddress2
        {
            get
            {
                return !string.IsNullOrWhiteSpace(this.Tiers.addr2);
            }
        }

        public ContactViewModel(Tiers customer, string id, CustomerTypes customerType)
        {
            this.CustomerType = customerType;
            this.IdCustomer = id;
            var task = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh();
            });
            task.Wait();
        }

        public async System.Threading.Tasks.Task Refresh()
        {
            this.EditCommand = new Command(async () => await ExecuteEditCommand());
            if (this.CustomerType == CustomerTypes.CONTACT_CUSTOMER)
            {
                this.Tiers = this.Service.ReadOffline<ContactCustomer>(this.IdCustomer).Result;
            }
            else if (this.CustomerType == CustomerTypes.CONTACT_PROSPECT)
            {
                this.Tiers = this.Service.ReadOffline<ContactProspect>(this.IdCustomer).Result;
            }

            this.Prefix = AppResources.Contact;
            this.Page = this.Tiers.descrOperLang;

            await System.Threading.Tasks.Task.Run(async () =>
            {
                this.Activity = await this.Service.GetActivity(this.IdCustomer);
            });
        }

        async System.Threading.Tasks.Task ExecuteEditCommand()
        {
            if (this.OnEdit != null)
            {
                this.OnEdit(this, null);
            }
        }
    }
}
