﻿using System;
using Xamarin.Forms;
using Abas_Shared_Xamarin.Models;
using AppCRM;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using AppCRM.Resx;
using System.Linq;
using Abas_Shared_Xamarin;
using AppCRM.ViewModels.Services;
using System.Globalization;
using AppCRM.Services;

namespace AppCRM.ViewModels
{
    public class AddUpdateContactViewModel : StackedBaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }

        public delegate void OnBusyDelegate(bool busy);
        public event OnBusyDelegate OnBusy;
        public delegate void OnErrorDelegate(string message);
        public event OnErrorDelegate OnError;
        public delegate void DialogEventHandler(string title, string msg);
        public event DialogEventHandler DialogEvent;

        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        public CustomerTypes CustomersType { get; private set; }

        private Tiers Customer;

        private Tiers tiers;
        public Tiers Tiers
        {
            get
            {
                return tiers;
            }
            set
            {
                SetProperty(ref tiers, value);
            }
        }

        public AddUpdateContactViewModel(CustomerTypes customerType, Tiers Customer, Tiers obj = null)
        {
            this.CustomersType = customerType;
            this.Customer = Customer;

            var task = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.Refresh(obj);
            });
            task.Wait();
        }

        public async System.Threading.Tasks.Task Refresh(Tiers obj)
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());

            if (obj == null)
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        this.Tiers = new ContactCustomer() { companyARAP = this.Customer.id };
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        this.Tiers = new ContactProspect() { companyARAP = this.Customer.id };
                        break;
                }

                this.Prefix = AppResources.Creer_un;
            }
            else
            {
                switch (this.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        this.tiers = obj;
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        this.tiers = obj;
                        break;
                }

                this.Prefix = AppResources.Modifier_un;
            }
            this.Page = AppResources.Contact.ToLower();
        }

        async System.Threading.Tasks.Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(true);
            }
            await System.Threading.Tasks.Task.Run(() =>
            {
                bool error = false;
                try
                {
                    if (this.ValidateMandatory())
                    {
                        System.Threading.Tasks.Task task = null;
                        this.ValidateSWD();
                        if (!string.IsNullOrWhiteSpace(this.Tiers.id))
                        {
                            switch (this.CustomersType)
                            {
                                case CustomerTypes.CONTACT_CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<ContactCustomer>(this.Tiers as ContactCustomer); });
                                    break;
                                case CustomerTypes.CONTACT_PROSPECT:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Update<ContactProspect>(this.Tiers as ContactProspect); });
                                    break;
                            }
                        }
                        else
                        {
                            switch (this.CustomersType)
                            {
                                case CustomerTypes.CONTACT_CUSTOMER:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<ContactCustomer>(this.Tiers as ContactCustomer, true); });
                                    break;
                                case CustomerTypes.CONTACT_PROSPECT:
                                    task = System.Threading.Tasks.Task.Run(async () => { await this.Service.Create<ContactProspect>(this.Tiers as ContactProspect, true); });
                                    break;
                            }
                        }                     
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            DependencyService.Get<AppCRM.Services.IMessage>().LongAlert(AppResources.UpdatedData);
                        });

                        task.Wait();
                    }
                    else
                    {
                        error = true;
                    }
                }
                catch (Exception e)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnError != null)
                        {
                            //DialogEvent(AppResources.Error, e.Message);
                            this.OnError(e.Message);
                        }
                    });
                    error = true;
                }
                if (!error)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnValidate != null)
                        {
                            //DependencyService.Get<IMessage>().LongAlert(AppResources.UpdatedData);
                            this.OnValidate(this, null);
                        }
                    });
                }
                else
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.OnBusy != null)
                        {
                            this.OnBusy(false);
                        }
                    });
                }
            });
        }

        private void ValidateSWD()
        {
            if (string.IsNullOrEmpty(this.Tiers.swd))
            {
                this.Tiers.swd = this.Customer.swd;
            }
            if (this.Tiers.swd.Length > 8)
            {
                this.Tiers.swd = this.Tiers.swd.Substring(0, 8);
            }
        }

        bool ValidateMandatory()
        {
            return !string.IsNullOrWhiteSpace(this.Tiers.descrOperLang);
        }

        async System.Threading.Tasks.Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }
    }
}