﻿using System.Threading.Tasks;
using Abas_Shared_Xamarin.Models;
using System.Collections.Generic;
using WFramework_Xamarin.Table;
using AppCRM.Resx;

namespace AppCRM.ViewModels
{

    public class ContactsMapViewModel : BaseViewModel
    {

        public string IdTiers { get; private set; }
        /*
        private List<Tiers> contacts;
        public List<Tiers> Contacts
        {
            get { return contacts; }
            set
            {
                SetProperty(ref contacts, value);
            }
        }
        */

        private const int RANGE = 50;

        public event OnContactsLoadedDelegate OnContactsLoaded;
        public delegate void OnContactsLoadedDelegate(List<Tiers> contacts, CustomerTypes customerType);


        public ContactsMapViewModel(string idTiers, CustomerTypes customerType, double latitudeSud, double latitudeNord, double longitudeOuest, double longitudeEst)
        {
            this.IdTiers = idTiers;
            //this.Customer = this.Service.GetCustomerAsync(id).Result; 
            this.Prefix = "";
            this.Page = AppResources.Carte;

            //this.Customers = new List<Customer>(this.Service.ReadList<Customer>().Result);

            System.Threading.Tasks.Task.Run(() =>
            {
                this.GetContacts(0, customerType);
            });
        }

        private void GetContacts(int currentPage, CustomerTypes customerType)
        {
            List<FilterField> filterFields = new List<FilterField>();
            filterFields.Add(new FilterField() { FieldName = "companyARAP", Operator = "==", Value = this.IdTiers });
            

            List<Tiers> tiers = null;
            if (customerType == CustomerTypes.CUSTOMER)
            {
                tiers = new List<Tiers>(this.Service.ReadList<ContactCustomer>(null, filterFields, currentPage, RANGE).Result);
            }
            else
            {
                tiers = new List<Tiers>(this.Service.ReadList<ContactProspect>(null, filterFields, currentPage, RANGE).Result);
                //List<Customer> customers = new List<Customer>(this.Service.GetProspectsAsync(null, currentPage, RANGE).Result); 
            }

            if (tiers != null && tiers.Count > 0)
            {
                if (this.OnContactsLoaded != null)
                {
                    this.OnContactsLoaded(tiers, customerType);
                    this.GetContacts(currentPage + 1, customerType);
                }
            }
        }

    }
}

