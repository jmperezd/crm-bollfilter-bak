﻿using System;
using Xamarin.Forms;

namespace AppCRM
{
    public interface IKeyboardHelper
    {
        void HideKeyboard();
    }
}

