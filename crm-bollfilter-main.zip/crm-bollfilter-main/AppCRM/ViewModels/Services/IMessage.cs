﻿using System;
namespace AppCRM.ViewModels.Services
{
    public interface IMessage
    {
        void LongAlert(string message);
        void ShortAlert(string message);
    }
}
