﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using Xamarin.Forms;

using Abas_Shared_Xamarin.Models;
using Abas_Shared_Xamarin.Services;
using Abas_Shared_Xamarin;

namespace AppCRM.ViewModels
{
    public class BaseViewModel : INotifyPropertyChanged
    {
        public IAbasService Service => DependencyService.Get<IAbasService>() ?? new AbasService();

        bool isBusy = false;
        public bool IsBusy
        {
            get { return isBusy; }
            set { SetProperty(ref isBusy, value); }
        }

        string title = string.Empty;
        public string Title
        {
            get { return title; }
            set
            {
                Context.Instance.CurrentPage = value;
                SetProperty(ref title, value);
            }
        }

        string page = string.Empty;
        public string Page
        {
            get { return page; }
            set
            {
                Context.Instance.CurrentPage = value;
                SetProperty(ref page, value);
            }
        }

        string prefix = string.Empty;
        public string Prefix
        {
            get { return prefix; }
            set
            {
                Context.Instance.CurrentPagePrefix = value;
                SetProperty(ref prefix, value);
            }
        }

        public bool ShowAddEditButton
        {
            get
            {
                bool haveConnection = Context.IsConnected;
                return haveConnection;
            }
        }

        protected bool SetProperty<T>(ref T backingStore, T value,
            [CallerMemberName] string propertyName = "",
            Action onChanged = null)
        {
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
                return false;

            backingStore = value;
            onChanged?.Invoke();
            OnPropertyChanged(propertyName);
            return true;
        }

        public Context Context
        {
            get { return Context.Instance; }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
