﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.Resx;
using AppCRM.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using WFramework_Xamarin;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using Xamarin.Forms;

namespace AppCRM.ViewModels
{

    public class ListDBOfflineViewModel : BaseViewModel
    {
        public delegate void DialogEventHandler(string title, string msg);
        public event DialogEventHandler DialogEvent;
        

        public ListDBOfflineViewModel(List<OfflineItems> listOfflineItems)
        {
            this.Prefix = AppResources.ListPendingUpload;
            this.Page = "";
        }                
    }
}
