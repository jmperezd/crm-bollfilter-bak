﻿using System;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ContactsProspectPage : ContentView, ITablePage
    {
        ContactsProspectViewModel viewModel;
        private TableTools TableTools;
        private TableToolsMobile TableToolsMobile;
        private PopupBusy PopupBusy;
        private Tiers Prospect;

        public delegate void OnSelectionDelegate(string id, string label, string swd);
        public event OnSelectionDelegate OnSelection;
        private bool SelectionMode { get; set; } = false;

        //responsive Part
        StackLayout StackLayout1;
        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                this.Refresh();
            }
        }

        public ContactsProspectPage(Tiers Prospect, bool selectionMode = false)
        {
            InitializeComponent();
            SetResponsiveVariables();
            this.Prospect = Prospect;
            NavigationPage.SetHasNavigationBar(this, false);
            this.SelectionMode = selectionMode;
            BindingContext = viewModel = new ContactsProspectViewModel(Prospect.id);
            this.viewModel.OnNewObject += ViewModel_OnNewObject;

            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.InitTableToolsMobile();
            }
            else
            {
                this.InitTableTools();
            }            
        }

        public void InitTableToolsMobile()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsMobile = new TableToolsMobile(this.StackLayout1, viewModel);
            this.TableToolsMobile.EnableGlobalSearch = true;
            this.TableToolsMobile.LinkAttribute = "id";
            this.TableToolsMobile.ArgAttributes = new List<string>() { "descrOperLang", "swd" };
            this.TableToolsMobile.PopupBusy = this.PopupBusy;
            this.TableToolsMobile.OnViewClicked += object_clicked;
            this.TableToolsMobile.PreviousClass = "contacts";
            this.TableToolsMobile.FirstColumnSize = 50;
            this.TableToolsMobile.SecondColumnSize = 50;
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayout1, viewModel);
            this.TableTools.EnableGlobalSearch = true;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.ArgAttributes = new List<string>() { "descrOperLang", "swd" };
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.OnViewClicked += object_clicked;
        }

        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    if (!this.SelectionMode)
                    {
                        Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                        ContactPage page = new ContactPage(Prospect, id, CustomerTypes.CONTACT_PROSPECT);
                        page.ParentPageContainer = this.ParentPageContainer;

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            this.ParentPageContainer.Content = page;
                            this.PopupBusy.Hide();
                        });
                    }
                    else
                    {
                        if (this.OnSelection != null)
                        {
                            this.OnSelection(id, dicoArgs["descrOperLang"] as string, dicoArgs["swd"] as string);
                        }
                    }
                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateContact page = new AddUpdateContact(CustomerTypes.CONTACT_PROSPECT, this.Prospect);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsMobile.Init();
            }
            else
            {                
                this.TableTools.Init();
            }
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.StackLayout1 = this.StackLayout1Phone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.StackLayout1 = this.StackLayout1Tablet;
            }
        }
    }
}
