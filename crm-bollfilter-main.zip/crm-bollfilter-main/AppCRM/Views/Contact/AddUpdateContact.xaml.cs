﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Abas_Shared_Xamarin.Models;
using WFramework_Xamarin.Components;
using Abas_Shared_Xamarin;

using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class AddUpdateContact : ContentView
    {
        AddUpdateContactViewModel viewModel;
        private PopupBusy PopupBusy;

        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2, ContentFrame3;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public AddUpdateContact(CustomerTypes customerType, Tiers customer, Tiers obj = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateContactViewModel(customerType, customer, obj);

            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;
            this.ContentFrame3.ContentView.BindingContext = this.viewModel;

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;
        }

        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert("info", message, "OK"));
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = ContentFrame1Phone;
                this.ContentFrame2 = ContentFrame2Phone;
                this.ContentFrame3 = ContentFrame3Phone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = ContentFrame1Tablet;
                this.ContentFrame2 = ContentFrame2Tablet;
                this.ContentFrame3 = ContentFrame3Tablet;
            }
        }
    }
}
