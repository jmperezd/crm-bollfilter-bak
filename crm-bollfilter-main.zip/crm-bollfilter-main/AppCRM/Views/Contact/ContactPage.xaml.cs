﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using System;
using WFramework_Xamarin;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class ContactPage : ContentView, IRefreshable
    {
        private ContactViewModel viewModel { get; set; }
        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2, ContentFrame3;
        Label LinkMail, LinkWebSite, phoneNo, cellPhoneNo, phoneNo2, cellPhoneNo2;
        StackLayout LinkAddress, LinkAddress2;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Popup PopupNewObject;


        public ContactPage(Tiers customer, string id, CustomerTypes customerType)
        {
            InitializeComponent();
            SetResponsiveVariables();
            BindingContext = viewModel = new ContactViewModel(customer, id, customerType);
            this.viewModel.OnEdit += this.ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
            this.ContentFrame3.ContentView.BindingContext = viewModel;

            this.PopupNewObject = new Popup(this);
            SetResponsiveEvents(id);
        }

        private void SetResponsiveEvents(string id)
        {
            LinkMail.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.Mail(this.viewModel.Tiers.emailAddr))
            });
            LinkWebSite.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.WebSite(this.viewModel.Tiers.webSiteURL))
            });
            LinkAddress.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Tiers.zipCode + "," + this.viewModel.Tiers.town + "," + this.viewModel.Tiers.addr + "," + this.viewModel.Tiers.street))
            });
            LinkAddress2.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Tiers.zipCode2 + "," + this.viewModel.Tiers.town2 + "," + this.viewModel.Tiers.addr2 + "," + this.viewModel.Tiers.street2))
            });

            phoneNo.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.PhoneCall(this.viewModel.Tiers.phoneNo))
            });

            cellPhoneNo.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.PhoneCall(this.viewModel.Tiers.cellPhoneNo))
            });

            phoneNo2.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.PhoneCall(this.viewModel.Tiers.phoneNo2))
            });

            cellPhoneNo2.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.PhoneCall(this.viewModel.Tiers.cellPhoneNo2))
            });
        }

        private void ShowPage(ITablePage page)
        {
            //this.PopupBusy.Show();
            try
            {
                Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ParentPageContainer.Content = page as ContentView;
                    page.ParentPageContainer = this.parentPageContainer;
                    //this.PopupBusy.Hide();
                });

            }
            catch (Exception ex)
            {
                //this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });

                    //AddUpdateCustomer page = new AddUpdateCustomer(this.viewModel.CustomerType, null, this.viewModel.Tiers);
                    AddUpdateContact page = new AddUpdateContact(this.viewModel.CustomerType, this.viewModel.Tiers, this.viewModel.Tiers);

                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.viewModel.Refresh();
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.ContentFrame2 = this.ContentFrame2Phone;
                this.ContentFrame3 = this.ContentFrame3Phone;
                this.LinkMail = this.LinkMailPhone;
                this.LinkWebSite = this.LinkWebSitePhone;
                this.LinkAddress = this.LinkAddressPhone;
                this.LinkAddress2 = this.LinkAddress2Phone;
                this.phoneNo = this.phoneNoPhone;
                this.cellPhoneNo = this.cellPhoneNoPhone;
                this.phoneNo2 = this.phoneNo2Phone;
                this.cellPhoneNo2 = this.cellPhoneNo2Phone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
                this.ContentFrame3 = this.ContentFrame3Tablet;
                this.LinkMail = this.LinkMailTablet;
                this.LinkWebSite = this.LinkWebSiteTablet;
                this.LinkAddress = this.LinkAddressTablet;
                this.LinkAddress2 = this.LinkAddress2Tablet;
                this.phoneNo = this.phoneNoTablet;
                this.cellPhoneNo = this.cellPhoneNoTablet;
                this.phoneNo2 = this.phoneNo2Tablet;
                this.cellPhoneNo2 = this.cellPhoneNo2Tablet;
            }
        }
    }
}
