﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.Resx;
using AppCRM.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using TK.CustomMap;
using WFramework_Xamarin;
using WFramework_Xamarin.Components;
using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class ContactsMap : ContentView
    {
        private ContactsMapViewModel viewModel { get; set; }
        public string IdTiers { get; private set; }
        public CustomerTypes CustomerType { get; private set; }
        private Tiers tier;
        //responsive Part
        ContentFrame ContentFrame1;
        TKCustomMap Map;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Dictionary<string, string> PinnedContacts { get; set; } = new Dictionary<string, string>();

        private PopupBusy PopupBusy;

        private int CurrentMAJId = 0;


        public ContactsMap(string idTiers, CustomerTypes customerType)
        {
            InitializeComponent();
            SetResponsiveVariables();

            Map.IsShowingUser = false;
            this.IdTiers = idTiers;
            this.CustomerType = customerType;

            this.Map.PropertyChanged += this.MapPropertyChanged;
            this.PopupBusy = new PopupBusy(this.ContentFrame1);

            this.Map.Pins = this.Pins;
            this.Map.CalloutClicked += this.CalloutClicked;
            this.Map.PinSelected += this.PinSelected;
            this.Map.MapClicked += this.MapClicked;

            var task = System.Threading.Tasks.Task.Run(async delegate
            {
                Plugin.Geolocator.Abstractions.Position position = MapTools.GetCurrentPosition().Result;

                await System.Threading.Tasks.Task.Delay(TimeSpan.FromSeconds(2));
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (position != null)
                    {
                        try
                        {
                            Map.IsShowingUser = true;
                            this.Map.MapRegion = MapSpan.FromCenterAndRadius(new Position(position.Latitude, position.Longitude), Distance.FromKilometers(1200));
                        }
                        catch (Exception e)
                        {
                            DialogEvent(AppResources.Error, e.Message);
                        }                        
                    }
                });
                return 0;
            });
            task.Wait();

        }

        public async void DialogEvent(string errorTitle, string errorMsg)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert(errorTitle, errorMsg, "OK"));
        }

        private void CalloutClicked(object sender, TKGenericEventArgs<TKCustomMapPin> e)
        {
            Tuple<string, PlaceTypes> bindingContext = e.Value.BindingContext as Tuple<string, PlaceTypes>;
            //PlaceTypes? placeType = e.Value.BindingContext as PlaceTypes?;
            if (bindingContext != null)
            {
                this.ShowContact(bindingContext.Item1, bindingContext.Item2);
                //this.ButtonShowDirection.IsVisible = false;
                this.Map.SelectedPin = null;
            }
        }

        private void PinSelected(object sender, TKGenericEventArgs<TKCustomMapPin> e)
        {

        }

        private void MapClicked(object sender, TKGenericEventArgs<Position> e)
        {

            this.Map.SelectedPin = null;
        }

        private void MapPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "MapRegion")
            {
                this.CurrentMAJId++;
                System.Threading.Tasks.Task.Run(() => PlacePins(CurrentMAJId));
            }
        }

        private void PlacePins(int id)
        {
            System.Threading.Tasks.Task.Run(async () =>
            {
                await System.Threading.Tasks.Task.Delay(100);

                if (id == this.CurrentMAJId)
                {
                    this.InitMap();
                }
            });
        }

        public async System.Threading.Tasks.Task InitMap()
        {
            //Task.Run(() =>
            //{
            //Plugin.Geolocator.Abstractions.Position position = MapTools.GetCurrentPosition().Result;

            var latitudeSud = this.Map.MapCenter.Latitude - this.Map.MapRegion.LatitudeDegrees / 2;
            var latitudeNord = this.Map.MapCenter.Latitude + this.Map.MapRegion.LatitudeDegrees / 2;

            var longitudeOuest = this.Map.MapCenter.Longitude - this.Map.MapRegion.LongitudeDegrees / 2;
            var longitudeEst = this.Map.MapCenter.Longitude + this.Map.MapRegion.LongitudeDegrees / 2;

            Coordonnee coordonnees = new Coordonnee(longitudeEst, longitudeOuest, latitudeNord, latitudeSud);

            BindingContext = viewModel = new ContactsMapViewModel(this.IdTiers, this.CustomerType, latitudeSud, latitudeNord, longitudeOuest, longitudeEst);//coordonnees);
            viewModel.OnContactsLoaded += ViewModel_OnContactsLoaded;

            this.ContentFrame1.ContentView.BindingContext = viewModel;

        }

        private ObservableCollection<TKCustomMapPin> Pins = new ObservableCollection<TKCustomMapPin>();

        private void PlacePinOnMap(double lat, double lon, string label, string address, string id, PlaceTypes type)
        {
            var position = new Position(lat, lon); // Latitude, Longitude
            var pin = new TKCustomMapPin()
            {
                Position = position,
                Title = label,
                Subtitle = address,
                BindingContext = new Tuple<string, PlaceTypes>(id, type),
                ShowCallout = true,
                IsCalloutClickable = true

            };
            if (type == PlaceTypes.CUSTOMER)
            {
                pin.DefaultPinColor = Color.Maroon;
                pin.Image = new Image() { Source = "pinGreen.png" }.Source;
                pin.Group = "Clients";
            }
            else if (type == PlaceTypes.PROSPECT)
            {
                pin.DefaultPinColor = Color.LightSteelBlue;
                pin.Image = new Image() { Source = "pinDark.png" }.Source;
                pin.Group = "Chantiers";
            }
            this.Pins.Add(pin);
        }

        void ViewModel_OnContactsLoaded(List<Tiers> tiers, CustomerTypes customerType)
        {
            foreach (Tiers _tiers in tiers)
            {
                if (!this.PinnedContacts.ContainsKey(_tiers.id))
                {

                    double lat = ToolsHelper.ConvertToDouble(_tiers.latitude);
                    double lon = ToolsHelper.ConvertToDouble(_tiers.longitude);

                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        try
                        {
                            if (!(lat == -1 && lon == 0 || lat == 0 && lon == 0))
                            { 
                                this.PlacePinOnMap(lat, lon, _tiers.descrOperLang, string.Format("{0} {1} {2}", _tiers.addr, _tiers.street, _tiers.town), _tiers.id.ToString(), customerType == CustomerTypes.CUSTOMER ? PlaceTypes.CUSTOMER : PlaceTypes.PROSPECT);
                            }
                            this.PinnedContacts.Add(_tiers.id, string.Empty);
                        }
                        catch (Exception e)
                        {

                        }
                    });
                }
            }
        }


        private void ShowContact(string id, PlaceTypes placeType)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ContentView page;
                    if (placeType == PlaceTypes.CUSTOMER)
                    {
                        page = new ContactPage(tier, id, CustomerTypes.CUSTOMER);
                        (page as ContactPage).ParentPageContainer = this.ParentPageContainer;
                    }
                    else
                    {
                        page = new ContactPage(tier, id, CustomerTypes.PROSPECT);
                        (page as ContactPage).ParentPageContainer = this.ParentPageContainer;
                    }

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.Map = this.MapPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.Map = this.MapTablet;
            }
        }
    }

    public enum PlaceTypes
    {
        PROSPECT,
        CUSTOMER
    }
}
