﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.Resx;
using AppCRM.ViewModels;
using System;
using System.Collections.Generic;
using WFramework_Xamarin;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ListDBOffline : ContentView
    {
        ListDBOfflineViewModel viewModel;
        
        private PopupBusy PopupBusy;


        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public ListDBOffline(List<OfflineItems> listOfflineItems)
        {
            InitializeComponent();

            NavigationPage.SetHasNavigationBar(this, false);

            BindingContext = viewModel = new ListDBOfflineViewModel(listOfflineItems);
            this.viewModel.DialogEvent += DialogEvent;
            this.InitListView(listOfflineItems);
        }
        private void DialogEvent(string title, string msg)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert(title, msg, "OK"));
        }

        public void InitListView(List<OfflineItems> listOfflineItems)
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();


            //Vide la liste des prestations
            this.StackLayoutListDB.Children.Clear();

            try
            {
                int i = 0;
                if (listOfflineItems.Count != 0)
                {
                    foreach (OfflineItems offlineItem in listOfflineItems)
                    {
                        if (i > 0)
                        {
                            BoxView separator = new BoxView() { Style = (Style)Application.Current.Resources["horizontalSeparator"] };
                            Device.BeginInvokeOnMainThread(() =>
                            {
                                this.StackLayoutListDB.Children.Add(separator);
                            });
                        }

                        Grid horizontalEventGrid = new Grid() { RowSpacing = 0, ColumnSpacing = 0 };
                        horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(90) });
                        horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = 2 });
                        horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });


                        //Left Panel
                        StackLayout startTimeStackLayout = new StackLayout() { HorizontalOptions = LayoutOptions.FillAndExpand, Spacing = 0 };
                        Grid.SetRow(startTimeStackLayout, 0);
                        Grid.SetColumn(startTimeStackLayout, 0);
                        horizontalEventGrid.Children.Add(startTimeStackLayout);



                        StackLayout stackLayoutDate = new StackLayout() { Style = (Style)Application.Current.Resources["dateEventStackLayoutService"], Padding = new Thickness(10, 10, 10, 10) };
                        startTimeStackLayout.Children.Add(stackLayoutDate);

                        //Date
                        Label dateLabel = new Label() { Text = offlineItem.Time.ToString("dd/MM/yyyy"), Style = (Style)Application.Current.Resources["dateEventLabel"] };
                        stackLayoutDate.Children.Add(dateLabel);

                        //Time
                        //ToolsHelper.FormatDate(offlineItem.Time.ToShortDateString());
                        Label timeLabel = new Label() { Text = offlineItem.Time.ToShortTimeString(), Style = (Style)Application.Current.Resources["dateEventLabel"] };
                        stackLayoutDate.Children.Add(timeLabel);


                        //Vertical separator
                        BoxView verticalSeparator = new BoxView() { Color = Color.FromHex("1BB8A3"), HorizontalOptions = LayoutOptions.FillAndExpand };
                        Grid.SetRow(startTimeStackLayout, 0);
                        Grid.SetColumn(verticalSeparator, 1);
                        horizontalEventGrid.Children.Add(verticalSeparator);


                        //Details
                        StackLayout eventDetailsStackLayout = new StackLayout() { Padding = new Thickness(15, 8, 10, 0) };
                        Grid.SetRow(eventDetailsStackLayout, 0);
                        Grid.SetColumn(eventDetailsStackLayout, 2);
                        horizontalEventGrid.Children.Add(eventDetailsStackLayout);


                        //Title
                        StackLayout stackLayoutTitle = new StackLayout();

                        stackLayoutTitle = new StackLayout() { Style = (Style)Application.Current.Resources["eventTitleStackLayout"] };
                        eventDetailsStackLayout.Children.Add(stackLayoutTitle);
                        Label eventDetailsTitle = new Label() { Text = AppResources.Class, Style = (Style)Application.Current.Resources["eventDetailsTitle"] };
                        stackLayoutTitle.Children.Add(eventDetailsTitle);


                        string title = offlineItem.Title;
                        string titulo1 = AppResources.Partenaire_commercial;
                        string description = AppResources.Destinataire_marchandise;
                        
                        switch (offlineItem.Title)
                        {
                            case "Quotation":
                                title = AppResources.Offres;                                
                                break;
                            case "Opportunity":
                                title = AppResources.Opportunites;
                                break;
                            case "Order":
                                title = AppResources.Commandes;
                                break;
                            case "Note":
                                title = AppResources.Notes;
                                titulo1 = AppResources.Titre;
                                description = AppResources.Description;
                                break;
                            case "Prospect":
                                title = AppResources.Prospects;
                                titulo1 = AppResources.Instance;
                                description = AppResources.Interlocuteur;
                                break;
                            case "Tasks":
                                title = AppResources.Taches;
                                titulo1 = AppResources.Titre;
                                description = AppResources.Description;
                                break;
                        }
                        Label classLabel = new Label() { Text = title, TextColor = Color.FromHex("1BB8A3") };
                        stackLayoutTitle.Children.Add(classLabel);

                        Label socioComercialLabel = new Label() { Text = titulo1 + ": " + offlineItem.SocioComercial, Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                        if (!string.IsNullOrEmpty(offlineItem.SocioComercial))
                        {
                            eventDetailsStackLayout.Children.Add(socioComercialLabel);
                        }

                        Label destinatarioMercanciasLabel = new Label() { Text = description + ": " + offlineItem.DestinatarioMercancias, Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                        if (!string.IsNullOrEmpty(offlineItem.DestinatarioMercancias))
                        {
                            eventDetailsStackLayout.Children.Add(destinatarioMercanciasLabel);
                        }

                        if (offlineItem.listArticles != null)
                        {
                            Label numberArticles = new Label() { Text = AppResources.NumberArticles + offlineItem.listArticles.Count.ToString(), Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                            eventDetailsStackLayout.Children.Add(numberArticles);

                            foreach (SaleProduct article in offlineItem.listArticles)
                            {
                                Label articleLabel = new Label() { Text = article.product_descrOperLang + ": " + article.unitQty + " Items", Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                                eventDetailsStackLayout.Children.Add(articleLabel);
                            }
                        }

                        Device.BeginInvokeOnMainThread(() =>
                        {
                        //if (!offlineItem.IsService)
                        //{                            
                        //    horizontalEventGrid.BackgroundColor = Color.FromHex("F2F2F2");                            
                        //}
                        this.StackLayoutListDB.Children.Add(horizontalEventGrid);
                        });

                        i++;
                    }
                }
            }
            catch (Exception e)
            {

            }



            this.PopupBusy.Hide();
        }

        public void Refresh()
        {
        }
    }
}