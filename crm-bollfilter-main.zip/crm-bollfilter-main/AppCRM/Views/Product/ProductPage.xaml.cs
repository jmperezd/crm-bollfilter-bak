﻿using System;
using System.Collections.Generic;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using WFramework_Xamarin;
using WFramework_Xamarin.Components;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProductPage : ContentView
    {
        private ProductViewModel viewModel { get; set; }
        public Popup PopupNewObject;

        public ProductPage(Product article)
        {
            InitializeComponent();
            BindingContext = viewModel = new ProductViewModel(article);
            ContentFrame1Phone.ContentView.BindingContext = viewModel;

            linkCatalog.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.WebSite(this.viewModel.Catalog))
            });
        }
    }
}
