﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Abas_Shared_Xamarin.Models;
using WFramework_Xamarin.Components;
using Xamarin.Forms;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    public partial class AddUpdateSaleProduct : ContentView
    {
        public AddUpdateSaleProductViewModel viewModel;
        private PopupBusy PopupBusy;

        //responsive Part
        Picker SearchableListTradeUnitObjects;
        LineEntry Entry1;
        Label titlePopUp;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public AddUpdateSaleProduct(string idProduct = null, SaleProduct saleProduct = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateSaleProductViewModel(idProduct, saleProduct);

            //On Title Click
            var tapGestureRecognizer = new TapGestureRecognizer();
            tapGestureRecognizer.Tapped += (s, e) => {
                this.TitleTapped(s, e);
            };
            titlePopUp.GestureRecognizers.Add(tapGestureRecognizer);

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnDelete += this.Delete;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;
            viewModel.OnTradeUnitObjectsLoaded += ViewModel_OnTradeUnitObjectsLoaded;

            /*
            this.Entry1.Completed += (sender, e) => {
                this.viewModel.ValidateCommand.Execute(null);
            };
            */
        }

        void ViewModel_OnTradeUnitObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListTradeUnitObjects.ItemsSource = this.viewModel.TradeUnitsList;
                this.SearchableListTradeUnitObjects.SelectedIndexChanged += SearchableListTradeUnitObjects_OnSelection;
                this.SearchableListTradeUnitObjects.SelectedItem = this.viewModel.SelectedTradeUnitObject.Text;

                this.Entry1.Focus();
            });

        }

        public event EventHandler OnTitleTapped;
        void TitleTapped(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnTitleTapped != null)
            {
                this.OnTitleTapped(sender, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(sender, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        public event EventHandler OnDelete;
        void Delete(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnDelete != null)
            {
                this.OnDelete(sender, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
        }

        async void SearchableListTradeUnitObjects_OnSelection(object sender, EventArgs e)
        {
            Picker picker = sender as Picker;
            if(picker.SelectedIndex != -1)
            {
                this.viewModel.SelectedTradeUnitObject = this.viewModel.TradeUnits[picker.SelectedIndex] as SimpleObject;
            }
        }

        void ViewModel_OnLoadSaleProduct(SaleProduct saleProduct)
        {

        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.SearchableListTradeUnitObjects = this.SearchableListTradeUnitObjectsPhone;
                this.Entry1 = this.Entry1Phone;
                this.titlePopUp = this.titlePopUpPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.SearchableListTradeUnitObjects = this.SearchableListTradeUnitObjectsTablet;
                this.Entry1 = this.Entry1Tablet;
                this.titlePopUp = this.titlePopUpTablet;
            }
        }

    }
}
