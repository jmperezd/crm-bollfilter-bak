﻿using System;
using System.Collections.Generic;
using AppSAV.ViewModels;
using Abas_Shared_Xamarin.Models;
using WFramework_Xamarin.Components;
using Xamarin.Forms;
using Abas_Shared_Xamarin;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin;

namespace AppSAV.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ArticlePage : ContentView
    {
        private ArticleViewModel viewModel { get; set; }
        public Popup PopupNewObject;

        public ArticlePage(Product article)
        {
            InitializeComponent();            
            BindingContext = viewModel = new ArticleViewModel(article);
            ContentFrame1Phone.ContentView.BindingContext = viewModel;

            linkCatalog.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.WebSite(this.viewModel.Catalog))
            });
        }
    }
}
