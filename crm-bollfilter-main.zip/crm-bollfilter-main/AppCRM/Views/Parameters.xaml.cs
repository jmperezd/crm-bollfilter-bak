﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using AppCRM.ViewModels;
using WFramework_Xamarin.Components;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    public partial class Parameters : ContentView
    {
        private ContentView parentPageContainer;

        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2;
        SearchableList SearchableListItemSearchDisplay, SearchableListQuotationDisplay, SearchableListSalesDisplay, SearchableListPrinterDisplay;

        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Context Context
        {
            get { return Context.Instance; }
        }

        private ParametersViewModel viewModel { get; set; }

        public Parameters()
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.BindingContext = this.viewModel = new ParametersViewModel();
            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;


            this.viewModel.ExecuteLoadQuotationPrintLayout().ContinueWith((arg) => this.SearchableListQuotationDisplay.ItemsSource = this.viewModel.LayoutSource).ContinueWith(HandleActionQuotation);
            this.SearchableListQuotationDisplay.OnSelection += SearchableListQuotationDisplay_OnSelection;

            this.viewModel.ExecuteLoadSalesPrintLayout().ContinueWith((arg) => this.SearchableListSalesDisplay.ItemsSource = this.viewModel.LayoutSource2).ContinueWith(HandleActionSales);
            this.SearchableListSalesDisplay.OnSelection += SearchableListSalesDisplay_OnSelection;

            this.viewModel.ExecuteLoadItemSearch().ContinueWith((arg) => this.SearchableListItemSearchDisplay.ItemsSource = this.viewModel.LayoutSource3).ContinueWith(HandleActionItemSearch);
            this.SearchableListItemSearchDisplay.OnSelection += SearchableListItemSearch_OnSelection;

            this.viewModel.ExecuteLoadPrinterSearch().ContinueWith((arg) => this.SearchableListPrinterDisplay.ItemsSource = this.viewModel.LayoutSource4).ContinueWith(HandleActionItemSearch);
            this.SearchableListPrinterDisplay.OnSelection += SearchableListPrinterSearch_OnSelection;

            

            //this.ComboBoxOffre.ItemsSource
        }


        void HandleActionQuotation(System.Threading.Tasks.Task<System.Collections.ObjectModel.ObservableCollection<IItemList>> arg)
        {
            this.SearchableListQuotationDisplay.SelectedItem = this.viewModel.SelectedQuotationPrintLayoutObject;
        }

        void HandleActionSales(System.Threading.Tasks.Task<System.Collections.ObjectModel.ObservableCollection<IItemList>> arg)
        {
            this.SearchableListSalesDisplay.SelectedItem = this.viewModel.SelectedSalesPrintLayoutObject;
        }

        void HandleActionItemSearch(System.Threading.Tasks.Task<System.Collections.ObjectModel.ObservableCollection<IItemList>> arg)
        {
            this.SearchableListItemSearchDisplay.SelectedItem = this.viewModel.SelectedItemSearchObject;
        }

        async void SearchableListQuotationDisplay_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedQuotationPrintLayoutObject = this.SearchableListQuotationDisplay.SelectedItem as SimpleObject;
        }

        async void SearchableListSalesDisplay_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedSalesPrintLayoutObject = this.SearchableListSalesDisplay.SelectedItem as SimpleObject;
        }

        async void SearchableListItemSearch_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedItemSearchObject = this.SearchableListItemSearchDisplay.SelectedItem as SimpleObject;
        }

        async void SearchableListPrinterSearch_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedPrinterSearchObject = this.SearchableListPrinterDisplay.SelectedItem as SimpleObject;
        }        

        //IItemList item = new IItemList();
        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.SearchableListItemSearchDisplay = this.SearchableListItemSearchDisplayPhone;
                this.ContentFrame2 = this.ContentFrame2Phone;
                this.SearchableListQuotationDisplay = this.SearchableListQuotationDisplayPhone;
                this.SearchableListSalesDisplay = this.SearchableListSalesDisplayPhone;
                //this.SearchableListPrinterDisplay = this.SearchableListPrinterDisplayPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.SearchableListItemSearchDisplay = this.SearchableListItemSearchDisplayTablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
                this.SearchableListQuotationDisplay = this.SearchableListQuotationDisplayTablet;
                this.SearchableListSalesDisplay = this.SearchableListSalesDisplayTablet;
                this.SearchableListPrinterDisplay = this.SearchableListPrinterDisplayTablet;
            }
        }
    }
}
