﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Abas_Shared_Xamarin.Models;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using System.Linq;
using Abas_Shared_Xamarin;

using Xamarin.Forms;
using WFramework_Xamarin;

namespace AppCRM.Views
{
    public partial class AddUpdateTransaction : ContentView
    {

        AddUpdateTransactionViewModel viewModel;
        TransactionProductsViewModel transactionProductsViewModel;

        private TableTools TableTools;
        private TableToolsMobile TableToolsMobile;
        Product ProductSelected { get; set; }
        bool AddNewLine { get; set; }

        private PopupBusy PopupBusy;
        private Popup PopupAddUpdateSaleProduct;
        //responsive Part
        StackLayout StackLayoutProducts;
        SearchableList SearchableListRefusalReasons;
        CustomSelectorList SearchableListPayTerms;
        ContentFrame ContentFrame1, ContentFrame2;
        LinkedList LinkedListSelectionClient, LinkedListSelectionGoodsRecipient;

        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                SetTableToolsInit();
                
            }
        }

        private double calculateTableSpace()
        {
            return Application.Current.MainPage.Height - (ContentFrame1.IsVisible ? ContentFrame1.Height : 0) - (ContentFrame2.IsVisible ? ContentFrame2.Height : 0) - buttonValidateTablet .Height - 60 - 130;/*margins toolbar*/
        }

        private void SetTableToolsInit()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsMobile.Init();
            }
            else
            {
                this.TableTools.Init();
            }
        }

        public AddUpdateTransaction(TransactionTypes transactionType, string idObj = null, Transaction obj = null, string customerID = null, string customerName = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.PopupBusy = new PopupBusy(this);
            this.PopupAddUpdateSaleProduct = new Popup(this) { AllowUserClose = false };

            BindingContext = viewModel = new AddUpdateTransactionViewModel(transactionType, idObj, obj);

            this.StackLayoutProducts.BindingContext = transactionProductsViewModel = new TransactionProductsViewModel(idObj, this.viewModel.Transaction);
            this.transactionProductsViewModel.EditView = true;

            this.LinkedListSelectionClient.OnClick += LinkedListSelectionClient_OnClick;
            this.LinkedListSelectionGoodsRecipient.OnClick += LinkedListSelectionGoodsRecipient_OnClick;


            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;

            this.viewModel.OnValidate += this.Validate;
            this.viewModel.OnBusy += this.Busy;
            this.viewModel.OnError += ViewModel_OnError;

            this.viewModel.OnPayTermObjectsLoaded += ViewModel_OnPayTermObjectsLoaded;
            this.viewModel.OnRefusalReasonObjectsLoaded += ViewModel_OnRefusalReasonObjectsLoaded;
            this.viewModel.OnLoadCustomer += ViewModel_OnLoadCustomer;
            this.viewModel.OnLoadGoodsRecipient += ViewModel_OnLoadGoodsRecipient;
            this.viewModel.OnNewObject += ViewModel_OnNewObject;
            /*
            viewModel.OnContactObjectsLoaded += ViewModel_OnContactObjectsLoaded;
            viewModel.OnProductObjectsLoaded += ViewModel_OnProductObjectsLoaded;
            */
            ContentFrame2Tablet.IsVisible = viewModel.ShowAnalysis;
            ContentFrame2Phone.IsVisible = viewModel.ShowAnalysis;            

            this.viewModel.Init();
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.InitTableToolsMobile();
            }
            else
            {
                this.InitTableTools();
            }
            SetResponsiveVisibility();

            if (!string.IsNullOrEmpty(customerID) && !string.IsNullOrEmpty(customerName))
            {
                this.viewModel.Transaction.customer = customerID;
                this.viewModel.ShowAddProduct = true;
                this.LinkedListSelectionClient.ContentText = customerName;

                //Specific for Bralo and subiñas
                this.viewModel.Transaction.goodsRecipient = customerID;
                this.LinkedListSelectionGoodsRecipient.ContentText = customerName;
            }
        }

        private void SetResponsiveVisibility()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                ContentFrame2.IsVisible = this.viewModel.ShowAnalysis;
            }
        }

        public void InitTableToolsMobile()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsMobile = new TableToolsMobile(this.StackLayoutProducts, this.transactionProductsViewModel);
            this.TableToolsMobile.EnableGlobalSearch = false;
            this.TableToolsMobile.LinkAttribute = "id";
            this.TableToolsMobile.HiddenAttributes = new List<string>() { "rowNo", "product" };
            this.TableToolsMobile.ArgAttributes = new List<string>() { "rowNo", "id", "product", "unitQty" };
            this.TableToolsMobile.PopupBusy = this.PopupBusy;
            this.TableToolsMobile.ListFieldsAmount = new List<string>() { "itemValEntCurr", "price" };
            this.TableToolsMobile.OnViewClicked += TableTools_OnViewClicked;
            this.TableToolsMobile.FirstColumnSize = 40;
            this.TableToolsMobile.SecondColumnSize = 60;
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayoutProducts, this.transactionProductsViewModel);
            this.TableTools.EnableGlobalSearch = false;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.HiddenAttributes = new List<string>() { "rowNo", "product" };
            this.TableTools.ArgAttributes = new List<string>() { "rowNo", "id", "product", "unitQty" };
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.ListFieldsAmount = new List<string>() { "itemValEntCurr", "price" };
            this.TableTools.OnViewClicked += TableTools_OnViewClicked;
            this.TableTools.Finished += TableToolsFinished;

            //this.TableTools.OnViewClicked += object_clicked;
            //this.TableTools.PaddingSearchBar = 200;
        }

        private void TableToolsFinished()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                ScrollProductsTablet.HeightRequest = calculateTableSpace();
                ScrollProductsTablet.MinimumHeightRequest = calculateTableSpace();
            });            
        }

        void ViewModel_OnPayTermObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListPayTerms.ItemsSource = this.viewModel.PayTermObjects;
                this.SearchableListPayTerms.OnSelection += SearchableListPayTermObjects_OnSelection;
                this.SearchableListPayTerms.FirstItemSelected();
            });
        }
        void ViewModel_OnRefusalReasonObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListRefusalReasons.ItemsSource = this.viewModel.RefusalReasonObjects;
                this.SearchableListRefusalReasons.SelectedItem = this.viewModel.SelectedRefusalReasonObject;
                this.SearchableListRefusalReasons.OnSelection += SearchableListRefusalReasonObjects_OnSelection;
            });
        }




        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert("Info", message, "OK"));
        }

        void LinkedListSelectionClient_OnClick()
        {
            this.DisplaySelectContactPage(this.CustomersPageSelection_LinkedListSelectionCustomers_OnSelection);
        }

        void LinkedListSelectionGoodsRecipient_OnClick()
        {
            this.DisplaySelectContactPage(this.CustomersPageSelection_LinkedListSelectionGoodsRecipient_OnSelection);
        }

        private void DisplaySelectContactPage(CustomersPage.OnSelectionDelegate delegateToCall)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage customersPageSelection = null;
                    switch (this.viewModel.TransactionType)
                    {
                        case TransactionTypes.OPPORTUNITY:
                            customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER_PROSPECT, true);
                            break;
                        case TransactionTypes.QUOTATION:
                            customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER_PROSPECT, true);
                            break;
                        case TransactionTypes.ORDER:
                            customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER, true);
                            break;

                    }
                    customersPageSelection.OnSelection += delegateToCall;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = customersPageSelection;
                        customersPageSelection.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void CustomersPageSelection_LinkedListSelectionCustomers_OnSelection(string id, string label, string swd)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Transaction.customer = id;
                this.viewModel.ShowAddProduct = true;
                this.LinkedListSelectionClient.ContentText = label;
                this.viewModel.Transaction.nameSocioComercial = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        void CustomersPageSelection_LinkedListSelectionGoodsRecipient_OnSelection(string id, string label, string swd)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Transaction.goodsRecipient = id;
                this.LinkedListSelectionGoodsRecipient.ContentText = label;
                this.viewModel.Transaction.nameDestinatarioMercancias = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }


        async void SearchableListPayTermObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedPayTermObject = sender as SimpleObject;
        }

        async void SearchableListRefusalReasonObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedRefusalReasonObject = this.SearchableListRefusalReasons.SelectedItem as SimpleObject;
        }

        void ViewModel_OnLoadCustomer(Tiers tiers)
        {
            this.LinkedListSelectionClient.ContentText = tiers.descrOperLang;
        }

        void ViewModel_OnLoadGoodsRecipient(Tiers tiers)
        {
            this.LinkedListSelectionGoodsRecipient.ContentText = tiers.descrOperLang;
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ProductsPage productsPage = new ProductsPage(this.viewModel.Transaction.customer, true);
                    productsPage.OnSelectionProduct += ProductsPage_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = productsPage;
                        productsPage.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    DialogEvent("Info", ex.Message);
                    this.PopupBusy.Hide();
                }
            });
        }

        void ProductsPage_OnSelection(string id, string label, Product product, bool addNewLine = false)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                ProductSelected = product;
                AddNewLine = addNewLine;
                this.DisplayAddUpdateSaleProductPopup(id, null);
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        AddUpdateSaleProduct addUpdateSaleProduct;
        private void DisplayAddUpdateSaleProductPopup(string idProduct = null, SaleProduct saleProduct = null)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                addUpdateSaleProduct = new AddUpdateSaleProduct(idProduct, saleProduct);                
                this.PopupAddUpdateSaleProduct.ContentView = addUpdateSaleProduct;
                addUpdateSaleProduct.OnHide += this.PopupAddUpdateSaleProduct.OnHide;
                addUpdateSaleProduct.OnValidate += AddUpdateSaleProduct_OnValidate;
                addUpdateSaleProduct.OnTitleTapped += ShowArticle;
                addUpdateSaleProduct.OnDelete += AddUpdateSaleProduct_OnDelete;
                this.PopupAddUpdateSaleProduct.Show();
            });
        }

        void AddUpdateSaleProduct_OnValidate(object sender, EventArgs e)
        {
            bool found = false;
            SaleProduct saleProduct;
            //The quantity is modified before
            for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
            {
                saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                //If editing
                if (saleProduct.id != null && saleProduct.id == (sender as SaleProduct).id)
                {
                    saleProduct.startDateTime = DateTime.Now;
                    saleProduct.deadline = DateTime.Now;
                    double productTotalPrice = ToolsHelper.ConvertToDouble(saleProduct.price) * ToolsHelper.ConvertToDouble(saleProduct.unitQty);
                    if (saleProduct.percent == null)
                    {
                        saleProduct.percent = "0";
                    }
                    double percent = ToolsHelper.ConvertToDouble(saleProduct.percent);
                    saleProduct.itemValEntCurr = ((productTotalPrice * percent / 100) + productTotalPrice).ToString();

                    //if find, then stop the loop
                    SetTableToolsInit();
                    return;
                }
                //If the product exist
                if (saleProduct.product == (sender as SaleProduct).product)
                {
                    if (AddNewLine)
                    {
                        //Create a new Line
                        found = false;
                        break;
                    }
                    SaleProduct product = sender as SaleProduct;
                    product.startDateTime = DateTime.Now;
                    product.deadline = DateTime.Now;
                    product.price = ProductSelected.salesPrice.ToString();
                    double productTotalPrice = ToolsHelper.ConvertToDouble(product.price) * ToolsHelper.ConvertToDouble(product.unitQty);
                    if (product.percent == null)
                    {
                        product.percent = "0";
                    }
                    double percent = ToolsHelper.ConvertToDouble(product.percent);
                    product.itemValEntCurr = ((productTotalPrice * percent / 100) + productTotalPrice).ToString();

                    this.viewModel.Transaction.SubItems.RemoveAt(i);
                    this.viewModel.Transaction.SubItems.Insert(i, product);
                    found = true;
                    break;
                }
            }
            //Creating a new one
            if (!found)
            {

                SaleProduct product = sender as SaleProduct;
                product.startDateTime = DateTime.Now;
                product.deadline = DateTime.Now;
                product.price = ProductSelected.salesPrice.ToString();
                if (!string.IsNullOrWhiteSpace(this.viewModel?.Transaction?.id))
                {
                    product.id = null;
                }
                else
                {
                    product.id = ProductSelected.id;
                }

                product.id = "";
                double productTotalPrice = ToolsHelper.ConvertToDouble(product.price) * ToolsHelper.ConvertToDouble(product.unitQty);
                if (product.percent == null)
                {
                    product.percent = "0";
                }
                double percent = ToolsHelper.ConvertToDouble(product.percent);
                product.itemValEntCurr = ((productTotalPrice * percent / 100) + productTotalPrice).ToString();
                this.viewModel.Transaction.SubItems.Add(product);
            }
            SetTableToolsInit();
        }

        void AddUpdateSaleProduct_OnDelete(object sender, EventArgs e)
        {
            bool found = false;
            for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
            {
                SaleProduct saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                if (saleProduct.id != null && saleProduct.id == (sender as SaleProduct).id)
                {
                    found = true;
                    (this.viewModel.Transaction.SubItems[i] as SaleProduct).status = "A";
                }
            }
            if (!found)
            {
                for (int i = 0; i < this.viewModel.Transaction.SubItems.Count; i++)
                {
                    SaleProduct saleProduct = this.viewModel.Transaction.SubItems[i] as SaleProduct;
                    if (saleProduct.product == (sender as SaleProduct).product)
                    {
                        this.viewModel.Transaction.SubItems.RemoveAt(i);
                    }
                }
            }

            SetTableToolsInit();
        }


        private void ShowArticle(Object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ProductPage articlePage = new ProductPage(addUpdateSaleProduct.viewModel.Product);

                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        DependencyService.Get<IKeyboardHelper>().HideKeyboard();
                        this.ParentPageContainer.Content = articlePage;
                        this.PopupBusy.Hide();
                        this.DisplayAddUpdateSaleProductPopup(addUpdateSaleProduct.viewModel.Product.id);
                    });
                }
                catch (Exception ex)
                {
                    DialogEvent("Error", ex.Message);
                    this.PopupBusy.Hide();
                }
            });
        }

        void TableTools_OnViewClicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            switch (this.viewModel.TransactionType)
            {
                case TransactionTypes.OPPORTUNITY:
                //this.DisplayAddUpdateSaleProductPopup(null, id, dicoArgs["rowNo"]);
                //break;
                case TransactionTypes.ORDER:
                case TransactionTypes.QUOTATION:
                    //this.DisplayAddUpdateSaleProductPopup(null, id, dicoArgs["id"]);
                    //"unitQty", "tradeUnit"
                    //this.DisplayAddUpdateSaleProductPopup(dicoArgs["product"], id, dicoArgs["rowNo"], dicoArgs["unitQty"]);
                    AddNewLine = false;
                    this.DisplayAddUpdateSaleProductPopup(null, dicoArgs["_object"] as SaleProduct);
                    break;
            }
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.LinkedListSelectionClient = this.LinkedListSelectionClientPhone;
                this.LinkedListSelectionGoodsRecipient = this.LinkedListSelectionGoodsRecipientPhone;
                this.SearchableListPayTerms = this.SearchableListPayTermsPhone;
                this.ContentFrame2 = this.ContentFrame2Phone;
                this.SearchableListRefusalReasons = this.SearchableListRefusalReasonsPhone;
                this.StackLayoutProducts = this.StackLayoutProductsPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.LinkedListSelectionClient = this.LinkedListSelectionClientTablet;
                this.LinkedListSelectionGoodsRecipient = this.LinkedListSelectionGoodsRecipientTablet;
                this.SearchableListPayTerms = this.SearchableListPayTermsTablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
                this.SearchableListRefusalReasons = this.SearchableListRefusalReasonsTablet;
                this.StackLayoutProducts = this.StackLayoutProductsTablet;
            }
        }

        public async void DialogEvent(string errorTitle, string errorMsg)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert(errorTitle, errorMsg, "OK"));
        }
    }
}
