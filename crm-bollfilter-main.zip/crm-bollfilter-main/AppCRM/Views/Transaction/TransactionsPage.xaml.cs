﻿using System;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abas_Shared_Xamarin;
using AppCRM.Resx;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TransactionsPage : ContentView, ITablePage
    {
        OpportunitiesViewModel opportunitiesViewModel;
        QuotationsViewModel quotationsViewModel;
        SalesViewModel salesViewModel;
        TransactionsViewModel viewModel;

        private TableTools TableToolsOpportunities;
        private TableTools TableToolsQuotations;
        private TableTools TableToolsSales;

        private TableToolsMobile TableToolsOpportunitiesMobile;
        private TableToolsMobile TableToolsQuotationsMobile;
        private TableToolsMobile TableToolsSalesMobile;

        private PopupBusy PopupBusy;

        //responsive Part
        CustomTab OpportunitiesCustomTab, QuotationsCustomTab, SalesCustomTab;
        StackLayout StackLayoutOpportunities, StackLayoutQuotations, StackLayoutSales;

        TransactionTypes? TransactionTypeShowed { get; set; } = null;

        private string SearchTable { get; set; }

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;              
                this.Init(this.TransactionTypeShowed);
                ReziseSearchBarTablet();
            }
        }

        public TransactionsPage(string customerId = null, TransactionTypes? transactionTypeShowed = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            //If comes from Customer, then we need to get the search
            try
            {
                if (Context.Instance.CurrentPagePrefix == AppResources.Client && !string.IsNullOrEmpty(Context.Instance.CurrentPage))
                {
                    SearchTable = Context.Instance.CurrentPage;
                }
            }
            catch (Exception e)
            {
            }

            this.TransactionTypeShowed = transactionTypeShowed;
            NavigationPage.SetHasNavigationBar(this, false);

            this.BindingContext = this.viewModel = new TransactionsViewModel();
            this.viewModel.OnNewObject += ViewModel_OnNewObject;

            this.StackLayoutOpportunities.BindingContext = opportunitiesViewModel = new OpportunitiesViewModel(customerId);
            this.StackLayoutQuotations.BindingContext = quotationsViewModel = new QuotationsViewModel(customerId);
            this.StackLayoutSales.BindingContext = salesViewModel = new SalesViewModel(customerId);

            this.OpportunitiesCustomTab.OnAction += CustomTab_OnAction;
            this.OpportunitiesCustomTab.Target = TransactionTypes.OPPORTUNITY.ToString();

            this.QuotationsCustomTab.OnAction += CustomTab_OnAction;
            this.QuotationsCustomTab.Target = TransactionTypes.QUOTATION.ToString();

            this.SalesCustomTab.OnAction += CustomTab_OnAction;
            this.SalesCustomTab.Target = TransactionTypes.ORDER.ToString();

            this.OpportunitiesCustomTab.Label = this.OpportunitiesCustomTab.Label.ToUpper();
            this.QuotationsCustomTab.Label = this.QuotationsCustomTab.Label.ToUpper();
            this.SalesCustomTab.Label = this.SalesCustomTab.Label.ToUpper();

            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.InitTableToolsMobile();
            }
            else
            {
                this.InitTableTools();
            }

        }

        public void InitTableToolsMobile()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsOpportunitiesMobile = new TableToolsMobile(this.StackLayoutOpportunities, opportunitiesViewModel);
            this.TableToolsOpportunitiesMobile.EnableGlobalSearch = true;
            this.TableToolsOpportunitiesMobile.LinkAttribute = "id";
            this.TableToolsOpportunitiesMobile.PopupBusy = this.PopupBusy;
            this.TableToolsOpportunitiesMobile.OnViewClicked += object_clicked;
            this.TableToolsOpportunitiesMobile.ListFieldsAmount = new List<string>() { "totalNetAmt" };
            this.TableToolsOpportunitiesMobile.FirstColumnSize = 55;
            this.TableToolsOpportunitiesMobile.SecondColumnSize = 45;

            this.TableToolsQuotationsMobile = new TableToolsMobile(this.StackLayoutQuotations, quotationsViewModel);
            this.TableToolsQuotationsMobile.EnableGlobalSearch = true;
            this.TableToolsQuotationsMobile.LinkAttribute = "id";
            this.TableToolsQuotationsMobile.PopupBusy = this.PopupBusy;
            this.TableToolsQuotationsMobile.OnViewClicked += object_clicked;
            this.TableToolsQuotationsMobile.ListFieldsAmount = new List<string>() { "totalNetAmt" };
            this.TableToolsQuotationsMobile.FirstColumnSize = 55;
            this.TableToolsQuotationsMobile.SecondColumnSize = 45;

            this.TableToolsSalesMobile = new TableToolsMobile(this.StackLayoutSales, salesViewModel);
            this.TableToolsSalesMobile.EnableGlobalSearch = true;
            this.TableToolsSalesMobile.LinkAttribute = "id";
            this.TableToolsSalesMobile.PopupBusy = this.PopupBusy;
            this.TableToolsSalesMobile.OnViewClicked += object_clicked;
            this.TableToolsSalesMobile.ListFieldsAmount = new List<string>() { "totalNetAmt" };
            this.TableToolsSalesMobile.FirstColumnSize = 55;
            this.TableToolsSalesMobile.SecondColumnSize = 45;
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsOpportunities = new TableTools(this.StackLayoutOpportunities, opportunitiesViewModel);

            this.TableToolsOpportunities.EnableGlobalSearch = true;
            this.TableToolsOpportunities.LinkAttribute = "id";
            this.TableToolsOpportunities.PopupBusy = this.PopupBusy;
            this.TableToolsOpportunities.OnViewClicked += object_clicked;
            this.TableToolsOpportunities.ListFieldsAmount = new List<string>() { "totalNetAmt" };

            this.TableToolsQuotations = new TableTools(this.StackLayoutQuotations, quotationsViewModel);
            this.TableToolsQuotations.EnableGlobalSearch = true;
            this.TableToolsQuotations.LinkAttribute = "id";
            this.TableToolsQuotations.PopupBusy = this.PopupBusy;
            this.TableToolsQuotations.OnViewClicked += object_clicked;
            this.TableToolsQuotations.ListFieldsAmount = new List<string>() { "totalNetAmt" };

            this.TableToolsSales = new TableTools(this.StackLayoutSales, salesViewModel);
            this.TableToolsSales.EnableGlobalSearch = true;
            this.TableToolsSales.LinkAttribute = "id";
            this.TableToolsSales.PopupBusy = this.PopupBusy;
            this.TableToolsSales.OnViewClicked += object_clicked;
            this.TableToolsSales.ListFieldsAmount = new List<string>() { "totalNetAmt" };
        }

        private void Init(TransactionTypes? transactionTypeShowed = null)
        {
            switch (transactionTypeShowed != null ? transactionTypeShowed : TransactionsViewModel.LastShowedTransactionTab)
            {
                case TransactionTypes.OPPORTUNITY:
                    this.OpportunitiesCustomTab.Selected = true;
                    this.StackLayoutQuotations.IsVisible = false;
                    this.StackLayoutSales.IsVisible = false;
                    this.StackLayoutOpportunities.IsVisible = true;
                    this.TableOpportunitiesInit(SearchTable);
                    break;
                case TransactionTypes.QUOTATION:
                    this.QuotationsCustomTab.Selected = true;
                    this.StackLayoutQuotations.IsVisible = true;
                    this.StackLayoutSales.IsVisible = false;
                    this.StackLayoutOpportunities.IsVisible = false;
                    this.TableQuotationsInit(SearchTable);
                    break;
                case TransactionTypes.ORDER:
                    this.SalesCustomTab.Selected = true;
                    this.StackLayoutQuotations.IsVisible = false;
                    this.StackLayoutSales.IsVisible = true;
                    this.StackLayoutOpportunities.IsVisible = false;
                    this.TableSalesInit(SearchTable);
                    break;
            }
        }

        private void CustomTab_OnAction(string target)
        {
            switch (Enum.Parse(typeof(TransactionTypes), target))
            {
                case TransactionTypes.OPPORTUNITY:
                    this.QuotationsCustomTab.Selected = false;
                    this.SalesCustomTab.Selected = false;
                    TransactionsViewModel.LastShowedTransactionTab = TransactionTypes.OPPORTUNITY;
                    break;
                case TransactionTypes.QUOTATION:
                    this.OpportunitiesCustomTab.Selected = false;
                    this.SalesCustomTab.Selected = false;
                    TransactionsViewModel.LastShowedTransactionTab = TransactionTypes.QUOTATION;
                    break;
                case TransactionTypes.ORDER:
                    this.OpportunitiesCustomTab.Selected = false;
                    this.QuotationsCustomTab.Selected = false;
                    TransactionsViewModel.LastShowedTransactionTab = TransactionTypes.ORDER;
                    break;
            }
            this.Init();
        }

        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    TransactionPage page;
                    if (this.OpportunitiesCustomTab.Selected == true)
                    {
                        page = new TransactionPage(id, TransactionTypes.OPPORTUNITY);
                    }
                    else if (this.QuotationsCustomTab.Selected == true)
                    {
                        page = new TransactionPage(id, TransactionTypes.QUOTATION);
                    }
                    else
                    {
                        page = new TransactionPage(id, TransactionTypes.ORDER);
                    }


                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTransaction page = new AddUpdateTransaction(TransactionsViewModel.LastShowedTransactionTab, null, null);
                    if (TransactionTypeShowed != null)
                    {
                        page = new AddUpdateTransaction(TransactionsViewModel.LastShowedTransactionTab, null, null, salesViewModel.IdClient, salesViewModel.CustomerNameSelected);
                    }
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.parentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
            this.Refresh();
        }

        public void Refresh()
        {
            this.TableOpportunitiesInit(SearchTable);
            this.TableQuotationsInit(SearchTable);
            this.TableSalesInit(SearchTable);
            ReziseSearchBarTablet();
        }

        public void TableOpportunitiesInit(string searchInit = null)
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsOpportunitiesMobile.Init(searchInit);
            }
            else
            {
                this.TableToolsOpportunities.Init(searchInit);
            }
        }

        public void TableQuotationsInit(string searchInit = null)
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsQuotationsMobile.Init(searchInit);
            }
            else
            {
                this.TableToolsQuotations.Init(searchInit);
            }
        }

        public void TableSalesInit(string searchInit = null)
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsSalesMobile.Init(searchInit);
            }
            else
            {
                this.TableToolsSales.Init(searchInit);
            }
        }


        void ReziseSearchBarTablet()
        {
            if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.TableToolsOpportunities.PaddingSearchBar = OpportunitiesCustomTab.Width + QuotationsCustomTab.Width + SalesCustomTab.Width + 10;
                this.TableToolsQuotations.PaddingSearchBar = OpportunitiesCustomTab.Width + QuotationsCustomTab.Width + SalesCustomTab.Width + 10;
                this.TableToolsSales.PaddingSearchBar = OpportunitiesCustomTab.Width + QuotationsCustomTab.Width + SalesCustomTab.Width + 10;
            }
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.OpportunitiesCustomTab = this.OpportunitiesCustomTabPhone;
                this.QuotationsCustomTab = this.QuotationsCustomTabPhone;
                this.SalesCustomTab = this.SalesCustomTabPhone;
                this.StackLayoutOpportunities = this.StackLayoutOpportunitiesPhone;
                this.StackLayoutQuotations = this.StackLayoutQuotationsPhone;
                this.StackLayoutSales = this.StackLayoutSalesPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.OpportunitiesCustomTab = this.OpportunitiesCustomTabTablet;
                this.QuotationsCustomTab = this.QuotationsCustomTabTablet;
                this.SalesCustomTab = this.SalesCustomTabTablet;
                this.StackLayoutOpportunities = this.StackLayoutOpportunitiesTablet;
                this.StackLayoutQuotations = this.StackLayoutQuotationsTablet;
                this.StackLayoutSales = this.StackLayoutSalesTablet;
            }
        }
    }
}