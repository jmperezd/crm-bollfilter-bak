﻿using System;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TransactionPage : ContentView, IRefreshable
    {
        TransactionViewModel viewModel;
        TransactionProductsViewModel transactionProductsViewModel;

        private TableTools TableTools;
        private TableToolsMobile TableToolsMobile;

        private PopupBusy PopupBusy;

        private TransactionPageTypes SelectedTransactionPageType { get; set; } = TransactionPageTypes.TRANSACTION;
        //responsive Part
        StackLayout StackLayoutProducts;
        ContentFrame ContentFrame1, ContentFrame2, ContentFrame3;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;                
                InitTable();                
            }
        }

        private double calculateTableSpace()
        {
            return Application.Current.MainPage.Height - (ContentFrame1.IsVisible ? ContentFrame1.Height : 0) - (ContentFrame2.IsVisible ? ContentFrame2.Height : 0) - (ContentFrame3.IsVisible ? ContentFrame3.Height : 0) - 40 - 130;/*margins toolbar*/
        }

        private void InitTable()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsMobile.Init();
            }
            else
            {
                this.TableTools.Init();
                
            }
        }

        public TransactionPage(string idTransaction, TransactionTypes transactionType)
        {
            InitializeComponent();
            SetResponsiveVariables();

            NavigationPage.SetHasNavigationBar(this, false);

            BindingContext = viewModel = new TransactionViewModel(idTransaction, transactionType);
            this.viewModel.OnBusy += ViewModel_OnBusy;
            this.viewModel.OnEdit += ViewModel_OnEdit;
            this.viewModel.OnError += ViewModel_OnError;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
            this.ContentFrame3.ContentView.BindingContext = viewModel;


            this.StackLayoutProducts.BindingContext = transactionProductsViewModel = new TransactionProductsViewModel(idTransaction, this.viewModel.Transaction);
            this.transactionProductsViewModel.EditView = false;

            buttonPdfTablet.IsVisible = viewModel.ShowEditPDF;

            /*
            this.TransactionCustomTab.OnAction += CustomTab_OnAction;
            this.TransactionCustomTab.Target = TransactionPageTypes.TRANSACTION.ToString();

            this.ProductsCustomTab.OnAction += CustomTab_OnAction;
            this.ProductsCustomTab.Target = TransactionPageTypes.PRODUCTS.ToString();
            */

            this.SetResponsiveEvents();

            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.InitTableToolsMobile();
            }
            else
            {
                this.InitTableTools();
            }            
        }

        private void SetResponsiveEvents()
        {
            this.ContentFrame2.IsVisible = viewModel.ShowAnalysis;
            if (Device.Idiom == TargetIdiom.Phone)
            {
                // Custom component didn't get the Binding correctly in the xaml, so it's necessary do it programatically here
                this.ContentFrame3.IsVisible = viewModel.ShowContact;
            }
        }

        public void InitTableToolsMobile()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsMobile = new TableToolsMobile(this.StackLayoutProducts, this.transactionProductsViewModel);
            this.TableToolsMobile.EnableGlobalSearch = false;
            this.TableToolsMobile.LinkAttribute = "id";
            this.TableToolsMobile.HiddenAttributes = new List<string>() { "rowNo", "product", "tradeUnitOrigin" };
            this.TableToolsMobile.PopupBusy = this.PopupBusy;
            this.TableToolsMobile.ArgAttributes = new List<string>() { "rowNo" };
            this.TableToolsMobile.ListFieldsAmount = new List<string>() { "itemValEntCurr", "price" };
            this.TableToolsMobile.FirstColumnSize = 55;
            this.TableToolsMobile.SecondColumnSize = 45;
            this.Init();
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableTools = new TableTools(this.StackLayoutProducts, this.transactionProductsViewModel);
            this.TableTools.EnableGlobalSearch = false;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.HiddenAttributes = new List<string>() { "rowNo", "product", "tradeUnitOrigin" };
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.ArgAttributes = new List<string>() { "rowNo" };
            this.TableTools.ListFieldsAmount = new List<string>() { "itemValEntCurr", "price" };
            this.TableTools.Finished += TableToolsFinished;
            //this.TableTools.OnViewClicked += object_clicked;
            //this.TableTools.PaddingSearchBar = 200;
            this.Init();
        }

        private void TableToolsFinished()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                ScrollProductsTablet.HeightRequest = calculateTableSpace();
                ScrollProductsTablet.MinimumHeightRequest = calculateTableSpace();
            });
        }

        private void Init()
        {
            /*
            switch (this.SelectedTransactionPageType)
            {
                case TransactionPageTypes.TRANSACTION:
                    this.TransactionCustomTab.Selected = true;
                    this.productView.IsVisible = false;
                    this.transactionView.IsVisible = true;
                    break;
                case TransactionPageTypes.PRODUCTS:
                    this.ProductsCustomTab.Selected = true;
                    this.productView.IsVisible = true;
                    this.transactionView.IsVisible = false;
                    break;
            }
            */
        }

        private void CustomTab_OnAction(string target)
        {
            /*
            this.SelectedTransactionPageType = (TransactionPageTypes)Enum.Parse(typeof(TransactionPageTypes), target);
            switch (Enum.Parse(typeof(TransactionPageTypes), target))
            {
                case TransactionPageTypes.TRANSACTION:
                    this.TransactionCustomTab.Selected = true;
                    this.ProductsCustomTab.Selected = false;
                    break;
                case TransactionPageTypes.PRODUCTS:
                    this.ProductsCustomTab.Selected = true;
                    this.TransactionCustomTab.Selected = false;
                    break;
            }
            this.Init();
            */
        }

        public void Refresh()
        {

            var taskResfresh = System.Threading.Tasks.Task.Run(async () =>
            {
                await this.viewModel.Refresh(); ;
            });
            taskResfresh.Wait();

            this.transactionProductsViewModel.ReInit();
            InitTable();
        }

        void ViewModel_OnBusy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string title, string descr)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert(title, descr, "OK"));
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTransaction page = new AddUpdateTransaction(this.viewModel.TransactionType, null, this.viewModel.Transaction);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
            this.Refresh();
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.ContentFrame2 = this.ContentFrame2Phone;
                this.ContentFrame3 = this.ContentFrame3Phone;
                this.StackLayoutProducts = this.StackLayoutProductsPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
                this.ContentFrame3 = this.ContentFrame3Tablet;
                this.StackLayoutProducts = this.StackLayoutProductsTablet;
            }
        }

    }

    public enum TransactionPageTypes
    {
        TRANSACTION,
        PRODUCTS
    }
}