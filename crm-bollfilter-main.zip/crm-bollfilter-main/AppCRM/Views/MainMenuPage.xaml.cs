﻿using System;
using System.Collections.Generic;
using AppCRM.Views;
using WFramework_Xamarin.Components;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Abas_Shared_Xamarin.Services;
using WFramework_Xamarin.Table;

using Xamarin.Forms;
using Abas_Shared_Xamarin;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using NavigationPage = Xamarin.Forms.NavigationPage;

namespace AppCRM
{
    public partial class MainMenuPage : ContentPage, INotifyPropertyChanged
    {

        public IAbasService Service => DependencyService.Get<IAbasService>() ?? new AbasService();

        public Command DisplayPage { get; set; }
        public Command DisplayOptions { get; set; }
        public Command ListOffline { get; set; }
        
        private INavigation _navigation;
        private Popup PopupOptions;

        //responsive part
        private Frame MainFrame;
        private ContentView PageContainer;
        private Label labelStatus;
        private Grid TaskElement, TiersElement, NotesElement, TransactionsElement;
        private Button labelOfflineDB;

        public Context Context
        {
            get { return Context.Instance; }
        }

        public MainMenuPage(INavigation navigation)
        {
            InitializeComponent();

            if (Device.Idiom == TargetIdiom.Phone && Device.RuntimePlatform == Device.iOS)
            {
                On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);                
            }
            MessagingCenter.Send(this, "PreventLandscape");
            SetResponsive();
            NavigationPage.SetHasNavigationBar(this, false);
            this.DisplayOptions = new Command(ExecuteDisplayOptionsCommand);
            this.ListOffline = new Command(ExecuteListOfflineCommand);
            this.PopupOptions = new Popup(this.MainFrame) { AllowUserClose = true };


            this._navigation = navigation;
            DisplayPage = new Command<string>(ExecuteDisplayPageCommand);
            this.BindingContext = this;

            Context.MainPageContainer = this.PageContainer;
            this.ExecuteDisplayPageCommand(App.LastVisitedPage);

            //Pour forcer le disconnected mode
            this.labelStatus.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ForceDisconnected()),
            });

            buttonShowPrevious.Clicked += (sender, args) =>
            {
                MessagingCenter.Send(this, "PreventLandscape");
            };

            buttonShowPrevious.Released -= (sender, args) =>
            {
                MessagingCenter.Send(this, "PreventLandscape");
            };

            Context.OnListOffline += this.SetOfflineBDList;
            SetOfflineBDList();

        }

        public void SetOfflineBDList()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                labelOfflineDB.IsVisible = Context.NumberOfflineItemsPendingUpload == 0 ? false : true;
                labelOfflineDB.Text = Context.NumberOfflineItemsPendingUpload.ToString();
            });
        }
        private void SetResponsive()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.MainFrame = this.MainFramePhone;
                this.PageContainer = this.PageContainerPhone;
                this.labelStatus = this.labelStatusPhone;
                this.TaskElement = this.TaskElementPhone;
                this.TiersElement = this.TiersElementPhone;
                this.NotesElement = this.NotesElementPhone;
                this.TransactionsElement = this.TransactionsElementPhone;
                this.labelOfflineDB = labelOfflineDBPhone;

            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.MainFrame = this.MainFrameTablet;
                this.PageContainer = this.PageContainerTablet;
                this.labelStatus = this.labelStatusTablet;
                this.TaskElement = this.TaskElementTablet;
                this.TiersElement = this.TiersElementTablet;
                this.NotesElement = this.NotesElementTablet;
                this.TransactionsElement = this.TransactionsElementTablet;
                this.labelOfflineDB = labelOfflineDBTablet;

            }

        }

        private void NotifyMenuColor()
        {
            OnPropertyChanged("TaskColor");
            OnPropertyChanged("TiersColor");
            OnPropertyChanged("NotesColor");
            OnPropertyChanged("TransactionsColor");
            OnPropertyChanged("ActivityColor");
        }


        private void ShowElement(Grid box, bool show)
        {
            this.HideAllElements();
            if (show)
            {
                box.FadeTo(1, 500, Easing.SpringOut);
            }
            else
            {
                box.FadeTo(0, 500, Easing.SpringOut);
            }
        }

        private void HideAllElements()
        {
            this.TaskElement.FadeTo(0, 500, Easing.SpringOut);
            this.TiersElement.FadeTo(0, 500, Easing.SpringOut);
            this.NotesElement.FadeTo(0, 500, Easing.SpringOut);
            this.TransactionsElement.FadeTo(0, 500, Easing.SpringOut);
            //this.ActivityElement.FadeTo(0, 500, Easing.SpringOut);
        }

        private void ExecuteDisplayPageCommand(string origin)
        {
            this.IsBusy = true;

            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    ITablePage view = null;
                    switch (origin.ToUpper())
                    {
                        case "TASKS":
                            this.ShowElement(this.TaskElement, true);
                            view = new TasksPage();
                            MessagingCenter.Send(this, "PreventLandscape");
                            this.Service.ReloadTasks();
                            Context.SwitchToOnline();
                            break;
                        case "TIERS":
                            this.ShowElement(this.TiersElement, true);
                            view = new CustomersPage();
                            MessagingCenter.Send(this, "PreventLandscape");
                            this.Service.ReloadTiers();
                            Context.SwitchToOnline();
                            break;
                        case "NOTES":
                            this.ShowElement(this.NotesElement, true);
                            view = new NotesPage();
                            MessagingCenter.Send(this, "PreventLandscape");
                            this.Service.ReloadNotes();
                            Context.SwitchToOnline();
                            break;
                        case "TRANSACTIONS":
                            this.ShowElement(this.TransactionsElement, true);
                            view = new TransactionsPage();
                            MessagingCenter.Send(this, "PreventLandscape");
                            this.Service.ReloadTransactions();
                            Context.SwitchToOnline();
                            break;
                        //case "ACTIVITE":
                            //this.ShowElement(this.ActivityElement, true);
                            //view = new ActivityPage();
                            //break;
                    }
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (view != null)
                        {
                            App.LastVisitedPage = origin;
                            Context.Instance.ClearStackedView();
                            Context.Instance.CheckNumberItemsPendingUpload();
                            this.PageContainer.Content = view as ContentView;
                            view.ParentPageContainer = this.PageContainer;
                            //await this._navigation.PushAsync(page, true);
                        }
                        this.IsBusy = false;
                    });
                }

                catch (Exception e)
                {
                    this.IsBusy = false;
                }

            });
        }

        private void ExecuteDisplayOptionsCommand()
        {
            OptionsPopup options = new OptionsPopup();
            options.OnHide += Options_OnHide;
            options.OnOpenParameters += Options_OnOpenParameters;
            options.ParentPageContainer = this.PageContainer;
            this.PopupOptions.ContentView = options;
            this.PopupOptions.Show();
        }

        private void ExecuteListOfflineCommand()
        {
            this.IsBusy = true;
            
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    ListDBOffline view = new ListDBOffline(Context.GetListPendingUploadItems());
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        if (view != null)
                        {
                            Context.Instance.ClearStackedView();
                            this.PageContainer.Content = view as ContentView;
                            view.ParentPageContainer = this.PageContainer;
                        }
                        this.IsBusy = false;
                    });
                }

                catch (Exception e)
                {
                    this.IsBusy = false;
                }
            });
        }

        void Options_OnHide()
        {
            this.PopupOptions.Hide();
        }

        void Options_OnOpenParameters()
        {
            this.HideAllElements();
        }


        int TotalForceDisconnectedHit = 0;
        DateTime LastForceDisconnectedHit = DateTime.Now;
        private void ForceDisconnected()
        {
            if (DateTime.Now - LastForceDisconnectedHit <= new TimeSpan(0, 0, 0, 0, 300) && this.TotalForceDisconnectedHit == 4)
            {
                Context.ForceDisconnected = !Context.ForceDisconnected;
                this.TotalForceDisconnectedHit = 0;
            }
            else if(DateTime.Now - LastForceDisconnectedHit <= new TimeSpan(0, 0, 0, 0, 300))
            {
                this.TotalForceDisconnectedHit++;
                this.LastForceDisconnectedHit = DateTime.Now;
            }
            else
            {
                this.LastForceDisconnectedHit = DateTime.Now;
            }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        protected override bool OnBackButtonPressed()
        {
            return true;
        }
    }
}

