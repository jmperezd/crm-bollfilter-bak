﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using WFramework_Xamarin.Components;
using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class Configuration : ContentPage
    {

        ConfigurationViewModel viewModel;
        //responsive Part
        LineEntry Entry1, Entry2, Entry3, Entry4, Entry5;
        Label LabelDatabaseMessage;
        Checkbox CheckboxDatabaseReset;

        public bool stateBoolDatabaseEmpty { get; set; } = false;


        public Configuration(INavigation iNavigation)
        {
            InitializeComponent();
            SetResponsiveVariables();

            BindingContext = viewModel = new ConfigurationViewModel(iNavigation);

            this.Entry1.Unfocused += Entry1_Unfocused;
            this.CheckboxDatabaseReset.CheckedChanged += CheckboxDatabaseReset_CheckedChanged;

            Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);
            this.Entry1.Keyboard = keyboard;
            this.Entry2.Keyboard = keyboard;
            this.Entry3.Keyboard = keyboard;
            this.Entry4.Keyboard = keyboard;
            this.Entry5.Keyboard = keyboard;

            this.Entry1.Completed += (s, e) => this.Entry2.Focus();
            this.Entry2.Completed += (s, e) => this.Entry3.Focus();
            this.Entry3.Completed += (s, e) => this.Entry4.Focus();
            this.Entry4.Completed += (s, e) => this.Entry5.Focus();

        }

        private void CheckboxDatabaseReset_CheckedChanged(object sender, EventArgs e)
        {
            stateBoolDatabaseEmpty = (bool)CheckboxDatabaseReset.Checked;
        }

        private void Entry1_Unfocused(object sender, FocusEventArgs e)
        {
            if (!String.IsNullOrEmpty(Entry1.Text))
            {
                this.LabelDatabaseMessage.IsVisible = true;
                this.CheckboxDatabaseReset.IsVisible = true;
                //stateBoolDatabaseEmpty = true;
                stateBoolDatabaseEmpty = (bool)CheckboxDatabaseReset.Checked;
            }
            else
            {
                this.LabelDatabaseMessage.IsVisible = false;
                this.CheckboxDatabaseReset.IsVisible = false;
            }
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.Entry1 = this.Entry1Phone;
                this.LabelDatabaseMessage = this.LabelDatabaseMessagePhone;
                this.CheckboxDatabaseReset = this.CheckboxDatabaseResetPhone;
                this.Entry2 = this.Entry2Phone;
                this.Entry3 = this.Entry3Phone;
                this.Entry4 = this.Entry4Phone;
                this.Entry5 = this.Entry5Phone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.Entry1 = this.Entry1Tablet;
                this.LabelDatabaseMessage = this.LabelDatabaseMessageTablet;
                this.CheckboxDatabaseReset = this.CheckboxDatabaseResetTablet;
                this.Entry2 = this.Entry2Tablet;
                this.Entry3 = this.Entry3Tablet;
                this.Entry4 = this.Entry4Tablet;
                this.Entry5 = this.Entry5Tablet;
            }
        }

    }
}
