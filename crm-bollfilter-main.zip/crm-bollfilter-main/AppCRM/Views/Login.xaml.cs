﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Components;

using AppCRM.ViewModels;
using System.Threading.Tasks;
using Abas_Shared_Xamarin;
using AppCRM.Resx;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Login : ContentPage
    {
        private LoginViewModel viewModel { get; set; }
        private PopupBusy PopupBusy;

        //responsive Part
        LineEntry userEntry, passEntry;
        Label feedBack;

        public Login(INavigation navigation)
        {
            try
            {
                InitializeComponent();
                SetResponsiveVariables();

                NavigationPage.SetHasNavigationBar(this, false);                
                Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);

                this.userEntry.Keyboard = keyboard;                
                this.userEntry.Completed += (s, e) => this.passEntry.Focus();


                this.passEntry.Keyboard = keyboard;
                this.passEntry.Completed += (s, e) => this.viewModel.Connect.Execute(null);                

                this.viewModel = new LoginViewModel(navigation)
                {
                    ServerUrl = App.ServerUrl,
                    InstancePath = Context.InstancePath,
                    ServerUsername = App.ServerUserName,
                    ServerPassword = App.ServerPassword
                };

                BindingContext = this.viewModel;
                this.viewModel.OnError += this.OnError;
                this.viewModel.OnBusy += this.OnBusy;                                                
            }
            catch(Exception e)
            {
                OnError(e.Message);
            }
        }


        #region Mobile and Android
        void SetResponsiveVariables()
        {            
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.userEntry = this.userPhone;
                this.passEntry = this.PassPhone;
                this.PopupBusy = new PopupBusy(MainFramePhone);                
                feedBack = this.FeedBackPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.userEntry = this.userTablet;
                this.passEntry = this.passTablet;
                this.PopupBusy = new PopupBusy(MainFrameTablet);                
                feedBack = this.FeedBackTablet;                
            }

          
        }

        #endregion

        void OnAppearing()
        {
            base.OnAppearing();
            this.userEntry.Focus();
        }


        private void OnBusy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        private void OnError(string error = null)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                this.PopupBusy.Hide();                
                if (string.IsNullOrEmpty(error))
                {
                    this.feedBack.Text = AppResources.Une_erreur_est_survenue;
                }
                else
                {
                    this.feedBack.Text = error;
                }                

                Task.Run(async () =>
                {
                    await Task.Delay(3000);
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.feedBack.Text = string.Empty;
                    });
                });
            });
        }
    }
}
