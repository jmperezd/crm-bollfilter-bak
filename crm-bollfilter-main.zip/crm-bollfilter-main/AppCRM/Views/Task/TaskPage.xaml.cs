﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    public partial class TaskPage : ContentView, IRefreshable
    {
        private TaskViewModel viewModel { get; set; }

        private PopupBusy PopupBusy { get; set; }

        private ContentView parentPageContainer;

        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2;

        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public TaskPage(string id)
        {
            InitializeComponent();
            SetResponsiveVariables();
            BindingContext = viewModel = new TaskViewModel(id);
            this.viewModel.OnEdit += ViewModel_OnEdit;
            this.viewModel.OnValidate += ViewModel_OnValidate;

            this.PopupBusy = new PopupBusy(this);
            this.viewModel.OnBusy += ViewModel_OnBusy;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame1.Title = this.viewModel.Task.descrOperLang;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTask page = new AddUpdateTask(null, this.viewModel.Task);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();


                }
            });
        }

        void ViewModel_OnValidate(object sender, EventArgs e)
        {
            this.Refresh();
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.viewModel.Refresh();
        }

        void ViewModel_OnBusy(bool busy)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                if (busy)
                {
                    this.PopupBusy.Show();
                }
                else
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void SetResponsiveVariables()
        {
            //ContentFrame ContentFrame1, ContentFrame2;

            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.ContentFrame2 = this.ContentFrame2Phone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
            }
        }
    }
}
