﻿using System;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using WFramework_Xamarin.Table;
using WFramework_Xamarin.Components;
using System.Collections.Generic;
using System.Threading.Tasks;
using AppCRM.Resx;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TasksPage : ContentView, ITablePage
    {
        TasksViewModel viewModel;
        private TableTools TableTools;
        private TableToolsMobile TableToolsMobile;
        private PopupBusy PopupBusy;
        //responsive Part
        StackLayout StackLayout1;
        CustomTab MyTasksCustomTab, AssignedTasksCustomTab;
        Grid GridTabs;

        TaskTypes? TaskTypeShowed { get; set; } = null;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                Refresh();
                this.Init(this.TaskTypeShowed);
                ReziseSearchBarTablet();
            }
        }

        public TasksPage(string customerId = null, TaskTypes? taskTypeShowed = null)
        {
            InitializeComponent();
            SetResponsiveVariables();
            this.TaskTypeShowed = taskTypeShowed;
            NavigationPage.SetHasNavigationBar(this, false);

            BindingContext = viewModel = new TasksViewModel(customerId);


            this.viewModel.OnNewObject += ViewModel_OnNewObject;


            this.MyTasksCustomTab.OnAction += CustomTab_OnAction;
            this.MyTasksCustomTab.Target = TaskTypes.MINE.ToString();

            this.AssignedTasksCustomTab.OnAction += CustomTab_OnAction;
            this.AssignedTasksCustomTab.Target = TaskTypes.ASSIGNED.ToString();
            this.MyTasksCustomTab.Label = this.MyTasksCustomTab.Label.ToUpper();
            this.AssignedTasksCustomTab.Label = this.AssignedTasksCustomTab.Label.ToUpper();

            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.InitTableToolsMobile();
                if (!string.IsNullOrWhiteSpace(this.viewModel.IdClient))
                {
                    this.MyTasksCustomTabPhone.IsVisible = false;
                    this.AssignedTasksCustomTabPhone.IsVisible = false;
                }
            }
            else
            {
                this.InitTableTools();
                if (!string.IsNullOrWhiteSpace(this.viewModel.IdClient))
                {
                    this.GridTabs.IsVisible = false;
                }
            }
        }

        public void InitTableToolsMobile()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsMobile = new TableToolsMobile(StackLayout1, viewModel);
            this.TableToolsMobile.LinkAttribute = "id";
            this.TableToolsMobile.PopupBusy = this.PopupBusy;
            this.TableToolsMobile.OnViewClicked += object_clicked;
            this.TableToolsMobile.HiddenAttributes.Add("id");
            this.TableToolsMobile.HiddenAttributes.Add("status");
            this.TableToolsMobile.HiddenAttributes.Add("businessPartner_descrOperLang");
            this.TableToolsMobile.ArgAttributes = new List<string>() { "endDate", "status" };
        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            if (Device.RuntimePlatform == Device.Android)
            {
                this.TableTools = new TableTools(this.StackLayout1, viewModel, "TASK");
            }
            else
            {
                this.TableTools = new TableTools(this.StackLayout1, viewModel);
            }
            //this.TableTools.EnableGlobalSearch = true;
            this.TableTools.LinkAttribute = "id";
            this.TableTools.PopupBusy = this.PopupBusy;
            this.TableTools.OnViewClicked += object_clicked;
            this.TableTools.EnableGlobalSearch = true;
            this.TableTools.HiddenAttributes.Add("status");
            this.TableTools.OnLoadSpecialIndicator += TableTools_OnLoadSpecialIndicator;
            this.TableTools.ArgAttributes = new List<string>() { "endDate", "status" };
        }

        private void Init(TaskTypes? taskTypeShowed = null)
        {
            switch (taskTypeShowed != null ? taskTypeShowed : TasksViewModel.LastShowedTaskTab)
            {
                case TaskTypes.MINE:
                    this.MyTasksCustomTab.Selected = true;
                    //filtrer ici
                    break;
                case TaskTypes.ASSIGNED:
                    this.AssignedTasksCustomTab.Selected = true;
                    //filtrer ici
                    break;
            }
        }

        private void CustomTab_OnAction(string target)
        {
            switch (Enum.Parse(typeof(TaskTypes), target))
            {
                case TaskTypes.MINE:
                    this.AssignedTasksCustomTab.Selected = false;
                    TasksViewModel.LastShowedTaskTab = TaskTypes.MINE;
                    break;
                case TaskTypes.ASSIGNED:
                    this.MyTasksCustomTab.Selected = false;
                    TasksViewModel.LastShowedTaskTab = TaskTypes.ASSIGNED;
                    break;
            }
            Refresh();
            this.Init();
        }

        bool TableTools_OnLoadSpecialIndicator(Dictionary<string, object> dicoArgs)
        {
            if (Device.RuntimePlatform != Device.Android)
            {
                if (dicoArgs.ContainsKey("endDate") && dicoArgs.ContainsKey("status"))
                {
                    DateTime dt;
                    DateTime.TryParse(dicoArgs["endDate"] as string, out dt);
                    if (dicoArgs["status"] as string != "(Done)" && dicoArgs["status"] as string != "(Confirmed)" && dt != null && dt < DateTime.Now)
                    {
                        return true;
                    }
                }
            }
            return false;
        }


        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    TaskPage page = new TaskPage(id);
                    page.ParentPageContainer = this.ParentPageContainer;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateTask page = new AddUpdateTask(null, null, this.viewModel.IdClient);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsMobile.Init();
            }
            else
            {
                this.ReziseSearchBarTablet();
                this.TableTools.Init();
            }
        }

        void ReziseSearchBarTablet()
        {
            if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.TableTools.PaddingSearchBar = (MyTasksCustomTab.IsEnabled ? MyTasksCustomTab.Width : 0)
                + (AssignedTasksCustomTab.IsEnabled ? AssignedTasksCustomTab.Width : 0);
            }
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.StackLayout1 = this.StackLayout1Phone;
                this.MyTasksCustomTab = this.MyTasksCustomTabPhone;
                this.AssignedTasksCustomTab = this.AssignedTasksCustomTabPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.StackLayout1 = this.StackLayout1Tablet;
                this.MyTasksCustomTab = this.MyTasksCustomTabTablet;
                this.AssignedTasksCustomTab = this.AssignedTasksCustomTabTablet;
                this.GridTabs = this.GridTabsTablet;
            }
        }


    }
}