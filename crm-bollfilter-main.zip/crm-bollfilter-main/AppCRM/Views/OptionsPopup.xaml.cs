﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using Abas_Shared_Xamarin.Classes;
using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Services;
using AppCRM.Resx;
using WFramework_Xamarin.Components;

namespace AppCRM.Views
{
    public partial class OptionsPopup : ContentView
    {
        public Command DisplayParameterCommand { get; set; }
        public Command DeconnexionCommand { get; set; }
        public Command DropDatabase { get; set; }

        public IAbasService Service => DependencyService.Get<IAbasService>() ?? new AbasService();

        public delegate void OnHideDelegate();
        public event OnHideDelegate OnHide;
        public delegate void OnOpenParametersDelegate();
        public event OnOpenParametersDelegate OnOpenParameters;
        //responsive Part
        ContentFrame ContentFrame1;
        StackLayout PopupSettingsFrame;
        Label DropDBInfo;
        Button DropDBButton, ParametersButton, DeconnexionButton;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Context Context
        {
            get { return Context.Instance; }
        }


        public OptionsPopup()
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.DropDatabase = new Command(async () => await ExecuteDropDatabaseCommand());
            this.DisplayParameterCommand = new Command(async () => await ExecuteGoToParameterCommand());
            this.DeconnexionCommand = new Command(async () => await ExecuteDeconnexionCommand());

            this.ParametersButton.Text = this.ParametersButton.Text.ToUpper();
            this.DeconnexionButton.Text = this.DeconnexionButton.Text.ToUpper();

            this.ContentFrame1.ContentView.BindingContext = this;

            if (Device.Idiom == TargetIdiom.Phone)
            {
                PopupSettingsFrame.Padding = new Thickness(20, 40, 20, 40);
            }

        }

        private void Hide()
        {
            if (this.OnHide != null)
            {
                this.OnHide();
            }
        }

        #region NavigationParameter

        async System.Threading.Tasks.Task ExecuteGoToParameterCommand()
        {
            try
            {
                Parameters page = new Parameters();
                page.ParentPageContainer = this.ParentPageContainer;
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ParentPageContainer.Content = page as ContentView;
                    page.ParentPageContainer = this.parentPageContainer;
                });
                this.Hide();
                if (this.OnOpenParameters != null)
                {
                    this.OnOpenParameters();
                }

            }
            catch (Exception ex)
            {

            }


        }

        async System.Threading.Tasks.Task ExecuteDropDatabaseCommand()
        {

            if (DropDBInfo.IsVisible == false)
            {
                DropDBInfo.IsVisible = true;
                DropDBButton.Text = AppResources.Confirmer;
            }
            else
            {
                this.Service.DropDatabase();
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await this.Navigation.PushAsync(new Login(this.Navigation), true);
                });
            }
        }

        async System.Threading.Tasks.Task ExecuteDeconnexionCommand()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                await this.Navigation.PushAsync(new Login(this.Navigation), true);
            });
        }

        #endregion



        #region Parameters
        //Parameter page = new Parameter();
        //page.ParentPageContainer = this.ParentPageContainer;

        //Device.BeginInvokeOnMainThread(() =>
        //{

        //    //this.ParentPageContainer.Content = page;

        //});

        #endregion

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.PopupSettingsFrame = this.PopupSettingsFramePhone;
                this.DropDBInfo = this.DropDBInfoPhone;
                this.DropDBButton = this.DropDBButtonPhone;
                this.ParametersButton = this.ParametersButtonPhone;
                this.DeconnexionButton = this.DeconnexionButtonPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.PopupSettingsFrame = this.PopupSettingsFrameTablet;
                this.DropDBInfo = this.DropDBInfoTablet;
                this.DropDBButton = this.DropDBButtonTablet;
                this.ParametersButton = this.ParametersButtonTablet;
                this.DeconnexionButton = this.DeconnexionButtonTablet;
            }
        }
    }
}
