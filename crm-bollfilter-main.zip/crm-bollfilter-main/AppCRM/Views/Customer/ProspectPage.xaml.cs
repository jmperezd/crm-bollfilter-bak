﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using WFramework_Xamarin;
using Abas_Shared_Xamarin.Models;
using WFramework_Xamarin.Table;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    public partial class ProspectPage : ContentView, IRefreshable
    {
        private ProspectViewModel viewModel { get; set; }

        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2, ContentFrame3, ContentFrame4;
        Label LinkMail, LinkWebSite, LabelNotes, LabelTasks, LabelOpportunities, LabelQuotations, phoneNo, cellPhoneNo;
        StackLayout LinkAddress, NotesStackLayout, TasksStackLayout, OpportunitiesStackLayout, QuotationsStackLayout;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public Popup PopupNewObject;


        public ProspectPage(string id)
        {
            InitializeComponent();
            SetResponsiveVariables();
            BindingContext = viewModel = new ProspectViewModel(id);
            this.viewModel.OnShowContacts += ViewModel_OnShowContacts;
            this.viewModel.OnNewObject += this.ViewModel_OnNewObject;
            this.viewModel.OnEdit += this.ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
            this.ContentFrame3.ContentView.BindingContext = viewModel;
            this.ContentFrame4.ContentView.BindingContext = viewModel;

            this.PopupNewObject = new Popup(this);


            this.LabelNotes.Text = this.LabelNotes.Text.ToUpper();
            this.LabelTasks.Text = this.LabelTasks.Text.ToUpper();
            this.LabelQuotations.Text = this.LabelQuotations.Text.ToUpper();
            this.LabelOpportunities.Text = this.LabelOpportunities.Text.ToUpper();

            SetResponsiveEvents(id);
        }

        private void SetResponsiveEvents(string id)
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                // Custom component didn't get the Binding correctly in the xaml, so it's necessary do it programatically here
                this.ContentFrame3.IsVisible = viewModel.DisplayAddress;

                LabelNotes.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new NotesPage(id)))
                });
                LabelTasks.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new TasksPage(id)))
                });
                LabelOpportunities.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.OPPORTUNITY)))
                });
                LabelQuotations.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.QUOTATION)))
                });
            }
            else
            {
                NotesStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new NotesPage(id)))
                });
                TasksStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new TasksPage(id)))
                });
                OpportunitiesStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.OPPORTUNITY)))
                });
                QuotationsStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(() => ShowPage(new TransactionsPage(id, TransactionTypes.QUOTATION)))
                });
            }
           
            LinkMail.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.Mail(this.viewModel.Prospect.emailAddr))
            });
            LinkWebSite.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.WebSite(this.viewModel.Prospect.webSiteURL))
            });
            LinkAddress.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.ShowDirection(this.viewModel.Prospect.zipCode + "," + this.viewModel.Prospect.town + "," + this.viewModel.Prospect.addr + "," + this.viewModel.Prospect.street))
            });

            phoneNo.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.PhoneCall(this.viewModel.Prospect.phoneNo))
            });

            cellPhoneNo.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => IntentHelper.PhoneCall(this.viewModel.Prospect.cellPhoneNo))
            });
        }

        private void ShowPage(ITablePage page)
        {
            //this.PopupBusy.Show();
            try
            {
                Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ParentPageContainer.Content = page as ContentView;
                    page.ParentPageContainer = this.parentPageContainer;
                    //this.PopupBusy.Hide();
                });

            }
            catch (Exception ex)
            {
                //this.PopupBusy.Hide();
            }
        }


        void ViewModel_OnShowContacts(object sender, EventArgs e)
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    ContactsProspectPage page = new ContactsProspectPage(this.viewModel.Prospect);
                    page.ParentPageContainer = this.parentPageContainer;
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            TiersActionPage page = new TiersActionPage(this.viewModel.Prospect.id);
            page.ParentModel = this.viewModel;
            page.ParentPageContainer = this.ParentPageContainer;

            this.PopupNewObject.ContentView = page;
            this.PopupNewObject.Show();
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateCustomer page = new AddUpdateCustomer(CustomerTypes.PROSPECT, null, this.viewModel.Prospect);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.viewModel.Refresh();
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.ContentFrame2 = this.ContentFrame2Phone;
                this.ContentFrame3 = this.ContentFrame3Phone;
                this.ContentFrame4 = this.ContentFrame4Phone;
                this.LinkMail = this.LinkMailPhone;
                this.LinkWebSite = this.LinkWebSitePhone;
                this.LinkAddress = this.LinkAddressPhone;
                this.LabelNotes = this.LabelNotesPhone;
                this.LabelTasks = this.LabelTasksPhone;
                this.LabelOpportunities = this.LabelOpportunitiesPhone;
                this.LabelQuotations = this.LabelQuotationsPhone;
                this.phoneNo = this.phoneNoPhone;
                this.cellPhoneNo = this.cellPhoneNoPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
                this.ContentFrame3 = this.ContentFrame3Tablet;
                this.ContentFrame4 = this.ContentFrame4Tablet;
                this.LinkMail = this.LinkMailTablet;
                this.LinkWebSite = this.LinkWebSiteTablet;
                this.LinkAddress = this.LinkAddressTablet;
                this.NotesStackLayout = this.NotesStackLayoutTablet;
                this.LabelNotes = this.LabelNotesTablet;
                this.TasksStackLayout = this.TasksStackLayoutTablet;
                this.LabelTasks = this.LabelTasksTablet;
                this.OpportunitiesStackLayout = this.OpportunitiesStackLayoutTablet;
                this.LabelOpportunities = this.LabelOpportunitiesTablet;
                this.QuotationsStackLayout = this.QuotationsStackLayoutTablet;
                this.LabelQuotations = this.LabelQuotationsTablet;
                this.phoneNo = this.phoneNoTablet;
                this.cellPhoneNo = this.cellPhoneNoTablet;
            }
        }
    }
}
