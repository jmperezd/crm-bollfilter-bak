﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using System;
using WFramework_Xamarin.Components;
using Xamarin.Forms;

namespace AppCRM.Views
{
    public partial class AddUpdateCustomer : ContentView
    {
        AddUpdateCustomerViewModel viewModel;
        private PopupBusy PopupBusy;

        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2, ContentFrame3, ContentFrame4, ContentFrame5;
        CustomSelectorList SearchableListCharacteristic1Objects, SearchableListCharacteristic2Objects, SearchableListCharacteristic3Objects,
            SearchableListCharacteristic4Objects, SearchableListCharacteristic5Objects, SearchableListCharacteristic6Objects;
        SearchableList SearchableListInhouseContactObjects, SearchableListCustomerObjects;
        Label labelSearchableListCharacteristic1Objects, labelSearchableListCharacteristic2Objects, labelSearchableListCharacteristic3Objects, labelSearchableListCharacteristic4Objects,
            labelSearchableListCharacteristic5Objects, labelSearchableListCharacteristic6Objects;


        ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public AddUpdateCustomer(CustomerTypes customerType, string idObj = null, Tiers obj = null, string idTiers = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateCustomerViewModel(customerType, idObj, obj, idTiers);
            viewModel.OnEmployeeObjectsLoaded += ViewModel_OnEmployeeObjectsLoaded;
            viewModel.OnCustomerObjectsLoaded += ViewModel_OnCustomerObjectsLoaded;
            viewModel.OnCharacteristicObjectsLoaded += ViewModel_OnCharacteristicObjectsLoaded;

            this.ContentFrame1.ContentView.BindingContext = this.viewModel;
            this.ContentFrame2.ContentView.BindingContext = this.viewModel;
            this.ContentFrame3.ContentView.BindingContext = this.viewModel;
            this.ContentFrame4.ContentView.BindingContext = this.viewModel;
            this.ContentFrame5.ContentView.BindingContext = this.viewModel;

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;
            this.viewModel.OnLoadCompany += ViewModel_OnLoadCompany;

            this.viewModel.Init();
            SetResponsiveVisibility();
        }

        private void SetResponsiveVisibility()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                labelContactPhone.IsVisible = this.viewModel.ShowContactSelection;
                labelSearchableListCharacteristic1Objects.IsVisible = this.viewModel.DisplayCharacteristic1;
                SearchableListCharacteristic1Objects.IsVisible = this.viewModel.DisplayCharacteristic1;
                labelSearchableListCharacteristic2Objects.IsVisible = this.viewModel.DisplayCharacteristic2;
                SearchableListCharacteristic2Objects.IsVisible = this.viewModel.DisplayCharacteristic2;
                labelSearchableListCharacteristic3Objects.IsVisible = this.viewModel.DisplayCharacteristic3;
                SearchableListCharacteristic3Objects.IsVisible = this.viewModel.DisplayCharacteristic3;
                labelSearchableListCharacteristic4Objects.IsVisible = this.viewModel.DisplayCharacteristic4;
                SearchableListCharacteristic4Objects.IsVisible = this.viewModel.DisplayCharacteristic4;
                labelSearchableListCharacteristic5Objects.IsVisible = this.viewModel.DisplayCharacteristic5;
                SearchableListCharacteristic5Objects.IsVisible = this.viewModel.DisplayCharacteristic5;
                labelSearchableListCharacteristic6ObjectsPhone.IsVisible = this.viewModel.DisplayCharacteristic6;
                SearchableListCharacteristic6Objects.IsVisible = this.viewModel.DisplayCharacteristic6;
            }

            ContentFrame2.IsVisible = this.viewModel.DisplayCharacteristics;
            ContentFrame3.IsVisible = this.viewModel.CustomersType == CustomerTypes.CUSTOMER;
            ContentFrame5.IsVisible = this.viewModel.CustomersType == CustomerTypes.CUSTOMER;
        }

        void ViewModel_OnLoadCompany(Tiers tiers)
        {
            //LinkedListSelectionCompany.ContentText = tiers.descrOperLang;
        }

        /*
        void ViewModel_OnLoadInhouseContact(Employee employee)
        {
            LinkedListSelectionInhouseContact.ContentText = employee.Descr;
        }
        */


        /*
        void ViewModel_OnTypeObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListTypeObjects.ItemsSource = this.viewModel.TypeObjects;
                this.SearchableListTypeObjects.SelectedItem = this.viewModel.SelectedTypeObject;
                this.SearchableListTypeObjects.OnSelection += SearchableListTypeObjects_OnSelection;
            });

        }
        */
        /*
        void ViewModel_OnProductObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {

                //this.SearchableListProductObjects.ItemsSource = this.viewModel.ProductObjects;
            });
        }
        */


        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert("info", message, "OK"));
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
        }

        void LinkedListSelectionCompany_OnClick()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage contactsPageSelection = null;
                    switch (this.viewModel.CustomersType)
                    {
                        case CustomerTypes.CONTACT_CUSTOMER:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER, true, this.viewModel.Tiers.id);
                            break;
                        case CustomerTypes.CONTACT_PROSPECT:
                            contactsPageSelection = new CustomersPage(CustomersPageDisplayTypes.PROSPECT, true, this.viewModel.Tiers.id);
                            break;
                    }
                    contactsPageSelection.OnSelection += Page_LinkedListSelectionCompany_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = contactsPageSelection;
                        contactsPageSelection.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }


        void Page_LinkedListSelectionCompany_OnSelection(string id, string label, string swd)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                switch (this.viewModel.CustomersType)
                {
                    case CustomerTypes.CONTACT_CUSTOMER:
                        (this.viewModel.Tiers as ContactCustomer).companyARAP = id;
                        break;
                    case CustomerTypes.CONTACT_PROSPECT:
                        (this.viewModel.Tiers as ContactProspect).companyARAP = id;
                        break;

                }
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        void ViewModel_OnEmployeeObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListInhouseContactObjects.ItemsSource = this.viewModel.EmployeeObjects;
                this.SearchableListInhouseContactObjects.SelectedItem = this.viewModel.SelectedInhouseContactObject;
                this.SearchableListInhouseContactObjects.OnSelection += SearchableListInhouseContactObjects_OnSelection;
                this.SetResponsiveVisibility();
            });
        }

        void ViewModel_OnCharacteristicObjectsLoaded()
        {
            this.ViewModel_OnSearchableListCharacteristic1ObjectsLoaded();
            this.ViewModel_OnSearchableListCharacteristic2ObjectsLoaded();
            this.ViewModel_OnSearchableListCharacteristic3ObjectsLoaded();
            this.ViewModel_OnSearchableListCharacteristic4ObjectsLoaded();
            this.ViewModel_OnSearchableListCharacteristic5ObjectsLoaded();
            this.ViewModel_OnSearchableListCharacteristic6ObjectsLoaded();
        }

        void ViewModel_OnSearchableListCharacteristic1ObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCharacteristic1Objects.ItemsSource = this.viewModel.Characteristic1Objects;
                this.SearchableListCharacteristic1Objects.OnSelection += SearchableListCharacteristic1Objects_OnSelection;
                if (this.viewModel.SelectedCharacteristic1Object != null)
                {
                    this.SearchableListCharacteristic1Objects.SelectItem(this.viewModel.SelectedCharacteristic1Object.Id);
                }
                this.SetResponsiveVisibility();
            });
        }

        void ViewModel_OnSearchableListCharacteristic2ObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCharacteristic2Objects.ItemsSource = this.viewModel.Characteristic2Objects;
                this.SearchableListCharacteristic2Objects.OnSelection += SearchableListCharacteristic2Objects_OnSelection;
                if (this.viewModel.SelectedCharacteristic2Object != null)
                {
                    this.SearchableListCharacteristic2Objects.SelectItem(this.viewModel.SelectedCharacteristic2Object.Id);
                }
                this.SetResponsiveVisibility();
            });
        }

        void ViewModel_OnSearchableListCharacteristic3ObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCharacteristic3Objects.ItemsSource = this.viewModel.Characteristic3Objects;
                this.SearchableListCharacteristic3Objects.OnSelection += SearchableListCharacteristic3Objects_OnSelection;
                if (this.viewModel.SelectedCharacteristic3Object != null)
                {
                    this.SearchableListCharacteristic3Objects.SelectItem(this.viewModel.SelectedCharacteristic3Object.Id);
                }
                this.SetResponsiveVisibility();
            });
        }

        void ViewModel_OnSearchableListCharacteristic4ObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCharacteristic4Objects.ItemsSource = this.viewModel.Characteristic4Objects;
                this.SearchableListCharacteristic4Objects.OnSelection += SearchableListCharacteristic4Objects_OnSelection;
                if (this.viewModel.SelectedCharacteristic4Object != null)
                {
                    this.SearchableListCharacteristic4Objects.SelectItem(this.viewModel.SelectedCharacteristic4Object.Id);
                }
                this.SetResponsiveVisibility();
            });
        }

        void ViewModel_OnSearchableListCharacteristic5ObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCharacteristic5Objects.ItemsSource = this.viewModel.Characteristic5Objects;
                this.SearchableListCharacteristic5Objects.OnSelection += SearchableListCharacteristic5Objects_OnSelection;
                if (this.viewModel.SelectedCharacteristic5Object != null)
                {
                    this.SearchableListCharacteristic5Objects.SelectItem(this.viewModel.SelectedCharacteristic5Object.Id);
                }
                this.SetResponsiveVisibility();
            });
        }

        void ViewModel_OnSearchableListCharacteristic6ObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCharacteristic6Objects.ItemsSource = this.viewModel.Characteristic6Objects;
                this.SearchableListCharacteristic6Objects.OnSelection += SearchableListCharacteristic6Objects_OnSelection;
                if (this.viewModel.SelectedCharacteristic6Object != null)
                {
                    this.SearchableListCharacteristic6Objects.SelectItem(this.viewModel.SelectedCharacteristic6Object.Id);
                }
                this.SetResponsiveVisibility();
            });
        }

        void SearchableListCharacteristic1Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic1Object = sender as SimpleObject;
        }
        void SearchableListCharacteristic2Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic2Object = sender as SimpleObject;
        }
        void SearchableListCharacteristic3Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic3Object = sender as SimpleObject;
        }
        void SearchableListCharacteristic4Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic4Object = sender as SimpleObject;
        }
        void SearchableListCharacteristic5Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic5Object = sender as SimpleObject;
        }
        void SearchableListCharacteristic6Objects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCharacteristic6Object = sender as SimpleObject;
        }
        void SearchableListInhouseContactObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedInhouseContactObject = this.SearchableListInhouseContactObjects.SelectedItem as EmployeeObject;
        }

        /*
        void ViewModel_OnLoadCustomerInhouseContact(Tiers tiers)
        {
            this.LinkedListSelectionInhouseContact.ContentText = tiers.Descr;
        }
        */

        void ViewModel_OnCustomerObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListCustomerObjects.ItemsSource = this.viewModel.CustomerObjects;
                this.SearchableListCustomerObjects.SelectedItem = this.viewModel.SelectedCustomerObject;
                this.SearchableListCustomerObjects.OnSelection += SearchableListCustomerObjects_OnSelection;
                this.SetResponsiveVisibility();
            });
        }

        void SearchableListCustomerObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedCustomerObject = this.SearchableListCustomerObjects.SelectedItem as CustomerObject;
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = ContentFrame1Phone;
                this.ContentFrame2 = ContentFrame2Phone;
                this.SearchableListCharacteristic1Objects = SearchableListCharacteristic1ObjectsPhone;
                this.SearchableListCharacteristic2Objects = SearchableListCharacteristic2ObjectsPhone;
                this.SearchableListCharacteristic3Objects = SearchableListCharacteristic3ObjectsPhone;
                this.SearchableListCharacteristic4Objects = SearchableListCharacteristic4ObjectsPhone;
                this.SearchableListCharacteristic5Objects = SearchableListCharacteristic5ObjectsPhone;
                this.SearchableListCharacteristic6Objects = SearchableListCharacteristic6ObjectsPhone;
                this.ContentFrame3 = ContentFrame3Phone;
                this.SearchableListInhouseContactObjects = SearchableListInhouseContactObjectsPhone;
                this.ContentFrame4 = ContentFrame4Phone;
                this.ContentFrame5 = ContentFrame5Phone;
                SearchableListCustomerObjects = this.SearchableListCustomerObjectsPhone;

                this.labelSearchableListCharacteristic1Objects = this.labelSearchableListCharacteristic1ObjectsPhone;
                this.labelSearchableListCharacteristic2Objects = this.labelSearchableListCharacteristic2ObjectsPhone;
                this.labelSearchableListCharacteristic3Objects = this.labelSearchableListCharacteristic3ObjectsPhone;
                this.labelSearchableListCharacteristic4Objects = this.labelSearchableListCharacteristic4ObjectsPhone;
                this.labelSearchableListCharacteristic5Objects = this.labelSearchableListCharacteristic5ObjectsPhone;
                this.labelSearchableListCharacteristic6Objects = this.labelSearchableListCharacteristic6ObjectsPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = ContentFrame1Tablet;
                this.ContentFrame2 = ContentFrame2Tablet;
                this.SearchableListCharacteristic1Objects = SearchableListCharacteristic1ObjectsTablet;
                this.SearchableListCharacteristic2Objects = SearchableListCharacteristic2ObjectsTablet;
                this.SearchableListCharacteristic3Objects = SearchableListCharacteristic3ObjectsTablet;
                this.SearchableListCharacteristic4Objects = SearchableListCharacteristic4ObjectsTablet;
                this.SearchableListCharacteristic5Objects = SearchableListCharacteristic5ObjectsTablet;
                this.SearchableListCharacteristic6Objects = SearchableListCharacteristic6ObjectsTablet;
                this.ContentFrame3 = ContentFrame3Tablet;
                this.SearchableListInhouseContactObjects = SearchableListInhouseContactObjectsTablet;
                this.ContentFrame4 = ContentFrame4Tablet;
                this.ContentFrame5 = ContentFrame5Tablet;
                SearchableListCustomerObjects = this.SearchableListCustomerObjectsTablet;

                this.labelSearchableListCharacteristic1Objects = this.labelSearchableListCharacteristic1ObjectsTablet;
                this.labelSearchableListCharacteristic2Objects = this.labelSearchableListCharacteristic2ObjectsTablet;
                this.labelSearchableListCharacteristic3Objects = this.labelSearchableListCharacteristic3ObjectsTablet;
                this.labelSearchableListCharacteristic4Objects = this.labelSearchableListCharacteristic4ObjectsTablet;
                this.labelSearchableListCharacteristic5Objects = this.labelSearchableListCharacteristic5ObjectsTablet;
                this.labelSearchableListCharacteristic6Objects = this.labelSearchableListCharacteristic6ObjectsTablet;

            }
        }
    }
}
