﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using AppCRM.ViewModels;
using System;
using System.Collections.Generic;
using WFramework_Xamarin.Components;
using WFramework_Xamarin.Table;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AppCRM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomersPage : ContentView, ITablePage
    {
        CustomersViewModel viewModel;

        public delegate void OnSelectionDelegate(string id, string label, string swd);
        public event OnSelectionDelegate OnSelection;
        private bool SelectionMode { get; set; } = false;

        private TableTools TableToolsClients;
        private TableToolsMobile TableToolsClientsMobile;

        private PopupBusy PopupBusy;

        private CustomersPageDisplayTypes CustomersPageDisplayType { get; set; } = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;

        //responsive Part
        CustomTab ClientsCustomTab, ProspectsCustomTab;
        StackLayout StackLayoutClients;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
                Refresh();
                this.Init();
            }
        }

        public CustomersPage(CustomersPageDisplayTypes customersPageDisplayType = CustomersPageDisplayTypes.CUSTOMER_PROSPECT, bool selectionMode = false, string idClient = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            NavigationPage.SetHasNavigationBar(this, false);

            this.CustomersPageDisplayType = customersPageDisplayType;
            this.SelectionMode = selectionMode;

            BindingContext = viewModel = new CustomersViewModel(idClient, this.CustomersPageDisplayType);
            this.viewModel.OnDisplayMap += ViewModel_OnDisplayMap;
            this.viewModel.OnNewObject += ViewModel_OnNewObject;
            this.viewModel.DialogEvent += DialogEvent;

            this.StackLayoutClients.BindingContext = viewModel;

            this.ClientsCustomTab.OnAction += CustomTab_OnAction;
            this.ClientsCustomTab.Target = CustomerTypes.CUSTOMER.ToString();

            this.ProspectsCustomTab.OnAction += CustomTab_OnAction;
            this.ProspectsCustomTab.Target = CustomerTypes.PROSPECT.ToString();

            this.ClientsCustomTab.Label = this.ClientsCustomTab.Label.ToUpper();
            this.ProspectsCustomTab.Label = this.ProspectsCustomTab.Label.ToUpper();

            this.SetTabsVisibility();

            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.InitTableToolsMobile();
            }
            else
            {
                this.InitTableTools();
            }
            
        }

        private void SetTabsVisibility()
        {
            switch (this.CustomersPageDisplayType)
            {
                case CustomersPageDisplayTypes.PROSPECT:
                case CustomersPageDisplayTypes.CUSTOMER:
                    this.ProspectsCustomTab.IsVisible = false;
                    this.ClientsCustomTab.IsVisible = false;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    this.ProspectsCustomTab.IsVisible = true;
                    this.ClientsCustomTab.IsVisible = true;
                    break;
            }
        }

        private void DialogEvent(string title, string msg)
        {
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert(title, msg, "OK"));
        }

        public void InitTableToolsMobile()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsClientsMobile = new TableToolsMobile(this.StackLayoutClients, this.viewModel);
            this.TableToolsClientsMobile.LinkAttribute = "id";
            this.TableToolsClientsMobile.HiddenAttributes.Add("grpNo");
            this.TableToolsClientsMobile.ArgAttributes = new List<string>() { "descrOperLang", "swd" };
            this.TableToolsClientsMobile.PopupBusy = this.PopupBusy;
            this.TableToolsClientsMobile.OnViewClicked += object_clicked;
            this.TableToolsClientsMobile.PreviousClass = "customers";
            this.TableToolsClientsMobile.FirstColumnSize = 100;
            this.TableToolsClientsMobile.SecondColumnSize = 0;

        }

        public void InitTableTools()
        {
            this.PopupBusy = new PopupBusy(this) { Margin = new Thickness(0, -6, 0, -6) };
            this.PopupBusy.Show();

            this.TableToolsClients = new TableTools(this.StackLayoutClients, this.viewModel);
            this.TableToolsClients.EnableGlobalSearch = true;
            this.TableToolsClients.LinkAttribute = "id";
            this.TableToolsClients.HiddenAttributes.Add("grpNo");
            this.TableToolsClients.ArgAttributes = new List<string>() { "descrOperLang", "swd" };
            this.TableToolsClients.PopupBusy = this.PopupBusy;
            this.TableToolsClients.OnViewClicked += object_clicked;
            this.TableToolsClients.PaddingSearchBar = 270;
            this.TableToolsClients.OnRowCellCreated += TableToolsClients_OnRowCellCreated;

            switch (this.CustomersPageDisplayType)
            {
                case CustomersPageDisplayTypes.ALL:
                    this.TableToolsClients.PaddingSearchBar = 600;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_PROSPECT:
                    this.TableToolsClients.PaddingSearchBar = 270;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER_AND_CONTACT:
                case CustomersPageDisplayTypes.PROSPECT_AND_CONTACT:
                    this.TableToolsClients.PaddingSearchBar = 320;
                    break;
                case CustomersPageDisplayTypes.CUSTOMER:
                case CustomersPageDisplayTypes.PROSPECT:
                case CustomersPageDisplayTypes.CUSTOMER_CONTACT:
                case CustomersPageDisplayTypes.PROSPECT_CONTACT:
                    this.TableToolsClients.PaddingSearchBar = 10;
                    break;
            }
        }


        private void Init()
        {
            switch (this.viewModel.LastShowedCustomerTab)
            {
                case CustomerTypes.CUSTOMER:
                    this.ProspectsCustomTab.Selected = false;
                    this.ClientsCustomTab.Selected = true;
                    break;
                case CustomerTypes.PROSPECT:
                    this.ProspectsCustomTab.Selected = true;
                    this.ClientsCustomTab.Selected = false;
                    break;
            }


            this.viewModel.Init();
        }

        void ReziseSearchBarTablet()
        {            
            this.TableToolsClients.PaddingSearchBar = (ClientsCustomTab.IsEnabled ? ClientsCustomTab.Width : 0)
            + (ProspectsCustomTab.IsEnabled ? ProspectsCustomTab.Width : 0);            
        }


        void TableToolsClients_OnRowCellCreated(StackLayout e, EntityRow row)
        {
            if (row.Cells["grpNo"].Value == "6")
            {
                e.BackgroundColor = Color.FromRgba(0, 0, 0, 15);
            }
        }

        void ViewModel_OnDisplayMap(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    CustomersPageDisplayTypes lastTab;
                    switch (this.viewModel.LastShowedCustomerTab)
                    {                        
                        case CustomerTypes.CONTACT_CUSTOMER:                            
                        case CustomerTypes.CUSTOMER:
                            lastTab = CustomersPageDisplayTypes.CUSTOMER;
                            break;
                        case CustomerTypes.CONTACT_PROSPECT:
                        case CustomerTypes.PROSPECT:
                            lastTab = CustomersPageDisplayTypes.PROSPECT;
                            break;
                        default:
                            lastTab = CustomersPageDisplayTypes.CUSTOMER_PROSPECT;
                            break;

                    }                    

                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    
                    CustomersMap page = new CustomersMap(null, lastTab, (Device.Idiom == TargetIdiom.Phone)? this.TableToolsClientsMobile.TextGlobalSearch : this.TableToolsClients.TextGlobalSearch);
                    
                    page.ParentPageContainer = this.ParentPageContainer;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    DialogEvent("Error", ex.Message);
                    this.PopupBusy.Hide();
                }
            });
        }

        void ViewModel_OnNewObject(object sender, EventArgs e)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateCustomer page = new AddUpdateCustomer(this.viewModel.LastShowedCustomerTab);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            InitTableData();
            
        }
       
        private void object_clicked(string id, Dictionary<string, object> dicoArgs = null)
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    if (!this.SelectionMode)
                    {
                        Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                        ContentView page = null;
                        string tiersType = string.Empty;
                        if (Device.Idiom == TargetIdiom.Phone)
                        {
                             tiersType = this.viewModel.GetTiersTypeMobile(TableToolsClientsMobile, id);
                        }
                        else
                        {
                            tiersType = this.viewModel.GetTiersType(TableToolsClients, id);
                        }

                        if (tiersType == "1")
                        {
                            page = new CustomerPage(id);
                            (page as CustomerPage).ParentPageContainer = this.ParentPageContainer;
                        }
                        else if (tiersType == "6")
                        {
                            page = new ProspectPage(id);
                            (page as ProspectPage).ParentPageContainer = this.ParentPageContainer;
                        }

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            this.ParentPageContainer.Content = page;
                            this.PopupBusy.Hide();
                        });
                    }
                    else
                    {
                        if (this.OnSelection != null)
                        {
                            this.OnSelection(id, dicoArgs["descrOperLang"] as string, dicoArgs["swd"] as string);
                        }
                    }

                }
                catch (Exception e)
                {
                    this.PopupBusy.Hide();
                }

            });
        }

        private void CustomTab_OnAction(string target)
        {
            switch (Enum.Parse(typeof(CustomerTypes), target))
            {
                case CustomerTypes.CUSTOMER:
                    this.ClientsCustomTab.Selected = true;
                    this.ProspectsCustomTab.Selected = false;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.CUSTOMER;
                    InitTableData();
                    break;
                case CustomerTypes.PROSPECT:
                    this.ClientsCustomTab.Selected = false;
                    this.ProspectsCustomTab.Selected = true;
                    this.viewModel.LastShowedCustomerTab = CustomerTypes.PROSPECT;
                    InitTableData();
                    break;
            }
            this.Init();
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ClientsCustomTab = this.ClientsCustomTabPhone;
                this.ProspectsCustomTab = this.ProspectsCustomTabPhone;
                this.StackLayoutClients = this.StackLayoutClientsPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ClientsCustomTab = this.ClientsCustomTabTablet;
                this.ProspectsCustomTab = this.ProspectsCustomTabTablet;
                this.StackLayoutClients = this.StackLayoutClientsTablet;
            }
        }

        private void InitTableData()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.TableToolsClientsMobile.Init();
            }
            else
            {
                this.ReziseSearchBarTablet();
                this.TableToolsClients.Init();
            }
        }
    }
}