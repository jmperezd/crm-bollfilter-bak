﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Xamarin.Forms;
using WFramework_Xamarin.Components;
using Abas_Shared_Xamarin;

namespace AppCRM.Views
{
    public partial class NotePage : ContentView, IRefreshable
    {
        private NoteViewModel viewModel { get; set; }
        //responsive Part
        ContentFrame ContentFrame1, ContentFrame2;

        private ContentView parentPageContainer;
        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public NotePage(string id)
        {
            InitializeComponent();
            SetResponsiveVariables();

            BindingContext = viewModel = new NoteViewModel(id);
            this.viewModel.OnEdit += ViewModel_OnEdit;

            this.ContentFrame1.ContentView.BindingContext = viewModel;
            this.ContentFrame2.ContentView.BindingContext = viewModel;
        }

        void ViewModel_OnEdit(object sender, EventArgs e)
        {
            //this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    AddUpdateNote page = new AddUpdateNote(null, this.viewModel.Note);
                    page.OnValidate += Page_OnValidate;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = page;
                        page.ParentPageContainer = this.ParentPageContainer;
                        //this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    //this.PopupBusy.Hide();
                }
            });
        }

        void Page_OnValidate(object sender, EventArgs e)
        {
            Context.Instance.ShowPreviousView(this.ParentPageContainer);
        }

        public void Refresh()
        {
            this.viewModel.Refresh();
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.ContentFrame2 = this.ContentFrame2Phone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.ContentFrame2 = this.ContentFrame2Tablet;
            }
        }
    }
}
