﻿using System;
using System.Collections.Generic;
using AppCRM.ViewModels;
using Abas_Shared_Xamarin.Models;
using WFramework_Xamarin.Components;
using Abas_Shared_Xamarin;
using Xamarin.Forms;
using AppCRM.CRMModels;

namespace AppCRM.Views
{
    public partial class AddUpdateNote : ContentView
    {
        AddUpdateNoteViewModel viewModel;
        private PopupBusy PopupBusy;
        //responsive Part
        ContentFrame ContentFrame1;
        LinkedList LinkedListSelectionCustomer;
        CustomSelectorList SearchableListTypeObjects;
        ContentView parentPageContainer;

        public ContentView ParentPageContainer
        {
            get { return this.parentPageContainer; }
            set
            {
                this.parentPageContainer = value;
            }
        }

        public string BusinessPartner
        {
            set
            {
                this.viewModel.Note.businessPartner = value;
                this.viewModel.Note.triggerOfEnt = value;
                //this.viewModel.Note.swd = /*Initialiser à la valeur swd du partenaire commercial*/
            }
        }

        public AddUpdateNote(string idObj = null, Note obj = null, string idTiers = null)
        {
            InitializeComponent();
            SetResponsiveVariables();

            this.PopupBusy = new PopupBusy(this);
            BindingContext = viewModel = new AddUpdateNoteViewModel(idObj, obj, idTiers);
            this.ContentFrame1.ContentView.BindingContext = this.viewModel;

            viewModel.OnCancel += this.Hiding;
            viewModel.OnValidate += this.Validate;
            viewModel.OnBusy += this.Busy;
            viewModel.OnError += ViewModel_OnError;
            viewModel.OnProductObjectsLoaded += ViewModel_OnProductObjectsLoaded;
            viewModel.OnTypeObjectsLoaded += ViewModel_OnTypeObjectsLoaded;
            viewModel.OnLoadCustomer += ViewModel_OnLoadCustomer;

            this.LinkedListSelectionCustomer.OnClick += LinkedListSelectionCustomer_OnClick;

            /*
            this.SearchableListProductObjects.SelectedItem = this.viewModel.SelectedProductObject;
            this.SearchableListProductObjects.OnSelection += this.SearchableListProductObjects_OnSelection;
            this.SearchableListProductObjects.OnSearch += this.viewModel.LoadProductsObjects;
            */

            this.viewModel.Init();
            /*
            this.Entry1.Completed += (s, e) => this.Entry2.Focus();
            this.Entry2.Completed += (s, e) => this.Entry3.Focus();
            this.Entry3.Completed += (s, e) => this.Entry4.Focus();
            this.Entry4.Completed += (s, e) => this.Entry5.Focus();
            this.Entry5.Completed += (s, e) => this.Entry6.Focus();
            */

        }
        void ViewModel_OnTypeObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.SearchableListTypeObjects.ItemsSource = this.viewModel.TypeObjects;
                this.SearchableListTypeObjects.OnSelection += SearchableListTypeObjects_OnSelection;
                if (this.viewModel.SelectedTypeObject != null)
                {
                    this.SearchableListTypeObjects.SelectItem(this.viewModel.SelectedTypeObject.Id);
                }
            });

        }

        void ViewModel_OnProductObjectsLoaded()
        {
            Device.BeginInvokeOnMainThread(() =>
            {

                //this.SearchableListProductObjects.ItemsSource = this.viewModel.ProductObjects;
            });
        }


        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public event EventHandler OnValidate;
        void Validate(object sender, EventArgs e)
        {
            this.PopupBusy.Hide();
            if (this.OnValidate != null)
            {
                this.OnValidate(this, null);
            }
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }

        }

        void Busy(bool busy)
        {
            if (busy)
            {
                this.PopupBusy.Show();
            }
            else
            {
                this.PopupBusy.Hide();
            }
        }

        void ViewModel_OnError(string message)
        {
            /*Popup popupError = new Popup(this);
            List<string> errors = new List<string>();
            errors.Add(message);
            Error errorWindow = new Error(errors);
            popupError.ContentView = errorWindow;
            popupError.Show();*/
            Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert("Info", message, "OK"));
        }

        void LinkedListSelectionCustomer_OnClick()
        {
            this.PopupBusy.Show();
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    Context.Instance.StackView(new StackedView() { View = this.ParentPageContainer.Content, Page = this.viewModel.Page, Prefix = this.viewModel.Prefix });
                    CustomersPage customersPageSelection = new CustomersPage(CustomersPageDisplayTypes.CUSTOMER_PROSPECT, true);
                    customersPageSelection.OnSelection += Page_LinkedListSelectionCustomers_OnSelection;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.ParentPageContainer.Content = customersPageSelection;
                        customersPageSelection.ParentPageContainer = this.ParentPageContainer;
                        this.PopupBusy.Hide();
                    });

                }
                catch (Exception ex)
                {
                    this.PopupBusy.Hide();
                }
            });
        }


        void Page_LinkedListSelectionCustomers_OnSelection(string id, string label, string swd)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.viewModel.Note.businessPartner = id;
                this.viewModel.BusinessPartnerSwd = swd;
                this.LinkedListSelectionCustomer.ContentText = label;
                Context.Instance.ShowPreviousView(this.ParentPageContainer);
            });
        }

        void SearchableListTypeObjects_OnSelection(object sender, EventArgs e)
        {
            this.viewModel.SelectedTypeObject = sender as TypeObject;
        }

        //async void SearchableListProductObjects_OnSelection(object sender, EventArgs e)
        //{
        //    this.viewModel.SelectedProductObject = this.SearchableListProductObjects.SelectedItem as ProductObject;
        //}

        void ViewModel_OnLoadCustomer(Tiers tiers)
        {
            this.LinkedListSelectionCustomer.ContentText = tiers.descrOperLang;
        }

        void SetResponsiveVariables()
        {
            if (Device.Idiom == TargetIdiom.Phone)
            {
                this.ContentFrame1 = this.ContentFrame1Phone;
                this.LinkedListSelectionCustomer = this.LinkedListSelectionCustomerPhone;
                this.SearchableListTypeObjects = this.SearchableListTypeObjectsPhone;
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                this.ContentFrame1 = this.ContentFrame1Tablet;
                this.LinkedListSelectionCustomer = this.LinkedListSelectionCustomerTablet;
                this.SearchableListTypeObjects = this.SearchableListTypeObjectsTablet;
            }
        }
    }
}
