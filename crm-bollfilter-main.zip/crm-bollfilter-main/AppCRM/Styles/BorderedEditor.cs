﻿using System;
using Xamarin.Forms;

namespace AppCRM
{
    public class BorderedEditor : Editor
    {

    }
}
