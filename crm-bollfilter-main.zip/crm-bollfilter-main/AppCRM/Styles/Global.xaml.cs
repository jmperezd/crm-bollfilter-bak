﻿
using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace AppCRM.Styles
{
    public partial class Global : ResourceDictionary
    {
        public Global()
        {
            InitializeComponent();
        }
    }
}
