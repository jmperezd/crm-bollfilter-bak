﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppCRM.CRMModels
{
    public static class CRMConstants
    {
        public static class TaskStatus
        {
            public const string ENTERED = "(Entered)";
            public const string PRIORITIZED = "(Prioritized)";
            public const string ACTIVE = "(Active)";
            public const string DONE = "(Done)";
            public const string CONFIRMED = "(Confirmed)";
            public const string CANCELED = "(Canceled)";
        }
    }

    
}
