﻿using Abas_Shared_Xamarin;
using Abas_Shared_Xamarin.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppCRM.CRMModels
{
    public class CRMTask : Task
    {
        public CRMTask()
        {
            base.DefaultHeadFieldsString = Constants.URI_TASK_HEADFIELDS + ",keyWord";
        }
    }
}
