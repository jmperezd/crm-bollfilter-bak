﻿using System;
using Xamarin.Forms;
using System.Globalization;

namespace WFramework_Xamarin.Components
{
    public class NullableDatePicker : DatePicker
    {
        private string _format = null;
        //public static readonly BindableProperty NullableDateProperty = BindableProperty.Create<NullableDatePicker, DateTime?>(p => p.NullableDate, null);

        public static readonly BindableProperty NullableDateProperty = BindableProperty.Create(nameof(NullableDatePicker), typeof(DateTime?), typeof(NullableDatePicker), null, defaultBindingMode: BindingMode.TwoWay);

        public DateTime? NullableDate
        {
            get { return (DateTime?)GetValue(NullableDateProperty); }
            set
            {
                SetValue(NullableDateProperty, value);
                UpdateDate();
            }
        }

        private void UpdateDate()
        {

            if (NullableDate.HasValue)
            {
                //if (null != _format) Format = "d MMMM yyyy"; Date = NullableDate.Value;
                if (null != _format)
                {
                    Format = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
                    Date = NullableDate.Value;
                }

            }
            else
            {
                _format = Format; Format = "                         ";
            }
        }
        protected override void OnBindingContextChanged()
        {
            base.OnBindingContextChanged();
            UpdateDate();
        }

        protected override void OnPropertyChanged(string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);
            if (propertyName == "Date") NullableDate = Date;
            if (propertyName == "IsFocused" && this.IsFocused) NullableDate = Date;
        }
    }
}
