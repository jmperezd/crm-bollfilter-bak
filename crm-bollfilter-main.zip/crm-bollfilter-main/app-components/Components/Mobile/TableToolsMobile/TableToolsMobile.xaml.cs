﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WFramework_Xamarin.Components.Mobile;
using WFramework_Xamarin.Resx;
using WFramework_Xamarin.Table;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public partial class TableToolsMobile : ContentView
    {
        //Search
        private string LastSearch { get; set; } = string.Empty;
        public string SearchLabel { get; private set; } = AppResources.Rechercher;
        public bool EnableGlobalSearch { get; set; } = true;

        //Clickable
        public delegate void ViewClickedEventHandler(string id, Dictionary<string, object> dicoArgs = null);
        public event ViewClickedEventHandler OnViewClicked;
        public string LinkAttribute { get; set; }
        public List<string> ArgAttributes = new List<string>();
        public List<string> ListFieldsAmount { get; set; } = new List<string>();

        //Data
        private ITableViewModel viewModel;
        public EntityTable EntityTable { get; set; }
        public Dictionary<int, EntityTable> DicoTables = new Dictionary<int, EntityTable>();
        public List<string> HiddenAttributes { get; set; } = new List<string>();

        //ContentData
        Grid gridContent;
        StackLayout StackLayoutScroll { get; set; }

        //PopUp
        public PopupBusy PopupBusy { get; set; }
        private bool IsPopupActive { get; set; }

        //Customize part
        public string PreviousClass { get; set; }
        public int FirstColumnSize { get; set; } = 65;
        public int SecondColumnSize { get; set; } = 35;


        #region Load Data and Init
        public TableToolsMobile()
        {
            InitializeComponent();
        }

        public TableToolsMobile(StackLayout container, ITableViewModel viewModel)
        {
            InitializeComponent();
            container.Children.Add(Container);
            this.viewModel = viewModel;
        }

        public void Init(string initialSearchText = "")
        {
            this.viewModel.NbElementsPerPage = 13;
            if (PreviousClass == "products")
            {                
                this.viewModel.NbElementsPerPage = 20000;
            }
            StackLayoutScroll = new StackLayout() { VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };

            this.Search(initialSearchText);
            if (EnableGlobalSearch)
            {
                SetSearchBar();
            }
            else
            {
                searchStackLayout.IsVisible = false;
                titleStackLayout.IsVisible = true;
                titleNoSearchBar.Text = AppResources.Article+"s";
            }
        }
        #endregion

        #region Search Bar and Search Global
        private void SetSearchBar()
        {
            //PlaceHolder and search completed
            Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);
            entryGlobalSearch.Placeholder = this.SearchLabel;
            entryGlobalSearch.Keyboard = keyboard;
            //Search with the search key, empty if has nothing
            entryGlobalSearch.Unfocused += (sender, e) =>
            {
                this.ResetLayout();
                this.Search(string.IsNullOrWhiteSpace(this.entryGlobalSearch.Text) ? string.Empty : this.entryGlobalSearch.Text);
            };
            //Reinit the Search
            buttonReinit.Command = new Command(() =>
            {
                this.Search(string.Empty);
                this.ResetLayout();
            });
        }

        private void Search(string searchedString = null)
        {
            this.ShowPopUp();
            //set the text on the search bar
            entryGlobalSearch.Text = string.IsNullOrWhiteSpace(searchedString) ? string.Empty : searchedString;
            this.LastSearch = searchedString;
            entryGlobalSearch.Text = this.LastSearch;

            Task.Run(() =>
            {
                if (!string.IsNullOrEmpty(searchedString))
                {
                    searchedString = searchedString.ToLower().DeleteAccentMarks();
                }
                EntityTable entityTable = viewModel.LoadDatas(0, searchedString);
                if (entityTable.Rows.Count() > 0)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.DicoTables.Clear();
                        this.tableView.Children.Clear();
                        if (this.viewModel.LazyLoading)
                        {
                            this.LastLazyLoading = DateTime.Now;
                        }
                        this.currentPage = 0;
                        this.LastPage = -1;
                        this.DicoTables.Add(this.CurrentPage, entityTable);

                        this.LoadLayout(entityTable);
                    });
                }
                else
                {
                    this.HidePopUp();
                }
            });
        }
        #endregion

        #region Filters
        List<KeyVal<string, string>> Filters { get; set; }
        string FilterPlaceholder { get; set; } = AppResources.SortBy;

        private void SetFilter(EntityTable entityTable)
        {
            //Initialize Filter placeHolder
            Filters = new List<KeyVal<string, string>>();
            Device.BeginInvokeOnMainThread(() =>
            {
                FilterSelector.Title = FilterPlaceholder;
                FilterSelector.TextColor = Color.Black;
            });

            if (entityTable != null && entityTable.Rows != null && entityTable.Rows.Count > 0)
            {
                foreach (var item in entityTable.Rows.FirstOrDefault().Cells)
                {
                    if (!HiddenAttributes.Contains(item.Key))
                    {
                        //Filters have a dictionary of id and description tranlated in TranslatedText method
                        Filters.Add(TranslatedText(item.Key));
                    }
                }
                SetFilterList();
            }

            FilterSelector.Unfocused += FilterOnSelection;
        }

        private void SetFilterList()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                FilterSelector.ItemsSource = null;
                List<string> listFilters = new List<string>();
                foreach (KeyVal<string, string> item in Filters)
                {
                    listFilters.Add(item.Text);
                }
                FilterSelector.ItemsSource = listFilters;
            });
        }

        private void FilterOnSelection(object sender, FocusEventArgs e)
        {
            Picker picker = (Picker)sender;
            if (picker.SelectedIndex != -1)
            {
                string filterKey = Filters[picker.SelectedIndex].Id;

                GridField gridField = this.viewModel.GridFields.Select(g => g).Where(g => g.FieldName == filterKey).FirstOrDefault();
                ResetAllFiltersExceptSelected(filterKey);
                if (gridField != null)
                {
                    switch (gridField.Order)
                    {
                        case GridField.SortOrder.Desc:
                            SetOrderForSearch(filterKey, GridField.SortOrder.Asc);
                            if (Filters[picker.SelectedIndex].Text.Contains("▼"))
                            {
                                Filters[picker.SelectedIndex].Text = Filters[picker.SelectedIndex].Text.Replace("▼", "▲");
                            }
                            else
                            {
                                Filters[picker.SelectedIndex].Text += " ▲";
                            }
                            break;
                        default:
                            SetOrderForSearch(filterKey, GridField.SortOrder.Desc);
                            if (Filters[picker.SelectedIndex].Text.Contains("▲"))
                            {
                                Filters[picker.SelectedIndex].Text = Filters[picker.SelectedIndex].Text.Replace("▲", "▼");
                            }
                            else
                            {
                                Filters[picker.SelectedIndex].Text += " ▼";
                            }
                            break;
                    }
                    FilterPlaceholder = Filters[picker.SelectedIndex].Text;
                    SetFilterList();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        FilterSelector.Title = FilterPlaceholder;
                        FilterSelector.TitleColor = Color.Black;
                    });
                }
                this.ResetLayout();
                this.Search("");
            }
        }

        private void ResetAllFiltersExceptSelected(string key)
        {
            foreach (var item in Filters)
            {
                if (item.Id != key)
                {
                    item.Text = item.Text.Replace("▼", "").Replace("▲", "");
                }
            }
        }

        //Reset all sort and set the one we need.
        void SetOrderForSearch(string filterKey, GridField.SortOrder order)
        {
            foreach (GridField item in this.viewModel.GridFields)
            {
                if (item.FieldName.Equals(filterKey))
                {
                    item.Order = order;
                }
                else
                {
                    item.Order = GridField.SortOrder.None;
                }
            }
        }

        #endregion

        #region LoadData
        private bool IsFilterSortSet { get; set; } = false;
        public void LoadLayout(EntityTable entityTable)
        {
            this.ShowPopUp();
            Task.Run(() =>
            {
                this.EntityTable = entityTable;

                if (!IsFilterSortSet)
                {
                    SetFilter(this.EntityTable);
                    IsFilterSortSet = true;
                }

                if (!this.viewModel.LazyLoading)
                {
                    this.LoadNextPage(true);
                }

                if (!this.viewModel.LazyLoading && this.LastPage > -1 && this.tableView.Children.Count - 1 >= this.CurrentPage)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (!this.viewModel.LazyLoading)
                        {
                            this.tableView.Children[this.CurrentPage].IsVisible = true;
                            this.tableView.Children[this.LastPage].IsVisible = false;
                        }
                    });
                }
                else
                {
                    try
                    {
                        gridContent = this.GenerateContent();
                        
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            //If the error is something like, dynamic list modified external, it's a problem for iOS emulator
                            try
                            {
                                Grid gridScrollView = new Grid() { ColumnSpacing = 0 };
                                gridScrollView.Children.Add(gridContent);
                                StackLayoutScroll.Children.Add(gridScrollView);
                                if (this.tableView.Children.Count == 0)
                                {
                                    ScrollView scrollView = new ScrollView() { HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
                                    scrollView.Content = StackLayoutScroll;
                                    scrollView.Scrolled += ScrollView_Scrolled;
                                    this.tableView.Children.Add(scrollView);
                                }
                                this.HidePopUp();
                            }
                            catch (Exception e)
                            {
                            }
                        });
                    }
                    catch (Exception e)
                    {

                    }
                }
                this.HidePopUp();
            });
        }

        private bool even = false;
        Grid GenerateContent()
        {
            gridContent = new Grid() { ColumnSpacing = 0, RowSpacing = 0, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };

            int rowCount = 0;
            //List for touch
            List<StackLayout> listStackLayouts = new List<StackLayout>();

            //Rows
            foreach (EntityRow row in this.EntityTable.Rows)
            {
                RowDefinition rowDefinition = new RowDefinition() { Height = GridLength.Auto };
                gridContent.RowDefinitions.Add(rowDefinition);

                //Stack for the border
                StackLayout borderStackLayout = new StackLayout() { Margin = new Thickness(0, 1, 0, 1), BackgroundColor = even ? Color.LightGray : Color.DarkGray };
                borderStackLayout.Children.Add(this.GenerateCardContent(row));

                listStackLayouts.Add(borderStackLayout);
                even = !even;

                gridContent.Children.Add(listStackLayouts[rowCount], 0, rowCount);
                rowCount++;
            }
            return gridContent;
        }

        StackLayout GenerateCardContent(EntityRow row)
        {
            //Content
            StackLayout stackLayout = new StackLayout() { Margin = new Thickness(0, 0, 0, 1), VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.CenterAndExpand, BackgroundColor = Color.White };
            Grid grid = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition() { Width = new GridLength(FirstColumnSize, GridUnitType.Star) }, new ColumnDefinition() { Width = new GridLength(SecondColumnSize, GridUnitType.Star) } },
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand,
                Margin = new Thickness(0, 10, 0, 10)
            };
            int gridPosition = 0;
            KeyValuePair<string, EntityCell> last = row.Cells.Last();
            StackLayout stacklayoutFullWidth = null;

            //Customization for each class, they are similar, but it's better to have these methods for later, if we want to set up another visualization
            switch (PreviousClass)
            {
                case "customers":
                case "contacts":
                    stackLayout = CustomerCardContent(stackLayout, grid, gridPosition, row);
                    break;                
                case "notes":
                    stackLayout = NotesCardContent(stackLayout, grid, gridPosition, row, last, stacklayoutFullWidth);
                    break;
                case "products":
                    stackLayout = ProductsCardContent(stackLayout, grid, gridPosition, row, stacklayoutFullWidth);
                    break;
                default:
                    stackLayout = DefaultCardContent(stackLayout, grid, gridPosition, row);
                    break;
            }

            //Add OnClick event
            AddOnViewClicked(row, stackLayout);

            return stackLayout;
        }

        private StackLayout DefaultCardContent(StackLayout stackLayout, Grid grid, int gridPosition, EntityRow row)
        {
            foreach (KeyValuePair<string, EntityCell> kvpClientCell in row.Cells)
            {
                if (kvpClientCell.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpClientCell.Key))
                {
                    Label labelTasks = null;
                    if (row.Object.GetType().Name == "Task")
                    {
                        labelTasks = new Label() { Text = row.Cells["businessPartner_descrOperLang"].Value, Style = (Style)Application.Current.Resources["titleLabelBlack"] };
                    }
                    string text = GetTextTranslatedAndFormated(kvpClientCell);

                    StackLayout stackLayoutTitle = new StackLayout() { Margin = new Thickness(10, 0, 10, 0), Orientation = StackOrientation.Horizontal };
                    if (gridPosition == 0)
                    {
                        if (labelTasks != null)
                        {
                            stackLayoutTitle.Children.Add(labelTasks);
                        }
                        Label label = new Label() { Text = text, Style = (Style)Application.Current.Resources["titleLabelGreen"] };
                        stackLayoutTitle.Children.Add(label);
                        stackLayout.Children.Add(stackLayoutTitle);
                    }
                    else
                    {
                        Label label = LabelStyles(kvpClientCell.Key, text, row.Cells);                       
                        //Two columns
                        grid.Children.Add(label, (gridPosition % 2 == 0 ? 1 : 0), (gridPosition - 1) / 2);                        
                    }
                    gridPosition++;
                }
            }

            //Set the individual Card, and customize each one for each Class
            CustomizeBackgroundCard(stackLayout, row.Cells);
            stackLayout.Children.Add(grid);
            return stackLayout;
        }

        private StackLayout ProductsCardContent(StackLayout stackLayout, Grid grid, int gridPosition, EntityRow row, StackLayout stacklayoutFullWidth)
        {
            foreach (KeyValuePair<string, EntityCell> kvpClientCell in row.Cells)
            {
                if (kvpClientCell.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpClientCell.Key))
                {
                    string text = GetTextTranslatedAndFormated(kvpClientCell);

                    if (gridPosition == 0)
                    {
                        Label label = new Label() { Text = text, Margin = new Thickness(10, 0, 10, 0), Style = (Style)Application.Current.Resources["titleLabelGreen"] };
                        stackLayout.Children.Add(label);
                    }
                    else
                    {
                        Label label = LabelStyles(kvpClientCell.Key, text, row.Cells);

                        if (kvpClientCell.Key == "descrOperLang")
                        {
                            //Title in full width
                            stacklayoutFullWidth = new StackLayout() { HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
                            stacklayoutFullWidth.Children.Add(label);
                        }
                        else
                        {
                            grid.Children.Add(label, ((gridPosition - 1) % 2 == 0 ? 1 : 0), (gridPosition - 2) / 2);
                        }                      
                    }
                    gridPosition++;
                }
            }

            //Set the individual Card, and customize each one for each Class
            CustomizeBackgroundCard(stackLayout, row.Cells);

            //then the first line in full width
            stackLayout.Children.Add(stacklayoutFullWidth);
            stackLayout.Children.Add(grid);
            return stackLayout;
        }

        private StackLayout NotesCardContent(StackLayout stackLayout, Grid grid, int gridPosition, EntityRow row, KeyValuePair<string, EntityCell> last, StackLayout stacklayoutFullWidth)
        {
            foreach (KeyValuePair<string, EntityCell> kvpClientCell in row.Cells)
            {
                if (kvpClientCell.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpClientCell.Key))
                {
                    string text = GetTextTranslatedAndFormated(kvpClientCell);

                    if (gridPosition == 0)
                    {
                        Label label = new Label() { Text = text, Margin = new Thickness(10, 0, 10, 0), Style = (Style)Application.Current.Resources["titleLabelGreen"] };
                        stackLayout.Children.Add(label);
                    }
                    else
                    {
                        Label label = LabelStyles(kvpClientCell.Key, text, row.Cells);
                        if (!kvpClientCell.Equals(last))
                        {
                            grid.Children.Add(label, (gridPosition % 2 == 0 ? 1 : 0), (gridPosition - 1) / 2);
                        }
                        else
                        {
                            //the last it's a full row
                            stacklayoutFullWidth = new StackLayout() { Margin = new Thickness(0, -10, 0, 10), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
                            stacklayoutFullWidth.Children.Add(label);
                        }
                    }
                    gridPosition++;
                }
            }
            //Set the individual Card, and customize each one for each Class
            CustomizeBackgroundCard(stackLayout, row.Cells);

            stackLayout.Children.Add(grid);
            //Adding the grid or last full row
            if (stacklayoutFullWidth != null)
            {
                stackLayout.Children.Add(stacklayoutFullWidth);
            }
            return stackLayout;
        }

        private StackLayout CustomerCardContent(StackLayout stackLayout, Grid grid, int gridPosition, EntityRow row)
        {
            foreach (KeyValuePair<string, EntityCell> kvpClientCell in row.Cells)
            {
                if (kvpClientCell.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpClientCell.Key))
                {
                    string text = GetTextTranslatedAndFormated(kvpClientCell);

                    if (kvpClientCell.Key == "descrOperLang")
                    {
                        Label label = new Label() { Text = text, Margin = new Thickness(10, 0, 10, 0), Style = (Style)Application.Current.Resources["titleLabelGreen"] };
                        stackLayout.Children.Add(label);
                    }
                    else
                    {
                        Label label = LabelStyles(kvpClientCell.Key, text, row.Cells);
                        grid.Children.Add(label, 0, gridPosition);
                    }
                    gridPosition++;
                }
            }

            //Set the individual Card, and customize each one for each Class
            CustomizeBackgroundCard(stackLayout, row.Cells);
            stackLayout.Children.Add(grid);
            return stackLayout;
        }

        private void CustomizeBackgroundCard(StackLayout stackLayout, Dictionary<string, EntityCell> row)
        {
            if (even)
            {
                stackLayout.BackgroundColor = Color.FromHex("fafafa");
            }
            else
            {
                stackLayout.BackgroundColor = Color.FromHex("fdfdfd");
            }

            if (PreviousClass == "customers")
            {
                if (row["grpNo"].Value == "6")
                {
                    stackLayout.BackgroundColor = Color.FromHex("eeeeee");
                }
            }
        }

        //Set the styles for each label of the card, include one generic
        private Label LabelStyles(string key, string text, Dictionary<string, EntityCell> cells)
        {
            Label label = new Label
            {
                Text = text,
                Margin = new Thickness(15, 0, 0, 0),
                HorizontalOptions = LayoutOptions.Start,
                Style = (Style)Application.Current.Resources["valueLabelGridStart"]
            };

            //add a Bell If status reached
            if (key == "status")
            {
                EntityCell value = cells["endDate"];

                label = new Label()
                {
                    Text = string.Empty,
                    Style = (Style)Application.Current.Resources["labelSpecialClientGridMobile"]
                };

                DateTime dt;
                DateTime.TryParse(value.Value, out dt);
                if (text.Contains("(Done)") || text.Contains("(Confirmed)") && dt != null && dt < DateTime.Now)
                {
                    label.Text = Icon.FABell;
                }

            }

            return label;
        }

        //When tap on the card event.
        private void AddOnViewClicked(EntityRow row, StackLayout stackLayout)
        {
            if (!string.IsNullOrWhiteSpace(this.LinkAttribute))
            {
                //Arguments for click
                Dictionary<string, object> dicoArgs = new Dictionary<string, object>();
                foreach (string arg in this.ArgAttributes)
                {
                    dicoArgs.Add(arg, row.Cells[arg].Value);
                }
                dicoArgs.Add("_object", row.Object);
                if (this.OnViewClicked != null)
                {
                    stackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                    {
                        Command = new Command(() => ViewClicked(stackLayout, row.Cells[this.LinkAttribute].Value, dicoArgs)),
                    });
                }
            }
        }

        private void ViewClicked(StackLayout stackLayout, string id, Dictionary<string, object> dicoArgs)
        {
            Color oldColor = stackLayout.BackgroundColor;
            stackLayout.BackgroundColor = Color.FromHex("eeeeee");

            if (this.OnViewClicked != null)
            {
                OnViewClicked(id, dicoArgs);
            }

            Task.Run(async () =>
            {
                await Task.Delay(300);
                Device.BeginInvokeOnMainThread(() =>
                {
                    stackLayout.BackgroundColor = oldColor;
                });
            });
        }

        #endregion

        #region Translate
        string GetTextTranslatedAndFormated(KeyValuePair<string, EntityCell> kvpClientCell)
        {
            string value = FormatText(this.EntityTable.Columns[kvpClientCell.Value.IdColumn].Type, kvpClientCell.Value.Value, kvpClientCell.Key);
            string text = kvpClientCell.Key + ": " + (string.IsNullOrEmpty(value) ? " - " : value);
            if (kvpClientCell.Key.Equals("descrOperLang")|| kvpClientCell.Key.Equals("customerDescr_descrOperLang"))
            {
                text = string.IsNullOrWhiteSpace(value) ? "-" : value;
            }
            text = text.Replace("prio_descrOperLang", AppResources.Priorite);
            text = text.Replace("prio^descrOperLang", AppResources.Priorite);
            text = text.Replace("endDate", AppResources.Date);
            text = text.Replace("date", AppResources.Date);
            text = text.Replace("dateFrom", AppResources.Date);
            text = text.Replace("DateFrom", AppResources.Date);
            text = text.Replace("editorExt_descrOperLang", AppResources.Responsable);
            text = text.Replace("editorExt^descrOperLang", AppResources.Responsable);
            text = text.Replace("confirm_descrOperLang", AppResources.Responsable);
            text = text.Replace("confirm^descrOperLang", AppResources.Responsable);
            text = text.Replace("status", AppResources.Status);
            text = text.Replace("idno", AppResources.Numero);
            text = text.Replace("swd", AppResources.Cle_de_recherche);
            text = text.Replace("type^descrOperLang", AppResources.Type);
            text = text.Replace("type_descrOperLang", AppResources.Type);
            text = text.Replace("businessPartner^descrOperLang", AppResources.Client);
            text = text.Replace("businessPartner_descrOperLang", AppResources.Client);
            text = text.Replace("customerDescr^descrOperLang", AppResources.Details_client);
            text = text.Replace("customerDescr_descrOperLang", AppResources.Details_client);
            text = text.Replace("FechaFrom", AppResources.Date);
            text = text.Replace("totalNetAmt", AppResources.Total_HT);
            text = text.Replace("probability", AppResources.Probabilite);
            text = text.Replace("productDescr", AppResources.Article);
            text = text.Replace("unitQty", AppResources.Quantite);
            text = text.Replace("tradeUnit", AppResources.Unite);
            text = text.Replace("price", AppResources.Prix);
            text = text.Replace("salesPrice", AppResources.Prix);
            text = text.Replace("percent", AppResources.Majoration_remise_mobile);
            text = text.Replace("itemValEntCurr", AppResources.Valeur_ligne);
            text = text.Replace("startDateTime", AppResources.Date);
            text = text.Replace("salesTradeUnit", AppResources.Unite);


            return text;
        }

        private KeyVal<string, string> TranslatedText(string text)
        {
            switch (text)
            {
                case "id":
                    return new KeyVal<string, string>(text, AppResources.Identifiant);
                case "descrOperLang":
                    return new KeyVal<string, string>(text, AppResources.Description);
                case "prio_descrOperLang":
                case "prio^descrOperLang":
                    return new KeyVal<string, string>(text, AppResources.Priorite);
                case "endDate":
                case "date":
                case "FechaFrom":
                case "dateFrom":
                case "startDateTime":
                    return new KeyVal<string, string>(text, AppResources.Date);
                case "editorExt_descrOperLang":
                case "editorExt^descrOperLang":
                    return new KeyVal<string, string>(text, AppResources.Responsable);
                case "confirm_descrOperLang":
                case "confirm^descrOperLang":
                    //TODO: is this the translate?
                    return new KeyVal<string, string>(text, AppResources.Responsable);
                case "status":
                    return new KeyVal<string, string>(text, AppResources.Status);
                case "idno":
                    return new KeyVal<string, string>(text, AppResources.Numero);
                case "swd":
                    return new KeyVal<string, string>(text, AppResources.Cle_de_recherche);
                case "type^descrOperLang":
                case "type_descrOperLang":
                    return new KeyVal<string, string>(text, AppResources.Type);
                case "businessPartner^descrOperLang":
                case "businessPartner_descrOperLang":
                    return new KeyVal<string, string>(text, AppResources.Client);
                case "customerDescr^descrOperLang":
                case "customerDescr_descrOperLang":
                    return new KeyVal<string, string>(text, AppResources.Details_client);
                case "totalNetAmt":
                    return new KeyVal<string, string>(text, AppResources.Total_HT);
                case "probability":
                    return new KeyVal<string, string>(text, AppResources.Probabilite);
                case "unitQty":
                    return new KeyVal<string, string>(text, AppResources.Quantite);
                case "tradeUnit":
                    return new KeyVal<string, string>(text, AppResources.Unite);
                case "price":
                case "salesPrice":
                    return new KeyVal<string, string>(text, AppResources.Prix);
                case "percent":
                    return new KeyVal<string, string>(text, AppResources.Majoration_remise);
                case "itemValEntCurr":
                    return new KeyVal<string, string>(text, AppResources.Valeur_ligne);
                case "productDescr":
                    return new KeyVal<string, string>(text, AppResources.Article);
                case "salesTradeUnit":
                    return new KeyVal<string, string>(text, AppResources.Unite);
                default:
                    return new KeyVal<string, string>(text, text);
            }
        }

        string FormatText(string type, string value, string key)
        {
            string resultValue = value;
            switch (type.ToLower())
            {
                case "datetime":
                    DateTime dt;
                    DateTime.TryParse(value, out dt);
                    if (dt != null)
                    {
                        resultValue = dt.ToString("HH:mm");
                    }
                    break;
                case "date":
                case "datetime-tz":
                    DateTime dt2;
                    DateTime.TryParse(value, out dt2);
                    if (dt2 != null)
                    {
                        if (Device.Idiom == TargetIdiom.Phone)
                        {
                            resultValue = dt2.ToString("dd/MM/yy");
                        }
                        else
                        {
                            resultValue = dt2.ToString("dd/MM/yyyy");
                        }
                    }
                    if (resultValue == "01/01/0001" || resultValue == "01/01/01")
                    {
                        resultValue = string.Empty;
                    }
                    break;
                case "decimal":
                    if (this.ListFieldsAmount.Contains(key))
                    {
                        double db = ToolsHelper.ConvertToDouble(value);
                        if (db != null)
                        {
                            resultValue = DisplayTools.FormatAmount(db);
                        }
                    }
                    break;
                case "percent":
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        resultValue = value + " %";
                    }
                    break;
            }
            return resultValue;
        }

        #endregion

        #region Custom Methods and Properties publics

        private void ResetLayout()
        {
            StackLayoutScroll.Children.Clear();
            this.tableView.Children.Clear();
        }

        //Only for customers
        public string TextGlobalSearch
        {
            get { return this.entryGlobalSearch.Text; }
        }

        private void ShowPopUp()
        {
            if (this.PopupBusy != null)
            {
                IsPopupActive = true;
                this.PopupBusy.Show();
            }
        }

        private void HidePopUp()
        {
            if (this.PopupBusy != null)
            {
                IsPopupActive = false;
                this.PopupBusy.Hide();
            }
        }


        #endregion

        #region Scroll and Pages

        private DateTime LastLazyLoading = DateTime.Now;

        void ScrollView_Scrolled(object sender, ScrolledEventArgs e)
        {
            ScrollView scrollView = sender as ScrollView;
            double scrollingSpace = scrollView.ContentSize.Height - scrollView.Height - 100;

            if (scrollingSpace <= e.ScrollY && DateTime.Now - LastLazyLoading >= new TimeSpan(0, 0, 0, 0, 1000))
            {
                if (!IsPopupActive)
                {
                    this.Next();
                }
            }
        }

        #endregion

        #region Pages

        public int LastPage = -1;

        private int currentPage = 0;
        public int CurrentPage
        {
            get { return this.currentPage; }
            set
            {
                this.LastPage = this.currentPage;
                this.currentPage = value;
            }
        }

        public void Next()
        {
            this.CurrentPage = this.CurrentPage + 1;
            if (this.DicoTables.ContainsKey(this.CurrentPage))
            {
                this.ReloadPage();
            }
            else
            {
                this.LoadNextPage();
            }
        }

        private void ReloadPage()
        {
            this.LoadLayout(this.DicoTables[this.CurrentPage]);
        }

        private void LoadNextPage(bool hidden = false)
        {
            if (hidden)
            {
                this.PreloadNextPageAsync();
            }
            else
            {
                this.ShowPopUp();
                Task.Run(() =>
                {
                    EntityTable entityTable = this.viewModel.LoadDatas(this.CurrentPage, entryGlobalSearch.Text);
                    if (entityTable.Rows.Count() > 0)
                    {
                        this.DicoTables.Add(this.CurrentPage, entityTable);

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            this.LoadLayout(entityTable);
                            this.HidePopUp();
                        });
                    }
                    else
                    {
                        this.HidePopUp();
                    }
                });
            }
        }


        private async Task PreloadNextPageAsync()
        {
            Task.Run(() =>
            {
                if (!this.DicoTables.ContainsKey(this.CurrentPage + 1))
                {
                    EntityTable entityTable = this.viewModel.LoadDatas(this.CurrentPage + 1);
                    if (entityTable.Rows.Count() > 0)
                    {
                        this.DicoTables.Add(this.CurrentPage + 1, entityTable);
                    }
                }
            });
        }
        #endregion

        #region New Object

        public delegate void NewObjectClickedEventHandler();
        public event NewObjectClickedEventHandler OnNewObjectClicked;

        private void NewObject()
        {
            if (this.OnNewObjectClicked != null)
            {
                this.OnNewObjectClicked();
            }
        }
        #endregion
    }
}
