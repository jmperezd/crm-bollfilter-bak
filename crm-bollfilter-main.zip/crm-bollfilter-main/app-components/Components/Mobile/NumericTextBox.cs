﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public class NumericTextBox : Entry
    {
        public NumericTextBox()
        {
            this.Keyboard = Keyboard.Numeric;
        }

        public static readonly BindableProperty BorderColorProperty =
            BindableProperty.Create<NumericTextBox, Color>(p => p.BorderColor, Color.Black);

        public Color BorderColor
        {
            get { return (Color)GetValue(BorderColorProperty); }
            set { SetValue(BorderColorProperty, value); }
        }

        public static readonly BindableProperty FontSizeProperty =
            BindableProperty.Create<NumericTextBox, double>(p => p.FontSize, Font.Default.FontSize);

        public double FontSize
        {
            get { return (double)GetValue(FontSizeProperty); }
            set { SetValue(FontSizeProperty, value); }
        }

        public static readonly BindableProperty PlaceholderColorProperty =
            BindableProperty.Create<NumericTextBox, Color>(p => p.PlaceholderColor, Color.Default);

        public Color PlaceholderColor
        {
            get { return (Color)GetValue(PlaceholderColorProperty); }
            set { SetValue(PlaceholderColorProperty, value); }
        }

        public static readonly BindableProperty LineHeightProperty =
            BindableProperty.Create<NumericTextBox, Double>(p => p.LineHeight, 0);

        public double LineHeight
        {
            get { return (double)GetValue(LineHeightProperty); }
            set { SetValue(LineHeightProperty, value); }
        }

        public static readonly BindableProperty LineWidthProperty =
            BindableProperty.Create<NumericTextBox, Double>(p => p.LineWidth, 0);

        public double LineWidth
        {
            get { return GetValue(LineWidthProperty) != null ? (double)GetValue(LineWidthProperty) : 1; }
            set { SetValue(LineWidthProperty, value); }
        }
    }
}
