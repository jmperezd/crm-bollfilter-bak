﻿using System;
using Xamarin.Forms;


namespace WFramework_Xamarin.Components
{
    public class ContentFrameViewModel : BaseViewModel
    {
        private string title;
        public string Title
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(this.title))
                {
                    return this.title.ToUpper();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                SetProperty(ref title, value);
                OnPropertyChanged("ExistsTitle");
                OnPropertyChanged("TitleHeight");
            }
        }

        public bool ExistsTitle
        {
            get { return string.IsNullOrWhiteSpace(this.title) ? false : true; }
        }

        public double TitleHeight
        {
            //-1 pour auto
            get { return string.IsNullOrWhiteSpace(this.title) ? 0 : -1; }
        }

        private View contentView;
        public View ContentView
        {
            get { return this.contentView; }
            set
            {
                SetProperty(ref contentView, value);
                OnPropertyChanged("DisplayedContentView");
            }
        }

        private Thickness contentViewPadding = new Thickness(20, 15, 20, 15);
        public Thickness ContentViewPadding
        {
            get { return this.contentViewPadding; }
            set { SetProperty(ref contentViewPadding, value);}
        }

        private bool scrollable = false;
        public bool Scrollable
        {
            get { return this.scrollable; }
            set
            {
                SetProperty(ref scrollable, value);
                OnPropertyChanged("DisplayedContentView");
            }
        }

        public View DisplayedContentView
        {
            get
            {
                try
                {
                    StackLayout stackLayout = new StackLayout();
                    stackLayout.Padding = this.ContentViewPadding;

                    if (this.ContentView != null)
                    {
                        if (!this.Scrollable)
                        {
                            stackLayout.Children.Add(this.ContentView);
                            return stackLayout;
                        }
                        else
                        {
                            stackLayout.Children.Add(this.ContentView);
                            ScrollView scrollView = new ScrollView();
                            scrollView.Content = stackLayout;
                            return scrollView;
                        }
                    }
                    else
                    {
                        return stackLayout;
                    }
                }
                catch(Exception e)
                {
                    return new StackLayout();
                }
            }
        }


        public ContentFrameViewModel()
        {
        }

        public ContentFrameViewModel(string title)
        {
            this.Title = title;
        }

    }
}
