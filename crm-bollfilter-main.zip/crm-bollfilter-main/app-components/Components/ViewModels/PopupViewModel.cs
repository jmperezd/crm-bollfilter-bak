﻿using System;
using Xamarin.Forms;


namespace WFramework_Xamarin.Components
{
    public class PopupViewModel : BaseViewModel
    {
        private View contentView;
        public View ContentView
        {
            get { return this.contentView; }
            set
            {
                SetProperty(ref contentView, value);
            }
        }
    }
}
