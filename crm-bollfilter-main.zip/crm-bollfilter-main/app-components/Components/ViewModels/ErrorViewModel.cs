﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using Plugin.Clipboard;

using Xamarin.Forms;

using System.Diagnostics.Contracts;

namespace WFramework_Xamarin.Components
{
    public class ErrorViewModel : BaseViewModel
    {
        public Command CopyCommand { get; set; }
        public Command CancelCommand { get; set; }

        public event EventHandler OnCancel;

        public string FullTextError { get; set; } = DateTime.Now.ToString() + " ::: ";


        public ErrorViewModel()
        {
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
            this.CopyCommand = new Command(async () => await ExecuteCopyCommand());
        }

        async Task ExecuteCopyCommand()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                CrossClipboard.Current.SetText(this.FullTextError);
            });
        }

        async Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if (this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }


    }
}
