﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

using Xamarin.Forms;

using System.Diagnostics.Contracts;

namespace WFramework_Xamarin.Components
{
    public class ConfirmViewModel : BaseViewModel
    {
        public Command ValidateCommand { get; set; }
        public Command CancelCommand { get; set; }

        public event EventHandler OnBusy;
        public event EventHandler OnValidate;
        public event EventHandler OnCancel;

        private Color confirmButtonColor = Color.FromHex("d9534e");
        public Color ConfirmButtonColor
        {
            get { return this.confirmButtonColor; }
            set { SetProperty(ref confirmButtonColor, value); }
        }

        public ConfirmViewModel()
        {
            this.ValidateCommand = new Command(async () => await ExecuteValidateCommand());
            this.CancelCommand = new Command(async () => await ExecuteCancelCommand());
        }


        async Task ExecuteValidateCommand()
        {
            if (this.OnBusy != null)
            {
                this.OnBusy(this, null);
            }
            Task.Run(() =>
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (this.OnValidate != null)
                    {
                        this.OnValidate(this, null);
                    }
                });
            });
        }

        async Task ExecuteCancelCommand()
        {
            if (IsBusy)
                return;
            if(this.OnCancel != null)
            {
                this.OnCancel(this, null);
            }
        }
    }
}
