﻿using System;
using Xamarin.Forms;
using System.Globalization;

namespace WFramework_Xamarin.Components
{
    public class CalendarViewModel : BaseViewModel
    {
        public String Day1
        {
            get { return this.GetDateShort(DayOfWeek.Monday); }
        }
        public String Day2
        {
            get { return this.GetDateShort(DayOfWeek.Tuesday); }
        }
        public String Day3
        {
            get { return this.GetDateShort(DayOfWeek.Wednesday); }
        }
        public String Day4
        {
            get { return this.GetDateShort(DayOfWeek.Thursday); }
        }
        public String Day5
        {
            get { return this.GetDateShort(DayOfWeek.Friday); }
        }
        public String Day6
        {
            get { return this.GetDateShort(DayOfWeek.Saturday); }
        }
        public String Day7
        {
            get { return this.GetDateShort(DayOfWeek.Sunday); }
        }


        public string GetDateShort(DayOfWeek dayOfWeek)
        {
            string[] names = CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames;
            return names[(int)dayOfWeek];
        }
    }
}
