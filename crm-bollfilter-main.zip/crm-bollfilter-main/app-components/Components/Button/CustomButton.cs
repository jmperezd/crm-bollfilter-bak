﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{

    public class CustomButton : Button
    {
        public Thickness padding = new Thickness(5, 5, 5, 5);
        public Thickness Padding 
        {
            get { return this.padding; }
            set { this.padding = value; }
        }

        //Parameterless constructor for XAML
        public CustomButton()
        {
        }
    }

}
