﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public class MaterialIconsButton : Button
    {
        public static readonly string MaterialIconsName = "materialicons";

        //Parameterless constructor for XAML
        public MaterialIconsButton()
        {
            FontFamily = MaterialIconsName;
        }

        public MaterialIconsButton(string MaterialIconsLabel = null)
        {
            FontFamily = MaterialIconsName;
            Text = MaterialIconsLabel;
        }
    }

}
