﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public class FontAwesomeButton : CustomButton
    {
        public static readonly string FontAwesomeName = "fontawesome-webfont";

        //Parameterless constructor for XAML
        public FontAwesomeButton()
        {
            FontFamily = FontAwesomeName;
        }

        public FontAwesomeButton(string fontAwesomeLabel = null)
        {
            FontFamily = FontAwesomeName;
            Text = fontAwesomeLabel;
        }
    }

}
