﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Xamarin.Forms;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;


namespace WFramework_Xamarin.Components
{
    public partial class CustomTab : Grid, INotifyPropertyChanged
    {
        public Command ActionCommand { get; set; }

        public event OnActionDelegate OnAction;
        public delegate void OnActionDelegate(string target);

        private Color tabBackgroundColor = Color.FromHex("1BB8A3");
        public Color TabBackgroundColor
        {
            get
            {
                return this.Selected ? Color.FromHex("1BB8A3") : Color.Transparent;
            }
        }

        private Color tabTextColor = Color.White;
        public Color TabTextColor
        {
            get
            {
               return this.Selected ? Color.White : Color.FromHex("30000000");
            }
        }

        private string label = "";
        public string Label
        {
            get { return label; }
            set
            {
                this.label = value;
                this.OnPropertyChanged("Label");
            }
        }


        private bool selected = false;
        public bool Selected
        {
            get { return selected; }
            set
            {
                this.selected = value;
                this.OnPropertyChanged("Selected");
                this.OnPropertyChanged("TabBackgroundColor");
                this.OnPropertyChanged("TabTextColor");
                this.OnPropertyChanged("TabLabel");
            }
        }

        public string Target { get; set; }


        public CustomTab()
        {
            this.BindingContext = this;
            this.ActionCommand = new Command(async () => await ExecuteActionCommand());
            InitializeComponent();
            
            if (Device.Idiom == TargetIdiom.Tablet)
            {                
                grid.MinimumWidthRequest = 140;
                grid.WidthRequest = 140;                
            }
            if (Device.Idiom == TargetIdiom.Phone)
            {
                stackLayout.Padding = new Thickness(5, 0, 5, 0);
            }
        }

        async System.Threading.Tasks.Task ExecuteActionCommand()
        {
            this.Selected = true;
            if (this.OnAction != null)
            {
                this.OnAction(this.Target);
            }
        }



        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
