﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public partial class FilterList : ContentView
    {
      
        public FilterList(List<string> itemsSource)
        {
            BindingContext = this;
            InitializeComponent();
            if (itemsSource != null)
            {
                ListView.ItemsSource = itemsSource;
                ItemSelected.Text = itemsSource?.FirstOrDefault().ToString();
            }            

            this.ShowSelectStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ExecuteShowSelectCommand()),
            });

        }

        void ListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;          
            if (ItemSelected != null)
            {
                ItemSelected.Text = e.Item.ToString();
            }           
            this.ListViewStackLayout.IsVisible = false;
            //Erase background Color
            if (sender is ListView lv) lv.SelectedItem = null;
        }

        void ExecuteShowSelectCommand()
        {
            this.ListViewStackLayout.IsVisible = true;
        }

    }
}
