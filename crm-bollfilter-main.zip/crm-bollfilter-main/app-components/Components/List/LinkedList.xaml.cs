﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Xamarin.Forms;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using System.Threading;


namespace WFramework_Xamarin.Components
{
    public partial class LinkedList : StackLayout, INotifyPropertyChanged
    {

        public delegate void OnClickDelegate();
        public event OnClickDelegate OnClick;

        private Color buttonTextColor = Color.FromHex("1BB8A3");
        public Color ButtonTextColor
        {
            get
            {
                return this.buttonTextColor;
            }
            set
            {
                this.buttonTextColor = value;
                this.OnPropertyChanged("ButtonTextColor");
            }
        }

        private Color inputPlaceholderColor = Color.Gray;
        public Color InputPlaceholderColor
        {
            get
            {
                return this.inputPlaceholderColor;
            }
            set
            {
                this.inputPlaceholderColor = value;
                this.OnPropertyChanged("InputPlaceholderColor");
            }
        }

        private string contentText = String.Empty;
        public string ContentText
        {
            get
            {
                return this.contentText;
            }
            set
            {
                this.contentText = value;
                this.OnPropertyChanged("ContentText");
            }
        }

        public event EventHandler OnSelection;

        public LinkedList()
        {
            BindingContext = this;
            InitializeComponent();

            if (Device.Idiom == TargetIdiom.Tablet && Device.RuntimePlatform == Device.Android)
            {
                ShowSelectStackLayout.Padding = new Thickness(0, 8, 0, 0);                
            }
            

            this.ShowSelectStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ExecuteShowSelectCommand()),
            });


        }

        async Task ExecuteShowSelectCommand()
        {
            if(this.OnClick != null)
            {
                this.OnClick();
            }
        }


        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
