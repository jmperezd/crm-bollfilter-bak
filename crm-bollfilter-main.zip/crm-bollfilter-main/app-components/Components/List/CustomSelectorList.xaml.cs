﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public partial class CustomSelectorList : StackLayout, INotifyPropertyChanged
    {
        public event EventHandler OnSelection;

        private ObservableCollection<IItemList> itemsSource { get; set; }
        public ObservableCollection<IItemList> ItemsSource
        {
            get
            {
                return this.itemsSource;
            }
            set
            {
                this.itemsSource = value;
                ListView.ItemsSource = null;
                ListView.ItemsSource = value;                
                this.OnPropertyChanged("ItemsSource");
            }
        }


        public CustomSelectorList()
        {            
            BindingContext = this;
            InitializeComponent();
            //seems like iOS need more margin
            this.bottomLine.Margin = new Thickness(0, Device.RuntimePlatform == Device.iOS ? 17 : 5, 0, 0);

            this.ShowSelectStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ExecuteShowSelectCommand()),
            });

        }

        public void FirstItemSelected()
        {
            if (this.itemsSource != null && this.ItemsSource.Count() > 0)
            {
                ItemSelected.Text = this.ItemsSource?.FirstOrDefault().Text;
                this.bottomLine.Margin = new Thickness(0, Device.RuntimePlatform == Device.iOS ? 0 : 5, 0, 0);
            }
        }

        public void SelectItem(string id)
        {
            if (this.itemsSource != null && this.ItemsSource.Count() > 0)
            {
                ItemSelected.Text = this.ItemsSource?.FirstOrDefault(x => x.Id == id).Text;
                this.bottomLine.Margin = new Thickness(0, Device.RuntimePlatform == Device.iOS ? 0 : 5, 0, 0);
            }
        }

        public CustomSelectorList(ObservableCollection<IItemList> itemsSource)
        {
            BindingContext = this;
            InitializeComponent();
            this.ItemsSource = itemsSource;
            if (ItemsSource != null)
            {
                ItemSelected.Text = this.ItemsSource?.FirstOrDefault().ToString();
            }
        }

        void ListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            if (e == null) return;
            //That's because the Class SimpleObject in into the shared components, and cannot be used here(crossing references errors)
            string item = JsonConvert.SerializeObject(e.Item);
            int pFrom = item.IndexOf("Text\":\"") + "Text\":\"".Length;
            int pTo = item.LastIndexOf("\",");
            if (ItemSelected != null)
            {
                ItemSelected.Text = item.Substring(pFrom, pTo - pFrom);
            }
            if (this.OnSelection != null)
            {
                this.OnSelection(e.Item, null);
            }
            this.ShowSelectStackLayout.IsVisible = true;
            this.ListViewStackLayout.IsVisible = false;
            //Erase background Color
            if (sender is ListView lv) lv.SelectedItem = null;
        }

        void ExecuteShowSelectCommand()
        {
            this.ShowSelectStackLayout.IsVisible = false;
            this.ListViewStackLayout.IsVisible = true;
            this.bottomLine.Margin = new Thickness(0, Device.RuntimePlatform == Device.iOS ? 0 : 5, 0, 0);
        }
    }
}
       