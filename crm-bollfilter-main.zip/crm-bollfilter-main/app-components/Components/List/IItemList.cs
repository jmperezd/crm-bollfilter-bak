﻿using System;
namespace WFramework_Xamarin.Components
{
    public interface IItemList
    {
        string Text { get; set; }
        string Id { get; set; }
    }
}
