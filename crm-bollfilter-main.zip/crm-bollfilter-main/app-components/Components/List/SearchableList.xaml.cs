﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Xamarin.Forms;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using System.Threading;


namespace WFramework_Xamarin.Components
{
    public partial class SearchableList : StackLayout, INotifyPropertyChanged
    {

        public delegate void OnSearchDelegate(string search);
        public event OnSearchDelegate OnSearch;

        private ObservableCollection<IItemList> itemsSourceDisplayed;
        public ObservableCollection<IItemList> ItemsSourceDisplayed
        {
            get
            {
                return this.itemsSourceDisplayed;
            }
            set
            {
                this.itemsSourceDisplayed = value;
                this.OnPropertyChanged("ItemsSourceDisplayed");
            }
        }

        private ObservableCollection<IItemList> itemsSource { get; set; }
        public ObservableCollection<IItemList> ItemsSource
        {
            get
            {
                return this.itemsSource;
            }
            set
            {
                this.itemsSource = value;
                this.ItemsSourceDisplayed = value;
                this.OnPropertyChanged("ItemsSource");
            }
        }

        private string searchText;
        public string SearchText
        {
            get
            {
                return this.searchText;
            }
            set
            {


                System.Threading.Tasks.Task.Run(() =>
                {
                    if (this.searchText != value)
                    {
                        this.searchText = value;
                        this.OnPropertyChanged("SearchText");

                        if (this.OnSearch == null)
                        {
                            if (!string.IsNullOrEmpty(value))
                            {
                                var req = from item in this.ItemsSource where item.Text.ToLower().Contains(value.ToLower()) select item;
                                this.ItemsSourceDisplayed = new ObservableCollection<IItemList>(req);
                            }
                            else
                            {
                                this.ItemsSourceDisplayed = this.ItemsSource;
                            }
                        }
                        else
                        {
                            /*
                            if (!string.IsNullOrEmpty(value))
                            {
                                if (this.OnSearch != null)
                                {
                                    this.OnSearch(this.EntrySearch.Text);
                                }
                            }
                            */
                        }
                    }
                });
            }
        }

        private IItemList selectedItem;
        public IItemList SelectedItem
        {
            get
            {
                return this.selectedItem;
            }
            set
            {
                if (!SelectionChanging)
                {
                    this.selectedItem = value;
                    this.OnPropertyChanged("SelectedItem");
                    this.OnPropertyChanged("ButtonTextDisplayed");
                }
            }
        }

        private string buttonText;
        public string ButtonText
        {
            get
            {
                return this.buttonText;
            }
            set
            {
                this.buttonText = value;
                this.OnPropertyChanged("ButtonText");
                this.OnPropertyChanged("ButtonTextDisplayed");
            }
        }

        private string buttonTextNoSelection;
        public string ButtonTextNoSelection
        {
            get
            {
                return this.buttonTextNoSelection;
            }
            set
            {
                this.buttonTextNoSelection = value;
                this.OnPropertyChanged("ButtonTextNoSelection");
                this.OnPropertyChanged("ButtonTextDisplayed");
            }
        }

        private string lineWidth;
        public string LineWidth
        {
            get
            {
                return this.lineWidth;
            }
            set
            {
                if (this.lineWidth != value)
                {
                    this.lineWidth = value;
                    this.OnPropertyChanged("LineWidth");
                }
            }
        }

        private Color buttonTextColor = Color.FromHex("1BB8A3");
        public Color ButtonTextColor
        {
            get
            {
                return this.buttonTextColor;
            }
            set
            {
                this.buttonTextColor = value;
                this.OnPropertyChanged("ButtonTextColor");
            }
        }

        private Color inputTextColor = Color.FromHex("1BB8A3");
        public Color InputTextColor
        {
            get
            {
                return this.inputTextColor;
            }
            set
            {
                this.inputTextColor = value;
                this.OnPropertyChanged("InputTextColor");
            }
        }

        private Color textColor = Color.FromHex("1BB8A3");// Color.White;
        public Color TextColor
        {
            get
            {
                return this.textColor;
            }
            set
            {
                this.textColor = value;
                this.OnPropertyChanged("TextColor");
            }
        }

        private Color inputPlaceholderColor = Color.Gray;
        public Color InputPlaceholderColor
        {
            get
            {
                return this.inputPlaceholderColor;
            }
            set
            {
                this.inputPlaceholderColor = value;
                this.OnPropertyChanged("InputPlaceholderColor");
            }
        }

        public string ButtonTextDisplayed
        {
            get
            {
                if (this.SelectedItem != null)
                {
                    if (!string.IsNullOrWhiteSpace(this.ButtonText))
                    {
                        return string.Format("{0} - {1}", this.ButtonText, this.SelectedItem.Text);
                    }
                    else
                    {
                        return string.Format("{0}", this.SelectedItem.Text);
                    }
                }
                else
                    return this.ButtonTextNoSelection;
            }
        }

        public event EventHandler OnSelection;

        public SearchableList()
        {
            BindingContext = this;
            InitializeComponent();


            this.ShowSelectStackLayout.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ExecuteShowSelectCommand()),
            });


            this.EntrySearch.Completed += (sender, e) =>
            {
                if (this.OnSearch != null)
                {
                    this.OnSearch(this.EntrySearch.Text);
                }
            };



        }

        public SearchableList(ObservableCollection<IItemList> itemsSource)
        {
            BindingContext = this;
            this.ItemsSource = itemsSource;
            this.ItemsSourceDisplayed = new ObservableCollection<IItemList>(this.ItemsSource);
            InitializeComponent();
        }

        private bool SelectionChanging = false;
        async void OnItemSelected(object sender, SelectedItemChangedEventArgs args)
        {
            if (!this.SelectionChanging)
            {
                this.ListViewStackLayout.IsVisible = false;
                this.ShowSelectStackLayout.IsVisible = true;

                if (this.OnSelection != null)
                {
                    this.OnSelection(this, null);
                }

                this.SelectionChanging = true;
                this.ListView.SelectedItem = null;
            }
            else
            {
                this.SelectionChanging = false;
            }
        }

        static void OnItemsSourceChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var element = newValue as Element;
            if (element == null)
                return;
            element.Parent = (Element)bindable;
        }


        async Task ExecuteShowSelectCommand()
        {
            this.ShowSelectStackLayout.IsVisible = false;
            this.ListViewStackLayout.IsVisible = true;
        }


        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        void Handle_Clicked(object sender, System.EventArgs e)
        {
            this.ListViewStackLayout.IsVisible = false;
            this.ShowSelectStackLayout.IsVisible = true;
        }
    }
}
