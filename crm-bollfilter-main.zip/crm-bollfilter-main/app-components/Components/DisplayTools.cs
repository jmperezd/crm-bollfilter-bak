﻿using System;
using System.Globalization;

namespace WFramework_Xamarin.Components
{
    public class DisplayTools
    {
        public DisplayTools()
        {
        }


        private static string Currency = "€";
        public static string FormatAmount(double amount, string precision = ".00", string currency = "€")
        {
            var nfi = (NumberFormatInfo)CultureInfo.InvariantCulture.NumberFormat.Clone();
            nfi.NumberGroupSeparator = " ";
            string formatted = amount.ToString("#,0" + precision, nfi);
            return string.Format(formatted + " {0}", currency);
            
        }

        /// <summary>
        /// Returns the input string with the first character converted to uppercase
        /// </summary>
        public static string FirstLetterToUpperCase(string s)
        {
            if (string.IsNullOrEmpty(s))
                throw new ArgumentException("There is no first letter");

            char[] a = s.ToCharArray();
            a[0] = char.ToUpper(a[0]);
            return new string(a);
        }
    }
}
