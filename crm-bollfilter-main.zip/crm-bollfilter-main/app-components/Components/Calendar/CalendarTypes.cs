﻿using System;
namespace WFramework_Xamarin.Components
{
    public enum CalendarTypes
    {
        Calendar,
        Vertical
    }
}
