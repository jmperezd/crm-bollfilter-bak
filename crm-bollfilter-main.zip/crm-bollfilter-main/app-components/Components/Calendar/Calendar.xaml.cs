﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Globalization;
using WFramework_Xamarin.Resx;

namespace WFramework_Xamarin.Components
{
    public partial class Calendar : ContentView
    {
        private PopupBusy PopupBusy;

        private ObservableCollection<StackLayout> MounthesCollection = new ObservableCollection<StackLayout>();
        public DateTime CurrentDate { get; set; } = DateTime.Now;
        public DateTime FirstDate { get; set;} = DateTime.Now.AddMonths(-1);
        bool EventClickedFlag { get; set; }
        public bool FirstMonthPassed { get; set; } = false;
        public List<Event> AllEvents;
        int LimitDays { get; set; }
        public DateTime EventDayClicked { get; set; }

        public CalendarTypes CalendarType { get; set; } = CalendarTypes.Calendar;


        private CalendarViewModel CalendarViewModel;

        public ICalendarViewModel datasViewModel = null;
        public ICalendarViewModel DatasViewModel
        {
            get
            {
                return this.datasViewModel;
            }
            set
            {
                this.datasViewModel = value;
            }
        }

        Color LineColor
        {
            get
            {
                return Color.FromHex("10000000");
            }
        }

        public Calendar()
        {
            this.CalendarViewModel = new CalendarViewModel();
            AllEvents = new List<Event>();
            BindingContext = this.CalendarViewModel;
            InitializeComponent();
            this.ScrollView.Scrolled += ScrollView_Scrolled;
            this.ScrollView.PropertyChanged += ScrollView_PropertyChanged;
            this.PopupBusy = new PopupBusy(this);
        }


        public void Init(bool wasCliked = false, int limitCalendar = 0, bool? showZipTown = false)
        {
            this.PopupBusy.Show();
            LimitDays = limitCalendar;
            EventClickedFlag = wasCliked;
            System.Threading.Tasks.Task.Run(() =>
            {
                this.Next(limitCalendar, showZipTown);                
                this.Next(limitCalendar, showZipTown);
                this.PopupBusy.Hide();
            });
        }

        private void Next(int limitCalendar = 0, bool? showZipTown = false, bool isLazyLoading = false, DateTime? eventClicked = null)
        {
            DateTime currDate = new DateTime(this.CurrentDate.Year, this.CurrentDate.Month, this.CurrentDate.Day);
            this.CurrentDate = this.CurrentDate.AddMonths(1);
            if (eventClicked != null)
            {
                //because the events from the start are loaded, we can skip them
                currDate = EventDayClicked.AddDays(limitCalendar == 0 ? 0 : limitCalendar - 1);
            }
            try
            {
                StackLayout mounthStackLayout = this.LoadMounth(currDate, limitCalendar, showZipTown, isLazyLoading);
                Device.BeginInvokeOnMainThread(async () =>
                {
                    this.MainList.Children.Add(mounthStackLayout);
                });
            }
            catch (Exception e)
            {

            }
        }


        private void Previous(int limitCalendar = 0, bool? showZipTown = false, bool isLazyLoading = false, DateTime? eventClicked = null, bool isPrevious = false)
        {
            DateTime firstDate = new DateTime(this.FirstDate.Year, this.FirstDate.Month, this.FirstDate.Day);
            this.FirstDate = this.FirstDate.AddMonths(-1);
            if (eventClicked != null)
            {
                //because the events from the start are loaded, we can skip them
                firstDate = EventDayClicked.AddDays(-limitCalendar - 1);
            }
            try
            {
                StackLayout mounthStackLayout = this.LoadMounth(firstDate, limitCalendar, showZipTown, isLazyLoading, isPrevious);
                Device.BeginInvokeOnMainThread(async () =>
                {
                    this.MainList.Children.Insert(0, mounthStackLayout);
                });
            }
            catch (Exception e)
            {

            }
        }

        private BoxView GenerateRow(DateTime dateTime, int currentRow, bool last = false)
        {
            BoxView boxView = new BoxView() { Color = this.LineColor, HorizontalOptions = LayoutOptions.FillAndExpand };
            Grid.SetRow(boxView, currentRow);
            int columnSpan = 1;
            int column = 0;
            if (!last)
            {
                column = this.GetDateTimeColumn(dateTime);
            }
            //Car 0 = dimanche
            if ((int)dateTime.DayOfWeek != 0)
            {
                if (!last)
                {
                    columnSpan = 7 - (int)dateTime.DayOfWeek + 1;
                }
                else
                {
                    columnSpan = (int)dateTime.DayOfWeek;
                }
            }
            else
            {
                if (last)
                {
                    columnSpan = 7;
                }
            }
            Grid.SetColumn(boxView, column);
            Grid.SetColumnSpan(boxView, columnSpan);

            return boxView;
        }

        private StackLayout GenerateHeader(DateTime dateTime, int currentRow)
        {
            StackLayout stackLayout = new StackLayout(){ Padding = new Thickness(10,0,0,0), MinimumWidthRequest = 200};
            Label label = new Label() { Text = dateTime.ToString("MMMM yyyy", CultureInfo.InstalledUICulture), Style = (Style)Application.Current.Resources["mounthLabel"] };
            stackLayout.Children.Add(label);
            Grid.SetColumn(stackLayout, this.GetDateTimeColumn(dateTime));

            return stackLayout;
        }


        private Grid GenerateDay(IEnumerable<Event> events, DateTime dateTime, int currentRow, bool last = false)
        {
            List<Event> eventsSorted = events.ToList<Event>();
            eventsSorted.Sort();

            if (eventsSorted.Count() <= 5)
            {


            }

            //Génération jour
            Grid grid = new Grid() { VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand, RowSpacing = 0, ColumnSpacing = 0 };
            grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1) });
            grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
            grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1) });
            grid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            grid.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => DayClicked(grid, dateTime)),
            });
            Grid.SetRow(grid, currentRow);
            Grid.SetColumn(grid, this.GetDateTimeColumn(dateTime));

            //Left
            if (dateTime.DayOfWeek != DayOfWeek.Monday)
            {
                BoxView boxViewLeft = new BoxView() { Color = this.LineColor, VerticalOptions = LayoutOptions.FillAndExpand };
                Grid.SetColumn(boxViewLeft, 0);
                Grid.SetRowSpan(boxViewLeft, 2);
                grid.Children.Add(boxViewLeft);
            }

            //Right
            if (last && dateTime.DayOfWeek != DayOfWeek.Sunday)
            {
                BoxView boxViewRight = new BoxView() { Color = this.LineColor, VerticalOptions = LayoutOptions.FillAndExpand };
                Grid.SetColumn(boxViewRight, 2);
                Grid.SetRowSpan(boxViewRight, 2);
                grid.Children.Add(boxViewRight);
            }


            StackLayout dayNumberStackLayout = new StackLayout() { Padding = new Thickness(2,2,2,0) };
            Grid.SetColumn(dayNumberStackLayout, 1);
            Grid.SetRow(dayNumberStackLayout, 0);
            grid.Children.Add(dayNumberStackLayout);

            Frame dayNumberFrame = new Frame() { Style = (Style)Application.Current.Resources["rondFrame"], HorizontalOptions = LayoutOptions.End };
            dayNumberStackLayout.Children.Add(dayNumberFrame);

            Label labelDayNumber = new Label() { Text = dateTime.Day.ToString(), HorizontalOptions = LayoutOptions.Center, Style = (Style)Application.Current.Resources["dayLabel"] };
            dayNumberFrame.Content = labelDayNumber;

            if (dateTime.Equals(DateTime.Today))
            {
                dayNumberFrame.BackgroundColor = Color.FromHex("1BB8A3");
                labelDayNumber.TextColor = Color.White;
            }
            StackLayout eventsStackLayout = new StackLayout() { Style = (Style)Application.Current.Resources["eventsStackLayout"], VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
            Grid.SetColumn(eventsStackLayout, 1);
            Grid.SetRow(eventsStackLayout, 1);
            grid.Children.Add(eventsStackLayout);

            // Show only 5 ServiceReservations maximum per day to fix the box of the calendar
            if (eventsSorted.Count() <= 5)
            {

                foreach (Event evt in eventsSorted)
                {

                    Grid eventGrid = new Grid() { Style = (Style)Application.Current.Resources["eventGrid"], RowSpacing = 0, ColumnSpacing = 0 };
                    eventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                    eventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                    eventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                    eventsStackLayout.Children.Add(eventGrid);

                    //Rond de couleur
                    Frame eventTypeFrame = new Frame() { Style = (Style)Application.Current.Resources["eventTypeFrame"] };
                    if (!string.IsNullOrEmpty(evt.ColorBackground))
                    {
                        eventTypeFrame.BackgroundColor = Color.FromHex(evt.ColorBackground);
                    }
                    Grid.SetColumn(eventTypeFrame, 0);
                    eventGrid.Children.Add(eventTypeFrame);

                    //Label titre
                    Label eventTitleLabel = new Label() { Style = (Style)Application.Current.Resources["eventTitleLabel"], Text = evt.Title, HorizontalOptions = LayoutOptions.Start };
                    Grid.SetColumn(eventTitleLabel, 1);
                    eventGrid.Children.Add(eventTitleLabel);

                    //Label heure

                    Label eventTimeLabel = new Label() { Style = (Style)Application.Current.Resources["eventTimeLabel"], Text = evt.Start.ToString("HH:mm"), HorizontalOptions = LayoutOptions.End};
                    Grid.SetColumn(eventTimeLabel, 2);
                    eventGrid.Children.Add(eventTimeLabel);
                }


            }

            // Show dot at the bottom of the box if there's more than 5 ServiceReservations to correctly fit the design of the box in calendar
            else if (eventsSorted.Count() >= 6)
            {
                
                var newList = eventsSorted.Take(4);
                
                foreach (Event evt in newList)
                {


                    Grid eventGrid = new Grid() { Style = (Style)Application.Current.Resources["eventGrid"], RowSpacing = 0, ColumnSpacing = 0 };
                    eventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                    eventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                    eventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                    eventsStackLayout.Children.Add(eventGrid);

                    //Rond de couleur
                    Frame eventTypeFrame = new Frame() { Style = (Style)Application.Current.Resources["eventTypeFrame"] };
                    if (!string.IsNullOrEmpty(evt.ColorBackground))
                    {
                        eventTypeFrame.BackgroundColor = Color.FromHex(evt.ColorBackground);
                    }
                    Grid.SetColumn(eventTypeFrame, 0);
                    eventGrid.Children.Add(eventTypeFrame);

                    //Label titre
                    Label eventTitleLabel = new Label() { Style = (Style)Application.Current.Resources["eventTitleLabel"], Text = evt.Title, HorizontalOptions = LayoutOptions.Start };
                    Grid.SetColumn(eventTitleLabel, 1);
                    eventGrid.Children.Add(eventTitleLabel);

                    //Label heure

                    Label eventTimeLabel = new Label() { Style = (Style)Application.Current.Resources["eventTimeLabel"], Text = evt.Start.ToString("HH:mm"), HorizontalOptions = LayoutOptions.End };
                    Grid.SetColumn(eventTimeLabel, 2);
                    eventGrid.Children.Add(eventTimeLabel);

                    var lastElement = eventsSorted[3];
                    if (evt == lastElement)
                    {
                        Label lastEventDot = new Label() { Style = (Style)Application.Current.Resources["eventTimeLabel"], Text = "...", HorizontalOptions = LayoutOptions.Center, FontSize = 25 };
                        Grid.SetColumn(lastEventDot, 1);
                        eventGrid.Children.Add(lastEventDot);
                    }
                }

                

            }
                


            return grid;
        }

        private int GetDateTimeColumn(DateTime dateTime)
        {
            int column = 6;
            //Car 0 = dimanche
            if ((int)dateTime.DayOfWeek != 0)
            {
                column = (int)dateTime.DayOfWeek - 1;
            }
            return column;
        }

        public bool ShowZipTown { get; set; }
        public void Search(string search = "")
        {
            //clean the layout before using the list
            this.PopupBusy.Show();
            foreach (var lay in MainList.Children)
            {                
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (lay != null)
                    {
                        lay.IsVisible = false;
                    }
                });
            }
            if (this.AllEvents != null)
            {
                List<Event> eventsFilter = this.AllEvents;
                if (!string.IsNullOrEmpty(search))
                {
                    eventsFilter = this.AllEvents.Where(x => x.Description.ToLower().DeleteAccentMarks().Contains(search.ToLower().DeleteAccentMarks()) || x.Title.ToLower().DeleteAccentMarks().Contains(search.ToLower().DeleteAccentMarks()) || x.Mark.ToLower().DeleteAccentMarks().Contains(search.ToLower().DeleteAccentMarks()) || x.Number.ToLower().DeleteAccentMarks().Contains(search.ToLower().DeleteAccentMarks()) || x.Model.ToLower().DeleteAccentMarks().Contains(search.ToLower().DeleteAccentMarks())).ToList();
                }

                StackLayout mainStackLayout = new StackLayout() { VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.FillAndExpand, Spacing = 0 };

                this.HeaderDaysStackLayout.IsVisible = false;
                eventsFilter.Sort();
                DateTime? lastDate = null;
                foreach (Event evt in eventsFilter)
                {
                    //Séparateur haut
                    BoxView separator = new BoxView() { Style = (Style)Application.Current.Resources["horizontalSeparator"] };
                    mainStackLayout.Children.Add(separator);

                    //Date du jour si besoin
                    if (!lastDate.HasValue || lastDate.Value.ToString("yyyyMMdd") != evt.Start.ToString("yyyyMMdd"))
                    {
                        lastDate = evt.Start;
                        StackLayout dayStackLayout = new StackLayout() { HorizontalOptions = LayoutOptions.FillAndExpand, Style = (Style)Application.Current.Resources["dayStackLayout"] };
                        mainStackLayout.Children.Add(dayStackLayout);

                        Grid dayGrid = new Grid() { HorizontalOptions = LayoutOptions.FillAndExpand };
                        dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                        dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                        dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                        dayStackLayout.Children.Add(dayGrid);

                        //Jour et numéro
                        Label horizontalDayLabel = new Label() { Text = lastDate.Value.ToString("dddd d"), Style = (Style)Application.Current.Resources["horizontalDayLabel"] };
                        Grid.SetColumn(horizontalDayLabel, 0);
                        dayGrid.Children.Add(horizontalDayLabel);

                        //Mois et année
                        Label horizontalYearLabel = new Label() { Text = lastDate.Value.ToString("MMMM yyyy"), Style = (Style)Application.Current.Resources["horizontalDayLabel"], Opacity = 0.3, HorizontalTextAlignment = TextAlignment.End };
                        Grid.SetColumn(horizontalYearLabel, 2);
                        dayGrid.Children.Add(horizontalYearLabel);

                        //Séparateur bas
                        BoxView separatorBottom = new BoxView() { Style = (Style)Application.Current.Resources["horizontalSeparator"] };
                        mainStackLayout.Children.Add(separatorBottom);


                        if (lastDate.Equals(DateTime.Today))
                        {
                            dayStackLayout.BackgroundColor = Color.FromHex("1BB8A3");
                            horizontalDayLabel.TextColor = Color.White;
                            horizontalYearLabel.TextColor = Color.White;
                            horizontalDayLabel.Opacity = 1;
                            horizontalYearLabel.Opacity = 0.6;
                        }
                    }

                    //Evénement
                    Grid horizontalEventGrid = new Grid() { RowSpacing = 0, ColumnSpacing = 0, HeightRequest = 65 };
                    horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(80) });
                    horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = 2 });
                    horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                    mainStackLayout.Children.Add(horizontalEventGrid);

                    horizontalEventGrid.GestureRecognizers.Add(new TapGestureRecognizer
                    {
                        Command = new Command(() => EventClicked(horizontalEventGrid, evt.Object)),
                    });

                    //Heure début et heure fin
                    StackLayout startTimeStackLayout = new StackLayout() { Padding = new Thickness(0, 8, 10, 0) };
                    Grid.SetRow(startTimeStackLayout, 0);
                    Grid.SetColumn(startTimeStackLayout, 0);
                    horizontalEventGrid.Children.Add(startTimeStackLayout);
                    Label startTimeLabel = new Label() { Text = evt.Start.ToString("HH:mm"), Style = (Style)Application.Current.Resources["startTimeLabel"] };
                    startTimeStackLayout.Children.Add(startTimeLabel);
                    Label endTimeLabel = new Label() { Text = evt.End.ToString("HH:mm"), Style = (Style)Application.Current.Resources["endTimeLabel"] };
                    startTimeStackLayout.Children.Add(endTimeLabel);

                    //Séparateur vertical 
                    BoxView verticalSeparator = new BoxView() { Color = Color.FromHex("1BB8A3"), HorizontalOptions = LayoutOptions.FillAndExpand };
                    if (!string.IsNullOrEmpty(evt.ColorBackground))
                    {
                        verticalSeparator.Color = Color.FromHex(evt.ColorBackground);
                    }
                    Grid.SetRow(startTimeStackLayout, 0);
                    Grid.SetColumn(verticalSeparator, 1);
                    horizontalEventGrid.Children.Add(verticalSeparator);

                    //Détail événement
                    StackLayout eventDetailsStackLayout = new StackLayout() { Padding = new Thickness(15, 8, 0, 0) };
                    Grid.SetRow(eventDetailsStackLayout, 0);
                    Grid.SetColumn(eventDetailsStackLayout, 2);
                    horizontalEventGrid.Children.Add(eventDetailsStackLayout);
                   
                    Label eventDetailsTitle = new Label() { Text = evt.Title, Style = (Style)Application.Current.Resources["eventDetailsTitle"] };
                    eventDetailsStackLayout.Children.Add(eventDetailsTitle);
                    string eventDetail = evt.Description;
                    if (ShowZipTown)
                    {
                        eventDetail = evt.Description;
                    }
                    Label eventDetailsClient = new Label() { Text = eventDetail, Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                    eventDetailsStackLayout.Children.Add(eventDetailsClient);                    

                    string eventMarkModel = string.Format("{0} - {1} - {2}", evt.Number, evt.Mark, evt.Model);
                    Label eventDetailsMarkModel = new Label() { Text = eventMarkModel, Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                    eventDetailsStackLayout.Children.Add(eventDetailsMarkModel);

                }

                if (eventsFilter.Count == 0)
                {
                    Label lblNoData = new Label() { Text = AppResources.EmptyList, Style = (Style)Application.Current.Resources["horizontalDayLabel"], Margin = new Thickness(0, 20, 0, 0), HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center };
                    mainStackLayout.Children.Add(lblNoData);
                }

                Device.BeginInvokeOnMainThread(async () =>
                {
                    this.MainList.Children.Add(mainStackLayout);
                });
            }
            this.PopupBusy.Hide();
        }

        private StackLayout LoadMounth(DateTime dateTimeMonth, int limitCalendar = 0, bool? showZipTown = false, bool isLazyLoading = false, bool isPrevious = false)
        {
            StackLayout mainStackLayout = new StackLayout() { VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.FillAndExpand, Spacing = 0 };
            
            if (this.CalendarType == CalendarTypes.Calendar)
            {
                CalendarType = CalendarTypes.Calendar;
                DateTime startDate = new DateTime(dateTimeMonth.Year, dateTimeMonth.Month, 1);
                DateTime endDate = new DateTime(dateTimeMonth.Year, dateTimeMonth.Month, DateTime.DaysInMonth(dateTimeMonth.Year, dateTimeMonth.Month));
                endDate = endDate.AddDays(1);
                List<Event> events = this.DatasViewModel.LoadDatas(startDate, endDate);

                this.HeaderDaysStackLayout.IsVisible = true;
                List<DateTime> dateTimes = this.GetDates(dateTimeMonth.Year, dateTimeMonth.Month);

                Grid gridMounth = new Grid() { HorizontalOptions = LayoutOptions.FillAndExpand, RowSpacing = 0, ColumnSpacing = 0, Margin = new Thickness(0, 10, 0, 0) };

                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                gridMounth.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });

                GridLength rowHeightSeparator = new GridLength(1);
                GridLength rowHeight = new GridLength(120);
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(30) });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeight });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeight });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeight });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeight });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeight });
                gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });

                if ((int)dateTimes.First().DayOfWeek == 0 && DateTime.DaysInMonth(dateTimes.First().Year, dateTimes.First().Month) >= 30
                    || (int)dateTimes.First().DayOfWeek == 6 && DateTime.DaysInMonth(dateTimes.First().Year, dateTimes.First().Month) >= 31)
                {
                    gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeight });
                    gridMounth.RowDefinitions.Add(new RowDefinition() { Height = rowHeightSeparator });
                }

                int currentRow = 0;

                foreach (DateTime dateTime in dateTimes)
                {
                    IEnumerable<Event> enventsOfDay = events.Where((arg) => arg.Start >= new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 0, 0, 0) && arg.End <= new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 23, 59, 59));
                    //Génération ligne si besoin
                    if (currentRow == 0 || dateTime.DayOfWeek == DayOfWeek.Monday)
                    {
                        if (currentRow == 0)
                        {
                            gridMounth.Children.Add(this.GenerateHeader(dateTime, currentRow));
                            currentRow++;
                        }
                        gridMounth.Children.Add(this.GenerateRow(dateTime, currentRow));
                        currentRow++;
                    }

                    bool last = false;
                    if (dateTime == dateTimes.Last())
                    {
                        last = true;
                    }

                    //Génération jour
                    gridMounth.Children.Add(this.GenerateDay(enventsOfDay, dateTime, currentRow, last));



                    if (dateTime.DayOfWeek == DayOfWeek.Sunday && !last)
                    {
                        currentRow++;
                    }
                }
                currentRow++;
                gridMounth.Children.Add(this.GenerateRow(dateTimes.Last(), currentRow, last: true));


                mainStackLayout.Children.Add(gridMounth);

            }
            else if (this.CalendarType == CalendarTypes.Vertical)
            {
                CalendarType = CalendarTypes.Vertical;
                if (!FirstMonthPassed || limitCalendar == 0 || isLazyLoading)
                {
                    EventDayClicked = dateTimeMonth;
                    
                    DateTime startDate = new DateTime(dateTimeMonth.Year, dateTimeMonth.Month, dateTimeMonth.Day);

                    DateTime endDate = startDate.AddMonths(1);
                    
                    if (limitCalendar != 0)
                    {
                        endDate = startDate.AddDays(limitCalendar);
                        FirstMonthPassed = true;
                    }
                                             
                    endDate = endDate.AddDays(-1);
                    if (isLazyLoading)
                    {                        
                        EventDayClicked = isPrevious? startDate : endDate;
                    }
                    List<Event> events = this.DatasViewModel.LoadDatas(startDate, endDate);
                    if (showZipTown.Value)
                    {
                        foreach (var evt in events)
                        {
                            AllEvents.Add(new Event()
                            {
                                Description = evt.Description + " - " + evt.Town + ", " + evt.Zip,
                                Title = evt.Title,
                                Town = evt.Town,
                                Zip = evt.Zip,
                                Start = evt.Start,
                                End = evt.End,
                                Object = evt.Object,
                                ColorBackground = evt.ColorBackground,
                                Number = evt.Number,
                                Mark = evt.Mark,
                                Model = evt.Model
                        });
                        }                        
                    }
                    else
                    {
                        AllEvents.AddRange(events);
                    }

                    AllEvents = AllEvents.Distinct().ToList();
                    Label lblNoData = new Label() { Text = AppResources.EmptyList, Style = (Style)Application.Current.Resources["horizontalDayLabel"], Margin = new Thickness(0, 20, 0, 0), HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center };


                    this.HeaderDaysStackLayout.IsVisible = false;
                    events.Sort();
                    DateTime? lastDate = null;
                    foreach (Event evt in events)
                    {
                        //Séparateur haut
                        BoxView separator = new BoxView() { Style = (Style)Application.Current.Resources["horizontalSeparator"] };
                        mainStackLayout.Children.Add(separator);

                        //Date du jour si besoin
                        if (!lastDate.HasValue || lastDate.Value.ToString("yyyyMMdd") != evt.Start.ToString("yyyyMMdd"))
                        {
                            lastDate = evt.Start;
                            StackLayout dayStackLayout = new StackLayout() { HorizontalOptions = LayoutOptions.FillAndExpand, Style = (Style)Application.Current.Resources["dayStackLayout"] };
                            mainStackLayout.Children.Add(dayStackLayout);

                            Grid dayGrid = new Grid() { HorizontalOptions = LayoutOptions.FillAndExpand };
                            dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                            dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                            dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                            dayStackLayout.Children.Add(dayGrid);

                            //Jour et numéro
                            Label horizontalDayLabel = new Label() { Text = lastDate.Value.ToString("dddd d"), Style = (Style)Application.Current.Resources["horizontalDayLabel"] };
                            Grid.SetColumn(horizontalDayLabel, 0);
                            dayGrid.Children.Add(horizontalDayLabel);

                            //Mois et année
                            Label horizontalYearLabel = new Label() { Text = lastDate.Value.ToString("MMMM yyyy"), Style = (Style)Application.Current.Resources["horizontalDayLabel"], Opacity = 0.3, HorizontalTextAlignment = TextAlignment.End };
                            Grid.SetColumn(horizontalYearLabel, 2);
                            dayGrid.Children.Add(horizontalYearLabel);

                            //Séparateur bas
                            BoxView separatorBottom = new BoxView() { Style = (Style)Application.Current.Resources["horizontalSeparator"] };
                            mainStackLayout.Children.Add(separatorBottom);


                            if (lastDate.Equals(DateTime.Today))
                            {
                                dayStackLayout.BackgroundColor = Color.FromHex("1BB8A3");
                                horizontalDayLabel.TextColor = Color.White;
                                horizontalYearLabel.TextColor = Color.White;
                                horizontalDayLabel.Opacity = 1;
                                horizontalYearLabel.Opacity = 0.6;
                            }
                        }

                        //Evénement
                        Grid horizontalEventGrid = new Grid() { RowSpacing = 0, ColumnSpacing = 0, HeightRequest = 65 };
                        horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(80) });
                        horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = 2 });
                        horizontalEventGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Star });
                        mainStackLayout.Children.Add(horizontalEventGrid);

                        horizontalEventGrid.GestureRecognizers.Add(new TapGestureRecognizer
                        {
                            Command = new Command(() => EventClicked(horizontalEventGrid, evt.Object)),
                        });

                        //Heure début et heure fin
                        StackLayout startTimeStackLayout = new StackLayout() { Padding = new Thickness(0, 8, 10, 0) };
                        Grid.SetRow(startTimeStackLayout, 0);
                        Grid.SetColumn(startTimeStackLayout, 0);
                        horizontalEventGrid.Children.Add(startTimeStackLayout);
                        Label startTimeLabel = new Label() { Text = evt.Start.ToString("HH:mm"), Style = (Style)Application.Current.Resources["startTimeLabel"] };
                        startTimeStackLayout.Children.Add(startTimeLabel);
                        Label endTimeLabel = new Label() { Text = evt.End.ToString("HH:mm"), Style = (Style)Application.Current.Resources["endTimeLabel"] };
                        startTimeStackLayout.Children.Add(endTimeLabel);

                        //Séparateur vertical 
                        BoxView verticalSeparator = new BoxView() { Color = Color.FromHex("1BB8A3"), HorizontalOptions = LayoutOptions.FillAndExpand };
                        if (!string.IsNullOrEmpty(evt.ColorBackground))
                        {
                            verticalSeparator.Color = Color.FromHex(evt.ColorBackground);
                        }
                        Grid.SetRow(startTimeStackLayout, 0);
                        Grid.SetColumn(verticalSeparator, 1);
                        horizontalEventGrid.Children.Add(verticalSeparator);

                        //Détail événement
                        StackLayout eventDetailsStackLayout = new StackLayout() { Padding = new Thickness(15, 8, 0, 0) };
                        Grid.SetRow(eventDetailsStackLayout, 0);
                        Grid.SetColumn(eventDetailsStackLayout, 2);
                        horizontalEventGrid.Children.Add(eventDetailsStackLayout);
                        Label eventDetailsTitle = new Label() { Text = evt.Title, Style = (Style)Application.Current.Resources["eventDetailsTitle"] };
                        eventDetailsStackLayout.Children.Add(eventDetailsTitle);
                        string eventDetail = evt.Description;
                        ShowZipTown = showZipTown.Value;
                        if (showZipTown.Value)
                        {
                            eventDetail = evt.Description + " - " + evt.Town + ", " + evt.Zip;
                        }
                        Label eventDetailsClient = new Label() { Text = eventDetail, Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                        eventDetailsStackLayout.Children.Add(eventDetailsClient);

                        string eventMarkModel = string.Format("{0} - {1} - {2}", evt.Number, evt.Mark, evt.Model);
                        Label eventDetailsMarkModel = new Label() { Text = eventMarkModel, Style = (Style)Application.Current.Resources["eventDetailsClient"] };
                        eventDetailsStackLayout.Children.Add(eventDetailsMarkModel);

                    }

                    //if you are lazy loading data, then the label " No data" is invisible
                    if (events.Count == 0 && !isLazyLoading)
                    {
                        mainStackLayout.Children.Add(lblNoData);
                    }                                                           
                }                
            }
            return mainStackLayout;
        }


        public List<DateTime> GetDates(int year, int month)
        {
            return Enumerable.Range(1, DateTime.DaysInMonth(year, month))  // Days: 1, 2 ... 31 etc.
                             .Select(day => new DateTime(year, month, day)) // Map each day to a date
                             .ToList(); // Load dates into a list
        }



        double lastHeight = 0;
        string lastPropertyChanged = String.Empty;
        void ScrollView_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if ((sender as ScrollView).Height > this.lastHeight)
            {
                this.lastHeight = (sender as ScrollView).Height;
            }

            if (e.PropertyName == "Renderer")
            {
                this.lastPropertyChanged = "Renderer";
                this.ScrollToLastPosition();
            }
            else if (e.PropertyName == "Height" && this.lastPropertyChanged == "Renderer")
            {
                (sender as ScrollView).HeightRequest = this.lastHeight;
            }
            else if (e.PropertyName == "ContentSize" && this.lastPropertyChanged == "Renderer" && !EventClickedFlag)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.ScrollView.ScrollToAsync(0, (sender as ScrollView).ScrollY + 1, false);
                });
            }
        }

        void ScrollToLastPosition()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                if (Device.RuntimePlatform == Device.Android)
                {
                    this.ScrollView.ScrollToAsync(0, this.LastScrollY + 1, false);
                }
                else
                {
                    this.ScrollView.ScrollToAsync(0, this.LastScrollY, false);
                }
            });
        }

        #region Lazyloading

        private DateTime LastLazyLoading = DateTime.Now;
        private double LastScrollY = 0;
        private double previousScrollPosition = 0;
        void ScrollView_Scrolled(object sender, ScrolledEventArgs e)
        {
            ScrollView scrollView = sender as ScrollView;
            double scrollingSpace = scrollView.ContentSize.Height - scrollView.Height;
            if (Device.RuntimePlatform == Device.Android)
            {
                //Works on Android, if you down a little and then up.
                if (previousScrollPosition >= e.ScrollY && e.ScrollY < 20)
                {
                    if (Convert.ToInt16(e.ScrollY) == 0)
                        previousScrollPosition = 0;

                    this.LastLazyLoading = DateTime.Now;
                    this.PopupBusy.Show();

                    System.Threading.Tasks.Task.Run(() =>
                    {
                        this.Previous();
                        this.PopupBusy.Hide();
                    });
                }
            }
            if (scrollingSpace <= e.ScrollY && DateTime.Now - LastLazyLoading >= new TimeSpan(0, 0, 0, 2, 0))
            {
                this.LastLazyLoading = DateTime.Now;
                this.PopupBusy.Show();
                System.Threading.Tasks.Task.Run(() =>
                {
                    if (CalendarType == CalendarTypes.Vertical)
                    {
                        //+1 because in the LoadMounth has -1 day
                        this.Next(LimitDays + 1, ShowZipTown, true, EventDayClicked);
                    }
                    else
                    {
                        this.Next(0, ShowZipTown, true);
                    }
                    this.PopupBusy.Hide();
                });
                this.DatasViewModel.SearchField(string.Empty);
            }
            else if (e.ScrollY < -100 && DateTime.Now - LastLazyLoading >= new TimeSpan(0, 0, 0, 2, 0))
            {
                this.LastLazyLoading = DateTime.Now;
                this.PopupBusy.Show();

                System.Threading.Tasks.Task.Run(() =>
                {
                    if (CalendarType == CalendarTypes.Vertical)
                    {
                        this.Previous(LimitDays + 1, ShowZipTown, true, EventDayClicked, true);
                    }
                    else
                    {
                        this.Previous(0, ShowZipTown, true);
                    }
                    this.PopupBusy.Hide();
                });
                this.DatasViewModel.SearchField(string.Empty);
            }
        }

        #endregion


        public delegate void DayClickedEventHandler(DateTime dateTime);
        public event DayClickedEventHandler OnDayClicked;

        private void DayClicked(Grid grid, DateTime dateTime)
        {
            Color oldColor = grid.BackgroundColor;
            grid.BackgroundColor = Color.FromHex("15000000");
            
            if (this.OnDayClicked != null)
            {
                this.LastScrollY = ScrollView.ScrollY;
                OnDayClicked(dateTime);
            }

            System.Threading.Tasks.Task.Run(async () =>
            {
                await System.Threading.Tasks.Task.Delay(300);
                Device.BeginInvokeOnMainThread(() =>
                {
                    grid.BackgroundColor = oldColor;
                });
            });
        }

        public delegate void EventClickedEventHandler(Object obj);
        public event EventClickedEventHandler OnEventClicked;

        private void EventClicked(Grid grid, Object obj)
        {
            Color oldColor = grid.BackgroundColor;
            grid.BackgroundColor = Color.FromHex("15000000");

            if (this.OnEventClicked != null)
            {
                this.LastScrollY = ScrollView.ScrollY;
                OnEventClicked(obj);
            }

            System.Threading.Tasks.Task.Run(async () =>
            {
                await System.Threading.Tasks.Task.Delay(300);
                Device.BeginInvokeOnMainThread(() =>
                {
                    grid.BackgroundColor = oldColor;
                });
            });
        }
    }
}
