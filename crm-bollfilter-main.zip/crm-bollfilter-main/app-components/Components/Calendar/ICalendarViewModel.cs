﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public interface ICalendarViewModel
    {
        List<Event> LoadDatas(DateTime from, DateTime to);
        void SearchField(string search);
    }
}
