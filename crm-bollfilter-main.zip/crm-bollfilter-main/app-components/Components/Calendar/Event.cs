﻿using System;
namespace WFramework_Xamarin.Components
{
    public class Event : IComparable
    {
        public string Title { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Description { get; set; }
        public string Zip { get; set; }
        public string Town { get; set; }
        public object Object { get; set; }
        public string ColorBackground { get; set; }      
        public string Number { get; set; }
        public string Mark { get; set; }
        public string Model { get; set; }

        public Event()
        {
        }

        public int CompareTo(Object obj)
        {
            
            if((obj as Event).Start < this.Start)
            {
                return 1;
            }
            else if((obj as Event).Start > this.Start)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
