﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public static class MaterialIcons
    {
        public static string MICloudDone = "\ue2bf";
        public static string MICloudOff = "\ue2c1";
        public static string MICloudDownload = "\ue2C0";
    }
}
