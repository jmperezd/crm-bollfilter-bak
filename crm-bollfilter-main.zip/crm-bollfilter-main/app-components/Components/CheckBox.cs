﻿using System;
using Xamarin.Forms;
using WFramework_Xamarin.Resx;

namespace WFramework_Xamarin.Components
{
    public class Checkbox : FontAwesomeButton
    {

        private string sTrue = AppResources.Oui;
        public string STrue
        {
            get { return sTrue; }
            set { this.sTrue = value; }
        }

        private string sFalse = AppResources.Non;
        public string SFalse
        {
            get { return sFalse; }
            set { this.sFalse = value; }
        }


        public Checkbox()
        {
            base.Text = this.SFalse;//Icon.FACircleThin;
            base.Clicked += new EventHandler(OnClicked);
            base.BackgroundColor = Color.Transparent;
            base.BorderWidth = 0;
            base.Style = (Style)Application.Current.Resources["checkbox"];
        }

        public void SetTrueFalse(string sTrue, string sFalse)
        {
            this.STrue = sTrue;
            this.SFalse = sFalse;
            base.Text = this.SFalse;
        }

        public static BindableProperty CheckedProperty = BindableProperty.Create(
            propertyName: "Checked",
            returnType: typeof(Boolean?),
            declaringType: typeof(Checkbox),
            defaultValue: null,
            defaultBindingMode: BindingMode.TwoWay,
            propertyChanged: CheckedValueChanged);

        public Boolean? Checked
        {
            get
            {
                if (GetValue(CheckedProperty) == null)
                {
                    return null;
                }
                return (Boolean)GetValue(CheckedProperty);
            }
            set
            {
                SetValue(CheckedProperty, value);
                OnPropertyChanged();
                RaiseCheckedChanged();
            }
        }

        private static void CheckedValueChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (newValue != null && (Boolean)newValue == true)
            {
                ((Checkbox)bindable).Text = ((Checkbox)bindable).STrue; //AppResources.Oui;//Icon.FACheckCircleO;
            }
            else
            {
                ((Checkbox)bindable).Text = ((Checkbox)bindable).SFalse;//Icon.FACircleThin;
            }
        }

        public event EventHandler CheckedChanged;
        private void RaiseCheckedChanged()
        {
            CheckedChanged?.Invoke(this, EventArgs.Empty);
        }


        public void OnClicked(object sender, EventArgs e)
        {
            Checked = !Checked;
        }

    }
}
