﻿using System;
namespace WFramework_Xamarin.Components
{
    public interface IHideable
    {
        event EventHandler OnHide;
    }
}
