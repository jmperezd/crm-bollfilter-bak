﻿
using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace WFramework_Xamarin.Components
{
    public partial class Error : ContentView, IHideable
    {

        ErrorViewModel viewModel;
        public Command CopyCommand { get; set; }
        public Command CancelCommand { get; set; }

        public Error(List<string> errors)
        {
            InitializeComponent();

            this.viewModel = new ErrorViewModel();
            this.viewModel.OnCancel += this.Hiding;
            this.BindingContext = this.viewModel;

            this.Init(errors);
        }


        public event EventHandler OnHide;
        void Hiding(object sender, EventArgs e)
        {
            if (this.OnHide != null)
            {
                this.OnHide(this, null);
            }
        }

        public void Init(List<string> errors)
        {
            if (errors.Count == 1)
            {
                this.Title.Text = "Attention, une erreur a été remontée.";
            }
            else
            {
                this.Title.Text = "Attention, plusieurs erreurs ont été remontées.";
            }
            foreach (string error in errors)
            {
                string text = error;

                Label lineError = new Label() { Text = text, Style = (Style)Application.Current.Resources["labelLineError"] };
                this.ErrorsLayout.Children.Add(lineError);
            }
        }

    }
}
