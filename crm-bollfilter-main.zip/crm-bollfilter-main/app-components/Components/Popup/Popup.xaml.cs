﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Threading.Tasks;

namespace WFramework_Xamarin.Components
{
    public partial class Popup : StackLayout
    {
        private PopupViewModel viewModel;
        private ContentPage CurrentPage { get; set; }
        private ContentView CurrentView { get; set; }
        private bool allowUserClose = true;
        public bool AllowUserClose
        {
            get { return this.allowUserClose; }
            set { this.allowUserClose = value; }
        }

        public View ContentView
        {
            get { return this.viewModel.ContentView; }
            set
            {
                this.viewModel.ContentView = value;

                if (value is IHideable)
                {
                    (value as IHideable).OnHide += this.OnHide;
                }
            }
        }

        public Popup()
        {
            InitializeComponent();
            BindingContext = viewModel = new PopupViewModel();

            this.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => Overlay_clicked()),
            });

            this.PopupFrame.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => DoNothing_clicked()),
            });
        }

        public Popup(ContentPage page) : this()
        {
            this.CurrentPage = page;
            this.InitPopupAble();
        }

        public Popup(ContentView view) : this()
        {
            this.CurrentView = view;
            this.InitPopupAble();
        }

        public void InitBusyIndicator()
        {
            this.AllowUserClose = false;
            ActivityIndicator activityIndicator = new ActivityIndicator { IsRunning = true, IsVisible = true, IsEnabled = true, Color = Color.White };
            this.ContentView = activityIndicator;
            this.PopupFrame.BackgroundColor = Color.Transparent;
            this.PopupFrame.OutlineColor = Color.Transparent;
            this.PopupFrame.HasShadow = false;
            this.InitPopupAble();
        }


        public void Show()
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                this.IsVisible = true;
                this.FadeTo(1, 300, Easing.SpringIn);
            });
        }

        public void InitPopupAble()
        {
            this.Opacity = 0;
            AbsoluteLayout absoluteLayout = new AbsoluteLayout();
            StackLayout stackLayout = new StackLayout();
            AbsoluteLayout.SetLayoutFlags(stackLayout, AbsoluteLayoutFlags.All);
            AbsoluteLayout.SetLayoutBounds(stackLayout, new Rectangle(0f, 0f, 1, 1));

            absoluteLayout.Children.Add(stackLayout);
            absoluteLayout.Children.Add(this);

            if (CurrentPage != null)
            {
                stackLayout.Children.Add(this.CurrentPage.Content);
                AbsoluteLayout.SetLayoutFlags(this.CurrentPage.Content, AbsoluteLayoutFlags.All);
                AbsoluteLayout.SetLayoutBounds(this.CurrentPage.Content, new Rectangle(0f, 0f, 1, 1));
                this.CurrentPage.Content = absoluteLayout;
            }
            else
            {
                stackLayout.Children.Add(this.CurrentView.Content);
                this.CurrentView.Content = absoluteLayout;
            }
        }

        async void Overlay_clicked()
        {
            if (this.AllowUserClose)
            {
                this.Hide();
            }
        }

        async void DoNothing_clicked()
        {
            //Do nothing (on purpose !)
        }

        public void Hide()
        {

            Device.BeginInvokeOnMainThread(() =>
            {
                //TODO: Ne fonctionne pas, trouver un moyen de faire un fadeout
                //((this.CurrentPage.Content as AbsoluteLayout).Children[1] as Popup).FadeTo(0, 5000, Easing.SpringIn);


                this.FadeTo(0, 300, Easing.SpringIn);


                Task.Run(async () =>
                {
                    await Task.Delay(300);
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.IsVisible = false;
                    });
                });

            });

        }


        public void OnHide(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
