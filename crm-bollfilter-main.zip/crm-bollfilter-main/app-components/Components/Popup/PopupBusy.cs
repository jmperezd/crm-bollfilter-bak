﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public class PopupBusy : Popup
    {
        
        private void InitBusyIndicator()
        {
            base.AllowUserClose = false;
            ActivityIndicator activityIndicator = new ActivityIndicator { IsRunning = true, IsVisible = true, IsEnabled = true, Color = Color.White };
            base.ContentView = activityIndicator;

            base.PopupFrame.BackgroundColor = Color.Transparent;
            base.PopupFrame.OutlineColor = Color.Transparent;
            base.PopupFrame.HasShadow = false;
        }
    

        public PopupBusy(ContentPage page) : base(page)
        {
            this.InitBusyIndicator();
        }

        public PopupBusy(ContentView view) : base(view)
        {
            this.InitBusyIndicator();
        }

    }
}
