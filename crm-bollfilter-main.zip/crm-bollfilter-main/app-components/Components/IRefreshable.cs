﻿using System;
using Xamarin.Forms;
namespace WFramework_Xamarin.Components
{
    public interface IRefreshable
    {
        void Refresh();
    }
}
