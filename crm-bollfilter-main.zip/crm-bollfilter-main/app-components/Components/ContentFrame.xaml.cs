﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public partial class ContentFrame : DataFrame
    {

        ContentFrameViewModel viewModel;


        public string Title
        {
            get { return this.viewModel.Title.ToUpper(); }
            set { this.viewModel.Title = value; }
        }

        public View ContentView
        {
            get { return this.viewModel.ContentView; }
            set { this.viewModel.ContentView = value; }
        }

        public Thickness ContentViewPadding
        {
            get { return this.viewModel.ContentViewPadding; }
            set { this.viewModel.ContentViewPadding = value; }
        }

        public bool Scrollable
        {
            get { return this.viewModel.Scrollable; }
            set { this.viewModel.Scrollable = value; }
        }

        public ContentFrame()
        {
            InitializeComponent();
            BindingContext = viewModel = new ContentFrameViewModel();
        }

    }
}
