﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public class DataFrame : Frame
    {
        // no other code needs to go here unless you want more customizable properties.
    }
}
