﻿using System;
using Xamarin.Forms;

namespace WFramework_Xamarin.Components
{
    public class FontAwesomeLabel : Label
    {
        public static readonly string FontAwesomeName = "fontawesome-webfont";

        //Parameterless constructor for XAML
        public FontAwesomeLabel()
        {
            FontFamily = FontAwesomeName;
        }

        public FontAwesomeLabel(string fontAwesomeLabel = null)
        {
            FontFamily = FontAwesomeName;
            Text = fontAwesomeLabel;
        }
    }

}
