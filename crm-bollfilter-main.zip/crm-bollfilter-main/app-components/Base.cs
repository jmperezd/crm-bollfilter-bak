﻿using System;
using Xamarin.Forms;
using System.Globalization;

namespace WFramework_Xamarin
{
    public class Base
	{
		public static void Init(CultureInfo ci)
        {
            WFramework_Xamarin.Resx.AppResources.Culture = ci; // set the RESX for resource localization
        }
	}
}
