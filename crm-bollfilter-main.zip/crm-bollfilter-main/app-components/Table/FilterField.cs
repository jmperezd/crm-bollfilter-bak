﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;

namespace WFramework_Xamarin.Table
{
    public class FilterField : IEquatable<FilterField>
    {
        public string FieldName { get; set; }
        public string Value { get; set; }
        public string Operator { get; set; } = "~/"; // ~/ : contient

        public override String ToString()
        {
            return FieldName;
        }

        public bool Equals(FilterField other)
        {
            return FieldName.Equals(other.FieldName) &&
                   Value.Equals(other.Value) &&
                   Operator.Equals(other.Operator);
        }

        public Query ToLiteDBQuery()
        {
            switch(Operator) // On ne peut pas vraiment supporter les fonctions décrites ici : https://extranet.abas.de/sub_de/help/he/html/2.6.18.9.html#2.6.18.2.1.1
            {
                case "~/":
                    return Query.Contains(FieldName, Value);
                case ">":
                    return Query.GT(FieldName, Value);
                case ">=":
                    return Query.GTE(FieldName, Value);
                case "<":
                    return Query.LT(FieldName, Value);
                case "<=":
                    return Query.LTE(FieldName, Value);
                case "<>":
                    return Query.Not(FieldName, Value);
                case "==":
                default:
                    return Query.EQ(FieldName, Value);
            }
            throw new NotImplementedException();
        }
    }
}
