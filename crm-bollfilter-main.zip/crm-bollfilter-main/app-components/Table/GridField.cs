﻿using LiteDB;
using System;
using System.Collections.Generic;
using System.Text;

namespace WFramework_Xamarin.Table
{
    public class GridField : IEquatable<GridField>
    {
        public enum SortOrder
        {
            None,
            Asc,
            Desc,
        }

        public string FieldName { get; set; }
        public string Value { get; set; }
        public SortOrder Order { get; set; }

        public string DisplayedName { get; set; } = null;
        public string DisplayedFormat { get; set; } = "string";

        public GridField(string fieldName, string value, SortOrder order)
        {
            FieldName = fieldName;
            Value = value;
            Order = order;
        }

        public override String ToString()
        {
            return FieldName;
        }

        public bool Equals(GridField other)
        {
            throw new NotImplementedException();
        }

        public String GetOrderString()
        {
            if (Order == SortOrder.None)
            {
                return string.Empty;
            }
            string dir = (Order == SortOrder.Asc ? "backwards" : "forwards" );
            return $";@order={FieldName}.{dir}";
        }

        public String GetOrderTypeString()
        {
            if (Order == SortOrder.None)
            {
                return string.Empty;
            }
            return (Order == SortOrder.Asc ? "ASC" : "DESC");
        }

        public int GetQueryValue()
        {
            return (Order == SortOrder.Asc ? Query.Ascending : Query.Descending);
        }
    }
}
