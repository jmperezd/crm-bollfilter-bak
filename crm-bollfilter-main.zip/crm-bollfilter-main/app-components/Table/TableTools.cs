﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Linq;
using System.Threading.Tasks;
using WFramework_Xamarin.Components;
using System.Globalization;
using WFramework_Xamarin.Resx;

using System.IO;

namespace WFramework_Xamarin.Table
{
    public class TableTools
    {

        public string SearchLabel { get; set; } = AppResources.Rechercher;
        string PreviousClass { get; set; } = string.Empty;
        private StackLayout Container { get; set; }
        public EntityTable EntityTable { get; set; }
        public Dictionary<int, EntityTable> DicoTables = new Dictionary<int, EntityTable>();
        public string LinkAttribute { get; set; }
        public List<string> HiddenAttributes { get; set; } = new List<string>();
        public string NameAttribute { get; set; }
        public string DocumentAttribute { get; set; }
        public PopupBusy PopupBusy { get; set; }
        public List<string> ArgAttributes = new List<string>();
        private ITableViewModel viewModel;


        public delegate void HandlerBis<T, Y>(T t, Y y);
        public event HandlerBis<StackLayout, EntityRow> OnRowCellCreated;

        public delegate void FinishedDelegate();
        public event FinishedDelegate Finished;

        public string CustomButtonText;

        public List<string> ListFieldsAmount { get; set; } = new List<string>();


        private GridLength globalSearchHeight = new GridLength(50);
        private GridLength headerHeight = new GridLength(50);
        private GridLength rowHeight = new GridLength(70);
        public GridLength RowHeight
        {
            get { return this.rowHeight; }
            set { this.rowHeight = value; }
        }
        private GridLength footerHeight = new GridLength(50);
        private GridLength FooterHeight
        {
            get
            {
                if (!this.viewModel.MultiPage || this.viewModel.LazyLoading)
                {
                    return new GridLength(10);
                }
                else
                {
                    return this.footerHeight;
                }
            }
        }
        public double PaddingSearchBar { get; set; } = 10;




        private string LastSearch = string.Empty;
        private Entry entryGlobalSearch;
        private bool enableGlobalSearch = false;
        public bool EnableGlobalSearch
        {
            get { return this.enableGlobalSearch; }
            set { this.enableGlobalSearch = value; }
        }

        private bool enableSort = true;
        public bool EnableSort
        {
            get { return this.enableSort; }
            set { this.enableSort = value; }
        }

        public bool AlternateLinesColor { get; set; } = false;

        private bool displayImages = false;
        public bool DisplayImages
        {
            //get { return Context.Instance.IsConnected && this.displayImages; }
            get { return this.displayImages; }
            set { this.displayImages = value; }
        }

        private bool forceDisplayRemoveButton = false;
        public bool ForceDisplayRemoveButton
        {
            get { return forceDisplayRemoveButton; }
            set { this.forceDisplayRemoveButton = value; }
        }



        private int currentPage = 0;
        public int CurrentPage
        {
            get { return this.currentPage; }
            set
            {
                this.LastPage = this.currentPage;
                this.currentPage = value;
            }
        }
        public int LastPage = -1;

        public string TextGlobalSearch
        {
            get { return this.entryGlobalSearch?.Text; }
        }

        public TableTools(StackLayout container, ITableViewModel viewModel)
        {
            this.Container = container;
            this.Container.Spacing = 0;
            this.viewModel = viewModel;
        }

        public TableTools(StackLayout container, ITableViewModel viewModel, string prevClass = "")
        {
            PreviousClass = prevClass;
            this.Container = container;
            this.Container.Spacing = 0;
            this.viewModel = viewModel;
        }

        public void Init(string initialSearchText = "")
        {
            int nbElementsPerPage = (int)((this.Container.Height - ((this.EnableGlobalSearch ? this.globalSearchHeight.Value : 0) + this.headerHeight.Value + this.FooterHeight.Value)) / this.rowHeight.Value);
            if (nbElementsPerPage <= 0)
            {
                nbElementsPerPage = 12;
            }
            else if (nbElementsPerPage < 3)
            {
                nbElementsPerPage = 3;
            }
            this.viewModel.NbElementsPerPage = nbElementsPerPage + 1;
            this.Search(initialSearchText);
        }

        private void Search(string searchedString = null)
        {
            if (this.PopupBusy != null)
            {
                this.PopupBusy.Show();
            }
            this.LastSearch = searchedString;

            Task.Run(() =>
            {
                if (!string.IsNullOrEmpty(searchedString))
                {
                    searchedString = searchedString.ToLower().DeleteAccentMarks();
                    if (searchedString.EndsWith("."))
                    {
                        searchedString = searchedString.Substring(0,searchedString.Count()-2);
                    }
                }
                EntityTable entityTable = viewModel.LoadDatas(0, searchedString);

                Device.BeginInvokeOnMainThread(() =>
                {
                    this.DicoTables.Clear();
                    this.Container.Children.Clear();
                    if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
                    {
                        this.LazyLoadingInitialized = false;
                        this.LastScrollY = 0;
                        this.LastLazyLoading = DateTime.Now;
                        //this.NoMoreItems = false;
                        //this.GeneralGrid = null;
                    }
                    this.currentPage = 0;
                    this.LastPage = -1;
                    this.DicoTables.Add(this.CurrentPage, entityTable);

                    this.LoadLayout(entityTable);
                });
            });
        }

        //private bool NoMoreItems { get; set; } = false;
        private bool LazyLoadingInitialized { get; set; } = false;
        private int ColumnCount { get; set; } = 0;

        public static Task RunOnMainThreadAsync(Action action)
        {
            var tcs = new TaskCompletionSource<object>();
            Device.BeginInvokeOnMainThread(
                () =>
                {
                    try
                    {
                        action();
                        tcs.SetResult(null);
                    }
                    catch (Exception e)
                    {
                        tcs.SetException(e);
                    }
                });

            return tcs.Task;
        }

        private void GenerateGridColumnDefinitions(ref Grid grid, bool countColumns)
        {
            if (countColumns)
            {
                this.ColumnCount = 0;
            }

            //Column for images
            if (this.DisplayImages)
            {
                grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = rowHeight });
                if (countColumns)
                {
                    this.ColumnCount++;
                }
            }

            //Construct columns
            foreach (KeyValuePair<string, EntityColumn> kvpColumns in this.EntityTable.Columns)
            {
                if (kvpColumns.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpColumns.Key))
                {
                    float widthColumnPhone = 1;
                    if (Device.Idiom == TargetIdiom.Phone)
                    {
                        if (PreviousClass == "CUSTOMER")
                        {
                            if (kvpColumns.Key == "idno")
                            {
                                widthColumnPhone = 0.25f;
                            }
                            else if (kvpColumns.Key == "swd")
                            {
                                widthColumnPhone = 0.3f;
                            }
                            else if (kvpColumns.Key == "descrOperLang")
                            {
                                widthColumnPhone = 0.45f;
                            }
                        }
                        else if (PreviousClass == "SERVICE")
                        {
                            if (kvpColumns.Key == "descrOperLang")
                            {
                                widthColumnPhone = 0.3f;
                            }
                            else if ((kvpColumns.Key == "customer_descrOperLang") || (kvpColumns.Key == "customer^descrOperLang"))
                            {
                                widthColumnPhone = 0.4f;
                            }
                            else if (kvpColumns.Key == "lotNo")
                            {
                                widthColumnPhone = 0.3f;
                            }
                        }
                        if (PreviousClass == "BOM")
                        {
                            if (kvpColumns.Key == "elemDescr")
                            {
                                widthColumnPhone = 0.2f;
                            }
                            else if (kvpColumns.Key == "elemQty")
                            {
                                widthColumnPhone = 0.1f;
                            }
                            else if (kvpColumns.Key == "elemSU")
                            {
                                widthColumnPhone = 0.2f;
                            }
                            else if (kvpColumns.Key == "serviceProductImplFrom")
                            {
                                widthColumnPhone = 0.25f;
                            }
                            else if (kvpColumns.Key == "serviceProductImplTo")
                            {
                                widthColumnPhone = 0.25f;
                            }

                        }
                    }

                    //Set custom Width for ProductsSAV for SOFTICA
                    if (PreviousClass == "SERVICE")
                    {
                        switch (kvpColumns.Key)
                        {
                            case "idno":
                                widthColumnPhone = 0.12f;
                                break;
                            case "clientModel":
                                widthColumnPhone = 0.25f;
                                break;
                            case "contract":
                                widthColumnPhone = 0.2f;
                                break;
                            case "lastVisit":
                                widthColumnPhone = 0.23f;
                                break;
                            case "nextVisit":
                                widthColumnPhone = 0.2f;
                                break;
                        }
                    }
                    grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(widthColumnPhone, GridUnitType.Star) });//GridLength.Auto });
                    if (countColumns)
                    {
                        this.ColumnCount++;
                    }
                }
            }


            //Buttons
            if (PreviousClass != "TASK")
            {
                if (!string.IsNullOrWhiteSpace(this.DocumentAttribute) || this.OnAddToCartClicked != null || this.OnCustomButtonClicked != null || this.OnRemoveClicked != null || this.OnLoadSpecialIndicator != null)
                {
                    grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });//GridLength.Auto });                
                    if (countColumns)
                    {
                        this.ColumnCount++;
                    }
                }
            }

            int widthLastColumn = 50;
            if (Device.Idiom == TargetIdiom.Phone)
            {
                widthLastColumn = 0;
            }
            if (PreviousClass != "TASK")
            {
                grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(widthLastColumn) });
            }
            if (countColumns)
            {
                this.ColumnCount++;
            }

        }

        private Grid GenerateHeader()
        {
            Grid gridHeader = new Grid() { ColumnSpacing = 0, RowSpacing = 0, VerticalOptions = LayoutOptions.Fill, HorizontalOptions = LayoutOptions.FillAndExpand };
            this.GenerateGridColumnDefinitions(ref gridHeader, true);
            int rowCount = 0;

            if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
            {
                this.LazyLoadingInitialized = true;
            }

            //Global search
            if (this.EnableGlobalSearch)
            {
                float widthBarPhone = 10;
                if (Device.Idiom == TargetIdiom.Phone)
                {
                    widthBarPhone = 80;
                }
                gridHeader.RowDefinitions.Add(new RowDefinition() { Height = globalSearchHeight });
                StackLayout stackLayoutGlobalSearch = new StackLayout() { Orientation = StackOrientation.Horizontal, Padding = new Thickness(this.PaddingSearchBar, 10, widthBarPhone, 0) };

                Label iconGlobalSearch = new Label() { VerticalOptions = LayoutOptions.Center, Text = Icon.FASearch, Style = (Style)Application.Current.Resources["iconGlobalSearchGrid"] };
                stackLayoutGlobalSearch.Children.Add(iconGlobalSearch);
                Keyboard keyboard = Keyboard.Create(KeyboardFlags.None);
                entryGlobalSearch = new LineEntry() { HorizontalOptions = LayoutOptions.FillAndExpand, Style = (Style)Application.Current.Resources["entryGlobalSearchGrid"], Placeholder = this.SearchLabel, BorderColor = Color.FromHex("30000000"), LineHeight = 15, LineWidth = this.Container.Width - this.PaddingSearchBar - 40, Text = this.LastSearch, Keyboard = keyboard };
                entryGlobalSearch.Completed += (sender, e) => { this.GlobalSearch(); };
                stackLayoutGlobalSearch.Children.Add(entryGlobalSearch);
                //Button buttonGlobalSearch = new Button() { Text = "Rechercher", Style = (Style)Application.Current.Resources["buttonGlobalSearchGrid"], Command = new Command(() => GlobalSearch()) };
                //stackLayoutGlobalSearch.Children.Add(buttonGlobalSearch);
                Button buttonReinitGlobalSearch = new Button() { Text = "X", Style = (Style)Application.Current.Resources["buttonReinitGlobalSearchGrid"], Command = new Command(() => ReinitGlobalSearch()) };
                stackLayoutGlobalSearch.Children.Add(buttonReinitGlobalSearch);

                gridHeader.Children.Add(stackLayoutGlobalSearch, 0, this.ColumnCount, rowCount, rowCount + 1);
                rowCount++;

                /*
                //Separator
                grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1) });
                BoxView boxViewSeparatorGlobalSearch = new BoxView() { HeightRequest = 1.0, BackgroundColor = Color.FromHex("00569A"), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.Center };
                grid.Children.Add(boxViewSeparatorGlobalSearch, 0, columnCount, rowCount, rowCount+1);
                rowCount++;
                */

            }




            //Header
            gridHeader.RowDefinitions.Add(new RowDefinition() { Height = headerHeight });

            int count = 0;
            if (this.DisplayImages)
            {
                count++;
            }
            foreach (KeyValuePair<string, EntityColumn> kvpColumns in this.EntityTable.Columns)
            {
                if (kvpColumns.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpColumns.Key))
                {
                    StackLayout stackLayout = new StackLayout() { Padding = this.EnableGlobalSearch ? new Thickness(20, 4, 0, 0) : new Thickness(20, 8, 0, 0), VerticalOptions = LayoutOptions.Center, Orientation = StackOrientation.Horizontal };
                    string titleLabel = kvpColumns.Value.ColLabel.ToUpper();
                    //ONLY FOR SOFTICA
                    if (PreviousClass == "SERVICE")
                    {
                        titleLabel = SetTitleServices(kvpColumns);
                    }
                    Label label = new Label() { Text = titleLabel, Style = (Style)Application.Current.Resources["headerLabelGrid"] };
                    stackLayout.Children.Add(label);

                    //Affichage des boutons de tri
                    GridField gridField = this.viewModel.GridFields.Select(g => g).Where(g => g.FieldName == kvpColumns.Key).FirstOrDefault();
                    if (gridField != null)
                    {
                        Label orderLabel = new Label() { Style = (Style)Application.Current.Resources["headerLabelGridChevron"] };
                        switch (gridField.Order)
                        {
                            case GridField.SortOrder.Desc:
                                orderLabel.Text = Icon.FAChevronDown;
                                break;
                            case GridField.SortOrder.Asc:
                                orderLabel.Text = Icon.FAChevronUp;
                                break;
                            case GridField.SortOrder.None:
                                orderLabel.Text = string.Empty;
                                break;
                        }
                        stackLayout.Children.Add(orderLabel);
                        if (this.EnableSort)
                        {
                            stackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                            {
                                Command = new Command(() => HeaderClicked(stackLayout, gridField)),
                            });
                        }
                    }

                    gridHeader.Children.Add(stackLayout, count, rowCount);
                    count++;
                }
            }
            rowCount++;

            //Separator
            gridHeader.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(2) });
            BoxView boxViewSeparator = new BoxView() { HeightRequest = 2.0, BackgroundColor = Color.FromHex("1BB8A3"), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.Center };
            gridHeader.Children.Add(boxViewSeparator, 0, this.ColumnCount, rowCount, rowCount + 1);
            rowCount++;
            //< BoxView HeightRequest = "1" BackgroundColor = "White" HorizontalOptions = "FillAndExpand" />


            return gridHeader;
        }

        private string SetTitleServices(KeyValuePair<string, EntityColumn> kvpColumns)
        {
            switch(kvpColumns.Key)
            {
                case "idno":
                    return "NUMÉRO ID";
                case "clientModel":
                    return "CLIENT / MARQUE MODELE";
                case "contract":
                    return "CONTRAT";
                default:
                    return kvpColumns.Value.ColLabel.ToUpper();
            }            
        }

        public Grid GenerateContent()
        {
            Grid gridContent = new Grid() { ColumnSpacing = 0, RowSpacing = 0, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
            this.GenerateGridColumnDefinitions(ref gridContent, false);

            int rowCount = 0;
            bool even = false;

            //Rows
            foreach (EntityRow row in this.EntityTable.Rows)
            {
                RowDefinition rowDefinition = new RowDefinition() { Height = rowHeight };

                gridContent.RowDefinitions.Add(rowDefinition);


                //List for touch
                List<StackLayout> listStackLayouts = new List<StackLayout>();

                int i = 0;
                foreach (KeyValuePair<string, EntityCell> kvpClientCell in row.Cells)
                {
                    if (kvpClientCell.Key != this.LinkAttribute && !this.HiddenAttributes.Contains(kvpClientCell.Key))
                    {
                        //Content
                        StackLayout stackLayout = new StackLayout() { Padding = new Thickness(30, 0, 0, 0), VerticalOptions = LayoutOptions.Center };
                        if (Device.Idiom == TargetIdiom.Phone)
                        {
                            stackLayout = new StackLayout() { Padding = new Thickness(5, 0, 5, 0), VerticalOptions = LayoutOptions.Center };
                        }

                        string value = kvpClientCell.Value.Value;
                        if (value == null)
                        {
                            value = string.Empty;
                        }
                        string styleValue = "valueLabelGrid";

                        //SOFTICA change string to datetime to get the format in dd/mm/yyyy
                        if (PreviousClass == "SERVICE")
                        {
                            if (kvpClientCell.Value.IdColumn == "lastVisit" || kvpClientCell.Value.IdColumn == "nextVisit")
                            {
                                string dateString = value.Substring(0,value.IndexOf(" "));
                                string extraString = value.Substring(value.IndexOf(" "));
                                DateTime dt2;
                                DateTime.TryParse(dateString, out dt2);
                                if (dt2 != null)
                                {
                                    dateString = dt2.ToString("dd/MM/yy");
                                    styleValue = "valueLabelGridCenter";
                                }
                                if ((dateString == "01/01/0001") || (dateString == "01/01/01"))
                                {
                                    dateString = string.Empty;
                                }
                                value = dateString + extraString;
                            }
                        }

                        switch (this.EntityTable.Columns[kvpClientCell.Value.IdColumn].Type.ToLower())
                        {
                            case "datetime":
                                DateTime dt;
                                DateTime.TryParse(value, out dt);
                                if (dt != null)
                                {
                                    value = dt.ToString("HH:mm");
                                    styleValue = "valueLabelGridCenter";
                                }
                                break;
                            case "date":
                            case "datetime-tz":
                                DateTime dt2;
                                DateTime.TryParse(value, out dt2);
                                if (dt2 != null)
                                {                                    
                                    value = dt2.ToString("dd/MM/yy");                                    
                                    styleValue = "valueLabelGridCenter";
                                }
                                if ((value == "01/01/0001") || (value == "01/01/01"))
                                {
                                    value = string.Empty;
                                }
                                break;
                            case "decimal":
                                if (this.ListFieldsAmount.Contains(kvpClientCell.Key))
                                {
                                    double db = ToolsHelper.ConvertToDouble(value);

                                    if (db != null)
                                    {
                                        value = DisplayTools.FormatAmount(db);
                                        styleValue = "valueLabelGridEnd";
                                    }
                                }
                                break;
                            case "percent":
                                if (!string.IsNullOrWhiteSpace(value))
                                {
                                    value = value + " %";
                                    styleValue = "valueLabelGridEnd";
                                }
                                break;
                            default:
                                if (this.ColumnCount - 1 > 5)
                                {
                                    if (i == 0 && value.Length > 20)
                                    {
                                        value = value.Substring(0, 20) + "...";
                                    }
                                    if (value.Length > 60)
                                    {
                                        value = value.Substring(0, 60) + "...";
                                    }
                                }
                                break;
                        }

                        Label label = new Label() { Text = value, Style = (Style)Application.Current.Resources[styleValue] };

                        if (PreviousClass == "SERVICE" && kvpClientCell.Key == "lastVisit")
                        {
                            System.Reflection.PropertyInfo colorCode = row.Object.GetType().GetProperty("codeColor");
                            String code = (String)(colorCode.GetValue(row.Object, null));

                            System.Reflection.PropertyInfo color = row.Object.GetType().GetProperty("color");
                            Color col = (Color)(color.GetValue(row.Object, null));

                            if (!string.IsNullOrEmpty(code) && !code.StartsWith("0"))
                            {
                                StackLayout stackLayoutCircleColor = new StackLayout() { Orientation = StackOrientation.Horizontal, VerticalOptions = LayoutOptions.FillAndExpand};
                                Frame frameColor = new Frame() { BackgroundColor = col, Style = (Style)Application.Current.Resources["eventTypeFrame"] };                                
                                stackLayoutCircleColor.Children.Add(frameColor);
                                stackLayoutCircleColor.Children.Add(label);
                                stackLayout.Children.Add(stackLayoutCircleColor);
                            }
                            else
                            {
                                stackLayout.Children.Add(label);
                            }
                        }
                        else
                        {
                            stackLayout.Children.Add(label);
                        }

                        gridContent.Children.Add(stackLayout, i, rowCount);


                        //Background (added after content to allow click on  text)
                        StackLayout stackLayoutContainer = new StackLayout() { VerticalOptions = LayoutOptions.FillAndExpand };
                        listStackLayouts.Add(stackLayoutContainer);
                        if (even)
                        {
                            stackLayoutContainer.BackgroundColor = Color.FromHex("1000569A");
                        }
                        else
                        {
                            stackLayoutContainer.BackgroundColor = Color.Transparent;
                        }

                        if (OnRowCellCreated != null)
                        {
                            OnRowCellCreated(stackLayoutContainer, row);
                        }

                        gridContent.Children.Add(stackLayoutContainer, i, rowCount);


                        i++;
                    }
                    else if (this.DisplayImages)
                    {

                        StackLayout stackLayoutActivityIndicator = new StackLayout() { VerticalOptions = LayoutOptions.Center, Padding = new Thickness(20) };
                        ActivityIndicator activityIndicator = new ActivityIndicator() { IsRunning = true, IsVisible = true, IsEnabled = true, Color = Color.FromHex("10000000") };
                        stackLayoutActivityIndicator.Children.Add(activityIndicator);
                        gridContent.Children.Add(stackLayoutActivityIndicator, i, rowCount);

                        //Background (added after content to allow click on  text)
                        StackLayout stackLayoutContainer = new StackLayout() { VerticalOptions = LayoutOptions.FillAndExpand };
                        listStackLayouts.Add(stackLayoutContainer);
                        if (even)
                        {
                            stackLayoutContainer.BackgroundColor = Color.FromHex("1000569A");
                        }
                        else
                        {
                            stackLayoutContainer.BackgroundColor = Color.Transparent;
                        }
                        gridContent.Children.Add(stackLayoutContainer, i, rowCount);

                        int j = i;
                        bool even2 = even;
                        int rowCount2 = rowCount;
                        Task.Run(() =>
                        {
                            StackLayout stackLayout = new StackLayout() { VerticalOptions = LayoutOptions.CenterAndExpand, Padding = new Thickness(10, 0, 0, 0) };

                            /*
                            Ressource resource = (this.viewModel as ProductsViewModel).GetResource(kvpClientCell.Value.Value);
                            Image image;
                            if (resource != null)
                            {
                                image = new Image() { Aspect = Aspect.AspectFit, Source = ImageSource.FromUri(new Uri(resource.LienRessource)) };
                                stackLayout.Children.Add(image);
                            }
                            else{
                                image = new Image() { Aspect = Aspect.AspectFit, Source = ImageSource.FromFile("no_picture.png") };
                                stackLayout.Children.Add(image);
                            }
                            */
                            Image image = null;


                            Device.BeginInvokeOnMainThread(() =>
                            {
                                stackLayout.Children.Add(image);
                                gridContent.Children.Add(stackLayout, j, rowCount2);

                                stackLayoutContainer.BackgroundColor = Color.Transparent;
                                //Background (added after content to allow click on  text)
                                StackLayout stackLayoutContainer2 = new StackLayout() { VerticalOptions = LayoutOptions.FillAndExpand };
                                listStackLayouts.Add(stackLayoutContainer2);
                                if (even2)
                                {
                                    stackLayoutContainer2.BackgroundColor = Color.FromHex("1000569A");
                                }
                                else
                                {
                                    stackLayoutContainer2.BackgroundColor = Color.Transparent;
                                }
                                gridContent.Children.Add(stackLayoutContainer2, j, rowCount2);

                            });
                        });
                        i++;
                    }
                }

                //Empty column

                //Background (added after content to allow click on  text)
                StackLayout stackLayoutContainerEmpty = new StackLayout() { VerticalOptions = LayoutOptions.FillAndExpand };
                listStackLayouts.Add(stackLayoutContainerEmpty);
                if (even)
                {
                    stackLayoutContainerEmpty.BackgroundColor = Color.FromHex("1000569A");
                }
                else
                {
                    stackLayoutContainerEmpty.BackgroundColor = Color.Transparent;
                }

                if (OnRowCellCreated != null)
                {
                    OnRowCellCreated(stackLayoutContainerEmpty, row);
                }

                gridContent.Children.Add(stackLayoutContainerEmpty, i, rowCount);
                i++;


                //Buttons
                if (PreviousClass != "TASK")
                {
                    if (!string.IsNullOrWhiteSpace(this.DocumentAttribute) || this.OnAddToCartClicked != null || this.OnCustomButtonClicked != null || this.OnRemoveClicked != null || this.OnLoadSpecialIndicator != null)
                    {

                        //Background (added before content to disallow click on button)
                        StackLayout stackLayoutContainer = new StackLayout() { VerticalOptions = LayoutOptions.FillAndExpand };
                        listStackLayouts.Add(stackLayoutContainer);
                        if (even)
                        {
                            stackLayoutContainer.BackgroundColor = Color.FromHex("1000569A");
                        }
                        else
                        {
                            stackLayoutContainer.BackgroundColor = Color.Transparent;
                        }

                        gridContent.Children.Add(stackLayoutContainer, i, rowCount);

                        Dictionary<string, object> dicoArgs = new Dictionary<string, object>();
                        foreach (string arg in this.ArgAttributes)
                        {
                            dicoArgs.Add(arg, row.Cells[arg].Value);
                        }
                        dicoArgs.Add("_object", row.Object);
                        StackLayout stackLayout = new StackLayout() { HorizontalOptions = LayoutOptions.Start, VerticalOptions = LayoutOptions.Center, Margin = new Thickness(0, 1, 0, 0), Orientation = StackOrientation.Horizontal };
                        if (this.OnLoadSpecialIndicator != null)
                        {
                            bool display = this.OnLoadSpecialIndicator(dicoArgs);
                            if (display)
                            {
                                Label labelBell = new Label() { Text = Icon.FABell, Style = (Style)Application.Current.Resources["labelSpecialClientGrid"] };
                                stackLayout.Children.Add(labelBell);
                            }
                        }
                        if (!string.IsNullOrWhiteSpace(this.DocumentAttribute))
                        {
                            //FontAwesomeButton fontAwesomeButton = new FontAwesomeButton() { Padding = new Thickness(0), Text = Icon.FAFilePdfO, Style = (Style)Application.Current.Resources["inlineButtonClientGrid"], Command = new Command(() => ViewDocumentClicked(row.Cells[this.DocumentAttribute].Value)) };
                            //fontAwesomeButton.BackgroundColor = Color.Transparent;
                            /*
                            fontAwesomeButton.BindingContext = Context.Instance;
                            fontAwesomeButton.SetBinding(Button.IsEnabledProperty, new Binding("IsConnected"));
                            */
                            //stackLayout.Children.Add(fontAwesomeButton);
                        }
                        if (this.OnAddToCartClicked != null)
                        {
                            FontAwesomeButton fontAwesomeButton = new FontAwesomeButton() { Padding = new Thickness(0), Margin = new Thickness(0, 20, 0, 0), Text = Icon.FAShoppingCart, Style = (Style)Application.Current.Resources["inlineBigButtonClientGrid"], Command = new Command(() => AddToCartClicked(row.Cells[this.LinkAttribute].Value)) };
                            fontAwesomeButton.BackgroundColor = Color.Transparent;
                            stackLayout.Children.Add(fontAwesomeButton);
                        }
                        if (this.OnRemoveClicked != null)
                        {
                            FontAwesomeButton fontAwesomeButton = new FontAwesomeButton() { Padding = new Thickness(0), Text = Icon.FATrashO, Style = (Style)Application.Current.Resources["inlineButtonClientGrid"], Command = new Command(() => RemoveClicked(row.Cells[this.LinkAttribute].Value)) };
                            fontAwesomeButton.BackgroundColor = Color.Transparent;
                            /*
                            fontAwesomeButton.BindingContext = Context.Instance;
                            if (!this.ForceDisplayRemoveButton)
                            {
                                fontAwesomeButton.SetBinding(Button.IsEnabledProperty, new Binding("IsConnected"));
                            }
                            */
                            stackLayout.Children.Add(fontAwesomeButton);
                        }
                        if (this.OnCustomButtonClicked != null)
                        {
                            CustomButton customButton = new FontAwesomeButton() { Margin = new Thickness(0, 6, 6, 6), Padding = new Thickness(0), Text = this.CustomButtonText, Style = (Style)Application.Current.Resources["inlineCustomButtonClientGrid"], Command = new Command(() => CustomButtonClicked(row.Cells[this.LinkAttribute].Value, row.Cells[this.NameAttribute].Value)) };
                            stackLayout.Children.Add(customButton);
                        }

                        if (PreviousClass != "TASK")
                        {
                            gridContent.Children.Add(stackLayout, i, rowCount);
                        }
                    }
                }
                foreach (StackLayout stackLayout in listStackLayouts)
                {
                    if (!string.IsNullOrWhiteSpace(this.LinkAttribute))
                    {
                        //Arguments for click
                        Dictionary<string, object> dicoArgs = new Dictionary<string, object>();
                        foreach (string arg in this.ArgAttributes)
                        {
                            dicoArgs.Add(arg, row.Cells[arg].Value);
                        }
                        dicoArgs.Add("_object", row.Object);
                        if (this.OnViewClicked != null)
                        {
                            stackLayout.GestureRecognizers.Add(new TapGestureRecognizer
                            {
                                Command = new Command(() => ViewClicked(listStackLayouts, row.Cells[this.LinkAttribute].Value, dicoArgs)),
                            });
                        }
                    }
                }


                rowCount++;

                /*
                grid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1) });
                boxViewSeparator = new BoxView() { HeightRequest = 1.0, BackgroundColor = Color.FromHex("15000000"), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.Center };
                grid.Children.Add(boxViewSeparator, 0, columnCount, rowCount, rowCount + 1);
                */


                gridContent.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1) });

                Grid gridSeparator = new Grid() { HorizontalOptions = LayoutOptions.FillAndExpand };
                gridContent.Children.Add(gridSeparator, 0, this.ColumnCount, rowCount, rowCount + 1);

                gridSeparator.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(5) });
                gridSeparator.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                gridSeparator.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(5) });
                BoxView boxViewSeparator = new BoxView() { HeightRequest = 1.0, BackgroundColor = Color.FromHex("102A3539"), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.Center };
                gridSeparator.Children.Add(boxViewSeparator, 1, 0);



                rowCount++;

                if (this.AlternateLinesColor)
                {
                    even = !even;
                }

            }

            if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
            {
                //Ne rien faire
            }
            else if (this.viewModel.MultiPage)
            {
                gridContent.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

                StackLayout stackLayoutButtons = new StackLayout() { HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.End, Margin = new Thickness(0, -6, 0, 0), Orientation = StackOrientation.Horizontal, HeightRequest = 50 };

                bool leftEnabled = true;
                if (this.CurrentPage == 0)
                {
                    leftEnabled = false;
                }
                Grid gridButton = new Grid() { Padding = new Thickness(0, 15, 0, 0) };
                Label labelPreviousButton = new Label() { Text = Icon.FACaretLeft, Style = (Style)Application.Current.Resources["labelClientGrid"] };
                FontAwesomeButton previousButton = new FontAwesomeButton() { Style = (Style)Application.Current.Resources["buttonClientGrid"], Command = new Command(() => Previous()), IsEnabled = leftEnabled };
                Grid.SetRow(labelPreviousButton, 0);
                Grid.SetColumn(labelPreviousButton, 0);
                Grid.SetRow(previousButton, 0);
                Grid.SetColumn(previousButton, 0);
                gridButton.Children.Add(labelPreviousButton);
                gridButton.Children.Add(previousButton);
                stackLayoutButtons.Children.Add(gridButton);

                Label labelCurrentPage = new Label() { Text = (this.CurrentPage + 1).ToString(), Margin = new Thickness(0, 12, 0, 0) };
                stackLayoutButtons.Children.Add(labelCurrentPage);

                bool rightEnabled = true;
                if (string.IsNullOrWhiteSpace(this.EntityTable.RowIdEnrSuiv))
                {
                    //rightEnabled = false;
                }

                gridButton = new Grid() { Padding = new Thickness(0, 15, 0, 0) };
                Label labelNextButton = new Label() { Text = Icon.FACaretRight, Style = (Style)Application.Current.Resources["labelClientGrid"] };
                FontAwesomeButton nextButton = new FontAwesomeButton() { Style = (Style)Application.Current.Resources["buttonClientGrid"], Command = new Command(() => Next()), IsEnabled = rightEnabled };
                Grid.SetRow(labelNextButton, 0);
                Grid.SetColumn(labelNextButton, 0);
                Grid.SetRow(nextButton, 0);
                Grid.SetColumn(nextButton, 0);
                gridButton.Children.Add(labelNextButton);
                gridButton.Children.Add(nextButton);
                stackLayoutButtons.Children.Add(gridButton);

                gridContent.Children.Add(stackLayoutButtons, 0, this.ColumnCount, rowCount, rowCount + 1);

                if (this.OnNewObjectClicked != null)
                {
                    StackLayout stackLayoutActions = new StackLayout() { HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.End, Margin = new Thickness(0, -6, 0, 0), Orientation = StackOrientation.Horizontal };
                    FontAwesomeButton newObjectButton = new FontAwesomeButton() { Text = Icon.FAPlusCircle, Style = (Style)Application.Current.Resources["buttonAddObjectViewClientGrid"], Command = new Command(() => NewObject()) };
                    stackLayoutActions.Children.Add(newObjectButton);
                    gridContent.Children.Add(stackLayoutActions, 0, this.ColumnCount, rowCount, rowCount + 1);
                    /*
                    newObjectButton.BindingContext = Context.Instance;
                    newObjectButton.SetBinding(Button.IsEnabledProperty, new Binding("IsConnected"));
                    */
                }

            }
            else
            {
                gridContent.RowDefinitions.Add(new RowDefinition() { Height = this.FooterHeight });
            }

            if (Finished != null)
            {
                Finished();
            }

            return gridContent;

        }

        private void Previous()
        {
            if (this.CurrentPage > 0)
            {
                this.CurrentPage = this.CurrentPage - 1;
                this.ReloadPage();
            }
        }

        public void Next()
        {
            //if (!string.IsNullOrWhiteSpace(this.EntityTable.RowIdEnrSuiv))
            //{
            this.CurrentPage = this.CurrentPage + 1;
            if (this.DicoTables.ContainsKey(this.CurrentPage))
            {
                this.ReloadPage();
            }
            else
            {
                this.LoadNextPage();
            }
            //this.PreloadNextPageAsync();
            //}
        }

        public delegate bool LoadSpecialIndicatorEventHandler(Dictionary<string, object> dicoArgs);
        public event LoadSpecialIndicatorEventHandler OnLoadSpecialIndicator;


        public delegate void NewObjectClickedEventHandler();
        public event NewObjectClickedEventHandler OnNewObjectClicked;

        private void NewObject()
        {
            if (this.OnNewObjectClicked != null)
            {
                this.OnNewObjectClicked();
            }
        }

        public void GlobalSearch()
        {
            if (this.entryGlobalSearch != null)
            {
                this.Search(this.entryGlobalSearch?.Text);
            }
            else
            {
                this.Search();
            }
        }

        private void ReinitGlobalSearch()
        {
            this.Search(string.Empty);
        }

        private void DisplayPage(int idPage)
        {
            if (this.DicoTables.ContainsKey(idPage))
            {
                this.CurrentPage = idPage;
                this.ReloadPage();
            }
        }

        private void ReloadPage()
        {
            this.LoadLayout(this.DicoTables[this.CurrentPage]);
        }

        public void LoadLayout(EntityTable entityTable)
        {
            if (this.PopupBusy != null)
            {
                this.PopupBusy.Show();
            }

            Task.Run(() =>
            {
                this.EntityTable = entityTable;

                if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
                {
                    //Ne rien faire
                }
                else
                {
                    this.LoadNextPage(true);
                }
                if (!this.viewModel.LazyLoading && this.LastPage > -1 && this.Container.Children.Count - 1 >= this.CurrentPage)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
                        {
                            //Ne rien faire
                        }
                        else
                        {
                            this.Container.Children[this.CurrentPage].IsVisible = true;
                            this.Container.Children[this.LastPage].IsVisible = false;
                        }
                    });
                }
                else
                {
                    try
                    {
                        Grid gridHeader = null;
                        //if (!this.viewModel.LazyLoading || (this.viewModel.MultiPage && this.viewModel.LazyLoading && !this.LazyLoadingInitialized))
                        //{
                        gridHeader = this.GenerateHeader();
                        //}
                        Grid gridContent = this.GenerateContent();

                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Grid gridScrollView;
                            if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
                            {
                                if (this.Container.Children.Count == 0)
                                {
                                    this.Container.Children.Add(gridHeader);
                                    ScrollView scrollView = new ScrollView() { HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
                                    gridScrollView = new Grid() { RowSpacing = 0 };
                                    scrollView.Content = gridScrollView;
                                    scrollView.Scrolled += ScrollView_Scrolled;
                                    scrollView.LayoutChanged += ScrollView_LayoutChanged;
                                    scrollView.PropertyChanged += ScrollView_PropertyChanged; ;

                                    this.Container.Children.Add(scrollView);
                                    gridScrollView.Children.Add(gridContent);
                                }
                                else
                                {
                                    this.ShowLazyLoadingIndicator(false);
                                    if (gridContent.Children.Count > 0)
                                    {
                                        gridScrollView = ((this.Container.Children[1] as ScrollView).Content as Grid);
                                        Grid.SetRow(gridContent, gridScrollView.Children.Count);

                                        this.LastScrollY = (this.Container.Children[1] as ScrollView).ScrollY;

                                        gridScrollView.Children.Add(gridContent);

                                        this.ScrollToLastPosition();
                                    }
                                }
                            }
                            else
                            {
                                Grid globalGrid = new Grid() { ColumnSpacing = 0, RowSpacing = 0, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
                                globalGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                                globalGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                                globalGrid.Children.Add(gridHeader);
                                globalGrid.Children.Add(gridContent);
                                Grid.SetRow(gridHeader, 0);
                                Grid.SetRow(gridContent, 1);

                                this.Container.Children.Add(globalGrid);

                                if (this.LastPage > -1)
                                {
                                    this.Container.Children[this.LastPage].IsVisible = false;
                                }
                            }
                            if (this.PopupBusy != null)
                            {
                                this.PopupBusy.Hide();
                            }
                        });
                    }
                    catch (Exception e)
                    {

                    }

                }
                if (this.PopupBusy != null)
                {
                    this.PopupBusy.Hide();
                }
            });
        }

        double lastHeight = 0;
        string lastPropertyChanged = String.Empty;
        void ScrollView_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if ((sender as ScrollView).Height > this.lastHeight)
            {
                this.lastHeight = (sender as ScrollView).Height;
            }

            if (e.PropertyName == "Renderer")
            {
                this.lastPropertyChanged = "Renderer";
                this.ScrollToLastPosition();
            }
            else if (e.PropertyName == "Height" && this.lastPropertyChanged == "Renderer")
            {
                (sender as ScrollView).HeightRequest = this.lastHeight;
            }
        }


        void ScrollView_PropertyChanging(object sender, PropertyChangingEventArgs e)
        {
        }


        void ScrollView_LayoutChanged(object sender, EventArgs e)
        {
        }


        private void ScrollToLastPosition()
        {

            if (this.Container.Children.Count > 1)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    try
                    {
                        (this.Container.Children[1] as ScrollView).ScrollToAsync(0, this.LastScrollY, false);
                    }
                    catch (Exception e)
                    {
                        //Debug e
                    }
                });
            }

        }

        private bool LazyIndicatorShowing = false;
        private ActivityIndicator ActivityIndicator = null;
        private StackLayout StackLayoutActivityIndicator = null;

        private void ShowLazyLoadingIndicator(bool show)
        {
            if (show && !LazyIndicatorShowing)
            {
                if (this.ActivityIndicator == null)
                {
                    ActivityIndicator = new ActivityIndicator { IsRunning = true, IsVisible = true, IsEnabled = true, Color = Color.Gray, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center, HeightRequest = 50 };
                    StackLayoutActivityIndicator = new StackLayout() { HeightRequest = 50, HorizontalOptions = LayoutOptions.FillAndExpand, Margin = new Thickness(0, -50, 0, 0) };
                    StackLayoutActivityIndicator.Children.Add(ActivityIndicator);
                    this.Container.Children.Add(this.StackLayoutActivityIndicator);
                }

                this.LazyIndicatorShowing = true;
                Device.BeginInvokeOnMainThread(() =>
                {
                    StackLayoutActivityIndicator.IsVisible = true;
                });
            }
            else if (!show && LazyIndicatorShowing)
            {
                this.LazyIndicatorShowing = false;
                Device.BeginInvokeOnMainThread(() =>
                {
                    this.StackLayoutActivityIndicator.IsVisible = false;
                });
            }
        }

        private DateTime LastLazyLoading = DateTime.Now;
        private double LastScrollY = 0;

        void ScrollView_Scrolled(object sender, ScrolledEventArgs e)
        {
            ScrollView scrollView = sender as ScrollView;
            double scrollingSpace = scrollView.ContentSize.Height - scrollView.Height - 100;

            if (scrollingSpace <= e.ScrollY && DateTime.Now - LastLazyLoading >= new TimeSpan(0, 0, 0, 0, 1000))
            {
                this.ShowLazyLoadingIndicator(true);
                this.LastLazyLoading = DateTime.Now;
                this.Next();
            }
        }

        public delegate void ViewClickedEventHandler(string id, Dictionary<string, object> dicoArgs = null);
        public event ViewClickedEventHandler OnViewClicked;

        private void ViewClicked(List<StackLayout> stackLayouts, string id, Dictionary<string, object> dicoArgs)
        {
            Color oldColor = stackLayouts[0].BackgroundColor;
            foreach (StackLayout stackLayout in stackLayouts)
            {
                stackLayout.BackgroundColor = Color.FromHex("15000000");
            }
            if (this.OnViewClicked != null)
            {
                if (this.viewModel.MultiPage && this.viewModel.LazyLoading)
                {
                    this.LastScrollY = (this.Container.Children[1] as ScrollView).ScrollY;
                }
                OnViewClicked(id, dicoArgs);
            }


            Task.Run(async () =>
            {
                await Task.Delay(300);
                Device.BeginInvokeOnMainThread(() =>
                {
                    foreach (StackLayout stackLayout in stackLayouts)
                    {
                        stackLayout.BackgroundColor = oldColor;
                    }
                });
            });
        }

        private void HeaderClicked(StackLayout stackLayout, GridField gridField)
        {
            Color oldColor = stackLayout.BackgroundColor;
            stackLayout.BackgroundColor = Color.FromHex("10000000");

            Task.Run(async () =>
            {
                await Task.Delay(300);
                Device.BeginInvokeOnMainThread(() =>
                {
                    stackLayout.BackgroundColor = oldColor;
                });
            });

            var gridFields = this.viewModel.GridFields.Select(g => g).Where(g => g.FieldName != gridField.FieldName).ToList();
            for (int i = 0; i < gridFields.Count; i++)
            {
                gridFields[i].Order = GridField.SortOrder.None;
            }

            switch (gridField.Order)
            {
                case GridField.SortOrder.None:
                    gridField.Order = GridField.SortOrder.Desc;
                    break;
                case GridField.SortOrder.Desc:
                    gridField.Order = GridField.SortOrder.Asc;
                    break;
                case GridField.SortOrder.Asc:
                    gridField.Order = GridField.SortOrder.None;
                    break;
            }

            this.GlobalSearch();

        }

        public delegate void AddToCartClickedEventHandler(string id);
        public event AddToCartClickedEventHandler OnAddToCartClicked;

        private void AddToCartClicked(string id)
        {
            if (this.OnAddToCartClicked != null)
            {
                OnAddToCartClicked(id);
            }
        }

        public delegate void RemoveClickedEventHandler(string id);
        public event RemoveClickedEventHandler OnRemoveClicked;

        private void RemoveClicked(string id)
        {
            if (this.OnRemoveClicked != null)
            {
                OnRemoveClicked(id);
            }
        }

        public delegate void CustomButtonClickedEventHandler(string id, string name);
        public event CustomButtonClickedEventHandler OnCustomButtonClicked;

        private void CustomButtonClicked(string id, string name)
        {
            if (this.OnCustomButtonClicked != null)
            {
                OnCustomButtonClicked(id, name);
            }
        }

        /*
        public delegate void ViewDocumentClickedEventHandler(string fileName);
        public event ViewDocumentClickedEventHandler OnViewDocumentClicked;

        private void ViewDocumentClicked(string docId)
        {
            if (this.viewModel is ITableDocumentsViewModel)
            {
                Task.Run(async () =>
                {
                    this.PopupBusy.Show();
                    Edition edition = (this.viewModel as ITableDocumentsViewModel).GetFile(docId);
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        if (edition != null)
                        {
                            string fileName = "Evolubat.pdf";
                            string fullFileName = Path.Combine(Android.OS.Environment.ExternalStorageDirectory.Path, fileName);
                            File.WriteAllBytes(fullFileName, edition.DataEdi);
                            if (this.OnViewDocumentClicked != null)
                            {
                                this.OnViewDocumentClicked(fullFileName);
                            }
                        }
                        this.PopupBusy.Hide();
                    });
                });
            }
        }
        */
        private void LoadNextPage(bool hidden = false)
        {
            if (hidden)
            {
                this.PreloadNextPageAsync();
            }
            else
            {
                this.PopupBusy.Show();
                Task.Run(() =>
                {
                    EntityTable entityTable = this.viewModel.LoadDatas(this.CurrentPage, entryGlobalSearch?.Text);
                    this.DicoTables.Add(this.CurrentPage, entityTable);

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.LoadLayout(entityTable);
                        this.PopupBusy.Hide();
                    });
                });
            }
        }


        private async Task PreloadNextPageAsync()
        {
            Task.Run(() =>
            {
                if (!this.DicoTables.ContainsKey(this.CurrentPage + 1))// && !string.IsNullOrWhiteSpace(this.EntityTable.RowIdEnrSuiv))
                {
                    EntityTable entityTable = this.viewModel.LoadDatas(this.CurrentPage + 1);
                    this.DicoTables.Add(this.CurrentPage + 1, entityTable);
                }
            });
        }
    }
}
