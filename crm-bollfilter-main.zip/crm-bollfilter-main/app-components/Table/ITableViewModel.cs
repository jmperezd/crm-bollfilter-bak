﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xamarin.Forms;

namespace WFramework_Xamarin.Table
{
    public interface ITableViewModel
    {
        bool MultiPage { get; set; }
        bool LazyLoading { get; set; }
        int NbElementsPerPage { get; set; }
        EntityTable LoadDatas(int requestedPage, string globalSearchedString = null);
        List<GridField> GridFields { get; set; }
    }
}
