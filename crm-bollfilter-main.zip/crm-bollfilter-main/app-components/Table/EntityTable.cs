﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Linq;
using System.Dynamic;
using System.ComponentModel;
using WFramework_Xamarin.Resx;
using Xamarin.Forms;
namespace WFramework_Xamarin.Table
{
    
    public class EntityTable
    {
        /// <summary>         
        /// string : IdChamps, EntityColumn : Valeur pour le champs
        /// </summary>
        //public Dictionary<string, Ressource> DicoRessources = new Dictionary<string, Ressource>();

        public Dictionary<string,EntityColumn> Columns { get; private set; }
        public List<EntityRow> Rows { get; set; }
            
        public string RowIdEnrSuiv { get; private set; }

        public EntityTable(Dictionary<string, EntityColumn> columns, List<EntityRow> rows)
        {
            this.Columns = columns;
            this.Rows = rows;
        }

        public EntityTable(dynamic j, List<GridField> gridFields = null)
        {
            Columns = new Dictionary<string, EntityColumn>();
            Rows = new List<EntityRow>();

            Dictionary<string, EntityCell> cells;

            bool connected = true;
            try
            {
                var e = j.erpDataObjects;
            }
            catch(Exception e)
            {
                connected = false;
            }
            if (connected)
            {
                var e = j.erpDataObjects;
                foreach (dynamic row in e)
                {
                    cells = new Dictionary<string, EntityCell>();
                    if (gridFields != null)
                    {
                        foreach (GridField gridField in gridFields)
                        {
                            bool found = false;
                            foreach (dynamic cell in row.head)
                            {
                                if (gridField.FieldName.ToUpper() == cell.Name.ToUpper())
                                {
                                    cells.Add(cell.Name, new EntityCell(cell.Name, cell.Value.ToString()));
                                    found = true;
                                    break;
                                }
                            }
                            if (!found)
                            {
                                cells.Add(gridField.FieldName, new EntityCell(gridField.FieldName, string.Empty));
                            }
                        }
                    }
                    else
                    {
                        foreach (dynamic item in row.head)
                        {
                            cells.Add(item.Name, new EntityCell(item.Name, item.Value.ToString()));
                        }
                    }
                    Rows.Add(new EntityRow(cells, row));
                }
            }
            else
            {
                foreach (var obj in j)
                {
                    cells = new Dictionary<string, EntityCell>();
                    if (gridFields != null)
                    {
                        foreach (GridField gridField in gridFields)
                        {
                            bool found = false;

                            foreach (string prop in ((object)obj).GetType().GetProperties().Select(p => p.Name))
                            {
                                if (gridField.FieldName.ToUpper() == prop.ToUpper())
                                {
                                    try
                                    {
                                        if (GetPropValue(obj, prop) == null)
                                        {
                                            found = false;
                                        }
                                        else
                                        {
                                            cells.Add(prop, new EntityCell(prop, GetPropValue(obj, prop).ToString()));
                                            found = true;
                                        }                                        
                                        break;
                                    }
                                    catch(Exception e)
                                    {
                                        
                                    }
                                }
                            }
                            if (!found)
                            {
                                cells.Add(gridField.FieldName, new EntityCell(gridField.FieldName, string.Empty));
                            }
                        }
                    }
                    else
                    {
                        foreach (string prop in ((object)obj).GetType().GetProperties().Select(p => p.Name))
                        {
                            cells.Add(prop, new EntityCell(prop, GetPropValue(obj, prop)));
                        }
                    }
                    Rows.Add(new EntityRow(cells, obj));
                }
            }


            #region Labels    

            var entityFields = new EntityFields(gridFields);
            Columns = entityFields.Columns;

            #endregion
        }

        private static object GetPropValue(object src, string propName)
        {
            return src.GetType().GetProperty(propName).GetValue(src, null);
        }


        /*
        public EntityTable(Reponse datas, Reponse labels, string tableName, List<string> requestedColumns, List<GridField> gridFields = null, string tableNameInfoPds = null)
        {
            Columns = new Dictionary<string, EntityColumn>();
            Rows = new List<EntityRow>();

            Dictionary<string, EntityCell> cells;
            
            #region Datas
            if (datas.DSRetour != null && datas.DSRetour.Tables.Count > 0 && datas.DSRetour.Tables.Contains(tableName))
            {
                foreach (DataRow row in datas.DSRetour.Tables[tableName].Rows)
                {
                    cells = new Dictionary<string, EntityCell>();
                    if (requestedColumns != null)
                    {
                        foreach (string columnId in requestedColumns)
                        {
                            cells.Add(columnId, new EntityCell(columnId, row[columnId].ToString()));
                        }
                    }
                    else
                    {
                        foreach (DataColumn col in row.Table.Columns)
                        {
                            cells.Add(col.ColumnName, new EntityCell(col.ColumnName, row[col.ColumnName].ToString()));
                        }
                    }
                    Rows.Add(new EntityRow(cells));

                }

                //Tri du retour du webservice
                if (gridFields != null)
                {
                    foreach(GridField field in gridFields)
                    {
                        if(field.Order != GridField.SortOrder.None)
                        {
                            if(field.Order == GridField.SortOrder.Asc)
                                Rows = Rows.OrderBy(x => x.Cells[field.FieldName].Value).ToList();
                            else
                                Rows = Rows.OrderByDescending(x => x.Cells[field.FieldName].Value).ToList();
                        }
                    }

                    
                }
            }

            if (datas.DSParamRetour != null && datas.DSParamRetour.Tables.Count > 0 && datas.DSParamRetour.Tables.Contains("ttParam"))
            {
                foreach (DataRow row in datas.DSParamRetour.Tables["ttParam"].Rows)
                {
                    if (row[1].ToString() == "RowIdEnrSuiv")
                    {
                        RowIdEnrSuiv = row[3].ToString();
                        break;
                    }
                }
            }
            #endregion

            #region Labels           
            var entityFields = new EntityFields(labels, tableNameInfoPds != null ? tableNameInfoPds : tableName, requestedColumns);
            Columns = entityFields.Columns;
            #endregion
        }*/
    }

    public class EntityFields
    {
        public Dictionary<string, EntityColumn> Columns { get; private set; }

        public EntityFields(List<GridField> gridFields)
        {
            Columns = new Dictionary<string, EntityColumn>();
            foreach(GridField gridField in gridFields)
            {
                if (!string.IsNullOrWhiteSpace(gridField.DisplayedName))
                {
                    Columns.Add(gridField.FieldName, new EntityColumn(gridField.FieldName, gridField.DisplayedName, gridField.DisplayedName, gridField.DisplayedFormat));
                    if(gridField.FieldName.Contains("^"))
                    {
                        var s = gridField.FieldName.Replace("^", "_");
                        Columns.Add(s, new EntityColumn(s, gridField.DisplayedName, gridField.DisplayedName, gridField.DisplayedFormat));
                    }
                }
                else
                {
                    switch (gridField.FieldName)
                    {
                        //"‘productDescr’", "unitQty", "price", "percent", "probability", "itemValEntCurr"

                        case "id":
                            //Columns.Add("id", new EntityColumn("id", "Identifiant", "Identifiant", "string"));
                            Columns.Add("id", new EntityColumn("id", AppResources.Identifiant, AppResources.Identifiant, "string"));
                            break;
                        case "descrOperLang":
                            Columns.Add("descrOperLang", new EntityColumn("descrOperLang", AppResources.Titre, AppResources.Titre, "string"));
                            break;
                        case "prio":
                            Columns.Add("prio", new EntityColumn("prio", AppResources.Priorite, AppResources.Priorite, "string"));
                            break;
                        case "prio_descrOperLang":
                            Columns.Add("prio_descrOperLang", new EntityColumn("prio_descrOperLang", AppResources.Priorite, AppResources.Priorite, "string"));
                            break;
                        case "prio^descrOperLang":
                            Columns.Add("prio^descrOperLang", new EntityColumn("prio^descrOperLang", AppResources.Priorite, AppResources.Priorite, "string"));
                            break;
                        case "editorExt^descrOperLang":
                            Columns.Add("editorExt^descrOperLang", new EntityColumn("editorExt^descrOperLang", AppResources.Priorite, AppResources.Priorite, "string"));
                            break;
                        case "editorExt_descrOperLang":
                            Columns.Add("editorExt_descrOperLang", new EntityColumn("editorExt_descrOperLang", AppResources.Priorite, AppResources.Priorite, "string"));
                            break;
                        case "endDate":
                            Columns.Add("endDate", new EntityColumn("endDate", AppResources.Date, AppResources.Date, "date"));
                            break;
                        case "date":
                            Columns.Add("date", new EntityColumn("date", AppResources.Date, AppResources.Date, "date"));
                            break;
                        case "dateFrom":
                            Columns.Add("dateFrom", new EntityColumn("dateFrom", AppResources.Date, AppResources.Date, "date"));
                            break;
                        case "confirm":
                            Columns.Add("confirm", new EntityColumn("confirm", AppResources.Auteur, AppResources.Auteur, "string"));
                            break;
                        case "idno":
                            Columns.Add("idno", new EntityColumn("idno", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "swd":
                            Columns.Add("swd", new EntityColumn("swd", AppResources.Cle_de_recherche, AppResources.Cle_de_recherche, "string"));
                            break;
                        case "descr":
                            Columns.Add("descr", new EntityColumn("descr", AppResources.Nom, AppResources.Nom, "string"));
                            break;
                        case "elemDescr":
                            Columns.Add("elemDescr", new EntityColumn("elemDescr", AppResources.Nom, AppResources.Nom, "string"));
                            break;
                        case "type":
                            Columns.Add("type", new EntityColumn("type", AppResources.Type, AppResources.Type, "string"));
                            break;
                        case "grpNo":
                            Columns.Add("grpNo", new EntityColumn("grpNo", AppResources.Type, AppResources.Type, "string"));
                            break;
                        case "type_descrOperLang":
                            Columns.Add("type_descrOperLang", new EntityColumn("type_descrOperLang", AppResources.Type, AppResources.Type, "string"));
                            break;
                        case "type^descrOperLang":
                            Columns.Add("type^descrOperLang", new EntityColumn("type^descrOperLang", AppResources.Type, AppResources.Type, "string"));
                            break;
                        case "editor":
                            Columns.Add("editor", new EntityColumn("editor", AppResources.Auteur, AppResources.Auteur, "string"));
                            break;
                        case "confirm_descrOperLang":
                            Columns.Add("confirm_descrOperLang", new EntityColumn("confirm_descrOperLang", AppResources.Responsable, AppResources.Responsable, "string"));
                            break;
                        case "confirm^descrOperLang":
                            Columns.Add("confirm^descrOperLang", new EntityColumn("confirm^descrOperLang", AppResources.Responsable, AppResources.Responsable, "string"));
                            break;
                        case "editor_descrOperLang":
                            Columns.Add("editor_descrOperLang", new EntityColumn("editor_descrOperLang", AppResources.Operateur, AppResources.Operateur, "string"));
                            break;
                        case "editor^descrOperLang":
                            Columns.Add("editor^descrOperLang", new EntityColumn("editor^descrOperLang", AppResources.Operateur, AppResources.Operateur, "string"));
                            break;
                        case "businessPartner_descrOperLang":
                            Columns.Add("businessPartner_descrOperLang", new EntityColumn("businessPartner_descrOperLang", AppResources.Client, AppResources.Client, "string"));
                            break;
                        case "businessPartner^descrOperLang":
                            Columns.Add("businessPartner^descrOperLang", new EntityColumn("businessPartner^descrOperLang", AppResources.Client, AppResources.Client, "string"));
                            break;
                        case "customerDescr":
                            Columns.Add("customerDescr", new EntityColumn("customerDescr", AppResources.Details_client, AppResources.Details_client, "string"));
                            break;
                        case "customerDescr_descrOperLang":
                            Columns.Add("customerDescr_descrOperLang", new EntityColumn("customerDescr_descrOperLang", AppResources.Details_client, AppResources.Details_client, "string"));
                            break;
                        case "customerDescr^descrOperLang":
                            Columns.Add("customerDescr^descrOperLang", new EntityColumn("customerDescr^descrOperLang", AppResources.Details_client, AppResources.Details_client, "string"));
                            break;
                        case "totalGrossAmtDom":
                            Columns.Add("totalGrossAmtDom", new EntityColumn("totalGrossAmtDom", AppResources.Total_HT, AppResources.Total_HT, "decimal"));
                            break;
                        case "totalNetAmt":
                            Columns.Add("totalNetAmt", new EntityColumn("totalNetAmt", AppResources.Total_HT, AppResources.Total_HT, "decimal"));
                            break;
                        case "probability":
                            Columns.Add("probability", new EntityColumn("probability", AppResources.Probabilite, AppResources.Probabilite, "percent"));
                            break;
                        case "status":
                            Columns.Add("status", new EntityColumn("status", AppResources.Status, AppResources.Status, "string"));
                            break;
                        case "productDescr":
                            Columns.Add("productDescr", new EntityColumn("productDescr", AppResources.Article, AppResources.Article, "string"));
                            break;
                        case "product":
                            Columns.Add("product", new EntityColumn("product", AppResources.Article, AppResources.Article, "string"));
                            break;
                        case "price":
                            Columns.Add("price", new EntityColumn("price", AppResources.Prix, AppResources.Prix, "decimal"));
                            break;
                        case "unitQty":
                            Columns.Add("unitQty", new EntityColumn("unitQty", AppResources.Quantite, AppResources.Quantite, "string"));
                            break;
                        case "elemQty":
                            if (Device.Idiom == TargetIdiom.Phone)
                            {
                                Columns.Add("elemQty", new EntityColumn("elemQty", AppResources.QuantitePhone, AppResources.QuantitePhone, "string"));
                            }
                            else
                            {
                                Columns.Add("elemQty", new EntityColumn("elemQty", AppResources.Quantite, AppResources.Quantite, "string"));
                            }
                            break;
                        case "tradeUnit":
                            Columns.Add("tradeUnit", new EntityColumn("tradeUnit", AppResources.Unite, AppResources.Unite, "string"));
                            break;
                        case "percent":
                            Columns.Add("percent", new EntityColumn("percent", AppResources.Majoration_remise, AppResources.Majoration_remise, "percent"));
                            break;
                        case "itemValEntCurr":
                            Columns.Add("itemValEntCurr", new EntityColumn("itemValEntCurr", AppResources.Valeur_ligne, AppResources.Valeur_ligne, "decimal"));
                            break;
                        case "purchPrice":
                            Columns.Add("purchPrice", new EntityColumn("purchPrice", AppResources.Prix, AppResources.Prix, "decimal"));
                            break;
                        case "salesPrice":
                            Columns.Add("salesPrice", new EntityColumn("salesPrice", AppResources.Prix, AppResources.Prix, "decimal"));
                            break;
                        case "salesPrice2":
                            Columns.Add("salesPrice2", new EntityColumn("salesPrice2", AppResources.Prix, AppResources.Prix, "decimal"));
                            break;
                        case "salesTradeUnit":
                            Columns.Add("salesTradeUnit", new EntityColumn("salesTradeUnit", AppResources.Unite, AppResources.Unite, "string"));
                            break;
                        case "SU":
                            Columns.Add("SU", new EntityColumn("SU", AppResources.Unite_de_stockage, AppResources.Unite_de_stockage, "string"));
                            break;
                        case "elemSU":
                            if (Device.Idiom == TargetIdiom.Phone)
                            {
                                Columns.Add("elemSU", new EntityColumn("elemSU", AppResources.Unite_de_stockagePhone, AppResources.Unite_de_stockagePhone, "string"));
                            }
                            else
                            {
                                Columns.Add("elemSU", new EntityColumn("elemSU", AppResources.Unite_de_stockage, AppResources.Unite_de_stockage, "string"));
                            }
                            break;
                        case "startDateTime":
                            Columns.Add("startDateTime", new EntityColumn("startDateTime", AppResources.Date, AppResources.Date, "date"));
                            break;
                        case "customer_descrOperLang":
                            Columns.Add("customer_descrOperLang", new EntityColumn("customer_descrOperLang", AppResources.Client, AppResources.Client, "string"));
                            break;
                        case "customer^descrOperLang":
                            Columns.Add("customer^descrOperLang", new EntityColumn("customer^descrOperLang", AppResources.Client, AppResources.Client, "string"));
                            break;
                        case "lotNo":
                            Columns.Add("lotNo", new EntityColumn("lotNo", AppResources.Numero_de_serie, AppResources.Numero_de_serie, "string"));
                            break;
                        case "serviceProductImplFrom":
                            if (Device.Idiom == TargetIdiom.Phone)
                            {
                                Columns.Add("serviceProductImplFrom", new EntityColumn("serviceProductImplFrom", AppResources.Monte_duPhone, AppResources.Monte_duPhone, "date"));
                            }
                            else
                            {
                                Columns.Add("serviceProductImplFrom", new EntityColumn("serviceProductImplFrom", AppResources.Monte_du, AppResources.Monte_du, "date"));
                            }
                            break;
                        case "serviceProductImplTo":
                            if (Device.Idiom == TargetIdiom.Phone)
                            {
                                Columns.Add("serviceProductImplTo", new EntityColumn("serviceProductImplTo", AppResources.Monte_jusqu_auPhone, AppResources.Monte_jusqu_auPhone, "date"));
                            }
                            else
                            {
                                Columns.Add("serviceProductImplTo", new EntityColumn("serviceProductImplTo", AppResources.Monte_jusqu_au, AppResources.Monte_jusqu_au, "date"));
                            }
                            break;
                        case "serviceProduct^descrOperLang":
                            Columns.Add("serviceProduct^descrOperLang", new EntityColumn("serviceProduct^descrOperLang", AppResources.ServiceProduct, AppResources.ServiceProduct, "string"));
                            break;
                        case "serviceProduct_descrOperLang":
                            Columns.Add("serviceProduct_descrOperLang", new EntityColumn("serviceProduct_descrOperLang", AppResources.ServiceProduct, AppResources.ServiceProduct, "string"));
                            break;
                        case "serviceEngineerDescr^descrOperLang":
                            Columns.Add("serviceEngineerDescr^descrOperLang", new EntityColumn("serviceEngineerDescr^descrOperLang", AppResources.ServiceEngineer, AppResources.ServiceEngineer, "string"));
                            break;
                        case "serviceEngineerDescr_descrOperLang":
                            Columns.Add("serviceEngineerDescr_descrOperLang", new EntityColumn("serviceEngineerDescr_descrOperLang", AppResources.ServiceEngineer, AppResources.ServiceEngineer, "string"));
                            break;
                        case "serviceEngineerDescr":
                            Columns.Add("serviceEngineerDescr", new EntityColumn("serviceEngineerDescr", AppResources.ServiceEngineer, AppResources.ServiceEngineer, "string"));
                            break;
                        case "deadlineExec":
                            Columns.Add("deadlineExec", new EntityColumn("deadlineExec", AppResources.Deadline, AppResources.Deadline, "string"));
                            break;
                        case "deadline":
                            Columns.Add("deadline", new EntityColumn("deadline", AppResources.Deadline, AppResources.Deadline, "string"));
                            break;
                        case "head^idno": 
                            Columns.Add("head^idno", new EntityColumn("head^idno", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "head_idno": 
                            Columns.Add("head_idno", new EntityColumn("head_idno", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "serviceOrderItem^searchExt":
                            Columns.Add("serviceOrderItem^searchExt", new EntityColumn("serviceOrderItem^searchExt", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "serviceOrderItem_id":
                            Columns.Add("serviceOrderItem_searchExt", new EntityColumn("serviceOrderItem_searchExt", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "serviceOrderItem":
                            Columns.Add("serviceOrderItem", new EntityColumn("serviceOrderItem", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "productDescr^descrOperLang":
                            Columns.Add("productDescr^descrOperLang", new EntityColumn("productDescr^descrOperLang", AppResources.Article, AppResources.Article, "string"));
                            break;
                        case "productDescr_descrOperLang":
                            Columns.Add("productDescr_descrOperLang", new EntityColumn("productDescr_descrOperLang", AppResources.Article, AppResources.Article, "string"));
                            break;
                        case "clientModel":
                            Columns.Add("clientModel", new EntityColumn("clientModel", AppResources.ClientModel, AppResources.ClientModel, "string"));
                            break;
                        case "contract":
                            Columns.Add("contract", new EntityColumn("contrat", AppResources.Numero, AppResources.Numero, "string"));
                            break;
                        case "lastVisit":
                            Columns.Add("lastVisit", new EntityColumn("lastVisit", AppResources.LastVisit, AppResources.LastVisit, "string"));
                            break;
                        case "nextVisit":
                            Columns.Add("nextVisit", new EntityColumn("nextVisit", AppResources.NextVisit, AppResources.NextVisit, "string"));
                            break;
                    }
                }
            }
            //Columns[fieldName] = new EntityColumn(fieldName, label, colLabel, type)
        }
            /*
        public EntityFields(Reponse labels, string tableName, List<string> requestedColumns = null)
        {
            try
            {
                Columns = new Dictionary<string, EntityColumn>();
                if (requestedColumns != null)
                {
                    foreach (string colName in requestedColumns)
                        Columns.Add(colName, null);
                }

                if (labels.DSRetour != null && labels.DSRetour.Tables.Count > 0 && labels.DSRetour.Tables.Contains("ttInfoPds"))
                {
                    string fieldName = string.Empty;
                    string label = string.Empty;
                    string colLabel = string.Empty;
                    string type = string.Empty;
                    bool stop = false;
                    foreach (DataRow row in labels.DSRetour.Tables["ttInfoPds"].Rows)
                    {
                        stop = false;
                        foreach (DataColumn col in row.Table.Columns)
                        {
                            switch (col.ColumnName)
                            {
                                case "ChpIPds"://Colonne contenant le nom du champs
                                    fieldName = row[col.ColumnName] != null ? row[col.ColumnName].ToString().Replace(tableName + ".", "") : null;//nom du champs : exemple ttCli.IdCli => IdCli                       
                                    if (requestedColumns != null)
                                    {
                                        if (requestedColumns.Any(f => "tt" + f == fieldName) == true) //.Contains(fieldName))
                                        {
                                            fieldName = fieldName.Remove(0, 2);//remove tt => Cas particulier table temporaire
                                        }
                                        else if (requestedColumns.Any(f => f == fieldName) == false) //.Contains(fieldName))
                                        {
                                            stop = true;//on stop
                                        }
                                    }
                                    break;
                                case "LabelIPds"://Colonne contenant le label
                                    label = row[col.ColumnName] != null ? row[col.ColumnName].ToString() : null;
                                    break;
                                case "ColLabelIPds"://Colonne contenant le labelColonne
                                    colLabel = row[col.ColumnName] != null ? row[col.ColumnName].ToString() : null;
                                    break;
                                case "TypeChpIPds"://Colonne contenant le type
                                    type = row[col.ColumnName] != null ? row[col.ColumnName].ToString() : null;
                                    stop = true; //Dernier champs récupéré

                                    if (requestedColumns == null)
                                    {
                                        if(!Columns.ContainsKey(fieldName))
                                            Columns.Add(fieldName, new EntityColumn(fieldName, label, colLabel, type));
                                        else
                                            Columns[fieldName] = new EntityColumn(fieldName, label, colLabel, type);
                                    }
                                    else
                                        Columns[fieldName] = new EntityColumn(fieldName, label, colLabel, type);

                                    break;
                            }
                            if (stop)
                                break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
        }        */
    }

    public class EntityColumn
    {
        public string Id { get; private set; }
        public string Label { get; private set; }
        public string ColLabel { get; set; } 
        /*
        character, //string
        int64,//Pour les ID
        integer, //Numéro Fac , doc
        date, //Date uniquement -- yyyy-MM-dd
        datetime-tz,//DateTime complète
        decimal, //Montant
        logical, //Bool true false
        */ 
        public string Type { get; private set; }

        public EntityColumn(string id, string label, string colLabel, string type)
        {
            Id = id;
            Label = label;
            ColLabel = colLabel;
            Type = type;
        }
    }

    public class EntityRow
    {
        /// <summary>
        /// Id de l'entité : exemple idclient, idchantier etc...
        /// </summary>
        //public string IdEntity { get; private set; } 
        public Dictionary<string, EntityCell> Cells { get; private set; }
        public object Object { get; set; }
        public EntityRow(Dictionary<string, EntityCell> cells, object obj)
        {
            this.Cells = cells;
            this.Object = obj;
        }
    }

    public class EntityCell
    {        
        public string IdColumn { get; private set; }
        public string Value { get; set; }

        public EntityCell(string idColumn, string value)
        {
            IdColumn = idColumn;
            Value = value;
        }

        public void ReplaceValue(string value)
        {
            this.Value = value;
        }
    }
}
