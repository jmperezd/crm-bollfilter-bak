﻿using System;
using Xamarin.Forms;
namespace WFramework_Xamarin.Table
{
    public interface ITablePage
    {
        ContentView ParentPageContainer { get; set; }
        void Refresh();
    }
}
