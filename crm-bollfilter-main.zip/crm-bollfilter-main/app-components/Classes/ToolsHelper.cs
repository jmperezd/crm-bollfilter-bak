﻿using System;
using System.Globalization;

namespace WFramework_Xamarin
{
    public static class ToolsHelper
    {

        public static double ConvertToDouble(string value)
        {

            double db = 0;
            if (CultureInfo.CurrentCulture.Name.Contains("es") || CultureInfo.CurrentCulture.Name.Contains("fr") || CultureInfo.CurrentCulture.Name.Contains("nl"))
            {                
                double.TryParse(value.Replace(".", ","), System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out db);
            }
            else if (!double.TryParse(value, System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out db))
            {
                double.TryParse(value.Replace(".", ","), System.Globalization.NumberStyles.Any, CultureInfo.CurrentCulture, out db);
            }
            return db;
        }

        public static string ReplaceDotsString(string value)
        {
            string result = value;
            if (CultureInfo.CurrentCulture.Name.Contains("es") || CultureInfo.CurrentCulture.Name.Contains("fr") || CultureInfo.CurrentCulture.Name.Contains("nl"))
            {
                result = value.Replace(".", ",");
            }
            return result;
        }

        public static string DeleteAccentMarks(this string input)
        {
            string result = input;
            result = result.Replace("á", "a").Replace("à", "a").Replace("â", "a");
            result = result.Replace("é", "e").Replace("è", "e").Replace("ê", "e");
            result = result.Replace("í", "i").Replace("ì", "i").Replace("î", "i");
            result = result.Replace("ó", "o").Replace("ò", "o").Replace("ô", "o");
            result = result.Replace("ú", "u").Replace("ù", "u").Replace("û", "u");
            return result;
        }

        public static DateTime FormatDate(string date)
        {
            DateTime dateValue = DateTime.MinValue;
            DateTime.TryParse(date, out dateValue);

            if (date != null)
            {
                try
                {
                    if (dateValue != DateTime.MinValue)
                    {
                        return dateValue;
                    }
                    else
                    {
                        if (!date.Contains(":"))
                        {
                            return DateTime.Parse(date);
                        }
                        else
                        {
                            return DateTime.ParseExact(date, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        }
                    }
                }
                catch (Exception)
                {
                    return DateTime.MinValue;
                }
            }
            return DateTime.MinValue;
        }

    }
}
