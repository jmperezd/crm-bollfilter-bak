﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

using System.Threading.Tasks;

using System.IO;
using Plugin.Geolocator;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System.Globalization;
using WFramework_Xamarin.Resx;

namespace WFramework_Xamarin
{
    public class MapTools
    {
        public static async Task<Plugin.Geolocator.Abstractions.Position> GetCurrentPosition()
        {
            Plugin.Geolocator.Abstractions.Position position = null;

            try
            {
                var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Location);                
                if (status != PermissionStatus.Granted && status != PermissionStatus.Unknown)
                {
                    Device.BeginInvokeOnMainThread(async () => await Application.Current.MainPage.DisplayAlert(AppResources.gpsNeed, AppResources.gpsNeedDescr, "OK"));
                }
                else if (status == PermissionStatus.Granted)
                {
                    var locator = CrossGeolocator.Current;
                    locator.DesiredAccuracy = 100;

                    position = await locator.GetLastKnownLocationAsync();

                    //if it's in New York
                    if ((position.Latitude > 37 && position.Latitude < 38) &&
                        (position.Longitude < -122 && position.Longitude > -123))
                    {
                        if (CultureInfo.CurrentCulture.Name.Contains("es"))
                        {
                            position.Latitude = 40.5;
                            position.Longitude = -3.7;
                        }
                        else
                        {
                            position.Latitude = 48.85;
                            position.Longitude = 2.35;
                        }
                            
                    }


                    if (position != null)
                    {
                        //got a cahched position, so let's use it.
                        return position;
                    }

                    if (!locator.IsGeolocationAvailable || !locator.IsGeolocationEnabled)
                    {
                        //not available or enabled
                        return null;
                    }

                    position = await locator.GetPositionAsync(TimeSpan.FromSeconds(20), null, true);
                }
            }
            catch (Exception ex)
            {
                
            }


            if (position == null)
                return null;
            
            return position;
        }
    }
}
