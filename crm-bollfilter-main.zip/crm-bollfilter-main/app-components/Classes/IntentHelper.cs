﻿using System;
using System.Net;
using Xamarin.Forms;


namespace WFramework_Xamarin
{
    public class IntentHelper
    {

        public static void ShowDirection(string latitude, string longitude)
        {
            ShowDirection(latitude.Replace(',', '.') + "," + longitude.Replace(',', '.'));
        }

        public static void ShowDirection(string search)
        {
            switch (Device.RuntimePlatform)
            {
                case Device.iOS:
                    Device.OpenUri(
                        new Uri(string.Format("http://maps.apple.com/?mode=d&q={0}", WebUtility.UrlEncode(search))));
                    break;
                case Device.Android:
                    Device.OpenUri(
                        new Uri(string.Format("google.navigation:?mode=d&q={0}", WebUtility.UrlEncode(search))));
                    break;
            }
        }

        public static void PhoneCall(string phoneNumber)
        {
            try
            {
                Device.OpenUri(new Uri("tel:" + phoneNumber));
            }
            catch (Exception e)
            {
            }
        }

        public static void Mail(string email)
        {
            Device.OpenUri(new Uri("mailto:" + email));
        }

        public static void WebSite(string webSite)
        {
            if (!webSite.StartsWith("http") && !string.IsNullOrEmpty(webSite))
            {
                webSite = "http://" + webSite;
                Device.OpenUri(new Uri(webSite));
            }
        }


        public static void File(string filePath)
        {
            try
            {
                if (!filePath.StartsWith("file://"))
                {
                    filePath = "file://" + filePath;
                }

                Uri uri = new Uri(WebUtility.HtmlEncode(filePath));
                Device.OpenUri(uri);
            }
            catch(Exception e)
            {

            }
        }
    }
}

