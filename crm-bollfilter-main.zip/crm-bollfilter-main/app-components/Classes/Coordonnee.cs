﻿using System;
namespace WFramework_Xamarin
{
    public class Coordonnee
    {
        public Coordonnee(double longitudeEst, double longitudeOuest, double latitudeNord, double latitudeSud)
        {
            LongitudeEst = longitudeEst;
            LongitudeOuest = longitudeOuest;
            LatitudeNord = latitudeNord;
            LatitudeSud = latitudeSud;
        }

        public double LongitudeEst { get; set; }
        public double LongitudeOuest { get; set; }
        public double LatitudeNord { get; set; }
        public double LatitudeSud { get; set; }

    }
}
