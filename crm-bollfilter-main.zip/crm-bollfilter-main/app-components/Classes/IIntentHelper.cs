﻿using System;
using System.Net;
using Xamarin.Forms;

namespace WFramework_Xamarin
{
    public interface IIntentHelper
    {
        void File(string filePath);
        void File(byte[] e);
        void SetPermissions();
    }
}
