﻿using System;
using AppCRM;
using AppCRM.iOS;
using AppCRM.Styles;
using CoreAnimation;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(BorderedEditor), typeof(BorderedEditorRenderer))]
namespace AppCRM.iOS
{
    public class BorderedEditorRenderer : EditorRenderer
    {
        private CALayer borderLayer;
        int sublayerNumber = 0;
        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)
        {
            base.OnElementChanged(e);

            if (Control != null)
            {

                borderLayer = new CALayer();
                Control.Layer.AddSublayer(borderLayer);                
                sublayerNumber = Control.Layer.Sublayers.Length - 1;
            }
        }

        public override void LayoutSubviews()
        {
            base.LayoutSubviews();
            Control.Layer.Sublayers[sublayerNumber].MasksToBounds = true;
            Control.Layer.Sublayers[sublayerNumber].Frame = new CoreGraphics.CGRect(0f, Frame.Height - 5, Frame.Width, 1f);
            Control.Layer.Sublayers[sublayerNumber].BorderColor = Color.FromHex("000000").ToCGColor();
            Control.Layer.Sublayers[sublayerNumber].BorderWidth = 1.0f;
        }
    }
}
