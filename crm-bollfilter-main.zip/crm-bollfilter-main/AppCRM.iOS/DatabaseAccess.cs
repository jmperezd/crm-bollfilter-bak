﻿using LiteDB;
using LiteQueue;
using AppCRM.iOS;
[assembly: Xamarin.Forms.Dependency(typeof(DatabaseAccess))]
namespace AppCRM.iOS
{
    public class DatabaseAccess {}
        /*: IDataBaseAccess
    {
        public string DatabasePath()
        {
            string docFolder = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            string libFolder = Path.Combine(docFolder, "..", "Library", "Databases");

            if (!Directory.Exists(libFolder))
            {
                Directory.CreateDirectory(libFolder);
            }

            return Path.Combine(libFolder, Constants.OFFLINE_DATABASE_NAME);

        }
    }*/
}
