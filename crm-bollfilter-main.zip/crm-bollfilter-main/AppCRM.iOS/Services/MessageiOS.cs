﻿using System;
using AppCRM.iOS.Services;
using AppCRM.Services;
using BigTed;
using Xamarin.Forms;

[assembly: Xamarin.Forms.Dependency(typeof(MessageiOS))]
namespace AppCRM.iOS.Services
{
    public class MessageiOS : IMessage
    {
        public void LongAlert(string message)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                ProgressHUD.Shared.HudBackgroundColour = UIKit.UIColor.FromRGB(27,184,163);
                BTProgressHUD.ShowToast(message, true, 2000);
            });
        }

        public void ShortAlert(string message)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                ProgressHUD.Shared.HudBackgroundColour = UIKit.UIColor.FromRGB(27, 184, 163);
                BTProgressHUD.ShowToast(message, true, 1000);
            });
        }
    }
}