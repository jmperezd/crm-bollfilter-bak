﻿using System;
using Xamarin.Forms;
using AppCRM;
using AppCRM.iOS;
using UIKit;

[assembly: Dependency(typeof(iOSKeyboardHelper))]
namespace AppCRM.iOS
{
    public class iOSKeyboardHelper : IKeyboardHelper
    {
        public void HideKeyboard()
        {
            UIApplication.SharedApplication.KeyWindow.EndEditing(true);
        }
    }
}
