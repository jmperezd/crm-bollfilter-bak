﻿using System;
using System.IO;
using System.Net;
using AppCRM.iOS;
using Foundation;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
using WFramework_Xamarin.Components;

[assembly: ExportRenderer(typeof(CustomWebView), typeof(CustomWebViewRenderer))]
namespace AppCRM.iOS
{
    public class CustomWebViewRenderer : ViewRenderer<CustomWebView, UIWebView>
    {
        protected override void OnElementChanged(ElementChangedEventArgs<CustomWebView> e)
        {
            base.OnElementChanged(e);

            if (Control == null)
            {
                SetNativeControl(new UIWebView());
            }
            if (e.OldElement != null)
            {
                // Cleanup
            }
            if (e.NewElement != null)
            {
                var customWebView = Element as CustomWebView;
                //string fileName = Path.Combine(NSBundle.MainBundle.BundlePath, string.Format("Content/{0}", WebUtility.UrlEncode(customWebView.Uri)));
                //string fileName = Path.Combine(NSBundle.MainBundle.BundlePath, string.Format("Content/{0}", WebUtility.UrlEncode(customWebView.Uri)));
                Control.LoadRequest(new NSUrlRequest(new NSUrl(WebUtility.UrlEncode(customWebView.Uri), false)));
                Control.ScalesPageToFit = true;
            }
        }
        /*protected override void OnElementChanged(ElementChangedEventArgs<CustomWebView> e)
         {
             base.OnElementChanged(e);

             if (Control == null)
             {
                 SetNativeControl(new UIWebView());
             }
             if (e.OldElement != null)
             {

             }
             if (e.NewElement != null)
             {
                 var customWebView = Element as CustomWebView;
                 string fileName = Path.Combine(NSBundle.MainBundle.BundlePath, string.Format("AppCRM/Content/{0}", WebUtility.UrlEncode(customWebView.Uri)));
                 Control.LoadRequest(new NSUrlRequest(new NSUrl(fileName, false)));
                 Control.ScalesPageToFit = true;
             }
         }*/
    }
}