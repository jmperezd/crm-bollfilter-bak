﻿
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Microsoft.AppCenter.Distribute;

using TK.CustomMap.iOSUnified;
using Foundation;
using UIKit;

//using Plugin.LocalNotifications;
using UserNotifications;
using AppCRM.Views;

namespace AppCRM.iOS
{
    // The UIApplicationDelegate for the application. This class is responsible for launching the 
    // User Interface of the application, as well as listening (and optionally responding) to 
    // application events from iOS.
    [Register("AppDelegate")]
    public partial class AppDelegate : global::Xamarin.Forms.Platform.iOS.FormsApplicationDelegate
    {
        //
        // This method is invoked when the application has loaded and is ready to run. In this 
        // method you should instantiate the window, load the UI into it and then make the window
        // visible.
        //
        // You have 17 seconds to return from this method, or iOS will terminate your application.
        //
        public override bool FinishedLaunching(UIApplication app, NSDictionary options)
        {
            
            if (UIDevice.CurrentDevice.CheckSystemVersion(10, 0))
            {
                // Ask the user for permission to get notifications on iOS 10.0+
                UNUserNotificationCenter.Current.RequestAuthorization(
                        UNAuthorizationOptions.Alert | UNAuthorizationOptions.Badge | UNAuthorizationOptions.Sound,
                        (approved, error) => { });
            }
            else if (UIDevice.CurrentDevice.CheckSystemVersion(8, 0))
            {
                // Ask the user for permission to get notifications on iOS 8.0+
                var settings = UIUserNotificationSettings.GetSettingsForTypes(
                        UIUserNotificationType.Alert | UIUserNotificationType.Badge | UIUserNotificationType.Sound,
                        new NSSet());

                UIApplication.SharedApplication.RegisterUserNotificationSettings(settings);
            }

            AppCenter.Start("android=e5a4ef89-8a51-40c4-8622-f8a648f4daf0;" + "ios=9e8e146d-9fa3-4e30-8def-60efb9d11f2d;", typeof(Analytics), typeof(Crashes));

#if DEBUG
            Distribute.SetEnabledAsync(false);
#else
            Distribute.SetEnabledAsync(true);
#endif
 			global::Xamarin.Forms.Forms.Init();
            app.StatusBarStyle = UIStatusBarStyle.LightContent;
            var renderer = new TKCustomMapRenderer();


            LoadApplication(new App());

            return base.FinishedLaunching(app, options);
        }

        public override void ReceivedLocalNotification(UIApplication application, UILocalNotification notification)
        {
            //Debug.WriteLine("Location Notification: {0}:{1}", notification.AlertAction, notification.AlertBody);
            //Debug.WriteLine("Location Notification: " + notification.AlertBody);

            if (UIApplication.SharedApplication.ApplicationState == UIApplicationState.Active)
            {
                new UIAlertView(notification.AlertAction, notification.AlertBody, null, "OK", null).Show();

                //var alert = UIAlertController.Create(notification.AlertAction, notification.AlertBody, UIAlertControllerStyle.Alert);
                //UIApplication.SharedApplication.KeyWindow.RootViewController.PresentViewController(alert, true, null);
            }
        }


        public override void HandleAction(UIApplication application, string actionIdentifier, NSDictionary remoteNotificationInfo, Action completionHandler)
        {
            if (UIApplication.SharedApplication.ApplicationState == UIApplicationState.Active)
                new UIAlertView("Notification Action", actionIdentifier, null, "OK", null).Show();
            else
                Console.WriteLine("Notification Action {0}", actionIdentifier);

            base.HandleAction(application, actionIdentifier, remoteNotificationInfo, completionHandler);
        }

        public override UIInterfaceOrientationMask GetSupportedInterfaceOrientations(UIApplication application, UIWindow forWindow)
        {
            var mainPage = Xamarin.Forms.Application.Current.MainPage;
            if (mainPage.Navigation.NavigationStack.Last() is CustomerTurnover)
            {
                return UIInterfaceOrientationMask.Landscape;
            }
            return UIInterfaceOrientationMask.Portrait;
        }
    }

}
