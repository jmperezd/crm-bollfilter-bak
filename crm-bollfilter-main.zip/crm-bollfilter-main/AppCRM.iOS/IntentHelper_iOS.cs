﻿using System;
using System.Drawing;
using System.Net;
using Foundation;
using UIKit;
using Xamarin.Forms;
using WFramework_Xamarin;

[assembly: Xamarin.Forms.Dependency(typeof(AppCRM.iOS.IntentHelper_iOS))]
namespace AppCRM.iOS
{
    public class IntentHelper_iOS : IIntentHelper
    {
        public IntentHelper_iOS()
        {
        }


        public void File(string filePath)
        {
            try
            {
                var PreviewController = UIDocumentInteractionController.FromUrl(NSUrl.FromFilename(filePath));
                PreviewController.Delegate = new UIDocumentInteractionControllerDelegateClass(UIApplication.SharedApplication.KeyWindow.RootViewController);
                PreviewController.PresentPreview(true);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void File(byte[] e)
        {
            throw new NotImplementedException();
        }

        public void SetPermissions()
        {
        }

    }

    public class UIDocumentInteractionControllerDelegateClass : UIDocumentInteractionControllerDelegate
    {
        UIViewController ownerVC;

        public UIDocumentInteractionControllerDelegateClass(UIViewController vc)
        {
            ownerVC = vc;
        }

        public override UIViewController ViewControllerForPreview(UIDocumentInteractionController controller)
        {
            return ownerVC;
        }

        public override UIView ViewForPreview(UIDocumentInteractionController controller)
        {
            return ownerVC.View;
        }
    }
}
