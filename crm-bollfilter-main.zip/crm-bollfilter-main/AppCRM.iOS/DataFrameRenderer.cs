﻿using UIKit;
using CoreGraphics;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
using System;
using AppCRM.iOS;
using WFramework_Xamarin.Components;

[assembly: ExportRenderer(typeof(DataFrame), typeof(DataFrameRenderer))]
namespace AppCRM.iOS
{
    /// <summary>
    /// Renderer to update all frames with better shadows matching material design standards
    /// </summary>

    public class DataFrameRenderer : FrameRenderer
    {
        /*public override void Draw(CGRect rect)
        {
            base.Draw(rect);
            Layer.CornerRadius = 5.0f;


            var elem = (DataFrame)this.Element;

            Layer.CornerRadius = (float)elem.CornerRadius;
            Layer.BackgroundColor = new CGColor(0,0,0,0);

            // Update shadow to match better material design standards of elevation
            Layer.ShadowRadius = 2.0f;
            Layer.ShadowColor = UIColor.Gray.CGColor;
            Layer.ShadowOffset = new CGSize(0.5, 1);
            Layer.ShadowOpacity = 0.50f;
            //Layer.ShadowPath = UIBezierPath.FromRect(Layer.Bounds).CGPath;
            Layer.MasksToBounds = true;


        }*/
        protected override void OnElementChanged(ElementChangedEventArgs<Xamarin.Forms.Frame> e)
        {
            Layer.ShadowRadius = 2.0f;
            Layer.ShadowColor = UIColor.Gray.CGColor;
            Layer.ShadowOffset = new CGSize(0.5, 1);
            Layer.ShadowOpacity = 0.50f;
        }

        /*
        protected override void OnElementChanged(ElementChangedEventArgs<Xamarin.Forms.Frame> e)
        {
            base.OnElementChanged(e);
            var elem = (BorderViewContainer)this.Element;
            if (elem != null)
            {

                // Border
                this.Layer.CornerRadius = (float)elem.CornerRadius;
                this.Layer.Bounds.Inset((int)elem.BorderThickness, (int)elem.BorderThickness);
                Layer.BorderColor = elem.BorderColor.ToCGColor();
                Layer.BorderWidth = (float)elem.BorderThickness;

                // Shadow
                this.Layer.ShadowColor = UIColor.DarkGray.CGColor;
                this.Layer.ShadowOpacity = 0.6f;
                this.Layer.ShadowRadius = 2.0f;
                this.Layer.ShadowOffset = new SizeF(0, 0);
                //this.Layer.MasksToBounds = true;

            }
        }
        */
    }
}