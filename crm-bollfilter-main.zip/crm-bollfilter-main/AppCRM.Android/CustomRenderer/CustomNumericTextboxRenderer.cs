﻿using System;
using Android.Widget;
using AppCRM.Droid.CustomRenderer;
using WFramework_Xamarin.Components;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using static Java.Util.ResourceBundle;

[assembly: ExportRenderer(typeof(NumericTextBox), typeof(CustomNumericTextboxRenderer))]
namespace AppCRM.Droid.CustomRenderer
{
    public class CustomNumericTextboxRenderer : EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            var native = Control as EditText;

            native.InputType = Android.Text.InputTypes.ClassNumber | Android.Text.InputTypes.NumberFlagSigned | Android.Text.InputTypes.NumberFlagDecimal;
        }
    }
}