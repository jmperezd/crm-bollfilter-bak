﻿using System;
using Android.Content;
using WFramework_Xamarin;
using Android.Support.V4.Content;
using Xamarin.Forms.Platform.Android;
using Android.Widget;
using System.Drawing;
using System.Net;
using Xamarin.Forms;
using System.Threading.Tasks;
using Android.OS;
using Google.Apis.Drive.v3.Data;
using System.IO;
using Android;
using Android.Support.V4.App;

[assembly: Xamarin.Forms.Dependency(typeof(AppCRM.Droid.IntentHelper_Android))]
namespace AppCRM.Droid
{
    public class IntentHelper_Android : IIntentHelper
    {
        public IntentHelper_Android()
        {
        }

		public void File(byte[] data)
		{
            try
            {
                string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                //string documentsPath = (string)Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).Path;
                string localFilename = $"abasReport.pdf";
                string filePath = Path.Combine(documentsPath, localFilename);
                System.IO.File.WriteAllBytes(filePath, data);

                var localFile = new Java.IO.File(filePath);
                var uri = FileProvider.GetUriForFile(MainActivity.Current, MainActivity.Current.ApplicationContext.PackageName + ".fileprovider", localFile);
                var extension = filePath.Substring(filePath.LastIndexOf(".", StringComparison.InvariantCultureIgnoreCase) + 1).ToLower();
                string contentType;
                switch (extension)
                {
                    case "pdf":
                        contentType = "application/pdf";
                        break;
                    case "png":
                        contentType = "image/png";
                        break;
                    default:
                        contentType = "application/octetstream";
                        break;
                }
                Intent intent = new Intent(Intent.ActionView);
                intent.SetFlags(ActivityFlags.ClearWhenTaskReset | ActivityFlags.NewTask);
                intent.AddFlags(ActivityFlags.GrantReadUriPermission);
                intent.SetDataAndType(uri, contentType);
                MainActivity.Current.StartActivity(intent);

            }
            catch (Exception e)
            {
                Toast.MakeText(Xamarin.Forms.Forms.Context, e.Message, ToastLength.Short).Show();
            }
        }


        


        public void SetPermissions()
        {
            if (ActivityCompat.CheckSelfPermission(MainActivity.Current, Manifest.Permission.WriteExternalStorage) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(MainActivity.Current, new String[] { Manifest.Permission.WriteExternalStorage, Manifest.Permission.WriteExternalStorage }, 0);
            }

            if (ActivityCompat.CheckSelfPermission(MainActivity.Current, Manifest.Permission.ReadExternalStorage) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(MainActivity.Current, new String[] { Manifest.Permission.ReadExternalStorage, Manifest.Permission.ReadExternalStorage }, 0);
            }
        }

        public void File(string filePath)
        {
            try
            {               
                var localFile = new Java.IO.File(filePath);
                var uri = FileProvider.GetUriForFile(MainActivity.Current, "abas.fileprovider", localFile);
                var extension = filePath.Substring(filePath.LastIndexOf(".", StringComparison.InvariantCultureIgnoreCase) + 1).ToLower();
                string contentType;
                switch (extension)
                {
                    case "pdf":
                        contentType = "application/pdf";
                        break;
                    case "png":
                        contentType = "image/png";
                        break;
                    default:
                        contentType = "application/octetstream";
                        break;
                }
                Intent intent = new Intent(Intent.ActionView);
                intent.SetFlags(ActivityFlags.ClearWhenTaskReset | ActivityFlags.NewTask);
                intent.AddFlags(ActivityFlags.GrantReadUriPermission);
                intent.SetDataAndType(uri, contentType);
                MainActivity.Current.StartActivity(intent);

            }
            catch (Exception e)
            {
                Toast.MakeText(Xamarin.Forms.Forms.Context, e.Message, ToastLength.Short).Show();
            }
        }
    }
}
