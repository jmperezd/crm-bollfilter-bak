﻿using Android.Widget;
using AppCRM.Droid.Services;
using AppCRM.Services;

[assembly: Xamarin.Forms.Dependency(typeof(MessageAndroid))]
namespace AppCRM.Droid.Services
{
    public class MessageAndroid : IMessage
    {
        public void LongAlert(string message)
        {
            Toast.MakeText(MainActivity.Current, message, ToastLength.Long).Show();
        }

        public void ShortAlert(string message)
        {
            Toast.MakeText(MainActivity.Current, message, ToastLength.Short).Show();
        }
    }
}