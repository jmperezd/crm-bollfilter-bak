﻿using System;
using TK.CustomMap;
using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using AppCRM;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using Xamarin.Forms;
using Android.Support.V4.Content;
using Android;
using Android.Support.V4.App;
using AppCRM.Views;

namespace AppCRM.Droid
{
    [Activity(Label = "CRM-Standard", Icon = "@drawable/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation, ScreenOrientation = ScreenOrientation.Portrait)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {

        public static MainActivity Current = null;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            Current = this;
            Plugin.CurrentActivity.CrossCurrentActivity.Current.Activity = this;

            //allowing the device to change the screen orientation based on the rotation 
            MessagingCenter.Subscribe<MainMenuPage>(this, "AllowLandscape", sender =>{ RequestedOrientation = ScreenOrientation.Landscape; });

            //during page close setting back to portrait
            MessagingCenter.Subscribe<MainMenuPage>(this, "PreventLandscape", sender =>{ RequestedOrientation = ScreenOrientation.Portrait; });

            //allowing the device to change the screen orientation based on the rotation 
            MessagingCenter.Subscribe<CustomerTurnover>(this, "AllowLandscape", sender =>{ RequestedOrientation = ScreenOrientation.Landscape; });

            //during page close setting back to portrait
            MessagingCenter.Subscribe<CustomerTurnover>(this, "PreventLandscape", sender => { RequestedOrientation = ScreenOrientation.Portrait; });

            //TabLayoutResource = Resource.Layout.Tabbar;
            //ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(savedInstanceState);

            //Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.AccessCoarseLocation) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.AccessCoarseLocation, Manifest.Permission.AccessFineLocation }, 0);
            }

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.Internet) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.Internet, Manifest.Permission.Internet }, 0);
            }

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.WriteExternalStorage) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.WriteExternalStorage, Manifest.Permission.WriteExternalStorage }, 0);
            }

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.ReadExternalStorage) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.ReadExternalStorage, Manifest.Permission.ReadExternalStorage }, 0);                
            }            

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.ReadCalendar) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.ReadCalendar, Manifest.Permission.ReadCalendar }, 0);
            }

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.WriteCalendar) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.WriteCalendar, Manifest.Permission.WriteCalendar }, 0);
            }

            if (ContextCompat.CheckSelfPermission(this, Manifest.Permission.BindNotificationListenerService) != Android.Content.PM.Permission.Granted)
            {
                ActivityCompat.RequestPermissions(this, new String[] { Manifest.Permission.BindNotificationListenerService, Manifest.Permission.BindNotificationListenerService }, 0);
            }

            TK.CustomMap.Droid.TKGoogleMaps.Init(this, savedInstanceState);
            
            LoadApplication(new App());
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);

        }

        //Explicit permission for the Map
        protected override void OnStart()
        {
            base.OnStart();
        }
    }
}

